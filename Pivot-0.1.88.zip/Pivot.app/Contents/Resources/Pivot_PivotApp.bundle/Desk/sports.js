/* Pivot's sports. Each sport is a package of its own (sport-*.js): how the game is played, what the scoreboard
   pop-out shows for it, and anything else only it needs. The rest of Pivot asks here which sports there are,
   and which of them this copy of Pivot can run. */
(function () {
  const PV = window.PV, D = window.PIVOT_DATA;
  const MODS = [];
  /* a sport registers itself: { id, name, codes: { MSOC: "Men's Soccer", … }, rules: { … } or per code, board: { … } } */
  PV.registerSport = function (m) {
    MODS.push(m);
    for (const code of Object.keys(m.codes)) {
      D.SPORTS[code] = D.SPORTS[code] || m.codes[code];
      D.RULES[code] = (m.rules && m.rules[code]) || m.rules;
      D.READY[code] = PV.sportUnlocked(code);
    }
  };
  /* which sports this copy can run. Every sport for now; selling sports one by one will answer here. */
  PV.sportUnlocked = () => true;
  PV.sportReady = code => !!(D.RULES[code] && D.READY[code]);
  /* the package behind a show (or a sport code) */
  PV.sportOf = x => { const code = typeof x === 'string' ? x : x && (x.sport || (x.show && x.show.sport)); return MODS.find(m => code in m.codes) || null; };
  PV.sportsAll = () => MODS.slice();
  /* what the scoreboard pop-out asks of the sport: the score buttons, a line under each score, extra rows in
     each team's panel and extra tools. A sport that doesn't say gets basketball-free defaults. */
  PV.board = sh => Object.assign({ steps: [1], teamLine: () => '', panel: () => '', tools: () => '', start: 'Start', banner: false, feedWord: 'live stats' }, (PV.sportOf(sh) || {}).board || {});
})();
