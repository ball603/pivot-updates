/* Pivot's field-sports kit: what soccer and field hockey share — the starting XI, goals, cards, subs, penalty kicks,
   team stats, player stats and the full-screen numbers. Each sport registers itself (sport-soccer.js, sport-fieldhockey.js). */
(function () {
  const PV = window.PV, D = window.PIVOT_DATA;
  const Eng = PV.Engine.prototype, A = Eng.actions;
  const store = PV.store;
  const field = st => PV.isField(st && st.show);
  const fromFR = st => !!(st && st.show && st.show.game && st.show.game.fr);
  const posShort = PV.posShort, rowOf = PV.liveRow;

  /* the starting XI */
  const oldTake = Eng.buildTake0;
  Eng.buildTake0 = function (side) {
    const g = oldTake.call(this, side);
    if (field(this.st)) {
      g.title = 'Starting XI';
      g.label = `${this.st.show[side].code} starting XI`;
      g.players = g.players.map(p => [p[0], p[1], posShort(p[2])]);
      g.many = g.players.length > 5;
    }
    return g;
  };
  const oldName = PV.gfxName;
  PV.gfxName = (ref, st) => { const n = oldName(ref, st); st = st || (PV.E && PV.E.st); return field(st) ? n.replace('starting five', 'starting XI') : n; };

  /* lower thirds: a field player's season line and this game's numbers */
  const pairs = items => (items || []).filter(([k]) => k !== 'GP').slice(0, 4).map(([k, v]) => [v, k]);
  /* the minute of the match, the way a soccer broadcast gives it: 23' is the 23rd minute */
  PV.matchMinute = st => {
    const sb = st.sb, R = st.show.rules || {}, len = (R.len || 45) * 60000;
    const left = Math.max(0, sb.running ? sb.clock - (Date.now() - sb.at) : sb.clock);
    const p = Math.min(sb.period || 1, R.periods || 2);
    return Math.max(1, Math.floor(((p - 1) * len + (len - left)) / 60000) + 1);
  };
  const initial = (first, last) => [first ? first[0] + '.' : '', last].filter(Boolean).join(' ');
  /* cards: a yellow or red card for a player, and the team playing a player short after a red.
     Each comes off on its own (holds below); any card from this game can be shown again. */
  // a card and a substitution stay up eight seconds; a goal and a team down a player ten
  PV.CARD_HOLD = 8; PV.GOAL_HOLD = 10;
  A['sb.card'] = function (side, num, color, t) {
    const st = this.st, sh = st.show; if (!sh[side] || !['yellow', 'red'].includes(color)) return;
    const p = PV.player(sh, side, num) || [num, '', ''], minute = PV.matchMinute(st);
    if (color === 'red') {
      const reds = sh[side].reds = sh[side].reds || [];
      if (!reds.some(r => r.num === String(num))) reds.push({ num: String(num), first: p[1], last: p[2], minute });
    }
    const cards = sh[side].cards = sh[side].cards || [];
    if (!cards.some(c => c.num === String(num) && c.color === color)) cards.push({ num: String(num), color, minute });
    const L = this.buildLower({ kind: 'card', side, num: String(num), color, minute });
    L.at = t || Date.now(); st.gfx.lower = L;
  };
  // a card from earlier in the game, back up again
  A['sb.recard'] = function (side, i, _c, t) {
    const st = this.st, c = ((st.show[side] || {}).cards || [])[+i]; if (!c) return;
    const L = this.buildLower({ kind: 'card', side, num: c.num, color: c.color, minute: c.minute });
    L.at = t || Date.now(); st.gfx.lower = L;
  };
  A['sb.unred'] = function (side, num) { const t = this.st.show[side]; if (t && t.reds) t.reds = t.reds.filter(r => r.num !== String(num)); };
  // back to full strength: the team's red cards no longer count against it (the cards themselves stay in the game's list)
  A['sb.full'] = function (side) {
    const st = this.st, t = st.show[side]; if (!t) return;
    t.reds = [];
    const L = st.gfx.lower; if (L && L.down && L.side === side) st.gfx.lower = null;
  };
  /* a goal: who scored it, shown for ten seconds (the scorer's goals this season with the minute, as ESPN's 9000 has it) */
  A['sb.goal'] = function (side, num, _c, t) {
    const st = this.st, sh = st.show; if (!sh[side]) return;
    const goals = sh[side].goals = sh[side].goals || [];
    goals.push({ num: String(num), minute: PV.matchMinute(st) });
    const L = this.buildLower({ kind: 'goal', side, num: String(num) });
    L.at = t || Date.now(); st.gfx.lower = L;
  };
  // the substitution box: who came on and who went off (a second one while the first is up joins it, four rows at most)
  Eng.subObj = function (side, inNum, outNum, t, join) {
    const st = this.st, sh = st.show, g = st.gfx;
    const nm = n => { const p = PV.player(sh, side, n) || [n, '', '']; return { num: String(p[0]), name: `${p[1]} ${p[2]}`.trim() }; };
    const pair = [Object.assign(nm(inNum), { io: 'IN' }), Object.assign(nm(outNum), { io: 'OUT' })];
    const now0 = t || Date.now();
    const cur = join && g.take && g.take.kind === 'subs' && g.take.side === side && now0 - g.take.at < PV.CARD_HOLD * 1000 ? g.take.rows : [];
    const rows = cur.concat(pair).slice(-4);
    return { id: 'sb' + now0, kind: 'subs', side, label: `${sh[side].code} substitution`, title: 'Substitutions', rows,
      players: rows.map(r => [r.num, r.name, r.io]), at: now0, hold: PV.CARD_HOLD };
  };
  A['sb.sub'] = function (side, inNum, outNum, t) {
    if (!this.st.show[side]) return;
    const o = this.subObj(side, inNum, outNum, t, true);
    for (const k of PV.SHOT_SLOTS) if (k !== 'take') this.st.gfx[k] = null;
    o.withBug = !!this.st.gfx.scorebug;
    this.st.gfx.take = o;
  };
  // a substitution waiting in Preview, to go with the next Take (or a double-click)
  A['sb.subPv'] = function (side, inNum, outNum) {
    const st = this.st; if (!st.show[side]) return;
    const obj = this.subObj(side, inNum, outNum, Date.now(), false);
    // one graphic at a time in a shot: it replaces a full page, lower third or takeover already there
    st.pv.gfx = st.pv.gfx.filter(x => !PV.SHOT_SLOTS.includes(PV.slotOf(x)));
    st.pv.gfx.push({ t: 'raw', slot: 'take', obj });
    this.buildPv();
  };
  /* penalty kicks: the shootout, kick by kick (G scored, X missed), shown in place of the scorebug while it's on */
  A['sb.pk'] = function (on) {
    const sh = this.st.show;
    sh.pk = Object.assign({ away: [], home: [] }, sh.pk, { on: on == null ? !(sh.pk && sh.pk.on) : !!on });
  };
  A['sb.pkKick'] = function (side, made) {
    const sh = this.st.show; if (!sh.pk || !['away', 'home'].includes(side)) return;
    sh.pk[side] = (sh.pk[side] || []).concat([made === true || made === 'true' || made === 1 || made === '1' ? 'G' : 'X']);
  };
  // a kick entered the wrong way round: scored becomes missed, missed becomes scored
  A['sb.pkFlip'] = function (side, i) { const sh = this.st.show, L = sh.pk && sh.pk[side]; i = +i; if (!L || !L[i]) return; L[i] = L[i] === 'G' ? 'X' : 'G'; };
  A['sb.pkUndo'] = function (side) { const sh = this.st.show; if (sh.pk && sh.pk[side]) sh.pk[side] = sh.pk[side].slice(0, -1); };
  /* team stats side by side: one (Corner kicks: 4 and 7) or several in columns. Numbers come from the live stats,
     or from what the operator typed (kept for the game) */
  PV.SOCCER_STATS = ['Shots', 'Shots on goal', 'Corner kicks', 'Fouls', 'Saves', 'Offsides'];
  const LIVE_STAT = { 'Shots': ['Shots', 'Sh'], 'Shots on goal': ['SOG', 'Shots on goal'], 'Corner kicks': ['Corners', 'Corner kicks', 'CK'], 'Fouls': ['Fouls'], 'Saves': ['Saves'], 'Offsides': ['Offsides'] };
  PV.teamStat = function (st, label, side) {
    const typed = ((st.show.comps || {})[label] || {})[side];
    if (typed != null && typed !== '') return String(typed);
    const T = (st.live || {}).totals || {}, names = LIVE_STAT[label] || [label];
    const row = (T[side] || []).find(x => names.some(n => String(x[0]).trim().toLowerCase() === n.toLowerCase()));
    return row && row[1] != null ? String(row[1]) : '0';
  };
  A['sb.comps'] = function (vals) { const sh = this.st.show; sh.comps = Object.assign({}, sh.comps, vals || {}); };

  /* soccer and field hockey player stats: this game's from the live stats (a keeper's from the goalkeeping table),
     the season's from NEC Front Row (its keeper line is "In goal") */
  const FIELD_GAME = {
    g: ['G', 'Goals', 'player', 'G'], a: ['A', 'Assists', 'player', 'A'], pts: ['PTS', 'Points', 'player', 'Pts'], sh: ['SH', 'Shots', 'player', 'Sh'],
    sog: ['SOG', 'Shots on goal', 'player', 'SOG'], min: ['MIN', 'Minutes', 'player', 'Min'], sv: ['SV', 'Saves', 'keeper', 'Saves'], ga: ['GA', 'Goals against', 'keeper', 'GA']
  };
  const FIELD_SEASON = {
    gp: ['GP', 'Games played'], g: ['G', 'Goals'], a: ['A', 'Assists'], pts: ['PTS', 'Points'], sh: ['SH', 'Shots'], gw: ['GW', 'Game-winning goals'],
    gaa: ['GAA', 'Goals against average'], svp: ['SV%', 'Save percentage'], sv: ['SV', 'Saves'], sho: ['SHO', 'Shutouts']
  };
  const isKeeper = (sh, side, num) => posShort((PV.player(sh, side, num) || [])[3]) === 'GK';
  const seasonItem = (t, num, abbr) => { for (const l of (t.frLines || {})[String(num)] || []) { const it = (l.items || []).find(([k]) => k === abbr); if (it) return it[1]; } return null; };
  /* the stats a player's lower third can show, for this sport: { list: key -> [abbreviation, name], pick: the default three } */
  PV.statLists = function (st, side, num, mode) {
    const sh = st.show;
    if (!field(st)) {
      const L = mode === 'game' ? PV.GAME_STATS : PV.SEASON_STATS, out = {};
      for (const k in L) out[k] = [L[k][0], L[k][2] || L[k][0]];
      return { list: out, pick: mode === 'game' ? ['pts', 'tp', 'ast'] : ['ppg', 'rpg', 'apg'], has: k => mode === 'game' || Object.values(sh[side].pstats || {}).some(ss => PV.seasonVal(ss, k) != null) };
    }
    const L = mode === 'game' ? FIELD_GAME : FIELD_SEASON, out = {};
    for (const k in L) out[k] = [L[k][0], L[k][1]];
    const gk = num != null && isKeeper(sh, side, num);
    const pick = mode === 'game' ? (gk ? ['sv', 'ga', 'min'] : ['g', 'a', 'sh']) : (gk ? ['gaa', 'svp', 'sho'] : ['g', 'a', 'pts']);
    // a season stat is offered when someone on the team has it on file
    const has = k => mode === 'game' || Object.keys(sh[side].frLines || {}).some(n => seasonItem(sh[side], n, L[k][0]) != null);
    return { list: out, pick, has };
  };
  PV.fieldGameVal = (st, side, num, k) => {
    const d = FIELD_GAME[k]; if (!d) return null;
    const g = rowOf(st, side, num), o = d[2] === 'keeper' ? g.keeper : g.player; if (!o) return null;
    const i = o.cols.indexOf(d[3]); return i >= 0 && o.r[i] != null && o.r[i] !== '' ? String(o.r[i]) : null;
  };
  PV.fieldSeasonVal = (t, num, k) => { const d = FIELD_SEASON[k]; return d ? seasonItem(t, num, d[0]) : null; };

  const oldLower = Eng.buildLower0;
  Eng.buildLower0 = function (spec) {
    const st0 = this.st, sh0 = st0.show;
    if (spec.kind === 'card') {
      const L = Object.assign(oldLower.call(this, { kind: 'bio', side: spec.side, num: spec.num }), { kind: 'player' });
      const word = spec.color === 'red' ? 'Red' : 'Yellow';
      return Object.assign(L, { key: 'card' + spec.side + spec.num + spec.color, card: spec.color, label: `${word} card · ${L.label}`, sub: `${word} card`, stats: [], minute: spec.minute || PV.matchMinute(st0), hold: PV.CARD_HOLD });
    }
    if (spec.kind === 'goal') {
      const L = Object.assign(oldLower.call(this, { kind: 'bio', side: spec.side, num: spec.num }), { kind: 'player' });
      const t = sh0[spec.side], mine = (t.goals || []).filter(x => x.num === String(spec.num)), last = mine[mine.length - 1] || { minute: PV.matchMinute(st0) };
      // the season's goals coming into the game, plus this game's: the ones entered here, or the live stats' count if it has more
      const gs = seasonItem(t, spec.num, 'G'), g0 = gs == null ? NaN : +gs;
      const live = +(PV.fieldGameVal(st0, spec.side, spec.num, 'g') || 0), today = Math.max(mine.length, live);
      const n = (isNaN(g0) ? 0 : g0) + today;
      const sub = isNaN(g0) ? `${PV.ordinal(mine.length || 1)} goal of the game (${last.minute}')` : `${PV.ordinal(n)} goal this season (${last.minute}')`;
      return Object.assign(L, { key: 'goal' + spec.side + spec.num + mine.length, goal: { n, minute: last.minute }, label: `Goal · ${L.label}`, sub, stats: [], hold: PV.GOAL_HOLD });
    }
    if (spec.kind === 'comps') {
      const picks = (spec.picks || []).slice(0, 6), sh = sh0;
      const rows = picks.map(l => [l, PV.teamStat(st0, l, 'away'), PV.teamStat(st0, l, 'home')]);
      const title = rows.length === 1 ? rows[0][0] : 'Team Stats';
      return { id: 'tc' + Date.now(), kind: 'team', key: 'comps' + picks.join('|'), side: 'home', label: `Team stats · ${picks.join(', ')}`, title,
        sub: rows.map(r => `${r[0]}: ${sh.away.code} ${r[1]}, ${sh.home.code} ${r[2]}`).join(' · '), comps: rows };
    }
    if (spec.kind === 'weather' || spec.kind === 'officials') {
      // drawn as a lower third (or a tab from the scorebug) by a look that asks for it
      const F = this.buildFull0(spec.kind) || { rows: [] };
      return Object.assign({}, F, { id: spec.kind.slice(0, 2) + Date.now(), kind: spec.kind, key: spec.kind, side: 'home', full: F });
    }
    if (spec.kind === 'down') {
      const t = sh0[spec.side], reds = t.reds || [], n = 11 - reds.length, last = reds[reds.length - 1];
      const who = last ? `${initial(last.first, last.last)} (Red Card) ${last.minute}'` : '';
      return { id: 'dn' + Date.now(), kind: 'team', key: 'down' + spec.side + n, side: spec.side, label: `${t.code} down to ${n}`, title: `Down to ${n}`, sub: who, down: { n, who }, hold: PV.GOAL_HOLD };
    }
    const L = oldLower.call(this, spec);
    const st = this.st; if (!L || !['season', 'game'].includes(spec.kind)) return L;
    const t = st.show[spec.side], num = String(L.num);
    // Front Row's season line, for any sport, when it has one for this player
    if (spec.kind === 'season' && !field(st) && !((t.frLines || {})[num])) return L;
    if (spec.kind === 'game' && !field(st)) return L;   // basketball: the live box score comes through statFor
    if (field(st)) {
      // the three the operator picked for this player (or the sport's own three), in that order
      const S = PV.statLists(st, spec.side, num, spec.kind), pick = (st.l3pick[PV.l3key(spec.side, num, spec.kind)] || S.pick).filter(k => S.list[k]);
      if (spec.kind === 'season') {
        L.stats = pick.map(k => [PV.fieldSeasonVal(t, num, k), S.list[k][0]]).filter(x => x[0] != null && x[0] !== '');
        L.sub = L.stats.length ? 'This season' : 'No season stats yet';
      } else {
        L.stats = st.live ? pick.map(k => [PV.fieldGameVal(st, spec.side, num, k) ?? '0', S.list[k][0]]) : [];
        L.sub = st.live ? PV.todayWord(st.show) : 'Waiting for live stats';
      }
      return L;
    }
    if (spec.kind === 'season') {
      const lines = (t.frLines || {})[num] || [];
      const line = lines[0];
      L.sub = line ? (line.title ? `${line.title} · this season` : 'This season') : 'No season stats yet';
      L.stats = line ? pairs(line.items) : [];
    }
    return L;
  };

  /* full-screen graphics with soccer and field hockey numbers in them (on top of what Front Row fills in for every sport) */
  const liveBest = PV.liveBest;
  const oldLeaders = Eng.leaders;
  Eng.leaders = function (side) {
    if (!field(this.st)) return oldLeaders.call(this, side);
    return [liveBest(this.st, side, 'G', 'G'), liveBest(this.st, side, 'A', 'A'), liveBest(this.st, side, 'Saves', 'SV')];
  };
  const oldFull = Eng.buildFull0;
  Eng.buildFull0 = function (kind, opts) {
    const st = this.st, sh = st.show;
    if (!field(st)) return oldFull.call(this, kind, opts);
    if (kind === 'standings' && !(sh.frStand && sh.frStand.rows.length)) {
      // the league table for these sports isn't in Pivot yet: the two teams' records instead
      return { id: 'rc' + Date.now(), kind: 'list', label: 'Records', title: 'Season Records', kicker: sh.event,
        rows: ['away', 'home'].map(s => [sh[s].name, [sh[s].rec && `${sh[s].rec} overall`, sh[s].conf && `${sh[s].conf} NEC`].filter(Boolean).join(' · ') || '—']) };
    }
    const F = oldFull.call(this, kind, opts);
    if (!F) return F;
    const cell = x => ({ v: parseFloat(x) || 0, t: x == null || x === '' ? '—' : String(x) });
    if (kind === 'featAway' || kind === 'featHome') {
      const side = kind === 'featAway' ? 'away' : 'home', line = ((sh[side].frLines || {})[String(F.num)] || [])[0];
      if (!line) { F.stats = []; F.note = 'No season stats yet'; }
    } else if (kind === 'tapeSeason' && !(sh.away.tape || []).concat(sh.home.tape || []).length) {
      // before NEC Front Row has the season's numbers: the lines it will fill, empty
      F.kicker = 'Season'; F.note = `Entering ${PV.todayWord(sh).toLowerCase()}'s action`;
      F.rows = [['Record', cell(sh.away.rec || '—'), cell(sh.home.rec || '—')]].concat(['Goals per game', 'Shots per game', 'Goals allowed per game', 'Save percentage'].map(l => [l, cell(null), cell(null)]));
    } else if (kind === 'tape') {
      // this game's team numbers, five lines: the same ones the Team stats graphic reads (live stats, or typed in)
      F.kicker = 'Game stats';
      F.rows = PV.SOCCER_STATS.slice(0, 5).map(l => [l, cell(PV.teamStat(st, l, 'away')), cell(PV.teamStat(st, l, 'home'))]);
    } else if (kind === 'gameLeaders') {
      const L = (s, c, u) => liveBest(st, s, c, u), r = (label, a, h) => [label, `${a.name} · ${a.v}`, `${h.name} · ${h.v}`];
      F.rows = [r('Goals', L('away', 'G', 'G'), L('home', 'G', 'G')), r('Assists', L('away', 'A', 'A'), L('home', 'A', 'A')), r('Shots', L('away', 'Sh', 'SH'), L('home', 'Sh', 'SH')), r('Saves', L('away', 'Saves', 'SV'), L('home', 'Saves', 'SV'))];
    }
    return F;
  };


  /* the rundown: no media timeouts; kickoff instead of tip-off */
  const oldRd = PV.buildRundown;
  PV.buildRundown = function (show) {
    const out = oldRd(show);
    if (!PV.isField(show)) return out;
    const start = show.sport === 'FH' ? 'Opening' : 'Kickoff';
    for (const it of out) {
      if (it.seg === 'Tip-off') it.seg = start;
      if (it.label === 'Tip-off') it.label = start;
      it.label = it.label.replace('starting five', 'starting XI');
      if (it.sub === 'Scorebug takeover') it.sub = 'Full lineup';
    }
    return out;
  };

})();
