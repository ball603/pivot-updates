/* Pivot sample feeds: a simulated game, four camera angles, canned video, audio levels.
   Everything is a pure function of game-world time, so any window can draw any moment,
   which is what lets instant replay show the exact play again. */
(function () {
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, u) => a + (b - a) * u;
  const smooth = u => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hash(n) { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); }
  function noise(x) { const i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f); return lerp(hash(i), hash(i + 1), u); }
  function strSeed(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

  /* ---------- color helpers ---------- */
  function hexRgb(h) { h = (h || '#888').replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function lum(h) { const c = hexRgb(h).map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
  function inkOn(h) { return lum(h) > 0.36 ? '#0b0f14' : '#ffffff'; }
  function shade(h, k) { const c = hexRgb(h); const f = v => clamp(Math.round(k > 0 ? v + (255 - v) * k : v * (1 + k)), 0, 255); return `rgb(${f(c[0])},${f(c[1])},${f(c[2])})`; }
  function rgba(h, a) { const c = hexRgb(h); return `rgba(${c[0]},${c[1]},${c[2]},${a})`; }
  function colorDist(a, b) { const x = hexRgb(a), y = hexRgb(b); return Math.sqrt((x[0] - y[0]) ** 2 + (x[1] - y[1]) ** 2 + (x[2] - y[2]) ** 2); }
  /* Away team switches to its second color when the two primaries are too close to tell apart */
  function teamColors(home, away) {
    let a = away.color, h = home.color;
    if (colorDist(a, h) < 90) a = away.accent && colorDist(away.accent, h) >= 90 ? away.accent : (lum(h) > 0.3 ? '#1b1f27' : '#f2f2f2');
    return { home: h, away: a };
  }

  /* ---------- the simulated game ---------- */
  const COURT_L = 94, COURT_W = 50;
  const BASKET = { home: 88.75, away: 5.25 };       // basket each side ATTACKS
  const ROLE_SET = [[24, 25], [19, 7], [19, 43], [9, 13], [9, 37]];

  function makeGame(homeKey, awayKey) {
    const R = rng(strSeed(homeKey + '|' + awayKey));
    const P = [];
    let t = 0, off = R() < 0.5 ? 'home' : 'away';
    function gen(until) {
      while (t < until) {
        const i = P.length;
        const len = 9 + R() * 13;
        const t0 = t, t1 = t + len;
        const turnover = R() < 0.12;
        const three = !turnover && R() < 0.36;
        const made = !turnover && R() < (three ? 0.36 : 0.53);
        const shooter = three ? Math.floor(R() * 3) : 3 + Math.floor(R() * 2);
        const shotStart = t1 - 1.5, shotEnd = t1 - 0.45;
        const handlers = [{ t: t0, role: 0 }];
        let ht = t0 + 3.4 + R() * 1.2, last = 0;
        while (ht < shotStart - 1.0) {
          let r; do { r = Math.floor(R() * 5); } while (r === last);
          handlers.push({ t: ht, role: r }); last = r; ht += 1.8 + R() * 1.4;
        }
        if (!turnover && last !== shooter) handlers.push({ t: Math.max(handlers[handlers.length - 1].t + 0.9, shotStart - 0.85), role: shooter });
        let ast = null;
        if (made) { const prev = handlers.length > 1 ? handlers[handlers.length - 2].role : null; if (prev != null && prev !== shooter && R() < 0.7) ast = prev; }
        const rebSide = made ? null : (R() < 0.72 ? (off === 'home' ? 'away' : 'home') : off);
        const rebRole = 3 + Math.floor(R() * 2);
        const stealRole = Math.floor(R() * 5);
        const missX = (R() - 0.5) * 2, missY = (R() - 0.5) * 2;
        P.push({ i, t0, t1, off, turnover, three, made, shooter, shotStart, shotEnd, handlers, ast, rebSide, rebRole, stealRole, missX, missY, j: R() * 10 });
        t = t1;
        off = turnover || made || rebSide !== off ? (off === 'home' ? 'away' : 'home') : off;
      }
    }
    function find(T) {
      if (T < 0) T = 0;
      gen(T + 30);
      let lo = 0, hi = P.length - 1;
      while (lo < hi) { const m = (lo + hi + 1) >> 1; if (P[m].t0 <= T) lo = m; else hi = m - 1; }
      return P[lo];
    }
    function setPos(p, side, role, T) {
      const offense = p.off === side;
      const atk = offense ? side : p.off;               // basket being attacked in this possession
      const bx = BASKET[atk], dir = bx > 47 ? -1 : 1;
      const rs = ROLE_SET[role];
      let dx = rs[0] + Math.sin(T * 0.9 + role * 1.7 + p.j) * 2.6;
      let y = rs[1] + Math.cos(T * 0.7 + role * 2.3 + p.j * 0.5) * 3.6;
      if (offense && !p.turnover && role === p.shooter && T > p.shotStart - 2.5) {
        const k = smooth((T - (p.shotStart - 2.5)) / 1.6);
        if (!p.three) { dx = lerp(dx, 6, k); y = lerp(y, 25 + (role === 3 ? -5 : 5), k); }
      }
      const ox = bx + dir * dx, oy = y;
      if (offense) return [ox, oy];
      return [lerp(ox, bx, 0.3) + dir * 0.6, lerp(oy, 25, 0.15) + (role % 2 ? 1 : -1)];
    }
    function playerPos(side, role, T) {
      const p = find(T);
      const cur = setPos(p, side, role, T);
      if (p.i === 0 || T - p.t0 > 3.4) return cur;
      const prev = P[p.i - 1];
      const from = setPos(prev, side, role, p.t0);
      const k = smooth((T - p.t0) / 3.4);
      return [lerp(from[0], cur[0], k), lerp(from[1], cur[1], k)];
    }
    function handlerAt(p, T) { let h = p.handlers[0], prev = null; for (const x of p.handlers) { if (x.t <= T) { prev = h; h = x; } } return { h, prev }; }
    function ballPos(T) {
      const p = find(T);
      const bx = BASKET[p.off], dir = bx > 47 ? -1 : 1;
      if (p.turnover && T > p.t1 - 1.1) {
        const def = p.off === 'home' ? 'away' : 'home';
        const a = handPos(p.off, handlerAt(p, p.t1 - 1.1).h.role, p.t1 - 1.1);
        const b = playerPos(def, p.stealRole, T);
        const u = smooth((T - (p.t1 - 1.1)) / 0.5);
        return [lerp(a[0], b[0], u), lerp(a[1], b[1], u), u < 1 ? 3 + Math.sin(u * Math.PI) * 2 : 1 + Math.abs(Math.sin(T * 9)) * 2.2];
      }
      if (!p.turnover && T >= p.shotStart) {
        const s = handPos(p.off, p.shooter, p.shotStart);
        if (T < p.shotEnd) {
          const u = (T - p.shotStart) / (p.shotEnd - p.shotStart);
          const z0 = 7.6, z1 = 10.2, peak = p.three ? 17 : 14.5;
          const z = lerp(z0, z1, u) + 4 * (peak - (z0 + z1) / 2) * u * (1 - u);
          return [lerp(s[0], bx, u), lerp(s[1], 25, u), z];
        }
        const d = T - p.shotEnd;
        if (p.made) {
          if (d < 0.35) return [bx, 25, lerp(10, 0.8, d / 0.35)];
          return [bx + dir * Math.min(3, d * 2), 25 + d * 1.5, 0.4 + Math.abs(Math.sin(d * 7)) * 1.6 * Math.exp(-d * 2)];
        }
        const rx = bx + dir * (6 + p.missX * 3), ry = 25 + p.missY * 9;
        const u = clamp(d / 0.45, 0, 1);
        return [lerp(bx, rx, u), lerp(25, ry, u), lerp(10.5, 7, u) + Math.sin(u * Math.PI) * 4];
      }
      const { h, prev } = handlerAt(p, T);
      const hp = handPos(p.off, h.role, T);
      if (prev && T - h.t < 0.45) {
        const a = handPos(p.off, prev.role, h.t), u = (T - h.t) / 0.45;
        return [lerp(a[0], hp[0], u), lerp(a[1], hp[1], u), 4 + Math.sin(u * Math.PI) * 2.5];
      }
      return [hp[0], hp[1], 1 + Math.abs(Math.sin(T * 8.5)) * 2.3];
    }
    function handPos(side, role, T) {
      const q = playerPos(side, role, T);
      const bx = BASKET[side];
      return [q[0] + (bx > q[0] ? 1 : -1) * 0.9, q[1] + 0.6];
    }
    /* Scoring events between two moments, in time order */
    function events(fromT, toT) {
      if (toT <= fromT) return [];
      gen(toT + 30);
      const out = [];
      for (const p of P) {
        if (p.t1 < fromT - 30) continue;
        if (p.t0 > toT) break;
        if (p.turnover) { if (p.t1 > fromT && p.t1 <= toT) out.push({ t: p.t1, kind: 'to', side: p.off, role: p.handlers[p.handlers.length - 1].role, stealSide: p.off === 'home' ? 'away' : 'home', stealRole: p.stealRole }); continue; }
        if (p.shotEnd > fromT && p.shotEnd <= toT) out.push({ t: p.shotEnd, kind: 'shot', side: p.off, role: p.shooter, three: p.three, made: p.made, ast: p.ast, rebSide: p.rebSide, rebRole: p.rebRole });
      }
      return out;
    }
    function excite(T) {
      let e = 0;
      for (const ev of events(T - 6, T)) if (ev.kind === 'shot' && ev.made) e = Math.max(e, Math.exp(-(T - ev.t) / 1.6) * (ev.three ? 1 : 0.75));
      return e;
    }
    function ballSmoothX(T, span) { let s = 0; const n = 7; for (let k = 0; k < n; k++) s += ballPos(T - (k / (n - 1)) * span)[0]; return s / n; }
    function ballSmooth(T, span) { let x = 0, y = 0; const n = 6; for (let k = 0; k < n; k++) { const b = ballPos(T - (k / (n - 1)) * span); x += b[0]; y += b[1]; } return [x / n, y / n]; }
    return { find, playerPos, ballPos, events, excite, ballSmoothX, ballSmooth, possessions: P };
  }

  /* ---------- cameras ---------- */
  const CAMS = {
    cam1: { name: 'Wide', desc: 'High center, follows play', view: (g, T) => { const bx = g.ballSmoothX(T, 1.4); return { pos: [47, -48, 31], tgt: [47 + (bx - 47) * 0.82, 25, 0], fov: 50 }; } },
    cam2: { name: 'Tight', desc: 'Follows the ball', view: (g, T) => { const b = g.ballSmooth(T, 0.55); return { pos: [47 + Math.sin(T * 1.3) * 0.25, -34, 13 + Math.sin(T * 1.9) * 0.15], tgt: [b[0], b[1], 4.2], fov: 15 }; } },
    cam3: { name: 'Baseline', desc: 'East baseline, low', view: (g, T) => { const b = g.ballSmooth(T, 1.2); return { pos: [100, 41, 6], tgt: [lerp(72, b[0], 0.35), lerp(24, b[1], 0.3), 5.5], fov: 62 }; } },
    cam4: { name: 'Reverse', desc: 'High corner, far side', view: (g, T) => { const bx = g.ballSmoothX(T, 1.6); return { pos: [-5, 62, 27], tgt: [lerp(36, bx, 0.6), 22, 0], fov: 56 }; } }
  };

  function camera(v, w, h) {
    const f = norm(sub(v.tgt, v.pos));
    let r = norm(cross(f, [0, 0, 1]));
    const u = cross(r, f);
    const focal = (w / 2) / Math.tan((v.fov * Math.PI / 180) / 2);
    return function (p) {
      const d = sub(p, v.pos);
      const z = dot(d, f);
      if (z < 0.5) return null;
      return [w / 2 + dot(d, r) / z * focal, h / 2 - dot(d, u) / z * focal, z, focal / z];
    };
  }
  function sub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function norm(a) { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }

  /* crowd seats, built once */
  const SEATS = (function () {
    const s = [];
    for (let k = 0; k < 9; k++) {
      for (let x = -12; x <= 106; x += 2.4) { s.push([x, -9 - k * 2.6, 1.2 + k * 1.9, hash(x * 7 + k)]); s.push([x, 59 + k * 2.6, 1.2 + k * 1.9, hash(x * 3 + k + 50)]); }
      for (let y = -6; y <= 56; y += 2.4) { s.push([-10 - k * 2.6, y, 1.2 + k * 1.9, hash(y * 5 + k + 90)]); s.push([104 + k * 2.6, y, 1.2 + k * 1.9, hash(y * 9 + k + 130)]); }
    }
    return s;
  })();

  function polyline(ctx, P, pts, close) {
    let started = false;
    ctx.beginPath();
    for (const q of pts) { const s = P(q); if (!s) { started = false; continue; } if (!started) { ctx.moveTo(s[0], s[1]); started = true; } else ctx.lineTo(s[0], s[1]); }
    if (close) ctx.closePath();
  }
  function arcPts(cx, cy, r, a0, a1, n) { const o = []; for (let i = 0; i <= n; i++) { const a = lerp(a0, a1, i / n); o.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r, 0]); } return o; }
  function rectPts(x0, y0, x1, y1) { const o = []; const n = 12; for (let i = 0; i <= n; i++) o.push([lerp(x0, x1, i / n), y0, 0]); for (let i = 0; i <= n; i++) o.push([x1, lerp(y0, y1, i / n), 0]); for (let i = 0; i <= n; i++) o.push([lerp(x1, x0, i / n), y1, 0]); for (let i = 0; i <= n; i++) o.push([x0, lerp(y1, y0, i / n), 0]); return o; }

  function drawCamera(ctx, w, h, camId, T, game, look) {
    const cam = CAMS[camId] || CAMS.cam1;
    const P = camera(cam.view(game, T), w, h);
    const lw = Math.max(1, w / 640);
    // arena
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#07090d'); g.addColorStop(0.55, '#121722'); g.addColorStop(1, '#0b0e14');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    // crowd
    const crowdCols = [look.home, look.away, '#7d8796', '#c8ccd2', '#3a414d', look.home];
    for (const s of SEATS) {
      const q = P(s); if (!q || q[0] < -4 || q[0] > w + 4 || q[1] < -4 || q[1] > h + 4) continue;
      const sz = Math.max(1, q[3] * 0.85);
      ctx.fillStyle = crowdCols[Math.floor(s[3] * crowdCols.length)];
      ctx.globalAlpha = 0.32 + s[3] * 0.25;
      ctx.fillRect(q[0] - sz / 2, q[1] - sz, sz, sz * 1.3);
    }
    ctx.globalAlpha = 1;
    // floor
    polyline(ctx, P, rectPts(-7, -7, 101, 57), true);
    ctx.fillStyle = '#7a4f2c'; ctx.fill();
    polyline(ctx, P, rectPts(0, 0, COURT_L, COURT_W), true);
    const wood = ctx.createLinearGradient(0, 0, w, h);
    wood.addColorStop(0, '#d39a62'); wood.addColorStop(1, '#c4874f');
    ctx.fillStyle = wood; ctx.fill();
    // paint and center
    ctx.fillStyle = rgba(look.home, 0.88);
    polyline(ctx, P, rectPts(0, 19, 19, 31), true); ctx.fill();
    polyline(ctx, P, rectPts(75, 19, 94, 31), true); ctx.fill();
    polyline(ctx, P, arcPts(47, 25, 6, 0, TAU, 28), true); ctx.fill();
    // lines
    ctx.strokeStyle = 'rgba(255,255,255,0.92)'; ctx.lineWidth = lw * 1.4; ctx.lineJoin = 'round';
    const lines = [rectPts(0, 0, COURT_L, COURT_W), [[47, 0, 0], [47, 12.5, 0], [47, 25, 0], [47, 37.5, 0], [47, 50, 0]], arcPts(47, 25, 6, 0, TAU, 28),
      rectPts(0, 19, 19, 31), rectPts(75, 19, 94, 31), arcPts(19, 25, 6, -Math.PI / 2, Math.PI / 2, 16), arcPts(75, 25, 6, Math.PI / 2, Math.PI * 1.5, 16)];
    const phi = Math.asin((25 - 3.35) / 22.15), cx3 = 22.15 * Math.cos(phi);
    lines.push([[0, 3.35, 0], [5.25 + cx3, 3.35, 0]].concat(arcPts(5.25, 25, 22.15, -phi, phi, 30)).concat([[5.25 + cx3, 46.65, 0], [0, 46.65, 0]]));
    lines.push([[94, 3.35, 0], [88.75 - cx3, 3.35, 0]].concat(arcPts(88.75, 25, 22.15, Math.PI + phi, Math.PI - phi, 30)).concat([[88.75 - cx3, 46.65, 0], [94, 46.65, 0]]));
    for (const l of lines) { polyline(ctx, P, l, false); ctx.stroke(); }
    // baskets (draw far one first by depth later with players)
    const items = [];
    for (const side of ['home', 'away']) for (let r = 0; r < 5; r++) { const q = game.playerPos(side, r, T); items.push({ kind: 'p', side, role: r, x: q[0], y: q[1] }); }
    items.push({ kind: 'hoop', x: 4, y: 25 }); items.push({ kind: 'hoop', x: 90, y: 25 });
    const b = game.ballPos(T);
    items.push({ kind: 'ball', x: b[0], y: b[1], z: b[2] });
    for (const it of items) { const q = P([it.x, it.y, it.z || 0]); it.d = q ? q[2] : -1; }
    items.sort((a, b2) => b2.d - a.d);
    for (const it of items) {
      if (it.d < 0) continue;
      if (it.kind === 'p') drawPlayer(ctx, P, it, look, lw);
      else if (it.kind === 'hoop') drawHoop(ctx, P, it.x, lw);
      else drawBall(ctx, P, it);
    }
  }
  function drawPlayer(ctx, P, it, look, lw) {
    const feet = P([it.x, it.y, 0]), head = P([it.x, it.y, 6.6]);
    if (!feet || !head) return;
    const hgt = feet[1] - head[1]; if (hgt < 2) return;
    const wd = hgt * 0.3;
    const col = it.side === 'home' ? look.home : look.away;
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.beginPath(); ctx.ellipse(feet[0], feet[1], wd * 0.75, wd * 0.22, 0, 0, TAU); ctx.fill();
    // legs
    ctx.fillStyle = '#20242c';
    ctx.fillRect(feet[0] - wd * 0.32, feet[1] - hgt * 0.42, wd * 0.24, hgt * 0.42);
    ctx.fillRect(feet[0] + wd * 0.08, feet[1] - hgt * 0.42, wd * 0.24, hgt * 0.42);
    // jersey
    ctx.fillStyle = col;
    roundRect(ctx, feet[0] - wd / 2, head[1] + hgt * 0.17, wd, hgt * 0.47, wd * 0.18); ctx.fill();
    ctx.strokeStyle = shade(col, -0.35); ctx.lineWidth = Math.max(0.6, lw * 0.6); ctx.stroke();
    // head
    ctx.fillStyle = '#5b3a29';
    ctx.beginPath(); ctx.arc(feet[0], head[1] + hgt * 0.08, hgt * 0.085, 0, TAU); ctx.fill();
    if (hgt > 26) {
      const team = it.side === 'home' ? look.homeTeam : look.awayTeam;
      const p = look.starters[it.side][it.role];
      ctx.fillStyle = inkOn(col);
      ctx.font = `700 ${Math.round(hgt * 0.17)}px "Barlow Condensed", "Arial Narrow", sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(p ? p[0] : '', feet[0], head[1] + hgt * 0.38);
      void team;
    }
  }
  function drawHoop(ctx, P, x, lw) {
    const dir = x < 47 ? 1 : -1;
    const bb = [[x, 22, 9.5], [x, 28, 9.5], [x, 28, 13], [x, 22, 13]].map(P);
    if (bb.some(q => !q)) return;
    // stanchion
    const s0 = P([x - dir * 4, 25, 0]), s1 = P([x - dir * 4, 25, 11]);
    if (s0 && s1) { ctx.strokeStyle = '#2b3240'; ctx.lineWidth = Math.max(2, s0[3] * 0.9); ctx.beginPath(); ctx.moveTo(s0[0], s0[1]); ctx.lineTo(s1[0], s1[1]); ctx.stroke(); }
    ctx.fillStyle = 'rgba(235,242,250,0.55)'; ctx.strokeStyle = '#f4f6f8'; ctx.lineWidth = lw;
    ctx.beginPath(); bb.forEach((q, i) => i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1])); ctx.closePath(); ctx.fill(); ctx.stroke();
    const rim = arcPts(x + dir * 1.25, 25, 0.75, 0, TAU, 18).map(q => [q[0], q[1], 10]);
    polyline(ctx, P, rim, true); ctx.strokeStyle = '#ff6a1a'; ctx.lineWidth = Math.max(1, lw * 1.6); ctx.stroke();
    const net = P([x + dir * 1.25, 25, 8.6]), rc = P([x + dir * 1.25, 25, 10]);
    if (net && rc) { ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = Math.max(0.6, lw * 0.7); ctx.beginPath(); ctx.moveTo(rc[0] - rc[3] * 0.7, rc[1]); ctx.lineTo(net[0] - net[3] * 0.4, net[1]); ctx.moveTo(rc[0] + rc[3] * 0.7, rc[1]); ctx.lineTo(net[0] + net[3] * 0.4, net[1]); ctx.stroke(); }
  }
  function drawBall(ctx, P, it) {
    const q = P([it.x, it.y, it.z]); if (!q) return;
    const g0 = P([it.x, it.y, 0]);
    const r = Math.max(1.6, q[3] * 0.42);
    if (g0) { ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(g0[0], g0[1], r, r * 0.35, 0, 0, TAU); ctx.fill(); }
    ctx.fillStyle = '#e8732a'; ctx.beginPath(); ctx.arc(q[0], q[1], r, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(40,20,10,0.6)'; ctx.lineWidth = Math.max(0.5, r * 0.15); ctx.stroke();
  }
  function roundRect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

  /* ---------- canned video (procedural clips) ---------- */
  const CLIPS = {
    pivotopen: { name: 'Show open', dur: 12, kind: 'open' },
    nfrpromo: { name: 'NEC Front Row promo', dur: 30, kind: 'promo', title: 'NEC FRONT ROW', sub: 'Every NEC game. Live and on demand.' },
    sponsor1: { name: 'Sponsor spot A', dur: 30, kind: 'sponsor', title: 'YOUR SPONSOR HERE', sub: '30-second spot' },
    sponsor2: { name: 'Sponsor spot B', dur: 15, kind: 'sponsor', title: 'PRESENTING PARTNER', sub: '15-second spot' },
    halfopen: { name: 'Halftime open', dur: 10, kind: 'open', title: 'HALFTIME' },
    countdown: { name: 'Countdown to tip', dur: 60, kind: 'countdown' },
    bumper: { name: 'Bumper', dur: 6, kind: 'bumper' }
  };
  function drawClip(ctx, w, h, clipId, t, look) {
    const c = CLIPS[clipId] || CLIPS.bumper;
    const u = clamp(t / c.dur, 0, 1);
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, shade(look.home, -0.55)); g.addColorStop(1, '#07090d');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    ctx.save();
    for (let i = 0; i < 9; i++) {
      const x = ((i * 0.17 + t * 0.06) % 1.3 - 0.15) * w;
      ctx.fillStyle = i % 2 ? rgba(look.home, 0.22) : 'rgba(255,176,32,0.12)';
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + w * 0.08, 0); ctx.lineTo(x - w * 0.12, h); ctx.lineTo(x - w * 0.2, h); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff';
    const fs = h / 9;
    const ap = smooth(t / 0.8);
    ctx.globalAlpha = ap;
    if (c.kind === 'countdown') {
      const left = Math.max(0, Math.ceil(c.dur - t));
      ctx.font = `600 ${fs * 0.5}px "Barlow", sans-serif`; ctx.fillText('TIP-OFF IN', w / 2, h * 0.36);
      ctx.font = `700 ${fs * 2}px "Barlow Condensed", sans-serif`; ctx.fillText(`${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`, w / 2, h * 0.55);
      ctx.font = `600 ${fs * 0.45}px "Barlow", sans-serif`; ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.fillText(`${look.awayTeam.name.toUpperCase()} AT ${look.homeTeam.name.toUpperCase()}`, w / 2, h * 0.74);
    } else if (c.kind === 'open') {
      ctx.font = `700 ${fs * 1.6 * (0.9 + 0.1 * ap)}px "Barlow Condensed", sans-serif`;
      ctx.fillText(c.title || `${look.awayTeam.code}  AT  ${look.homeTeam.code}`, w / 2, h * 0.47);
      ctx.font = `600 ${fs * 0.42}px "Barlow", sans-serif`; ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.fillText(String(look.event || '').toUpperCase(), w / 2, h * 0.62);
    } else if (c.kind === 'bumper') {
      ctx.font = `700 ${fs * 1.1}px "Barlow Condensed", sans-serif`; ctx.fillText('PIVOT', w / 2, h * 0.5);
    } else {
      ctx.font = `700 ${fs * 1.15}px "Barlow Condensed", sans-serif`; ctx.fillText(c.title, w / 2, h * 0.45);
      ctx.font = `500 ${fs * 0.42}px "Barlow", sans-serif`; ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.fillText(c.sub, w / 2, h * 0.58);
    }
    ctx.globalAlpha = 1;
    // progress
    ctx.fillStyle = 'rgba(255,255,255,0.15)'; ctx.fillRect(0, h - h * 0.012, w, h * 0.012);
    ctx.fillStyle = '#ffb020'; ctx.fillRect(0, h - h * 0.012, w * u, h * 0.012);
  }

  /* ---------- audio levels (0..1) ---------- */
  function voiceLevel(ch, T) {
    const talker = noise(T * 0.18 + 3) > 0.5 ? 0 : 1;
    const gate = smooth((noise(T * 0.9 + ch * 40) - 0.35) * 4);
    const base = ch === talker ? 0.72 : 0.12;
    return clamp(base * gate * (0.6 + 0.4 * noise(T * 13 + ch * 7)), 0, 1);
  }
  function natLevel(ch, T, game) {
    return clamp(0.26 + 0.08 * noise(T * 3 + ch * 9) + 0.06 * noise(T * 17 + ch) + 0.5 * game.excite(T), 0, 1);
  }

  window.PIVOT_SIM = { makeGame, drawCamera, drawClip, CAMS, CLIPS, teamColors, inkOn, shade, rgba, lum, voiceLevel, natLevel, noise, clamp, lerp };
})();
