/* Pivot editors: rundown items, camera settings, the M/E builder, clip in and out points,
   graphic words and lower-third stats. ⌘E or right-click opens the one that fits. */
(function () {
  const PV = window.PV, S = window.PIVOT_SIM, G = window.PIVOT_GFX, UI = PV.UI;
  const esc = UI.esc, $ = UI.$, $$ = UI.$$;
  const ui = UI.state;
  const uid = () => Math.random().toString(36).slice(2, 8);

  /* small team logo for the desk (not the on-air graphics) */
  UI.logo = function (t, color, size) {
    const s = size || 18;
    return t && t.logo ? `<span class="tlogo" style="width:${s}px;height:${s}px"><img src="${esc(t.logo)}" alt=""></span>` : `<i class="swc" style="background:${esc(color || (t && t.color) || '#5b6474')}"></i>`;
  };

  function modal(html, cls, onClose) {
    $$('.scrim').forEach(x => x.remove());
    const s = document.createElement('div'); s.className = 'scrim'; s.dataset.modal = '1';
    s.innerHTML = `<div class="dlg ${cls || ''}" role="dialog" aria-modal="true">${html}</div>`;
    // keys reach the dialog wherever focus is; the desk ignores keys while a dialog is open
    s.keys = [];
    const kh = e => {
      if (!s.isConnected) { document.removeEventListener('keydown', kh); return; }
      for (const f of s.keys) { f(e); if (e.defaultPrevented) return; }
      if (e.key === 'Escape') { e.preventDefault(); close(); }
    };
    const close = () => { if (!s.isConnected) return; s.remove(); document.removeEventListener('keydown', kh); if (onClose) onClose(); };
    s.close = close;
    s.addEventListener('pointerdown', e => { if (e.target === s) close(); });
    document.addEventListener('keydown', kh);
    document.body.appendChild(s);
    return s;
  }
  UI.modal = modal;
  const opt = (v, label, sel) => `<option value="${esc(v)}"${sel ? ' selected' : ''}>${esc(label)}</option>`;
  const typing = el => el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|number|search|)$/i.test(el.type || '')));
  const dB = g => g <= 0.01 ? '-∞ dB' : (20 * Math.log10(g / 0.8)).toFixed(1) + ' dB';

  /* ======================================================================
     ⌘E / right-click: edit whatever is selected
     ====================================================================== */
  UI.editSelected = function () {
    const st = PV.E.st, s = ui.sel;
    if (!s) { if (st.pv.rd != null) UI.editRundown(st.pv.rd); else UI.editRundown(); return; }
    if (s.kind === 'rd') return UI.editRundown(s.a);
    if (s.kind === 'src') {
      if (PV.isME(s.a)) return UI.meEditor(s.a.slice(3));
      if (/^cam/.test(s.a)) { const g = $(`[data-gear="${s.a}"]`); if (g) UI.inputMenu(g, s.a); return; }
      UI.toast(s.a === 'bars' ? 'Bars have nothing to edit' : 'Black has nothing to edit'); return;
    }
    if (s.kind === 'sbg') return UI.sbgEdit(null, s.a, s.b);
    if (s.kind === 'vid') return UI.clipEditor({ kind: 'vid', id: s.a });
    if (s.kind === 'rp') return UI.rpPanel(s.a, s.b);
    if (s.kind === 'snd') { if (s.a === 'tone') { UI.toast('Tone is a steady 1 kHz at −20 dB. It plays until the next Take.'); return; } return UI.clipEditor({ kind: 'snd', id: s.a }); }
    if (s.kind === 'cat') return UI.gfxEditor(s.a);
    if (s.kind === 'l3') { if (s.a === 'bio' || s.a === 'text') return UI.l3Editor(s.b, s.c, s.a); return UI.statPicker(s.b, s.c, s.a); }
    if (s.kind === 'tog') { if (s.a === 'big') UI.gfxEditor('big'); else UI.openSettings('gfx'); return; }
    UI.editRundown();
  };

  /* ======================================================================
     Rundown item editor
     ====================================================================== */
  UI.editRundown = function (which) {
    const st = PV.E.st, rd = st.rd;
    const isNew = which === 'new';
    let i = isNew ? -1 : which == null || which === '' ? (rd.cue < rd.items.length ? rd.cue : rd.idx) : +which;
    if (!isNew && !rd.items[i]) { UI.toast('Nothing cued in the rundown'); return; }
    const it = isNew ? { label: '', sub: '', seg: (rd.items[Math.min(rd.cue, rd.items.length - 1)] || {}).seg || 'Open', kind: 'gfx', act: ['gfx.play', 'title'] } : rd.items[i];
    const kind0 = it.kind;
    const ref0 = it.act && it.act[0] === 'gfx.play' ? it.act[1] : 'title';
    const cam0 = it.cam || (it.act && (it.act[0] === 'auto' || it.act[0] === 'cut') ? it.act[1] : 'cam2');
    const vid0 = it.act && it.act[0] === 'pl.cue' ? it.act[1] : Object.keys(S.CLIPS)[0];
    const keep = ['break', 'playlist'].includes(kind0);
    const segs = [...new Set(rd.items.map(x => x.seg))];
    const kinds = [['gfx', 'Graphic'], ['cam', 'Camera or M/E'], ['video', 'Video'], ['cue', 'Note only']].concat(keep ? [[kind0, kind0 === 'break' ? 'Break' : 'Playlist']] : []);
    const live = !isNew && rd.on && rd.idx === i;
    const shots = PV.camIds(st).concat(st.me.list.map(m => 'me:' + m.id));
    const s = modal(`<div class="dlgh"><b>${isNew ? 'New rundown item' : 'Edit rundown item'}</b><span class="sp"></span>${live ? '<span class="status bad">On air</span>' : ''}</div>
      <div class="dlgb">
        <div class="grid2" style="grid-template-columns:2fr 1fr;gap:10px"><div class="fld"><label>Name</label><input type="text" id="reLabel" value="${esc(it.label)}" placeholder="What the crew calls it"></div>
        <div class="fld"><label>Part of the show</label><select id="reSeg" class="inp">${segs.map(x => opt(x, x, x === it.seg)).join('')}</select></div></div>
        <div class="fld"><label>Note under the name</label><input type="text" id="reSub" value="${esc(it.sub)}" placeholder="e.g. Talent on camera, cue the band"></div>
        <div class="fld"><label>When you click it</label><div class="seg" id="reKind">${kinds.map(([k, n]) => `<button type="button" data-k="${k}" class="${k === kind0 ? 'on' : ''}">${n}</button>`).join('')}</div></div>
        <div data-pane="gfx"><div class="fld"><label>Graphic</label><select id="reRef" class="inp">${PV.GFX.map(g => opt(g[0], g[1], g[0] === ref0)).join('')}</select></div>
          <div id="reWords"></div></div>
        <div data-pane="cam"><div class="fld"><label>Shot</label><select id="reCam" class="inp">${shots.map(c => opt(c, (/^cam/.test(c) ? PV.srcShort(c) + ' · ' : 'M/E · ') + PV.srcName(st, c), c === cam0)).join('')}</select></div><div class="hint">Clicking this item puts that shot in Preview.</div></div>
        <div data-pane="video"><div class="fld"><label>Video</label><select id="reVid" class="inp">${Object.entries(S.CLIPS).map(([k, c]) => opt(k, `${c.name} (${UI.ms(c.dur)})`, k === vid0)).join('')}</select></div></div>
        <div data-pane="cue"><div class="hint">A reminder for the crew. Taking it just marks the spot in the show.</div></div>
        ${keep ? `<div data-pane="${kind0}"><div class="hint">This item ${kind0 === 'break' ? 'starts a commercial break' : 'rolls a playlist'} when you take it.</div></div>` : ''}
      </div>
      <div class="dlgf">${isNew ? '' : `<button class="btn ghost red" id="reDel" ${live ? 'disabled title="Take it off first"' : ''}>Delete item</button>`}<span class="sp"></span><button class="btn" id="reCancel">Cancel</button><button class="btn pri" id="reSave">${isNew ? 'Add to rundown' : 'Save'}</button></div>`, 'dlg-rd');
    let kind = kind0;
    const panes = () => s.querySelectorAll('[data-pane]').forEach(p => { p.hidden = p.dataset.pane !== kind; });
    const fillText = () => {
      const ref = s.querySelector('#reRef').value;
      s.querySelector('#reWords').innerHTML = wordFields(UI.gfxWords(ref), st.text[ref] || {}, 're');
    };
    panes(); fillText();
    s.querySelector('#reKind').addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (!b) return; kind = b.dataset.k; s.querySelectorAll('#reKind button').forEach(x => x.classList.toggle('on', x === b)); panes(); });
    s.querySelector('#reRef').addEventListener('change', fillText);
    s.querySelector('#reCancel').onclick = () => s.close();
    if (s.querySelector('#reDel')) s.querySelector('#reDel').onclick = () => { UI.send('rd.del', i); s.close(); };
    const save = () => {
      const patch = { label: s.querySelector('#reLabel').value.trim(), sub: s.querySelector('#reSub').value.trim(), seg: s.querySelector('#reSeg').value, kind };
      if (kind === 'gfx') { patch.ref = s.querySelector('#reRef').value; const w = id => { const el = s.querySelector(id); return el ? el.value.trim() : ''; }; patch.text = { title: w('#reT1'), sub: w('#reT2') }; if (!patch.label) patch.label = PV.gfxName(patch.ref); }
      if (kind === 'cam') { patch.cam = s.querySelector('#reCam').value; if (!patch.label) patch.label = PV.srcName(st, patch.cam); }
      if (kind === 'video') { patch.ref = s.querySelector('#reVid').value; if (!patch.label) patch.label = S.CLIPS[patch.ref].name; }
      if (keep && kind === kind0) delete patch.kind;
      if (!patch.label) patch.label = 'New item';
      if (isNew) UI.send('rd.add', rd.cue - 1, patch); else UI.send('rd.edit', i, patch);
      s.close();
    };
    s.querySelector('#reSave').onclick = save;
    s.keys.push(e => { if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); save(); } });
    setTimeout(() => s.querySelector('#reLabel').focus(), 30);
  };

  /* ======================================================================
     Camera settings (gear on each camera)
     ====================================================================== */
  /* in every camera's settings: kept for replay or not, and the last camera can be taken away */
  UI.camExtras = function (cam) {
    const st = PV.E.st, ids = PV.camIds(st), last = ids[ids.length - 1] === cam && ids.length > 1;
    return `<label class="chk" style="color:var(--ink);margin-top:2px"><input type="checkbox" data-camrp="${cam}" ${(st.inputs[cam] || {}).replay === false ? '' : 'checked'}> Record for replay</label>
      ${last ? `<button class="btn sm ghost red" data-camdel="1" style="align-self:flex-start">Remove ${PV.srcShort(cam)}</button>` : ''}`;
  };
  UI.wireCamExtras = function (m, cam) {
    m.addEventListener('change', e => { const c = e.target.closest('[data-camrp]'); if (c) UI.send('cam.replay', cam, c.checked); });
    m.addEventListener('click', e => { if (e.target.closest('[data-camdel]')) { UI.send('cams.remove'); UI.closeMenus(); } });
  };
  UI.inputMenu = function (anchor, cam) {
    UI.closeMenus();
    const st = PV.E.st, inp = st.inputs[cam];
    const m = document.createElement('div'); m.className = 'menu inmenu';
    m.innerHTML = `<div class="cardh">${PV.srcShort(cam)} settings<span class="sp"></span><button class="btn sm ghost" data-x="close">Done</button></div>
      <div class="fld"><label>Name</label><input type="text" value="${esc(inp.name)}" data-f="name" maxlength="24"></div>
      <div class="fld"><label>Input</label><select class="inp" data-f="device">${PV.DEVICES.map(d => opt(d, d, d === inp.device)).join('')}</select></div>
      <div class="fld"><label>Format</label><select class="inp" data-f="fmt">${PV.CAM_FORMATS.map(f => opt(f, f, f === inp.fmt)).join('')}</select></div>
      <div class="hint">Pivot converts any input format to the show format.</div>${UI.camExtras(cam)}`;
    document.body.appendChild(m);
    UI.wireCamExtras(m, cam);
    const r = anchor.getBoundingClientRect(), mh = m.getBoundingClientRect().height;
    m.style.left = Math.max(8, Math.min(r.left - 120, window.innerWidth - 300)) + 'px';
    m.style.top = (r.bottom + 6 + mh < window.innerHeight ? r.bottom + 6 : Math.max(8, r.top - mh - 6)) + 'px';
    const set = el => { const v = el.value.trim(); if (!v) return; UI.send('input.set', cam, { [el.dataset.f]: v }); };
    m.addEventListener('change', e => { const el = e.target.closest('[data-f]'); if (el) set(el); });
    m.addEventListener('keydown', e => { if (e.key === 'Enter') { const el = e.target.closest('[data-f]'); if (el) { set(el); UI.closeMenus(); } } });
    m.addEventListener('click', e => { if (e.target.closest('[data-x]')) { set(m.querySelector('[data-f=name]')); UI.closeMenus(); } });
    setTimeout(() => document.addEventListener('pointerdown', function off(e) { if (!m.contains(e.target)) { const n = m.querySelector('[data-f=name]'); if (n && n.value.trim() !== inp.name) set(n); UI.closeMenus(); document.removeEventListener('pointerdown', off, true); } }, true), 0);
    setTimeout(() => { const n = m.querySelector('[data-f=name]'); if (n) n.select(); }, 20);
  };

  /* ======================================================================
     M/E builder: drag, scale and snap up to five layers
     ====================================================================== */
  const GFX_LAYERS = [['scorebug', 'Scorebug'], ['watermark', 'Watermark'], ['ticker', 'Ticker'], ['big', 'Big score']];
  const PRESETS = [['full', 'Full frame', [0, 0, 1, 1]], ['left', 'Left half', [0, 0, 0.5, 1]], ['right', 'Right half', [0.5, 0, 0.5, 1]], ['tl', 'Top left quarter', [0, 0, 0.5, 0.5]], ['tr', 'Top right quarter', [0.5, 0, 0.5, 0.5]], ['bl', 'Bottom left quarter', [0, 0.5, 0.5, 0.5]], ['br', 'Bottom right quarter', [0.5, 0.5, 0.5, 0.5]], ['pip', 'Picture in picture', [0.62, 0.07, 0.33, 0.33]], ['centre', 'Centre box', [0.2, 0.2, 0.6, 0.6]]];
  /* layer properties, Wirecast style: every value has a slider and a number box.
     key: [label, min, max, step, unit, read(layer), write(layer, value, lockShape)] */
  const OW = 1920, OH = 1080;
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const PROPS = {
    x: ['X', -960, 1920, 1, 'px', l => l.x * OW, (l, v) => { l.x = v / OW; }],
    y: ['Y', -540, 1080, 1, 'px', l => l.y * OH, (l, v) => { l.y = v / OH; }],
    w: ['Width', 40, 3840, 1, 'px', l => l.w * OW, (l, v, lock) => { const r = l.h / l.w; l.w = cl(v, 40, 3840) / OW; if (lock) l.h = l.w * r; }],
    h: ['Height', 24, 2160, 1, 'px', l => l.h * OH, (l, v, lock) => { const r = l.w / l.h; l.h = cl(v, 24, 2160) / OH; if (lock) l.w = l.h * r; }],
    scale: ['Scale', 5, 200, 1, '%', l => l.w * 100, (l, v) => { const cx = l.x + l.w / 2, cy = l.y + l.h / 2, r = l.h / l.w; l.w = cl(v, 5, 200) / 100; l.h = l.w * r; l.x = cx - l.w / 2; l.y = cy - l.h / 2; }],
    rotX: ['X rotation', -80, 80, 0.5, '°', l => l.rotX || 0, (l, v) => { l.rotX = v; }],
    rotY: ['Y rotation', -80, 80, 0.5, '°', l => l.rotY || 0, (l, v) => { l.rotY = v; }],
    rotZ: ['Z rotation', -180, 180, 0.5, '°', l => l.rotZ || 0, (l, v) => { l.rotZ = v; }],
    opacity: ['Opacity', 0, 100, 1, '%', l => (l.opacity == null ? 1 : l.opacity) * 100, (l, v) => { l.opacity = cl(v, 0, 100) / 100; }],
    reflection: ['Reflection', 0, 100, 1, '%', l => (l.reflection || 0) * 100, (l, v) => { l.reflection = cl(v, 0, 100) / 100; }],
    borderWidth: ['Width', 1, 40, 1, 'px', l => (l.borderWidth == null ? 0.004 : l.borderWidth) * OW, (l, v) => { l.borderWidth = cl(v, 1, 40) / OW; }],
    cropL: ['Left', 0, 45, 0.5, '%', l => ((l.crop || {}).l || 0) * 100, (l, v) => { l.crop = Object.assign({}, l.crop, { l: cl(v, 0, 45) / 100 }); }],
    cropR: ['Right', 0, 45, 0.5, '%', l => ((l.crop || {}).r || 0) * 100, (l, v) => { l.crop = Object.assign({}, l.crop, { r: cl(v, 0, 45) / 100 }); }],
    cropT: ['Top', 0, 45, 0.5, '%', l => ((l.crop || {}).t || 0) * 100, (l, v) => { l.crop = Object.assign({}, l.crop, { t: cl(v, 0, 45) / 100 }); }],
    cropB: ['Bottom', 0, 45, 0.5, '%', l => ((l.crop || {}).b || 0) * 100, (l, v) => { l.crop = Object.assign({}, l.crop, { b: cl(v, 0, 45) / 100 }); }],
    brightness: ['Brightness', -100, 100, 1, '', l => (l.brightness || 0) * 100, (l, v) => { l.brightness = cl(v, -100, 100) / 100; }],
    contrast: ['Contrast', 0, 200, 1, '%', l => (l.contrast == null ? 1 : l.contrast) * 100, (l, v) => { l.contrast = cl(v, 0, 200) / 100; }],
    saturation: ['Saturation', 0, 200, 1, '%', l => (l.saturation == null ? 1 : l.saturation) * 100, (l, v) => { l.saturation = cl(v, 0, 200) / 100; }],
    shadowBlur: ['Softness', 0, 80, 1, 'px', l => (l.shadowBlur == null ? 0.01 : l.shadowBlur) * OW, (l, v) => { l.shadowBlur = cl(v, 0, 80) / OW; }],
    shadowOpacity: ['Darkness', 0, 100, 1, '%', l => (l.shadowOpacity == null ? 0.6 : l.shadowOpacity) * 100, (l, v) => { l.shadowOpacity = cl(v, 0, 100) / 100; }],
    volume: ['Volume', 0, 200, 1, '%', l => (l.volume == null ? 1 : l.volume) * 100, (l, v) => { l.volume = cl(v, 0, 200) / 100; }],
    pan: ['Pan', -100, 100, 1, '', l => (l.pan || 0) * 100, (l, v) => { l.pan = cl(v, -100, 100) / 100; }]
  };
  const fmtV = (k, v) => { const st = PROPS[k][3]; return st < 1 ? (Math.round(v * 10) / 10).toString() : Math.round(v).toString(); };
  const propRow = (k, l) => { const [lab, mn, mx, st, unit, rd] = PROPS[k]; const v = rd(l); return `<div class="prow"><span>${lab}</span><input type="range" min="${mn}" max="${mx}" step="${st}" value="${v}" data-k="${k}" aria-label="${lab}"><input type="number" class="inp" step="${st}" value="${fmtV(k, v)}" data-k="${k}" aria-label="${lab} value"><i>${unit}</i></div>`; };
  const numPair = (a, b, l, extra) => `<div class="prow pair"><span>${a === 'x' ? 'Position' : 'Size'}</span><input type="number" class="inp" step="1" value="${Math.round(PROPS[a][5](l))}" data-k="${a}" aria-label="${PROPS[a][0]}"><input type="number" class="inp" step="1" value="${Math.round(PROPS[b][5](l))}" data-k="${b}" aria-label="${PROPS[b][0]}">${extra || ''}</div>`;

  UI.meEditor = function (id) {
    const st = PV.E.st;
    const src = id ? PV.meById(st, id) : null;
    const builtIn = id && /^me[1-4]$|^(split|pip|three|quad)$/.test(id);
    const d = src ? JSON.parse(JSON.stringify(src)) : { id: 'me' + uid(), name: 'New M/E', pre: null, layers: [{ k: 'src', src: 'cam1', x: 0, y: 0, w: 1, h: 1, border: false }, { k: 'src', src: 'cam2', x: 0.62, y: 0.07, w: 0.33, h: 0.33, border: true }], bars: [] };
    let sel = d.layers.findIndex(l => l.k === 'src'); if (sel < 0) sel = 0;
    let lock = true;
    const openSecs = new Set();
    const guides = { v: false, h: false };
    const srcOpts = cur => PV.camIds(st).map(x => opt(x, `${PV.srcShort(x)} · ${st.inputs[x].name}`, x === cur)).join('')
      + st.me.list.filter(m => m.id !== d.id).map(m => opt('me:' + m.id, 'M/E · ' + m.name, 'me:' + m.id === cur)).join('')
      + opt('replay', 'Replay', cur === 'replay') + opt('video', 'Video', cur === 'video') + opt('black', 'Black', cur === 'black');
    const s = modal(`<div class="dlgh"><b>${src ? 'Edit M/E' : 'Build an M/E'}</b><input type="text" id="meName" class="inp" value="${esc(d.name)}" maxlength="30" aria-label="M/E name" style="width:220px;margin-left:12px"><span class="sp"></span><span class="hint">Drag to move · drag a corner to scale · arrows nudge · snaps to the middle</span></div>
      <div class="dlgb mecols"><div><div class="mestage"><canvas id="meCv" tabindex="0"></canvas></div><div id="meLayers"></div></div><div id="meSide"></div></div>
      <div class="dlgf">${src && !builtIn ? '<button class="btn ghost red" id="meDel">Delete M/E</button>' : ''}<span class="sp"></span><button class="btn" id="meCancel">Cancel</button><button class="btn" id="meSave">Save</button><button class="btn pri" id="meUse">Save and put in Preview</button></div>`, 'dlg-me', () => cancelAnimationFrame(raf));
    const layersEl = s.querySelector('#meLayers'), side = s.querySelector('#meSide');
    const typeOf = l => l.k === 'gfx' ? 'gfx' : l.k === 'snd' ? 'snd' : 'src';
    const pct = v => Math.round(v * 1000) / 10;
    const section = (key, title, body, toggle) => `<details class="psec" data-sec="${key}" ${openSecs.has(key) ? 'open' : ''}><summary>${title}${toggle || ''}</summary>${body}</details>`;

    const listHtml = () => `<div class="sech">Layers <span class="hint" style="text-transform:none;letter-spacing:0">(up to 5; lower in the list sits on top)</span></div>
        ${d.layers.map((l, i) => `<div class="mel${i === sel ? ' on' : ''}" data-l="${i}">
          <b class="mln">${i + 1}</b>
          <select class="inp" data-p="type" aria-label="Layer type">${opt('src', 'Video', typeOf(l) === 'src')}${opt('gfx', 'Graphic', typeOf(l) === 'gfx')}${opt('snd', 'Sound', typeOf(l) === 'snd')}</select>
          <select class="inp" data-p="what" aria-label="Layer source">${l.k === 'gfx' ? GFX_LAYERS.map(([k, n]) => opt(k, n, l.g === k)).join('') : l.k === 'snd' ? st.snds.map(x => opt(x.id, x.name, x.id === l.id)).join('') : srcOpts(l.src)}</select>
          <button class="btn sm ghost" data-a="up" ${i ? '' : 'disabled'} title="Send back">↑</button><button class="btn sm ghost" data-a="dn" ${i < d.layers.length - 1 ? '' : 'disabled'} title="Bring forward">↓</button><button class="btn sm ghost" data-a="rm" ${d.layers.length > 1 ? '' : 'disabled'} title="Remove">✕</button></div>`).join('')}
        <div class="row">${d.layers.length < 5 ? '<button class="btn sm" id="meAdd">+ Add a layer</button>' : ''}<span class="sp" style="flex:1"></span>
        ${(d.bars || []).length < 4 ? '<button class="btn sm ghost" data-addbar="v">+ Vertical league bar</button><button class="btn sm ghost" data-addbar="h">+ Horizontal league bar</button>' : ''}</div>
        ${(d.bars || []).map((b, i) => `<div class="row mebar" data-b="${i}"><span>${b.o === 'v' ? 'Vertical' : 'Horizontal'} league bar at</span><input type="number" class="inp" step="0.5" data-bp="at" value="${pct(b.at)}" style="width:72px">%<button class="btn sm ghost" data-ba="rm" title="Remove">✕</button></div>`).join('')}`;

    const propsHtml = () => {
      const L = d.layers[sel];
      if (!L) return '';
      if (L.k === 'gfx') return `<div class="sech">Layer ${sel + 1} · graphic</div><div class="hint">Graphics sit in their normal spot on screen.</div>`;
      if (L.k === 'snd') return `<div class="sech">Layer ${sel + 1} · sound</div><div class="hint">The sound plays when this M/E is taken to Program.</div>`;
      return `<div class="sech">Layer ${sel + 1} properties<span class="sp"></span><span class="hint" style="text-transform:none;letter-spacing:0">${esc(PV.srcName(st, L.src))}</span></div>
        <div class="props">
        ${numPair('x', 'y', L)}
        ${numPair('w', 'h', L, `<button class="btn sm ghost lockb${lock ? ' on' : ''}" data-pa="lock" title="${lock ? 'Width and height move together' : 'Width and height move separately'}">${lock ? '🔒' : '🔓'}</button>`)}
        ${propRow('scale', L)}
        <div class="prow"><span></span><div class="row" style="gap:6px"><button class="btn sm" data-pa="fit" title="Fill the whole frame">Fit to frame</button><button class="btn sm" data-pa="reset" title="Undo rotation, opacity, crop, color and effects">Reset look</button>
          <select class="inp" id="mePre" aria-label="Quick position" style="height:26px"><option value="">Quick position…</option>${PRESETS.map(([k, n]) => opt(k, n)).join('')}</select></div></div>
        <div class="prow"><span>Fill</span><select class="inp" data-k="fill" style="grid-column:2/-1">${opt('fill', 'Fill the box (trims the edges)', (L.fill || 'fill') === 'fill')}${opt('fit', 'Show the whole picture', L.fill === 'fit')}${opt('stretch', 'Stretch to the box', L.fill === 'stretch')}</select></div>
        ${propRow('rotX', L)}${propRow('rotY', L)}${propRow('rotZ', L)}${propRow('opacity', L)}${propRow('reflection', L)}
        </div>
        ${section('border', 'Border', `<div class="props">${propRow('borderWidth', L)}<div class="prow"><span>Color</span><input type="color" value="${esc(L.borderColor || '#ffffff')}" data-k="borderColor" aria-label="Border color"></div></div>`,
          `<label class="chk" onclick="event.stopPropagation()"><input type="checkbox" data-k="border" ${L.border ? 'checked' : ''}>On</label>`)}
        ${section('crop', 'Crop', `<div class="props">${propRow('cropL', L)}${propRow('cropR', L)}${propRow('cropT', L)}${propRow('cropB', L)}</div>`)}
        ${section('color', 'Color', `<div class="props">${propRow('brightness', L)}${propRow('contrast', L)}${propRow('saturation', L)}</div>`)}
        ${section('shadow', 'Drop shadow', `<div class="props">${propRow('shadowBlur', L)}${propRow('shadowOpacity', L)}</div>`,
          `<label class="chk" onclick="event.stopPropagation()"><input type="checkbox" data-k="shadow" ${L.shadow ? 'checked' : ''}>On</label>`)}
        ${section('audio', 'Sound', `<div class="props">${propRow('volume', L)}${propRow('pan', L)}</div><div class="hint">Changes here only affect this layer, while this M/E is on air.</div>`)}`;
    };

    const form = () => { layersEl.innerHTML = listHtml(); side.innerHTML = propsHtml(); };
    /* while dragging, update the numbers without rebuilding the panel */
    const syncProps = except => {
      const L = d.layers[sel]; if (!L || L.k !== 'src') return;
      side.querySelectorAll('input[data-k]').forEach(el => {
        if (el === except || el.type === 'checkbox' || el.type === 'color') return;
        const k = el.dataset.k; if (!PROPS[k]) return;
        const v = PROPS[k][5](L);
        el.value = el.type === 'number' ? (k === 'x' || k === 'y' || k === 'w' || k === 'h' ? Math.round(v) : fmtV(k, v)) : v;
      });
    };
    form();
    s.querySelector('#meName').addEventListener('input', e => { d.name = e.target.value; });
    layersEl.addEventListener('pointerdown', e => { const r = e.target.closest('[data-l]'); if (r && !e.target.closest('select,button')) { sel = +r.dataset.l; form(); } });
    side.addEventListener('toggle', e => { const dt = e.target.closest && e.target.closest('details[data-sec]'); if (dt) { if (dt.open) openSecs.add(dt.dataset.sec); else openSecs.delete(dt.dataset.sec); } }, true);
    const onProp = (el, final) => {
      const L = d.layers[sel]; if (!L || L.k !== 'src') return;
      const k = el.dataset.k;
      if (k === 'border' || k === 'shadow') { L[k] = el.checked; return; }
      if (k === 'borderColor') { L.borderColor = el.value; return; }
      if (k === 'fill') { L.fill = el.value; return; }
      if (!PROPS[k]) return;
      const v = +el.value; if (!isFinite(v)) return;
      PROPS[k][6](L, v, lock);
      syncProps(final ? null : el);
    };
    side.addEventListener('input', e => { if (e.target.dataset.k) onProp(e.target, false); });
    side.addEventListener('change', e => {
      const el = e.target;
      if (el.id === 'mePre') { const P = PRESETS.find(x => x[0] === el.value); if (P && d.layers[sel]) [d.layers[sel].x, d.layers[sel].y, d.layers[sel].w, d.layers[sel].h] = P[2]; form(); return; }
      if (el.dataset.k) onProp(el, true);
    });
    side.addEventListener('click', e => {
      const b = e.target.closest('[data-pa]'); if (!b) return;
      const L = d.layers[sel]; if (!L) return;
      if (b.dataset.pa === 'lock') lock = !lock;
      if (b.dataset.pa === 'fit') Object.assign(L, { x: 0, y: 0, w: 1, h: 1 });
      if (b.dataset.pa === 'reset') { for (const k of ['rotX', 'rotY', 'rotZ', 'opacity', 'reflection', 'crop', 'brightness', 'contrast', 'saturation', 'shadow', 'shadowBlur', 'shadowOpacity', 'fill', 'volume', 'pan']) delete L[k]; }
      form();
    });
    layersEl.addEventListener('input', e => {
      const el = e.target;
      if (el.dataset.bp) { const b = d.bars[+el.closest('[data-b]').dataset.b]; b.at = Math.max(0, Math.min(1, (+el.value || 0) / 100)); }
    });
    layersEl.addEventListener('change', e => {
      const el = e.target;
      const row = el.closest('[data-l]'); if (!row) return;
      const i = +row.dataset.l, l = d.layers[i]; sel = i;
      if (el.dataset.p === 'type') {
        const v = el.value;
        if (v === 'gfx') d.layers[i] = { k: 'gfx', g: 'scorebug', x: 0, y: 0, w: 1, h: 1 };
        else if (v === 'snd') { if (!st.snds.length) { UI.toast('Add a sound in the Sounds row first'); form(); return; } d.layers[i] = { k: 'snd', id: st.snds[0].id, x: 0, y: 0, w: 0, h: 0 }; }
        else d.layers[i] = { k: 'src', src: 'cam1', x: 0.25, y: 0.25, w: 0.5, h: 0.5, border: false };
      } else if (el.dataset.p === 'what') { if (l.k === 'gfx') l.g = el.value; else if (l.k === 'snd') l.id = el.value; else l.src = el.value; }
      form();
    });
    layersEl.addEventListener('click', e => {
      if (e.target.id === 'meAdd') { d.layers.push({ k: 'src', src: 'cam3', x: 0.25, y: 0.25, w: 0.5, h: 0.5, border: true }); sel = d.layers.length - 1; form(); return; }
      const ab = e.target.closest('[data-addbar]'); if (ab) { d.bars = d.bars || []; d.bars.push({ o: ab.dataset.addbar, at: 0.5 }); form(); return; }
      const br = e.target.closest('[data-ba]'); if (br) { d.bars.splice(+br.closest('[data-b]').dataset.b, 1); form(); return; }
      const b = e.target.closest('[data-a]'); if (!b) return;
      const i = +b.closest('[data-l]').dataset.l, a = b.dataset.a;
      if (a === 'rm') { d.layers.splice(i, 1); sel = Math.min(sel, d.layers.length - 1); }
      if (a === 'up' && i > 0) { [d.layers[i - 1], d.layers[i]] = [d.layers[i], d.layers[i - 1]]; sel = i - 1; }
      if (a === 'dn' && i < d.layers.length - 1) { [d.layers[i + 1], d.layers[i]] = [d.layers[i], d.layers[i + 1]]; sel = i + 1; }
      form();
    });

    /* the canvas: what you see is what goes to air */
    const cv = s.querySelector('#meCv');
    let raf = 0, drag = null;
    const H = 9; // handle size in css px
    const draw = () => {
      if (!cv.isConnected) return;
      const [w, h] = UI.fit(cv, 1280), ctx = cv.getContext('2d'), k = w / cv.getBoundingClientRect().width;
      UI.drawME(ctx, w, h, d, PV.E.st, Date.now(), { thumb: true });
      d.layers.forEach((l, i) => {
        if (l.k === 'snd') return;
        const x = l.x * w, y = l.y * h, bw = l.w * w, bh = l.h * h;
        ctx.save();
        if (i === sel && l.k === 'src') {
          ctx.strokeStyle = '#ffb020'; ctx.lineWidth = 2 * k; ctx.setLineDash([]); ctx.strokeRect(x, y, bw, bh);
          ctx.fillStyle = '#ffb020'; for (const [cx, cy] of [[x, y], [x + bw, y], [x, y + bh], [x + bw, y + bh]]) ctx.fillRect(cx - H * k / 2, cy - H * k / 2, H * k, H * k);
          ctx.font = `700 ${13 * k}px "Barlow Condensed", sans-serif`; ctx.textBaseline = 'top';
          const lab = `${i + 1} · ${PV.srcName(st, l.src)}`; const tw = ctx.measureText(lab).width;
          ctx.fillStyle = 'rgba(0,0,0,.7)'; ctx.fillRect(x + 4 * k, y + 4 * k, tw + 10 * k, 18 * k); ctx.fillStyle = '#ffd38a'; ctx.fillText(lab, x + 9 * k, y + 7 * k);
        } else if (l.k === 'src') { ctx.strokeStyle = 'rgba(255,255,255,.28)'; ctx.lineWidth = 1 * k; ctx.setLineDash([5 * k, 4 * k]); ctx.strokeRect(x, y, bw, bh); }
        ctx.restore();
      });
      if (drag) {
        ctx.save(); ctx.strokeStyle = '#ff3fa4'; ctx.lineWidth = 1.5 * k; ctx.setLineDash([6 * k, 4 * k]);
        if (guides.v) { ctx.beginPath(); ctx.moveTo(w / 2, 0); ctx.lineTo(w / 2, h); ctx.stroke(); }
        if (guides.h) { ctx.beginPath(); ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2); ctx.stroke(); }
        ctx.restore();
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    const rel = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height, r]; };
    const SNAP = 0.015;
    const snapMove = l => {
      guides.v = guides.h = false;
      const cx = l.x + l.w / 2, cy = l.y + l.h / 2;
      if (Math.abs(cx - 0.5) < SNAP) { l.x = 0.5 - l.w / 2; guides.v = true; }
      if (Math.abs(cy - 0.5) < SNAP) { l.y = 0.5 - l.h / 2; guides.h = true; }
      for (const e of [0, 1]) { if (Math.abs(l.x - e) < SNAP) l.x = e; if (Math.abs(l.x + l.w - e) < SNAP) l.x = e - l.w; if (Math.abs(l.y - e) < SNAP) l.y = e; if (Math.abs(l.y + l.h - e) < SNAP) l.y = e - l.h; }
      if (!guides.v && Math.abs(l.x - 0.5) < SNAP) { l.x = 0.5; guides.v = true; } else if (!guides.v && Math.abs(l.x + l.w - 0.5) < SNAP) { l.x = 0.5 - l.w; guides.v = true; }
      if (!guides.h && Math.abs(l.y - 0.5) < SNAP) { l.y = 0.5; guides.h = true; } else if (!guides.h && Math.abs(l.y + l.h - 0.5) < SNAP) { l.y = 0.5 - l.h; guides.h = true; }
    };
    cv.addEventListener('pointerdown', e => {
      e.preventDefault(); cv.focus();
      const [px, py, r] = rel(e), tol = H / r.width * 1.2, tolY = H / r.height * 1.2;
      // a corner of the selected layer first, then the topmost layer under the pointer
      const L0 = d.layers[sel];
      let corner = null;
      if (L0 && L0.k === 'src') for (const [cx, cy, ox, oy] of [[L0.x, L0.y, 1, 1], [L0.x + L0.w, L0.y, 0, 1], [L0.x, L0.y + L0.h, 1, 0], [L0.x + L0.w, L0.y + L0.h, 0, 0]]) if (Math.abs(px - cx) < tol && Math.abs(py - cy) < tolY) corner = [ox, oy];
      if (!corner) {
        let hit = -1;
        for (let i = d.layers.length - 1; i >= 0; i--) { const l = d.layers[i]; if (l.k === 'src' && px >= l.x && px <= l.x + l.w && py >= l.y && py <= l.y + l.h) { hit = i; break; } }
        if (hit < 0) return;
        if (hit !== sel) { sel = hit; form(); }
      }
      const l = d.layers[sel], start = { x: l.x, y: l.y, w: l.w, h: l.h, px, py };
      // the corner opposite the one grabbed stays put
      const anchor = corner ? [start.x + start.w * corner[0], start.y + start.h * corner[1]] : null;
      drag = { corner };
      cv.setPointerCapture(e.pointerId);
      const mv = ev => {
        const [qx, qy] = rel(ev);
        if (!corner) { l.x = start.x + (qx - start.px); l.y = start.y + (qy - start.py); snapMove(l); }
        else {
          let nw = Math.max(0.04, Math.abs(qx - anchor[0])), nh = Math.max(0.04, Math.abs(qy - anchor[1]));
          if (lock !== ev.altKey) { const ar = start.w / start.h; if (nw / nh > ar) nh = nw / ar; else nw = nh * ar; }
          l.w = nw; l.h = nh;
          l.x = corner[0] === 1 ? anchor[0] - nw : anchor[0]; l.y = corner[1] === 1 ? anchor[1] - nh : anchor[1];
          guides.v = guides.h = false;
        }
        syncProps();
      };
      const up = () => { cv.removeEventListener('pointermove', mv); cv.removeEventListener('pointerup', up); drag = null; guides.v = guides.h = false; syncProps(); };
      cv.addEventListener('pointermove', mv); cv.addEventListener('pointerup', up);
    });
    s.keys.push(e => {
      if (typing(e.target) || e.target.tagName === 'SELECT' || (e.target.type === 'range')) return;
      const l = d.layers[sel]; if (!l || l.k !== 'src') return;
      const st2 = e.shiftKey ? 0.05 : 0.005;
      const k = e.key;
      if (k === 'ArrowLeft') l.x -= st2; else if (k === 'ArrowRight') l.x += st2; else if (k === 'ArrowUp') l.y -= st2; else if (k === 'ArrowDown') l.y += st2;
      else if (k === '=' || k === '+' || k === ']') { const cx = l.x + l.w / 2, cy = l.y + l.h / 2; l.w *= 1.04; l.h *= 1.04; l.x = cx - l.w / 2; l.y = cy - l.h / 2; }
      else if (k === '-' || k === '[') { const cx = l.x + l.w / 2, cy = l.y + l.h / 2; l.w = Math.max(0.04, l.w / 1.04); l.h = Math.max(0.04, l.h / 1.04); l.x = cx - l.w / 2; l.y = cy - l.h / 2; }
      else if ((k === 'Backspace' || k === 'Delete') && d.layers.length > 1) { d.layers.splice(sel, 1); sel = Math.max(0, sel - 1); form(); e.preventDefault(); return; }
      else if (k === 'Tab') { sel = (sel + 1) % d.layers.length; form(); e.preventDefault(); return; }
      else return;
      e.preventDefault(); syncProps();
    });
    const save = use => {
      d.name = (d.name || '').trim() || 'M/E';
      UI.send('me.save2', d);
      if (use) { UI.send('pv.src', 'me:' + d.id); ui.sel = { kind: 'src', a: 'me:' + d.id }; }
      s.close(); UI.toast(use ? `${d.name} is in Preview` : `${d.name} saved`);
    };
    s.querySelector('#meSave').onclick = () => save(false);
    s.querySelector('#meUse').onclick = () => save(true);
    s.querySelector('#meCancel').onclick = () => s.close();
    if (s.querySelector('#meDel')) s.querySelector('#meDel').onclick = () => { UI.send('me.del', d.id); s.close(); };
    setTimeout(() => cv.focus(), 30);
  };

  /* ======================================================================
     Clip editor: videos, replay angles and sounds
     in and out on a timeline, playhead, I and O, arrows step a frame
     ====================================================================== */
  const FR = 1 / 30;
  const fmtS = v => { v = Math.max(0, v); const m = Math.floor(v / 60), r = v - m * 60; return `${m}:${r.toFixed(2).padStart(5, '0')}`; };
  UI.sndUrls = UI.sndUrls || {};
  UI.clipEditor = function (o) {
    const st = PV.E.st, look = PV.lookFor(st.show), game = PV.gameFor(st.show);
    let c = { name: '', tIn: 0, tOut: 1, gain: 0.8, lo: 0, hi: 1 }, rp = null, snd = null, vid = null;
    if (o.kind === 'vid') { vid = PV.vidItem(st, o.id); if (!vid) return; const C = S.CLIPS[vid.ref]; c = { name: vid.name, tIn: vid.tIn, tOut: vid.tOut, gain: vid.gain, lo: 0, hi: vid.dur || (C && C.dur) || 60 }; }
    else if (o.kind === 'rp') {
      rp = st.rp.clips.find(x => x.id === o.id); if (!rp) return;
      const ang = o.ang || rp.angles[0] || 'cam1';
      const lo = rp.win ? rp.win[0] : rp.tIn - 20, hi = Math.max(lo + 1, Math.min(rp.win ? rp.win[1] : rp.tOut + 10, PV.worldT(st)));
      const cuts = {}; for (const a of PV.camIds(st)) { const k = PV.cut(rp, a); cuts[a] = [k.tIn, k.tOut]; }
      c = { name: rp.name, ang, cuts, lo, hi, tIn: cuts[ang][0], tOut: cuts[ang][1], gain: 1 };
    } else {
      snd = st.snds.find(x => x.id === o.id); if (!snd) return;
      c = { name: snd.name, tIn: snd.tIn || 0, tOut: snd.tOut || snd.dur || 8, gain: snd.gain, lo: 0, hi: snd.dur || 8, file: snd.file, dur: snd.dur };
    }
    let ph = c.tIn, playing = false, t0 = 0, ph0 = 0, raf = 0, audio = null;
    const title = o.kind === 'vid' ? 'Edit video' : o.kind === 'rp' ? 'Edit replay' : 'Edit sound';
    const s = modal(`<div class="dlgh"><b>${title}</b><input type="text" id="ceName" class="inp" value="${esc(c.name)}" maxlength="40" aria-label="Name" style="width:240px;margin-left:12px"><span class="sp"></span>
        ${rp ? `<div class="seg sm" id="ceAng">${PV.camIds(st).map(a => `<button data-a="${a}" class="${a === c.ang ? 'on' : ''}">${PV.srcShort(a)}</button>`).join('')}</div>` : ''}</div>
      <div class="dlgb">
        <div class="cestage">${snd ? '<canvas id="ceWave"></canvas>' : '<canvas id="ceCv"></canvas>'}<span class="cetc tc" id="ceTc"></span></div>
        <div class="rpe-track ce" id="ceTrack"><div class="rpe-sel" id="ceSel"></div><i class="rpe-h in" data-h="in" title="Drag the in point"></i><i class="rpe-h out" data-h="out" title="Drag the out point"></i><i class="rpe-ph" id="cePh"></i></div>
        <div class="row rpe-ctl">
          <button class="btn sm" data-c="toIn" title="Go to the in point">⇤</button>
          <button class="btn sm" data-c="stepB" title="Back one frame">◂ <kbd>←</kbd></button>
          <button class="btn sm pri" data-c="play" id="cePlay">▶ <kbd>K</kbd></button>
          <button class="btn sm" data-c="stepF" title="Ahead one frame"><kbd>→</kbd> ▸</button>
          <button class="btn sm" data-c="toOut" title="Go to the out point">⇥</button>
          <span class="sp" style="flex:1"></span>
          <span class="hint" id="ceLen"></span>
          <button class="btn sm" data-c="in">Set in <kbd>I</kbd></button><button class="btn sm" data-c="out">Set out <kbd>O</kbd></button>
          ${rp ? '<button class="btn sm" data-c="all" title="Use these in and out points on every angle of this play">Set all</button>' : ''}</div>
        ${rp ? '' : `<div class="row" style="margin-top:10px;gap:14px"><label class="fld" style="flex:1;margin:0"><span class="hint">Level <b id="ceDb">${dB(c.gain)}</b></span><input type="range" id="ceGain" min="0" max="1" step="0.01" value="${c.gain}" aria-label="Level"></label>
          ${snd ? `${PV.native ? '<button class="btn sm" id="ceNative">Choose a sound file…</button>' : '<label class="btn sm">Choose a sound file…<input type="file" id="ceFile" accept="audio/*" hidden></label>'}<span class="hint" id="ceFn">${esc(c.file ? (snd.fileName || c.file) : 'No file yet')}</span>` : ''}</div>`}
        <div class="hint" style="margin-top:8px">J and L jump a second · Shift with the arrows jumps a second · ${rp ? 'Each angle keeps its own in and out' : 'Changes apply next time it plays'}</div>
      </div>
      <div class="dlgf">${vid || snd ? '<button class="btn ghost red" id="ceDel">Delete</button>' : ''}<span class="sp"></span><button class="btn" id="ceCancel">Cancel</button><button class="btn pri" id="ceSave">Save</button></div>`, 'dlg-ce', () => { cancelAnimationFrame(raf); if (audio) audio.pause(); });
    const now = () => playing ? Math.min(c.hi, ph0 + (Date.now() - t0) / 1000) : ph;
    const seek = v => { ph = Math.max(c.lo, Math.min(c.hi, v)); if (playing) { ph0 = ph; t0 = Date.now(); if (audio) audio.currentTime = ph; } };
    const setPlay = on => {
      if (on) { if (ph >= c.tOut - 0.02) ph = c.tIn; ph0 = ph; t0 = Date.now(); playing = true; if (audio) { audio.currentTime = ph; audio.volume = Math.min(1, c.gain / 0.8 * 0.8); audio.play().catch(() => {}); } }
      else { ph = now(); playing = false; if (audio) audio.pause(); }
      s.querySelector('#cePlay').innerHTML = `${playing ? '❚❚' : '▶'} <kbd>K</kbd>`;
    };
    const track = s.querySelector('#ceTrack');
    const pos = v => ((v - c.lo) / (c.hi - c.lo) * 100).toFixed(3) + '%';
    const bar = () => {
      const sl = s.querySelector('#ceSel'); sl.style.left = pos(c.tIn); sl.style.width = `calc(${pos(c.tOut)} - ${pos(c.tIn)})`;
      s.querySelector('.rpe-h.in').style.left = pos(c.tIn); s.querySelector('.rpe-h.out').style.left = pos(c.tOut);
      s.querySelector('#ceLen').innerHTML = `In ${fmtS(c.tIn - c.lo)} · Out ${fmtS(c.tOut - c.lo)} · <b style="color:var(--ink)">${(c.tOut - c.tIn).toFixed(2)} s</b>`;
    };
    const wave = (ctx, w, h) => {
      ctx.fillStyle = '#0a0d12'; ctx.fillRect(0, 0, w, h);
      const n = Math.floor(w / 3), seed = (snd.id || 'x').split('').reduce((a, ch) => a + ch.charCodeAt(0), 0);
      for (let i = 0; i < n; i++) {
        const tt = c.lo + (i / n) * (c.hi - c.lo), inside = tt >= c.tIn && tt <= c.tOut;
        const a = c.file ? (0.25 + 0.7 * Math.abs(Math.sin(i * 0.37 + seed) * Math.cos(i * 0.051 + seed * 0.3))) * c.gain / 0.8 : 0.04;
        ctx.fillStyle = inside ? '#4fb3e8' : '#2a3442';
        const bh = Math.max(1, a * h * 0.8); ctx.fillRect(i * 3, (h - bh) / 2, 2, bh);
      }
      if (!c.file) { ctx.fillStyle = '#6b7686'; ctx.font = `600 ${Math.max(12, h / 9)}px system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('Choose a sound file below', w / 2, h / 2); }
      const x = (now() - c.lo) / (c.hi - c.lo) * w; ctx.fillStyle = '#ffb020'; ctx.fillRect(x - 1, 0, 2, h);
    };
    const draw = () => {
      if (!s.isConnected) return;
      let v = now();
      if (playing && v >= c.tOut) { ph = c.tOut; setPlay(false); v = ph; }
      const cv = s.querySelector('#ceCv'), wv = s.querySelector('#ceWave');
      if (cv) { const [w, h] = UI.fit(cv, 1280), ctx = cv.getContext('2d');
        if (vid && /^file:/.test(vid.ref)) { if (PV.native) PV.native.drawSnap(ctx, w, h, `${vid.ref}@${v.toFixed(2)}`, { key: 'clipedit' }); }
        else if (vid) S.drawClip(ctx, w, h, vid.ref, v, look);
        else if (PV.native) PV.native.drawSnap(ctx, w, h, `replay:${c.ang}@${Math.round(PV.wallOf(st, v))}`, { key: 'clipedit' });
        else S.drawCamera(ctx, w, h, c.ang, v, game, look);
        if (v < c.tIn || v > c.tOut) { ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(0, 0, w, h); } }
      if (wv) { const [w, h] = UI.fit(wv, 1280); wave(wv.getContext('2d'), w, h); }
      s.querySelector('#cePh').style.left = pos(v);
      s.querySelector('#ceTc').textContent = fmtS(v - c.lo);
      raf = requestAnimationFrame(draw);
    };
    bar(); raf = requestAnimationFrame(draw);
    const doIt = what => {
      const v = now();
      if (what === 'play') setPlay(!playing);
      else if (what === 'stepB') { setPlay(false); seek(ph - FR); }
      else if (what === 'stepF') { setPlay(false); seek(ph + FR); }
      else if (what === 'back') seek(v - 1);
      else if (what === 'fwd') seek(v + 1);
      else if (what === 'toIn') { setPlay(false); seek(c.tIn); }
      else if (what === 'toOut') { setPlay(false); seek(c.tOut); }
      else if (what === 'in') { c.tIn = Math.min(v, c.tOut - 0.2); if (rp) c.cuts[c.ang] = [c.tIn, c.tOut]; bar(); }
      else if (what === 'out') { c.tOut = Math.max(v, c.tIn + 0.2); if (rp) c.cuts[c.ang] = [c.tIn, c.tOut]; bar(); }
      else if (what === 'all') { for (const a in c.cuts) c.cuts[a] = [c.tIn, c.tOut]; c.all = true; UI.toast('Every angle of this play now uses these in and out points'); }
    };
    s.querySelector('.rpe-ctl').addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (b) doIt(b.dataset.c); });
    s.keys.push(e => {
      if (typing(e.target)) return;
      const k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
      const m = { I: 'in', O: 'out', K: 'play', ' ': 'play', J: 'back', L: 'fwd', ArrowLeft: e.shiftKey ? 'back' : 'stepB', ArrowRight: e.shiftKey ? 'fwd' : 'stepF', Home: 'toIn', End: 'toOut' }[k];
      if (m) { e.preventDefault(); doIt(m); }
    });
    track.addEventListener('pointerdown', e => {
      e.preventDefault();
      const h = e.target.dataset && e.target.dataset.h;
      const at = ev => { const r = track.getBoundingClientRect(); return c.lo + Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)) * (c.hi - c.lo); };
      setPlay(false);
      const mv = ev => {
        const v = at(ev);
        if (h === 'in') c.tIn = Math.min(v, c.tOut - 0.2); else if (h === 'out') c.tOut = Math.max(v, c.tIn + 0.2);
        if (h && rp) c.cuts[c.ang] = [c.tIn, c.tOut];
        ph = v; bar();
      };
      mv(e); track.setPointerCapture(e.pointerId);
      const up = () => { track.removeEventListener('pointermove', mv); track.removeEventListener('pointerup', up); };
      track.addEventListener('pointermove', mv); track.addEventListener('pointerup', up);
    });
    if (rp) s.querySelector('#ceAng').addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      c.ang = b.dataset.a; [c.tIn, c.tOut] = c.cuts[c.ang]; setPlay(false); ph = c.tIn; bar();
      s.querySelectorAll('#ceAng button').forEach(x => x.classList.toggle('on', x === b));
    });
    const g = s.querySelector('#ceGain'); if (g) g.addEventListener('input', () => { c.gain = +g.value; s.querySelector('#ceDb').textContent = dB(c.gain); if (audio) audio.volume = Math.min(1, c.gain); });
    if (snd) {
      if (UI.sndUrls[snd.id]) { audio = new Audio(UI.sndUrls[snd.id]); }
      const nb = s.querySelector('#ceNative');
      if (nb) nb.onclick = () => PV.native.pickSound(it => {
        c.file = it.ref; c.fileName = it.name; c.dur = it.dur; c.hi = it.dur; c.tIn = 0; c.tOut = it.dur; ph = 0;
        if (!s.querySelector('#ceName').value.trim() || /^New sound/.test(s.querySelector('#ceName').value)) s.querySelector('#ceName').value = it.name.slice(0, 30);
        s.querySelector('#ceFn').textContent = it.name; bar();
      });
      if (s.querySelector('#ceFile')) s.querySelector('#ceFile').addEventListener('change', e => {
        const f = e.target.files && e.target.files[0]; if (!f) return;
        const url = URL.createObjectURL(f);
        const a = new Audio(); a.preload = 'metadata'; a.src = url;
        a.addEventListener('loadedmetadata', () => {
          if (!isFinite(a.duration) || a.duration <= 0) { UI.toast('That file has no length Pivot can read'); return; }
          audio = a; c.file = f.name; c.dur = a.duration; c.hi = a.duration; c.tIn = 0; c.tOut = a.duration; ph = 0; c.url = url;
          if (!s.querySelector('#ceName').value.trim() || /^New sound/.test(s.querySelector('#ceName').value)) s.querySelector('#ceName').value = f.name.replace(/\.[^.]+$/, '').slice(0, 30);
          s.querySelector('#ceFn').textContent = f.name; bar();
        });
        a.addEventListener('error', () => UI.toast('Pivot couldn’t read that sound file'));
      });
    }
    s.querySelector('#ceCancel').onclick = () => s.close();
    if (s.querySelector('#ceDel')) s.querySelector('#ceDel').onclick = () => { if (vid) UI.send('vid.del', vid.id); else UI.send('snd.del', snd.id); ui.sel = null; s.close(); };
    s.querySelector('#ceSave').onclick = () => {
      const name = s.querySelector('#ceName').value.trim();
      if (vid) UI.send('vid.edit', vid.id, { name, tIn: c.tIn, tOut: c.tOut, gain: c.gain });
      else if (snd) { if (c.url) UI.sndUrls[snd.id] = c.url; if (c.fileName) snd.fileName = c.fileName; UI.send('snd.edit', snd.id, { name, file: c.file || '', dur: c.dur || 0, tIn: c.tIn, tOut: c.tOut, gain: c.gain }); }
      else { for (const a in c.cuts) UI.send('rp.cut', rp.id, a, [c.cuts[a][0], c.cuts[a][1]]); if (name) UI.send('rp.name', rp.id, name); }
      s.close();
    };
  };

  /* ======================================================================
     Watermark and replay burn: pick the picture (built in, a team logo, or one from a folder) and the corner
     ====================================================================== */
  PV.marks = () => { const m = PV.store.get('marks', []); return Array.isArray(m) ? m : []; };
  function publishMarks() {
    const map = {}; for (const m of PV.marks()) map[m.id] = m.src;
    window.PIVOT_MARKS = map;
    if (PV.native) PV.native.post({ type: 'gfxMarks', marks: map });
  }
  PV.saveMarks = list => { PV.store.set('marks', list.slice(-24)); publishMarks(); };
  PV.publishMarks = publishMarks;
  publishMarks();

  /* any picture file, made small enough to keep (wide side at most 640), see-through kept */
  function shrink(src, done) {
    const im = new Image();
    im.onload = () => {
      const k = Math.min(1, 640 / Math.max(im.naturalWidth || 1, im.naturalHeight || 1));
      const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      done(c.toDataURL('image/png'));
    };
    im.onerror = () => UI.toast('Pivot couldn’t read that picture');
    im.src = src;
  }

  UI.markEditor = function (kind) {
    const st = PV.E.st, sh = st.show, wm = kind === 'wm';
    const title = wm ? 'Watermark' : 'Replay burn';
    const cur = () => wm ? Object.assign({ src: 'nfr', pos: 'tr', size: 'm' }, PV.E.st.gfx.wm) : Object.assign({ src: 'text', pos: 'tl' }, PV.E.st.gfx.burn);
    // a look with its own watermark shows it in place of the built-in one
    const look = (G.pkgOf(st.gfx.pkg) || {}), lookWm = wm && look.build && look.build.wmSrc ? look.build.wmSrc(st) : '';
    const builtIn = () => (wm ? [['nfr', lookWm ? `${look.name} watermark` : 'NEC Front Row', lookWm || 'logos/nfr.webp']] : [['text', 'REPLAY (words)', '']])
      .concat([['league', 'League logo', 'logos/nec.svg']])
      .concat(['away', 'home'].filter(sd => sh[sd].logo).map(sd => [sd, `${sh[sd].name} logo`, sh[sd].logo]));
    const tile = (id, name, src, mine) => `<div class="mkt${cur().src === id ? ' on' : ''}" data-mk="${esc(id)}" role="button" tabindex="0" title="${esc(name)}">
        <span class="mki">${src ? `<img src="${esc(src)}" alt="">` : '<b>REPLAY</b>'}</span><small>${esc(name)}</small>${mine ? `<button class="mkx" data-mkdel="${esc(id.slice(4))}" title="Remove this picture" aria-label="Remove ${esc(name)}">×</button>` : ''}</div>`;
    const body = () => {
      const c = cur();
      const corners = wm ? [['tl', 'Top left'], ['tr', 'Top right'], ['bl', 'Bottom left'], ['br', 'Bottom right']] : [['tl', 'Top left'], ['tr', 'Top right']];
      return `<div class="mkg">${builtIn().map(([id, n, src]) => tile(id, n, src)).join('')}${PV.marks().map(m => tile('img:' + m.id, m.name, m.src, true)).join('')}
          <label class="mkt add" title="Choose a picture from a folder">${PV.native ? '<button class="mkadd" data-mkpick="1">+</button>' : '<input type="file" accept="image/*" id="mkFile" hidden><span class="mkadd">+</span>'}<small>From a folder…</small></label></div>
        <div class="row" style="gap:10px;flex-wrap:wrap"><span class="hint">Corner</span><div class="seg sm">${corners.map(([k, n]) => `<button data-mkpos="${k}" class="${c.pos === k ? 'on' : ''}">${n}</button>`).join('')}</div>
          ${wm ? `<span class="hint" style="margin-left:12px">Size</span><div class="seg sm">${[['s', 'Small'], ['m', 'Medium'], ['l', 'Large']].map(([k, n]) => `<button data-mksize="${k}" class="${c.size === k ? 'on' : ''}">${n}</button>`).join('')}</div>` : ''}</div>
        <div class="hint">${wm ? 'The watermark shows on cameras and M/Es only: never on breaks, videos, replays, black or bars.' : 'The burn shows only while a replay is on air.'} PNG pictures with a see-through background look best.</div>`;
    };
    const s = modal(`<div class="dlgh"><b>${title}</b><span class="sp"></span></div><div class="dlgb" id="mkBody">${body()}</div>
      <div class="dlgf"><span class="sp"></span><button class="btn pri" id="mkDone">Done</button></div>`, 'dlg-mk');
    const set = p => UI.send(wm ? 'gfx.wmSet' : 'gfx.burnSet', p);
    const redraw = () => { s.querySelector('#mkBody').innerHTML = body(); wireFile(); };
    const add = (src, name) => shrink(src, small => {
      const id = 'm' + Math.random().toString(36).slice(2, 9);
      PV.saveMarks(PV.marks().concat([{ id, name: String(name || 'Picture').replace(/\.[^.]+$/, '').slice(0, 40), src: small }]));
      set({ src: 'img:' + id }); redraw();
    });
    const wireFile = () => { const f = s.querySelector('#mkFile'); if (f) f.onchange = e => { const file = e.target.files && e.target.files[0]; if (!file) return; const r = new FileReader(); r.onload = () => add(r.result, file.name); r.readAsDataURL(file); }; };
    wireFile();
    s.addEventListener('click', e => {
      const del = e.target.closest('[data-mkdel]');
      if (del) { e.stopPropagation(); const id = del.dataset.mkdel; PV.saveMarks(PV.marks().filter(m => m.id !== id)); if (cur().src === 'img:' + id) set({ src: wm ? 'nfr' : 'text' }); redraw(); return; }
      if (e.target.closest('[data-mkpick]')) { e.preventDefault(); PV.native.pickImage(it => add(it.src, it.name)); return; }
      const t = e.target.closest('[data-mk]'); if (t) { set({ src: t.dataset.mk }); redraw(); return; }
      const p = e.target.closest('[data-mkpos]'); if (p) { set({ pos: p.dataset.mkpos }); redraw(); return; }
      const z = e.target.closest('[data-mksize]'); if (z) { set({ size: z.dataset.mksize }); redraw(); return; }
    });
    s.querySelector('#mkDone').onclick = () => s.close();
  };

  /* sounds with a file play for real when they're taken */
  let lastSnd = null, sndEl = null, toneOsc = null;
  setInterval(() => {
    const E = PV.E; if (!E || PV.native) return;
    const sp = E.st.sndPlay, key = sp ? sp.id + '|' + sp.start : null;
    if (key === lastSnd) return;
    lastSnd = key;
    if (sndEl) { sndEl.pause(); sndEl = null; }
    if (toneOsc) { try { toneOsc.stop(); toneOsc.ctx.close(); } catch (e) { /* closed */ } toneOsc = null; }
    if (sp && sp.tone) {   // the test tone, made here (the Mac makes its own)
      try { const ctx = new AudioContext(), o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = 1000; g.gain.value = 0.1; o.connect(g).connect(ctx.destination); o.start(); o.ctx = ctx; toneOsc = o; } catch (e) { /* no sound here */ }
      return;
    }
    if (!sp || !UI.sndUrls[sp.id]) return;
    const s = E.st.snds.find(x => x.id === sp.id); if (!s) return;
    sndEl = new Audio(UI.sndUrls[sp.id]); sndEl.currentTime = s.tIn || 0; sndEl.volume = Math.min(1, s.gain); sndEl.play().catch(() => {});
  }, 80);

  /* ======================================================================
     Graphic editor: words, featured player, coach, officials
     ====================================================================== */
  /* one catalogue graphic, built from the show as it stands (as the editor and Preview show it) */
  const gfxSet = (E, ref) => {
    const g = { scorebug: false, water: false, big: false, ticker: false, lower: null, full: null, take: null, trans: null };
    const side = /Away$/.test(ref) ? 'away' : 'home';
    if (ref === 'big') g.big = true;
    else if (PV.isLowerRef(ref, E.st)) g.lower = E.buildLower(PV.lowerSpec(ref));
    else if (/^five/.test(ref)) g.take = E.buildTake(side);
    else if (ref === 'ticker') { g.ticker = true; g.tickerData = E.buildTicker(); }
    else g.full = E.buildFull(ref);
    return g;
  };
  /* the words a graphic takes, in the look that's on: each box named for the line it changes, with that line's own words shown in it */
  UI.gfxWords = function (ref) {
    const E = PV.E, st = E.st, keep = st.text[ref];
    delete st.text[ref];
    let g;
    try { g = gfxSet(E, ref); } finally { if (keep) st.text[ref] = keep; }
    const B = (G.pkgOf(st.gfx.pkg) || {}).build || {}, obj = g.full || g.lower || g.take;
    const own = B.words && (obj || ref === 'big') ? B.words(obj, st, ref) : null;
    if (own) return own;
    if (ref === 'big') return { t1: null, t2: null, hint: 'The big score shows the teams, the score and the clock.' };
    const lower = ['scene', 'coachAway', 'coachHome'].includes(ref);
    if (ref === 'announcers') return { t1: null, t2: null, hint: 'Talent names come from Settings › Game.' };
    if (ref === 'ticker') return { t1: null, t2: null, hint: 'The ticker shows the day\'s other games.' };
    if (obj && obj.kind === 'standings') return { t1: { label: 'Top line', ph: obj.title || '' }, t2: { label: 'Second line', ph: obj.sub || '' }, t3: { label: 'Bottom line', ph: obj.note || '' } };
    return { t1: { label: 'Top line', ph: '' }, t2: { label: 'Second line', ph: '' }, hint: lower ? 'Top line replaces the big name, second line the line under it.' : 'Top line replaces the title, second line the small heading beside it.' };
  };
  const wordFields = (w, o, pre) => {
    const box = (k, f, v, max) => f ? `<div class="fld"><label>${esc(f.label)}</label><input type="text" id="${pre}${k}" value="${esc(v || '')}" placeholder="${esc(f.ph || f.label)}" maxlength="${max}"></div>` : '';
    return (w.t1 || w.t2 ? `<div class="hint">Leave a box empty for the words shown in it.</div>` : '') + box('T1', w.t1, o.title, 60) + box('T2', w.t2, o.sub, 90) + box('T3', w.t3, o.foot, 80) + (w.hint ? `<div class="hint">${esc(w.hint)}</div>` : '');
  };

  UI.gfxEditor = function (ref) {
    const E = PV.E, st = E.st, sh = st.show;
    const name = ref === 'big' ? 'Big score' : PV.gfxName(ref);
    const feat = ref === 'featAway' || ref === 'featHome', coach = ref === 'coachAway' || ref === 'coachHome';
    const side = /Away$/.test(ref) ? 'away' : 'home';
    const o = st.text[ref] || {};
    let body = '';
    if (feat) body = `<div class="fld"><label>Player</label><select class="inp" id="geFeat">${sh[side].roster.map(p => opt(p[0], `#${p[0]} ${p[1]} ${p[2]}`, p[0] === sh[side].featured)).join('')}</select></div>`;
    else if (coach) body = `<div class="grid2" style="grid-template-columns:2fr 1fr;gap:10px"><div class="fld"><label>Head coach</label><input type="text" id="geCoach" value="${esc(sh[side].coach || '')}" maxlength="40"></div><div class="fld"><label>Season</label><input type="text" id="geSeason" value="${esc(sh[side].coachSeason || '')}" maxlength="2" placeholder="e.g. 4"></div></div>`;
    else if (ref === 'officials') body = `<div class="fld"><label>Officials</label>${[0, 1, 2].map(i => `<input type="text" data-of="${i}" value="${esc((sh.officials || [])[i] || '')}" placeholder="${i === 0 ? 'Referee' : sh.rules && sh.rules.soccer ? 'Assistant referee' : 'Umpire'}" maxlength="40" style="margin-bottom:6px">`).join('')}</div>`;
    if (!feat && ref !== 'officials') body += wordFields(UI.gfxWords(ref), o, 'ge');
    // a team capsule (its four lines, each filled in from the team's numbers until typed over) and the halftime report's stories
    const cap = ref === 'capAway' || ref === 'capHome' || ref === 'halftime';
    if (cap) { const d = (gfxSet(E, ref).full || {}).lines || []; body += `<div class="fld"><label>Lines <span class="hint" style="text-transform:none;letter-spacing:0">(leave one empty for what's shown in it)</span></label>${d.map((l, i) => `<input type="text" data-ln="${i}" value="${esc((o.lines || [])[i] || '')}" placeholder="${esc(l)}" maxlength="80" style="margin-bottom:6px">`).join('')}</div>`; }
    if (ref === 'weather') { const w = PV.weatherFor(sh.home.key, (sh.game.at || '').slice(0, 10), sh); body += `<div class="hint">${w ? `${w.live ? 'Live from Open-Meteo' : 'Saved forecast (no answer from Open-Meteo yet)'} for ${esc(PV.wxTown(sh) || sh.home.name)}: ${w.now ? `now ${w.now.temp}° and ${w.now.text.toLowerCase()}; ` : ''}${w.text}, high ${w.hi}°, low ${w.lo}°, ${w.pop}% chance of rain.` : 'No forecast for this date yet.'}</div>`; }
    const s = modal(`<div class="dlgh"><b>Edit ${esc(name)}</b><span class="sp"></span><span class="hint">Live preview</span></div>
      <div class="dlgb"><div class="gestage"><canvas id="geCv"></canvas><div class="gfxhost" id="geHost"></div></div>${body}</div>
      <div class="dlgf"><span class="sp"></span><button class="btn" id="geCancel">Cancel</button><button class="btn" id="geSave">Save</button><button class="btn pri" id="geUse">Save and put in Preview</button></div>`, 'dlg-ge', () => cancelAnimationFrame(raf));
    const stage = G.createStage(s.querySelector('#geHost'));
    const val = id => { const el = s.querySelector(id); return el ? el.value.trim() : null; };
    /* build the graphic with the words being typed, without touching the show */
    const build = () => {
      const keepText = st.text[ref], keepFeat = sh[side].featured, keepCoach = [sh[side].coach, sh[side].coachSeason], keepOff = sh.officials;
      try {
        const t1 = val('#geT1'), t2 = val('#geT2');
        const w0 = typed();
        if (t1 != null || t2 != null || val('#geT3') != null || cap) { if (w0) st.text[ref] = w0; else delete st.text[ref]; }
        if (feat) sh[side].featured = val('#geFeat');
        if (coach) { sh[side].coach = val('#geCoach'); sh[side].coachSeason = val('#geSeason'); }
        if (ref === 'officials') sh.officials = $$('[data-of]', s).map(x => x.value.trim());
        // drawn as it will go to air: in the look that's on, with the scorebug if it's up
        const g = Object.assign(gfxSet(E, ref), { pkg: st.gfx.pkg, burn: st.gfx.burn, wm: st.gfx.wm, scorebug: !!st.gfx.scorebug });
        if (g.lower) g.lower.at = 0; if (g.take) g.take.at = 0;
        return g;
      } finally { if (keepText) st.text[ref] = keepText; else delete st.text[ref]; sh[side].featured = keepFeat; sh[side].coach = keepCoach[0]; sh[side].coachSeason = keepCoach[1]; sh.officials = keepOff; }
    };
    // the words being typed, for a look that reads them while it draws (the big score)
    const lines = () => $$('[data-ln]', s).map(x => x.value.trim());
    function typed() { const t1 = val('#geT1'), t2 = val('#geT2'), t3 = val('#geT3'), l = lines(); return t1 || t2 || t3 || l.some(Boolean) ? Object.assign({ title: t1 || '', sub: t2 || '' }, t3 ? { foot: t3 } : {}, l.some(Boolean) ? { lines: l } : {}) : null; }
    let gfx = build(), words = typed(), raf = 0;
    s.addEventListener('input', () => { gfx = build(); words = typed(); });
    s.addEventListener('change', () => { gfx = build(); words = typed(); });
    const draw = () => {
      if (!s.isConnected) return;
      const cv = s.querySelector('#geCv'), [w, h] = UI.fit(cv, 960), t = Date.now();
      UI.drawSource(cv.getContext('2d'), w, h, st.program, st, t);
      const text = Object.assign({}, st.text); if (words) text[ref] = words; else delete text[ref];
      stage.update(Object.assign({}, st, { program: 'cam1', gfx, text, trans: Object.assign({}, st.trans, { active: null }), brk: false }), t);
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    const save = use => {
      const t1 = val('#geT1'), t2 = val('#geT2');
      if (feat) UI.send('feat.set', side, val('#geFeat'));
      if (coach) UI.send('show.coach', side, { coach: val('#geCoach'), coachSeason: val('#geSeason') });
      if (ref === 'officials') UI.send('show.officials', $$('[data-of]', s).map(x => x.value.trim()));
      const t3 = val('#geT3');
      if (t1 != null || t2 != null || t3 != null || cap) UI.send('gfx.text', ref, { title: t1 || '', sub: t2 || '', foot: t3 || '', lines: lines() });
      if (use) UI.send('pv.gfx', ref === 'big' ? { t: 'tog', k: 'big' } : { t: 'cat', ref }, false);
      s.close();
    };
    s.querySelector('#geSave').onclick = () => save(false);
    s.querySelector('#geUse').onclick = () => save(true);
    s.querySelector('#geCancel').onclick = () => s.close();
    s.keys.push(e => { if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); save(false); } });
  };

  /* ======================================================================
     Team stats side by side (soccer): pick what to show, check or type the numbers
     ====================================================================== */
  UI.teamStats = function () {
    const st = PV.E.st, sh = st.show;
    const picked = PV.store.get('compsPick', ['Corner kicks']);
    const row = l => `<tr><td><label class="chk"><input type="checkbox" value="${esc(l)}" ${picked.includes(l) ? 'checked' : ''}>${esc(l)}</label></td>
      ${['away', 'home'].map(sd => `<td><input type="text" inputmode="numeric" class="inp tsn" data-l="${esc(l)}" data-sd="${sd}" value="${esc(PV.teamStat(st, l, sd))}" maxlength="4" aria-label="${esc(sh[sd].code)} ${esc(l)}"></td>`).join('')}</tr>`;
    const s = modal(`<div class="dlgh"><b>Team stats</b><span class="sp"></span>${st.live ? '<span class="status">Live stats</span>' : ''}</div>
      <div class="dlgb"><div class="hint">Tick one for a single stat, or up to six to show them in columns. ${st.live ? 'Numbers come from the live stats; type over any of them.' : 'Type the numbers; they\'re kept for this game.'}</div>
        <table class="tst"><thead><tr><th></th><th>${UI.logo(sh.away, sh.colors.away, 16)} ${esc(sh.away.code)}</th><th>${UI.logo(sh.home, sh.colors.home, 16)} ${esc(sh.home.code)}</th></tr></thead><tbody>${PV.SOCCER_STATS.map(row).join('')}</tbody></table></div>
      <div class="dlgf"><span class="sp"></span><button class="btn" id="tsCancel">Cancel</button><button class="btn" id="tsSave">Save</button><button class="btn pri" id="tsUse">Save and put in Preview</button></div>`, 'dlg-ts');
    const save = use => {
      const picks = $$('input[type=checkbox]', s).filter(x => x.checked).map(x => x.value).slice(0, 6);
      if (use && !picks.length) { UI.toast('Tick at least one'); return; }
      // only numbers typed over the live ones are kept as typed
      const vals = {};
      $$('.tsn', s).forEach(x => { const l = x.dataset.l, v = x.value.trim(); vals[l] = vals[l] || {}; vals[l][x.dataset.sd] = st.live && v === PV.teamStat(Object.assign({}, st, { show: Object.assign({}, sh, { comps: {} }) }), l, x.dataset.sd) ? '' : v; });
      UI.send('sb.comps', vals);
      PV.store.set('compsPick', picks);
      if (use) UI.send('pv.gfx', { t: 'l3', spec: { kind: 'comps', picks } }, false);
      s.close();
    };
    s.querySelector('#tsCancel').onclick = () => s.close();
    s.querySelector('#tsSave').onclick = () => save(false);
    s.querySelector('#tsUse').onclick = () => save(true);
    s.addEventListener('change', e => { if (e.target.type === 'checkbox' && $$('input[type=checkbox]:checked', s).length > 6) { e.target.checked = false; UI.toast('Six at most'); } });
  };

  /* ======================================================================
     Lower-third stat picker (game or season)
     ====================================================================== */
  /* a player's bio (filled in from the roster, change anything) or a note for the Text lower third */
  UI.l3Editor = function (side, num, kind, then) {
    const E = PV.E, st = E.st, sh = st.show, t = sh[side], p = PV.player(sh, side, num); if (!p) return;
    const w = PV.l3words(st, side, p[0], kind) || {};
    const rosterName = `${p[1]} ${p[2]}`.trim(), rosterLine = [p[3], p[4], p[5], p[6]].filter(Boolean).join(' · ');
    const bio = kind === 'bio';
    const s = modal(`<div class="dlgh">${UI.logo(t, sh.colors[side], 22)}<b style="margin-left:8px">#${esc(p[0])} ${esc(rosterName)} · ${bio ? 'bio' : 'note'}</b><span class="sp"></span><span class="hint">Live preview</span></div>
      <div class="dlgb"><div class="gestage"><canvas id="leCv"></canvas><div class="gfxhost" id="leHost"></div></div>${bio ? `<div class="fld"><label>Name</label><input type="text" id="leName" value="${esc(w.name || rosterName)}" maxlength="40"></div>
        <div class="fld"><label>Second line</label><input type="text" id="leSub" value="${esc(w.sub != null && w.sub !== '' ? w.sub : rosterLine)}" maxlength="90" placeholder="Class · position · height · hometown"></div>
        <div class="hint">Filled in from the roster. Your changes are kept for this player in later shows too.</div>`
        : `<div class="fld"><label>Note</label><input type="text" id="leSub" value="${esc(w.sub || '')}" maxlength="90" placeholder="e.g. 1st goal this season (8')"></div>
        <div class="fld"><label>Box under it <span class="hint" style="text-transform:none;letter-spacing:0">(leave empty for none)</span></label><input type="text" id="leDrop" value="${esc(w.drop || '')}" maxlength="60" placeholder="e.g. Today, Entering today, 10th career goal"></div>
        <div class="hint">The note shows under the player's name; the box under the lower third fits what you type.</div>`}</div>
      <div class="dlgf">${bio && (w.name || w.sub) ? '<button class="btn ghost" id="leReset">Back to the roster</button>' : ''}${!bio && (w.sub || w.drop) ? '<button class="btn ghost red" id="leReset">Clear the note</button>' : ''}<span class="sp"></span><button class="btn" id="leCancel">Cancel</button><button class="btn pri" id="leSave">Save</button></div>`, 'dlg-ge', () => cancelAnimationFrame(raf));
    const val = id => { const el = s.querySelector(id); return el ? el.value.trim() : ''; };
    // what would be stored: a bio left as the roster has it isn't a change
    const words = () => bio ? { name: val('#leName') === rosterName ? '' : val('#leName'), sub: val('#leSub') === rosterLine ? '' : val('#leSub') } : { sub: val('#leSub'), drop: val('#leDrop') };
    /* the lower third with the words being typed, drawn as it will go to air */
    const stage = G.createStage(s.querySelector('#leHost'));
    const k = `${side}|${p[0]}|${kind}`;
    const build = () => {
      const keep = st.l3text;
      try {
        const o = words(); st.l3text = Object.assign({}, keep); if (o.name || o.sub || o.drop) st.l3text[k] = o; else delete st.l3text[k];
        const L = E.buildLower({ kind, side, num: p[0] }); L.at = 0;
        return { scorebug: !!st.gfx.scorebug, water: false, big: false, ticker: false, lower: L, full: null, take: null, trans: null, pkg: st.gfx.pkg, burn: st.gfx.burn, wm: st.gfx.wm };
      } finally { st.l3text = keep; }
    };
    let gfx = build(), raf = 0;
    s.addEventListener('input', () => { gfx = build(); });
    const draw = () => {
      if (!s.isConnected) return;
      const cv = s.querySelector('#leCv'), [cw, ch] = UI.fit(cv, 960), tm = Date.now();
      UI.drawSource(cv.getContext('2d'), cw, ch, st.program, st, tm);
      stage.update(Object.assign({}, st, { program: 'cam1', gfx, trans: Object.assign({}, st.trans, { active: null }), brk: false }), tm);
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    const save = () => {
      const o = words();
      UI.send('l3.text', { side, num: p[0], kind }, o); s.close();
      if (then && (o.sub || o.name || o.drop)) then();
    };
    s.querySelector('#leSave').onclick = save;
    s.querySelector('#leCancel').onclick = () => s.close();
    const r = s.querySelector('#leReset'); if (r) r.onclick = () => { UI.send('l3.text', { side, num: p[0], kind }, {}); s.close(); };
    s.keys.push(e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
    setTimeout(() => { const f = s.querySelector(bio ? '#leName' : '#leSub'); f.focus(); f.select(); }, 30);
  };

  UI.statPicker = function (side, num, mode) {
    const st = PV.E.st, sh = st.show, t = sh[side];
    const p = PV.player(sh, side, num); if (!p) return;
    // this sport's stats; a season stat is offered when someone on the team has it on file
    const S = PV.statLists(st, side, p[0], mode), list = S.list, has = S.has;
    const key = PV.l3key(side, p[0], mode);
    const cur = st.l3pick[key] || S.pick;
    const s = modal(`<div class="dlgh">${UI.logo(t, sh.colors[side], 22)}<b style="margin-left:8px">#${esc(p[0])} ${esc(p[1])} ${esc(p[2])} · ${mode === 'game' ? 'game stats' : 'season stats'}</b></div>
      <div class="dlgb"><div class="hint">Pick up to three, in the order they should show.</div>
        <div class="stpick">${Object.keys(list).map(k => `<label class="chk${has(k) ? '' : ' off'}"${has(k) ? '' : ' title="Not in the season stats yet"'}><input type="checkbox" value="${k}" ${cur.includes(k) ? 'checked' : ''} ${has(k) ? '' : 'disabled'}>${list[k][1]}<small>${list[k][0]}</small></label>`).join('')}</div>
        <label class="chk" style="margin-top:10px"><input type="checkbox" id="spAll">Use these for every ${esc(t.name)} player</label></div>
      <div class="dlgf"><span class="sp"></span><button class="btn" id="spCancel">Cancel</button><button class="btn pri" id="spSave">Save</button></div>`, 'dlg-sp');
    let order = cur.filter(k => list[k]);
    s.querySelector('.stpick').addEventListener('change', e => {
      const el = e.target; if (!el.value) return;
      if (el.checked) { if (order.length >= 3) { el.checked = false; UI.toast('Three stats at most'); return; } order.push(el.value); } else order = order.filter(k => k !== el.value);
    });
    s.querySelector('#spCancel').onclick = () => s.close();
    s.querySelector('#spSave').onclick = () => {
      if (!order.length) { UI.toast('Pick at least one'); return; }
      const keys = s.querySelector('#spAll').checked ? t.roster.map(r => PV.l3key(side, r[0], mode)) : [key];
      keys.forEach(k => UI.send('l3.pick', k, order));
      s.close();
    };
  };
})();
