/* Pivot core: the show state, the engine that runs the show, actions, rundown, playlists,
   shortcuts, macros, saved profiles and templates, and the link between windows and screens. */
(function () {
  const D = window.PIVOT_DATA, S = window.PIVOT_SIM, G = window.PIVOT_GFX;
  const PV = window.PV = {};
  const uid = () => 'i' + Math.random().toString(36).slice(2, 9);
  const now = () => Date.now();
  PV.uid = uid; PV.now = now;
  PV.APP_URL = 'https://claude.ai/artifact/Dy9qV4XbFybrPsFq1d1pJJ';

  /* ---------- safe local storage ---------- */
  // inside the Mac app, settings live in the app's own store instead of browser storage
  const store = window.__pivotStore || {
    get(k, d) { try { const v = localStorage.getItem('pivot.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('pivot.' + k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  };
  PV.store = store;
  // a wipe runs as long as the look's own wipe does, if it brings one; the picture changes at its midpoint
  // where the picture changes during a wipe: half way through it
  PV.wipeHalf = (st, to, wid) => (window.PIVOT_GFX && window.PIVOT_GFX.wipeMs ? window.PIVOT_GFX.wipeMs(st, { from: st.program, to, wipe: wid || 'replay' }) : 1000) / 2;
  // where the picture changes under an end stamp: once it covers the screen
  PV.stampCut = (st, sid) => { const tr = PV.sting(st, { type: 'stinger', from: st.program, to: st.program, stamp: sid }); return tr.dur * tr.at; };
  // tr.at: how far through it the picture changes (an end stamp changes it once the screen is covered)
  PV.sting = (st, tr) => { const G = window.PIVOT_GFX; tr.dur = G && G.wipeMs ? G.wipeMs(st, tr) : 1000; tr.at = G && G.wipeAt ? G.wipeAt(st, tr) : 0.5; return tr; };

  /* ---------- the show: built from the game picked on the start screen ---------- */
  PV.makeShow = function (game, edits, prev) {
    edits = edits || {};
    const sport = game.sport;
    const home = D.team(game.home, sport, edits[game.home]);
    const away = D.team(game.away, sport, edits[game.away]);
    const fm = store.get('featured', {});
    for (const t of [home, away]) { const n = fm[t.key + '|' + sport]; if (n && t.roster.some(r => r[0] === n)) t.featured = n; }
    const v = D.venueFor(game);
    return {
      game: { id: game.id, fr: game.fr || null, at: game.at, sport, venue: game.manualVenue || v.venue, city: game.manualCity || v.city, state: game.manualState || v.state, manual: !!game.manual },
      sport, rules: D.RULES[sport], home, away,
      colors: S.teamColors(home, away),
      event: D.SPORTS[sport], network: 'NEC Front Row',
      announcers: (prev && prev.announcers) || store.get('announcers', null) || [{ role: 'Play-by-play', name: 'Announcer One' }, { role: 'Analyst', name: 'Announcer Two' }]
    };
  };
  const games = {};
  PV.gameFor = function (show) { const k = show.sport + '|' + show.home.key + '|' + show.away.key; return games[k] || (games[k] = S.makeGame(k, show.home.key + show.away.key)); };
  PV.lookFor = function (show) {
    const row = (side, n) => show[side].roster.find(r => r[0] === n) || [n];
    return { home: show.colors.home, away: show.colors.away, homeTeam: show.home, awayTeam: show.away, event: show.event,
      starters: { home: show.home.starters.map(n => row('home', n)), away: show.away.starters.map(n => row('away', n)) } };
  };
  PV.player = (show, side, num) => show[side].roster.find(r => r[0] === String(num));
  PV.worldT = (st, t) => ((t || now()) - st.epoch) / 1000 + 60;
  /* the desk clock (ms) for a moment of show time, the other way round */
  PV.wallOf = (st, T) => st.epoch + (T - 60) * 1000;
  /* a game that starts at 5 PM or later is tonight's; earlier, today's */
  PV.tonight = sh => +String((sh && sh.game && sh.game.at) || '').slice(11, 13) >= 17;
  PV.todayWord = sh => PV.tonight(sh) ? 'Tonight' : 'Today';
  /* a standings streak ("W5", "L 3", "T1") as words: Won last 5 games, Lost last game */
  PV.streakWords = s => {
    const m = /^\s*([WLT])\w*\s*(\d+)/i.exec(String(s || '')); if (!m) return '';
    const n = +m[2], w = { W: 'Won', L: 'Lost', T: 'Tied' }[m[1].toUpperCase()];
    return n === 1 ? `${w} last game` : `${w} last ${n} games`;
  };
  PV.ordinal = n => n + (['th', 'st', 'nd', 'rd'][(n % 100 > 10 && n % 100 < 14) ? 0 : n % 10] || 'th');
  PV.gameDate = g => { const d = new Date(g.at); return d; };
  PV.fmtDate = (at, opt) => { try { return new Date(at).toLocaleDateString([], opt || { weekday: 'long', month: 'long', day: 'numeric' }); } catch (e) { return at; } };
  PV.fmtTime = at => { try { return new Date(at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); } catch (e) { return ''; } };

  /* ---------- inputs and sources ---------- */
  PV.SOURCES = [
    { id: 'cam1', short: 'CAM 1' }, { id: 'cam2', short: 'CAM 2' }, { id: 'cam3', short: 'CAM 3' }, { id: 'cam4', short: 'CAM 4' },
    { id: 'replay', short: 'REPLAY' }, { id: 'video', short: 'VIDEO' }, { id: 'me', short: 'M/E' }, { id: 'black', short: 'BLACK' }, { id: 'bars', short: 'BARS' }
  ];
  PV.CAM_FORMATS = ['1080p59.94', '1080p29.97', '1080i59.94', '720p59.94', '2160p29.97', '2160p59.94'];
  PV.DEVICES = ['Blackmagic UltraStudio Recorder 3G (1)', 'Blackmagic UltraStudio Recorder 3G (2)', 'Blackmagic UltraStudio Recorder 3G (3)', 'Blackmagic UltraStudio Recorder 3G (4)',
    'Blackmagic breakout chassis · Input 1', 'Blackmagic breakout chassis · Input 2', 'Blackmagic breakout chassis · Input 3', 'Blackmagic breakout chassis · Input 4',
    'NDI · iPhone (camera app)', 'NDI · Second Mac', 'Sample feed'];
  /* "CAM 3 · Baseline", or just "CAM 3" when the camera has no name */
  PV.srcLabel = (st, id) => { const n = PV.srcName(st, id); return n && n.toUpperCase() !== PV.srcShort(id) ? `${PV.srcShort(id)} · ${n}` : PV.srcShort(id); };
  PV.srcName = (st, id) => /^cam/.test(id) ? (st.inputs[id] || {}).name || '' : id === 'me' ? ((PV.meSel(st) || {}).name || 'M/E') : ({ replay: 'Replay', video: 'Video', black: 'Black', bars: 'Color bars' }[id] || id);
  PV.meSel = st => st.me && (st.me.list.find(m => m.id === st.me.sel) || st.me.list[0]);

  /* ---------- M/E: composed shots (split screen, picture in picture, boxes) ---------- */
  PV.ME_SPOTS = [
    ['full', 'Full frame', [0, 0, 1, 1]], ['left', 'Left half', [0, 0, 0.5, 1]], ['right', 'Right half', [0.5, 0, 0.5, 1]],
    ['boxL', 'Left box', [0.06, 0.2, 0.42, 0.56]], ['boxR', 'Right box', [0.52, 0.2, 0.42, 0.56]],
    ['pipBR', 'Corner, bottom right', [0.64, 0.6, 0.32, 0.32]], ['pipBL', 'Corner, bottom left', [0.04, 0.6, 0.32, 0.32]], ['pipTR', 'Corner, top right', [0.64, 0.08, 0.32, 0.32]], ['pipTL', 'Corner, top left', [0.04, 0.08, 0.32, 0.32]],
    ['q1', 'Top left quarter', [0, 0, 0.5, 0.5]], ['q2', 'Top right quarter', [0.5, 0, 0.5, 0.5]], ['q3', 'Bottom left quarter', [0, 0.5, 0.5, 0.5]], ['q4', 'Bottom right quarter', [0.5, 0.5, 0.5, 0.5]]
  ];
  const lay = (src, spot, border) => { const s = PV.ME_SPOTS.find(x => x[0] === spot); const [x, y, w, h] = s[2]; return { src, spot, x, y, w, h, border: !!border }; };
  PV.defaultMEs = () => [
    { id: 'me-split', name: 'Split', bg: 'black', layers: [lay('cam2', 'left'), lay('cam3', 'right')] },
    { id: 'me-pip', name: 'PiP', bg: 'black', layers: [lay('cam1', 'full'), lay('cam2', 'pipBR', true)] },
    { id: 'me-box', name: 'Two boxes', bg: 'team', layers: [lay('cam2', 'boxL', true), lay('cam4', 'boxR', true)] },
    { id: 'me-quad', name: 'Four cameras', bg: 'black', layers: [lay('cam1', 'q1'), lay('cam2', 'q2'), lay('cam3', 'q3'), lay('cam4', 'q4')] }
  ];
  PV.meLayer = lay;
  PV.srcShort = id => { const s = PV.SOURCES.find(x => x.id === id); if (s) return s.short; const m = /^cam(\d+)$/.exec(id); return m ? 'CAM ' + m[1] : String(id).toUpperCase(); };
  /* the camera slots this show has, in order (4 by default, up to 8) */
  PV.MAX_CAMS = 8;
  PV.camIds = st => Object.keys((st && st.inputs) || {}).filter(k => /^cam\d+$/.test(k)).sort((a, b) => +a.slice(3) - +b.slice(3));
  PV.isCam = (st, s) => /^cam\d+$/.test(s) && !!(st && st.inputs && st.inputs[s]);

  /* ---------- recording math ---------- */
  PV.FORMATS = {
    hevc: { name: 'HEVC (H.265)', note: 'Default. Near-ProRes quality, small files.', mbps: { good: 16, better: 25, best: 34 } },
    h264: { name: 'H.264', note: 'Plays anywhere. Bigger and a bit softer than HEVC.', mbps: { good: 28, better: 35, best: 45 } },
    proxy: { name: 'ProRes Proxy', note: 'Easy editing, large files.', mbps: { good: 90, better: 90, best: 90 } },
    lt: { name: 'ProRes 422 LT', note: 'Editing quality, very large files.', mbps: { good: 204, better: 204, best: 204 } },
    p422: { name: 'ProRes 422', note: 'Full editing quality, the largest files.', mbps: { good: 293, better: 293, best: 293 } }
  };
  PV.gbPerHour = mbps => mbps * 3600 / 8 / 1000;

  /* ---------- graphics catalogue: what can go in a playlist or rundown ---------- */
  PV.GFX = [
    ['title', 'Title card', 'full'], ['scene', 'Scene setter', 'lower'], ['announcers', 'Talent', 'lower'],
    ['tapeSeason', 'Inside the matchup', 'full'], ['standings', 'Standings', 'full'],
    ['featAway', '{A} featured', 'full'], ['featHome', '{H} featured', 'full'],
    ['coachAway', '{A} coach', 'lower'], ['coachHome', '{H} coach', 'lower'],
    ['fiveAway', '{A} starting five', 'take'], ['fiveHome', '{H} starting five', 'take'],
    ['lineups', 'Starting lineups', 'full'], ['tape', 'Tale of the tape (live)', 'full'], ['board', 'Score board', 'full'],
    ['coming', 'Coming up', 'full'], ['ticker', 'Around the NEC ticker', 'ticker']
  ];
  /* catalogue graphics that go up as lower thirds; a look can add its own (ESPN's weather and officials drop from its scorebug) */
  PV.LOWER_REFS = ['announcers', 'scene', 'coachAway', 'coachHome'];
  PV.isLowerRef = (ref, st) => {
    if (PV.LOWER_REFS.includes(ref)) return true;
    st = st || (PV.E && PV.E.st);
    const P = st && st.gfx && G && G.pkgOf ? G.pkgOf(st.gfx.pkg) : null;
    return !!(P && P.build && (P.build.lowers || []).includes(ref));
  };
  /* graphics a look leaves out (ESPN's has no ticker) */
  PV.lookLacks = (what, st) => {
    st = st || (PV.E && PV.E.st);
    const P = st && st.gfx && G && G.pkgOf ? G.pkgOf(st.gfx.pkg) : null;
    return !!(P && P.build && (P.build.without || []).includes(what));
  };
  /* pictures a look brings in sets of its own (a set can be for some sports only), each with a drawer of its own */
  PV.lookSets = st => {
    st = st || (PV.E && PV.E.st);
    const P = st && st.gfx && G && G.pkgOf ? G.pkgOf(st.gfx.pkg) : null;
    return ((P && P.build && P.build.sets) || []).filter(s => !s.sports || s.sports.includes(st.show.sport));
  };
  PV.lookPic = (st, key) => { const [s, i] = String(key || '').split(':'); const set = PV.lookSets(st).find(x => x.id === s); return set ? set.items.find(x => x.id === i) || null : null; };
  /* the wipes a look can use: one without its own team wipes leaves out the team and player ones */
  PV.wipesOf = st => { const off = PV.lookLacks('teamWipes', st); return st.trans.wipes.filter(w => !(off && (w.kind === 'team' || w.kind === 'player'))); };
  PV.wipeOk = (st, id) => PV.wipesOf(st).some(w => w.id === id);
  PV.lowerSpec = ref => ref === 'coachAway' || ref === 'coachHome' ? { kind: 'coach', side: ref === 'coachAway' ? 'away' : 'home' } : { kind: ref };
  PV.lowerKeyOfRef = ref => ref === 'coachAway' ? 'coachaway' : ref === 'coachHome' ? 'coachhome' : ref;
  /* in and out points for one angle of a replay */
  PV.cut = (clip, ang) => (clip.cuts && clip.cuts[ang]) || { tIn: clip.tIn, tOut: clip.tOut };
  PV.cutLen = (clip, ang) => { const c = PV.cut(clip, ang); return c.tOut - c.tIn; };
  /* a graphic's name: the operator's own (⌘R), or the catalogue's with the teams' codes in it */
  PV.gfxName = (ref, st) => {
    st = st || (PV.E && PV.E.st);
    const own = st && st.gfxNames && st.gfxNames[ref]; if (own) return own;
    const n = (PV.GFX.find(g => g[0] === ref) || [ref, ref])[1], sh = st && st.show;
    return n.replace('{A}', sh ? sh.away.code : 'Away').replace('{H}', sh ? sh.home.code : 'Home');
  };

  /* ---------- playlists: the left tray holds one per part of the show ---------- */
  function li(type, ref, dur, name) {
    const C = S.CLIPS[ref];
    return { id: uid(), type, ref, name: name || (type === 'video' ? C.name : type === 'reel' ? 'Highlights reel (auto)' : PV.gfxName(ref)), dur: dur != null ? dur : (type === 'video' ? C.dur : 0), played: false };
  }
  function defaultLists() {
    return [
      { id: 'pre', name: 'Pregame', mode: 'one', items: [li('video', 'countdown'), li('gfx', 'coming', 10), li('video', 'nfrpromo')] },
      { id: 'open', name: 'Open', mode: 'one', items: [li('video', 'pivotopen'), li('gfx', 'title', 8), li('gfx', 'scene', 6), li('gfx', 'announcers', 6), li('gfx', 'tapeSeason', 10), li('gfx', 'standings', 10), li('gfx', 'featAway', 10), li('gfx', 'featHome', 10), li('gfx', 'capAway', 10), li('gfx', 'capHome', 10), li('gfx', 'fiveAway', 8), li('gfx', 'fiveHome', 8)] },
      { id: 'g1', name: '1st Half', mode: 'one', items: [li('gfx', 'tape', 10), li('gfx', 'ticker', 0), li('gfx', 'coming', 8)] },
      { id: 'half', name: 'Halftime', mode: 'order', items: [li('video', 'halfopen'), li('gfx', 'board', 10), li('reel', 'reel'), li('gfx', 'tape', 10), li('video', 'nfrpromo'), li('gfx', 'comingHalf', 8)] },
      { id: 'g2', name: '2nd Half', mode: 'one', items: [li('gfx', 'tape', 10), li('gfx', 'standings', 10), li('gfx', 'coming', 8)] },
      { id: 'post', name: 'Postgame', mode: 'one', items: [li('gfx', 'board', 12), li('reel', 'reel'), li('video', 'bumper')] },
      { id: 'brk', name: 'Break', mode: 'order', items: [li('video', 'sponsor1'), li('video', 'nfrpromo'), li('video', 'sponsor2'), li('video', 'bumper')] }
    ];
  }
  PV.RD_TAG = { gfx: 'GFX', video: 'VID', cue: 'CUE', cam: 'CAM', break: 'BRK', playlist: 'PL' };
  PV.PL_MODES = [['one', 'One at a time'], ['order', 'In order'], ['loop', 'Loop']];

  /* A show saved before graphics were swapped or retired gets the same changes as a new one: the team capsules for the
     head coaches, no Coming up after the game, the halftime Coming up of its own, and none of the retired graphics */
  const RETIRED = ['scores', 'campusAway', 'campusHome', 'seasonLeaders'];
  PV.updateShow = function (st) {
    const sh = st.show, cap = { coachAway: 'capAway', coachHome: 'capHome' };
    st.rd.items = st.rd.items.filter(it => {
      const ref = it.act && it.act[0] === 'gfx.play' ? it.act[1] : null;
      if (!ref) return true;
      if (RETIRED.includes(ref) || (ref === 'coming' && /^post/i.test(it.seg))) return false;
      if (cap[ref]) { const s = ref === 'coachAway' ? 'away' : 'home'; it.act = ['gfx.play', cap[ref]]; it.label = `${sh[s].code} capsule`; it.sub = 'Name, coach, record and form'; }
      return true;
    });
    for (const l of st.pl.lists || []) {
      l.items = l.items.filter(i => !(i.type === 'gfx' && (RETIRED.includes(i.ref) || (l.id === 'post' && i.ref === 'coming'))));
      for (const i of l.items) if (i.type === 'gfx') {
        if (cap[i.ref]) { i.ref = cap[i.ref]; i.name = PV.gfxName(i.ref, st); i.dur = 10; }
        if (l.id === 'half' && i.ref === 'coming') { i.ref = 'comingHalf'; i.name = PV.gfxName(i.ref, st); }
      }
    }
  };

  /* ---------- copyright: who the show is produced for (the league, or a school), and the year ---------- */
  PV.LEAGUE_NAMES = { NEC: 'Northeast Conference' };
  // the year it goes to air (the computer's clock), not the year the game was scheduled in
  PV.showYear = () => new Date().getFullYear();
  PV.copyrightOwner = show => show.rightsHolder || PV.LEAGUE_NAMES[show.league || 'NEC'] || show.league || 'Northeast Conference';

  /* ---------- rundown: every mark to hit, in order ---------- */
  PV.buildRundown = function (show) {
    const R = show.rules, A = show.away, H = show.home, out = [];
    const add = (seg, label, sub, act, kind) => out.push({ id: uid(), seg, label, sub: sub || '', act: act || null, kind: kind || (act ? 'gfx' : 'cue') });
    const g = ref => ['gfx.play', ref];
    add('Open', 'Show open', 'Video, about 0:12', ['pl.cue', 'pivotopen'], 'video');
    add('Open', 'Title card', `${A.name} at ${H.name}`, g('title'));
    add('Open', 'Scene setter', [show.game.venue, [show.game.city, show.game.state].filter(Boolean).join(', ')].filter(Boolean).join(' · ') || 'Venue', g('scene'));
    out.push({ id: uid(), seg: 'Open', label: 'Two-shot', sub: 'Talent on camera', act: ['auto', 'cam2'], kind: 'cam', cam: 'cam2' });
    add('Open', 'Talent', show.announcers.map(a => a.name).join(' & '), g('announcers'));
    add('Open', 'Inside the matchup', 'Season averages', g('tapeSeason'));
    add('Open', 'Standings', `NEC ${show.event}`, g('standings'));
    const fp = (side) => { const p = PV.player(show, side, show[side].featured); return p ? `#${p[0]} ${p[1]} ${p[2]}` : 'Pick a player'; };
    add('Open', `${A.code} featured player`, fp('away'), g('featAway'));
    add('Open', `${H.code} featured player`, fp('home'), g('featHome'));
    add('Open', 'Animate to live', 'Cue', null);
    add('Open', `${A.code} capsule`, 'Name, coach, record and form', g('capAway'));
    add('Open', `${H.code} capsule`, 'Name, coach, record and form', g('capHome'));
    add('Tip-off', 'Tip-off', 'Starts the game clock', ['sb.tip'], 'cue');
    add('Tip-off', 'Officials', 'Verbal mention', null);
    add('Tip-off', `${A.code} starting five`, 'Scorebug takeover', g('fiveAway'));
    add('Tip-off', `${H.code} starting five`, 'Scorebug takeover', g('fiveHome'));
    let b = 0;
    const per = p => R.periods === 2 ? (p === 1 ? '1st Half' : '2nd Half') : `${PV.ordinal(p)} Quarter`;
    for (let p = 1; p <= R.periods; p++) {
      for (const m of R.media) add(per(p), `Under ${m}:00 · Break ${++b}`, 'Media timeout, first dead ball', ['brk.toggle'], 'break');
      if (p === R.halftimeAfter) {
        add('Halftime', 'Halftime board', 'Full screen', ['gfx.full', 'board']);
        add('Halftime', 'Roll Halftime playlist', 'Highlights, stats, promo', ['pl.play', 'half', 0], 'playlist');
      } else if (p < R.periods) {
        add(per(p), `End of ${PV.ordinal(p)} · Break ${++b}`, 'Between quarters', ['brk.toggle'], 'break');
      }
    }
    add('Postgame', 'Final board', 'Full screen', ['gfx.full', 'board']);
    add('Postgame', 'Highlights', 'Auto reel from replays', ['pl.play', 'post', 1], 'playlist');
    add('Postgame', 'Close', 'Talent close copy', null);
    add('Postgame', 'Copyright', `© ${PV.showYear(show)} ${PV.copyrightOwner(show)}`, g('copyright'));
    return out;
  };

  /* ---------- default state ---------- */
  function defaultState(show) {
    const t = now();
    const R = show.rules;
    const st = {
      v: 1, eng: uid(), epoch: t, pin: String(1000 + Math.floor(Math.random() * 9000)),
      show,
      inputs: {
        cam1: { name: 'Wide', device: PV.DEVICES[0], fmt: '1080p59.94' },
        cam2: { name: 'Tight', device: PV.DEVICES[1], fmt: '1080p59.94' },
        cam3: { name: '', device: PV.DEVICES[2], fmt: '1080i59.94' },
        cam4: { name: '', device: PV.DEVICES[3], fmt: '1080p59.94' }
      },
      program: 'cam1', preview: 'cam2',
      trans: { type: 'mix', dur: 600, active: null },
      gfx: { pkg: 'arena', scorebug: true, ticker: false, tickerData: null, lower: null, full: null, take: null, lowerHold: 0, burn: { on: true, pos: 'tl' } },
      sb: { feed: 'box', boxOk: true, op: 'box', period: 1, clock: R.len * 60000, running: false, at: t, score: { home: 0, away: 0 }, fouls: { home: 0, away: 0 }, bonus: { home: false, away: false }, timeouts: { home: R.timeouts || 4, away: R.timeouts || 4 }, poss: 'home', status: 'pre', flag: '' },
      rp: { back: 8, angles: ['cam2', 'cam3', 'cam4', 'cam1'], speed: 0.75, clips: [], playing: null, n: 0, lists: [] },
      vlists: [],
      pl: { left: 'open', active: null, cue: {}, last: null, lists: defaultLists() },
      rd: { items: PV.buildRundown(show), idx: -1, on: false, cue: 0 },
      text: {},
      me: { list: PV.defaultMEs(), sel: 'me-split' },
      audio: { mode: '4ch', ch: [{ name: 'Voice 1', fader: 0.8, mute: false }, { name: 'Voice 2', fader: 0.8, mute: false }, { name: 'Nats L', fader: 0.7, mute: false }, { name: 'Nats R', fader: 0.7, mute: false }], master: 0.85, device: 'USB mixer (4 channels)', pgmMute: false, hp: false },
      brk: false, brkSave: null,
      rec: { on: false, start: 0, fmt: 'hevc', q: 'better', feeds: { cam1: false, cam2: false, cam3: false, cam4: false, program: true, clean: false }, folder: 'Movies/Pivot' },
      stream: { on: false, start: 0, kbps: 6000, res: '1080p60', dests: [{ id: 'hudl', name: 'Hudl', on: true }, { id: 'youtube', name: 'YouTube', on: false }, { id: 'vimeo', name: 'Vimeo', on: false }, { id: 'facebook', name: 'Facebook', on: false }, { id: 'rtmp', name: 'Custom RTMP', on: false }] },
      out: { device: 'Blackmagic UltraStudio Monitor 3G', feed: 'program', hdmi: 'multiview', ndi: { program: true, clean: false, gfx: false } },
      sugg: [],
      macro: { running: null, recording: false },
      tpl: { id: 'nec-arena', locks: {} },
      profile: { name: 'KJ', trialEnds: t + 7 * 864e5 }
    };
    // more camera slots, if this Mac's shows use them
    const n = Math.max(1, Math.min(PV.MAX_CAMS, +store.get('camCount', 4) || 4));
    for (let k = 5; k <= n; k++) st.inputs['cam' + k] = { name: '', device: '', fmt: '1080p59.94' };
    for (let k = n + 1; k <= 4; k++) delete st.inputs['cam' + k];
    if (!st.inputs[st.preview]) st.preview = 'cam1';
    st.rp.angles = st.rp.angles.filter(a => st.inputs[a]);
    return st;
  }
  PV.defaultState = defaultState;

  /* ---------- templates ---------- */
  PV.BUILTIN_TEMPLATES = [
    { id: 'nec-arena', name: 'NEC · Pivot Arena', network: 'arena', league: 'NEC', locks: {} },
    { id: 'nec-tourney', name: 'NEC Tournament · brand locked', network: 'arena', league: 'NEC', locks: { pkg: true } }
  ];

  /* ======================================================================
     ENGINE: only the main window runs it. Everything else sends it actions.
     ====================================================================== */
  function Engine(st) {
    this.st = st;
    this.listeners = [];
    this.macroTimer = null;
    this.runLen = { side: null, pts: 0 };
    this.box = { home: [0, 1, 2, 3, 4].map(blank), away: [0, 1, 2, 3, 4].map(blank) };
    this.lastT = PV.worldT(st);
    this.suggest({ id: 'rd', title: 'Start the rundown', why: 'Pregame', act: ['rd.next'] }, true);
  }
  function clamp01(v) { v = +v; return isFinite(v) ? Math.max(0, Math.min(1, v)) : 0; }
  function blank() { return { pts: 0, fgm: 0, fga: 0, tpm: 0, tpa: 0, ftm: 0, fta: 0, reb: 0, oreb: 0, ast: 0, to: 0, stl: 0, blk: 0, pf: 0, min: 0 }; }
  PV.Engine = Engine;
  Engine.prototype.changed = function () { this.st.v++; for (const f of this.listeners) f(); };
  Engine.prototype.rules = function () { return this.st.show.rules; };

  /* scoring from the scoreboard box (simulated) and the live stats feed */
  Engine.prototype.applyEvents = function (evs) {
    const st = this.st, sb = st.sb, R = this.rules();
    if (!(sb.running && sb.status === 'live')) return;
    for (const ev of evs) {
      const B = this.box;
      if (ev.kind === 'to') { B[ev.side][ev.role].to++; B[ev.stealSide][ev.stealRole].stl++; continue; }
      const p = B[ev.side][ev.role];
      p.fga++; if (ev.three) p.tpa++;
      const def = ev.side === 'home' ? 'away' : 'home';
      if (Math.abs(Math.sin(ev.t * 12.9898)) < 0.3 && sb.feed === 'box') { sb.fouls[def]++; if (sb.fouls[def] >= R.bonus) sb.bonus[ev.side] = true; }
      if (ev.made) {
        const pts = ev.three ? 3 : 2;
        p.fgm++; p.pts += pts; if (ev.three) p.tpm++;
        if (ev.ast != null) B[ev.side][ev.ast].ast++;
        if (sb.feed === 'box') sb.score[ev.side] += pts;
        this.onScore(ev, pts);
      } else if (ev.rebSide) B[ev.rebSide][ev.rebRole].reb++;
    }
  };
  Engine.prototype.starter = function (side, role) {
    const sh = this.st.show; const num = sh[side].starters[role];
    return { p: PV.player(sh, side, num) || [num, '', ''], b: this.box[side][role] };
  };
  Engine.prototype.statFor = function (side, num) {
    const role = this.st.show[side].starters.indexOf(String(num));
    return role >= 0 ? this.box[side][role] : { pts: 0, reb: 0, ast: 0 };
  };
  Engine.prototype.onScore = function (ev, pts) {
    const { p, b } = this.starter(ev.side, ev.role);
    const before = b.pts - pts;
    for (const m of [10, 15, 20, 25, 30]) if (before < m && b.pts >= m) this.suggest({ id: 'pl' + ev.side + ev.role + m, title: `${p[1]} ${p[2]}: ${b.pts} points`, why: `Reached ${m}`, act: ['gfx.lower', { kind: 'player', side: ev.side, num: p[0] }] });
    if (this.runLen.side === ev.side) this.runLen.pts += pts; else this.runLen = { side: ev.side, pts };
    if (this.runLen.pts >= 8 && this.runLen.pts - pts < 8) {
      const t = this.st.show[ev.side];
      this.suggest({ id: 'run' + uid(), title: `${t.name} on a ${this.runLen.pts}-0 run`, why: 'Momentum', act: ['gfx.lower', { kind: 'team', side: ev.side, title: `${t.name} · ${this.runLen.pts}-0 run`, sub: 'Unanswered points' }] });
    }
  };
  Engine.prototype.suggest = function (s, quiet) {
    const st = this.st;
    st.sugg = st.sugg.filter(x => x.id !== s.id);
    s.at = now(); st.sugg.unshift(s); st.sugg = st.sugg.slice(0, 8);
    if (!quiet) this.changed();
  };
  Engine.prototype.leaders = function (side) {
    const arr = this.box[side].map((b, i) => ({ b, p: this.starter(side, i).p }));
    const top = k => arr.slice().sort((x, y) => y.b[k] - x.b[k])[0];
    const nm = p => `${(p[1] || '')[0] || ''}. ${p[2] || ''}`;
    return [{ name: nm(top('pts').p), v: `${top('pts').b.pts} PTS` }, { name: nm(top('reb').p), v: `${top('reb').b.reb} REB` }, { name: nm(top('ast').p), v: `${top('ast').b.ast} AST` }];
  };
  Engine.prototype.teamTotals = function (side) { const t = blank(); for (const b of this.box[side]) for (const k in t) t[k] += b[k]; return t; };
  Engine.prototype.topScorer = function (side) { let best = 0; this.box[side].forEach((b, i) => { if (b.pts > this.box[side][best].pts) best = i; }); return this.st.show[side].starters[best]; };

  /* ---------- building each graphic from the data ---------- */
  /* text the producer typed over a graphic (Edit, ⌘E) */
  Engine.prototype.withText = function (ref, g) {
    const o = g && this.st.text && this.st.text[ref];
    if (!o) return g;
    if (o.foot) g.note = o.foot;
    if (g.kind === 'scene' || g.kind === 'team') { if (o.title) g.title = o.title; if (o.sub) g.sub = o.sub; }
    else if (g.kind === 'coach') { if (o.title) g.name = o.title; if (o.sub) g.title = o.sub; }
    else if (g.kind === 'announcers') { if (o.sub) g.okicker = o.sub; }   // the names come from Settings › Game; a look may show a line under them
    else if (g.kind === 'capsule' || g.kind === 'report') { if (o.title) g.title = o.title; if (o.sub) g.sub = o.sub; if (o.lines) g.lines = g.lines.map((l, i) => o.lines[i] || l); }
    else if (g.kind === 'copyright') { if (o.title) { g.notice = (g.notice || '').split(g.owner).join(o.title); g.owner = o.title; } if (o.sub) g.notice = g.onotice = o.sub; }
    else { if (o.title) g.otitle = o.title; if (o.sub) g.okicker = o.sub; }
    return g;
  };
  PV.refOfLower = spec => spec.kind === 'coach' ? (spec.side === 'away' ? 'coachAway' : 'coachHome') : spec.kind;
  Engine.prototype.buildLower = function (spec) {
    const L = this.withText(PV.refOfLower(spec), this.buildLower0(spec));
    // whether a player's numbers are from this game or the season so far (a look can say so on the graphic)
    if (L && (spec.kind === 'game' || spec.kind === 'season')) L.statKind = spec.kind;
    return L;
  };
  Engine.prototype.buildFull = function (kind, opts) { return this.withText(kind, this.buildFull0(kind, opts)); };
  Engine.prototype.buildLower0 = function (spec) {
    const st = this.st, sh = st.show;
    if (spec.kind === 'announcers') return { id: 'ann' + uid(), kind: 'announcers', key: 'announcers', label: 'Talent', people: sh.announcers };
    if (spec.kind === 'scene') {
      const where = [sh.game.city, sh.game.state].filter(Boolean).join(', ');
      return { id: 'sc' + uid(), kind: 'scene', key: 'scene', label: 'Scene setter', title: sh.game.venue || where || sh.home.name, sub: sh.game.venue ? where : PV.fmtDate(sh.game.at) };
    }
    if (spec.kind === 'coach') {
      const t = sh[spec.side];
      const season = t.coachSeason ? `${PV.ordinal(+t.coachSeason)} season` : '';
      return { id: 'co' + uid(), kind: 'coach', key: 'coach' + spec.side, side: spec.side, label: `${t.code} head coach`, name: t.coach || 'Head Coach', title: ['Head Coach', season].filter(Boolean).join(' · ') };
    }
    if (spec.kind === 'team') return { id: 'tm' + uid(), kind: 'team', key: 'team' + spec.side + spec.title, side: spec.side, label: spec.title, title: spec.title, sub: spec.sub };
    const num = spec.num != null ? String(spec.num) : this.topScorer(spec.side);
    const p = PV.player(sh, spec.side, num) || [num, 'Player', '#' + num, '', '', '', ''];
    const b = this.statFor(spec.side, num);
    const live = st.sb.status !== 'pre';
    const ss = sh[spec.side].pstats[num];
    return { id: 'pl' + uid(), kind: 'player', key: 'pl' + spec.side + num, side: spec.side, num: p[0], label: `#${p[0]} ${p[2]}`, name: `${p[1]} ${p[2]}`.trim(),
      sub: [p[3], p[4], p[5], p[6]].filter(Boolean).join(' · '),
      stats: live ? [[b.pts, 'PTS'], [b.reb, 'REB'], [b.ast, 'AST']] : (ss ? [[ss[0], 'PPG'], [ss[1], 'RPG'], [ss[2], 'APG']] : []) };
  };
  Engine.prototype.buildFull0 = function (kind, opts) {
    const st = this.st, sh = st.show;
    const sideOf = kind === 'featAway' ? 'away' : 'home';
    if (kind === 'title') return { id: 'ti' + uid(), kind, label: 'Title card', date: PV.fmtDate(sh.game.at, { weekday: 'long', month: 'long', day: 'numeric' }), time: PV.fmtTime(sh.game.at), venue: sh.game.venue, where: [sh.game.city, sh.game.state].filter(Boolean).join(', ') };
    if (kind === 'featAway' || kind === 'featHome') {
      const t = sh[sideOf]; const num = t.featured || t.starters[0];
      const p = PV.player(sh, sideOf, num) || [num, 'Player', '#' + num, '', '', '', ''];
      const ss = t.pstats[num];
      return { id: 'fp' + uid(), kind: 'featured', side: sideOf, label: `${t.code} featured · #${p[0]} ${p[2]}`, num: p[0], first: p[1], last: p[2], pos: p[3], cls: p[4], ht: p[5], home: p[6],
        stats: ss ? [[ss[0].toFixed(1), 'PPG'], [ss[1].toFixed(1), 'RPG'], [ss[2].toFixed(1), 'APG'], [ss[3], 'GAMES']] : [], note: ss ? '2025-26 season' : 'First season with the team' };
    }
    if (kind === 'lineups') {
      const f = side => sh[side].starters.map(n => { const p = PV.player(sh, side, n) || [n, '', '', '', '', '']; return [p[0], p[1], p[2], p[3], p[4], p[5]]; });
      return { id: 'lu' + uid(), kind, label: 'Starting lineups', away: f('away'), home: f('home') };
    }
    if (kind === 'tapeSeason') {
      const a = sh.away.season, h = sh.home.season;
      const v = (s, k, pct) => s ? { v: s[k], t: pct ? Math.round(s[k] * 100) + '%' : (+s[k]).toFixed(1) } : { v: 0, t: '—' };
      return { id: 'ts' + uid(), kind: 'tape', label: 'Inside the matchup', title: 'Inside the Matchup', kicker: '2025-26 season averages',
        rows: [['Record', { v: 0, t: sh.away.rec || '—' }, { v: 0, t: sh.home.rec || '—' }], ['Points per game', v(a, 'ppg'), v(h, 'ppg')], ['Rebounds per game', v(a, 'rpg'), v(h, 'rpg')], ['Assists per game', v(a, 'apg'), v(h, 'apg')], ['Field goal %', v(a, 'fg', 1), v(h, 'fg', 1)], ['3-point %', v(a, 'tp', 1), v(h, 'tp', 1)], ['Steals per game', v(a, 'spg'), v(h, 'spg')]] };
    }
    if (kind === 'tape') {
      const a = this.teamTotals('away'), h = this.teamTotals('home');
      const pct = (m, n) => n ? Math.round(m / n * 100) : 0;
      const row = (label, av, hv, fmt) => [label, { v: av, t: fmt ? fmt(av) : av }, { v: hv, t: fmt ? fmt(hv) : hv }];
      return { id: 'tt' + uid(), kind, label: 'Tale of the tape', title: 'Tale of the Tape', kicker: 'Game stats',
        rows: [row('Field goal %', pct(a.fgm, a.fga), pct(h.fgm, h.fga), x => x + '%'), row('3-pointers', a.tpm, h.tpm), row('Rebounds', a.reb, h.reb), row('Assists', a.ast, h.ast), row('Steals', a.stl, h.stl), row('Turnovers', a.to, h.to)] };
    }
    if (kind === 'standings') {
      const S2 = D.STANDINGS[sh.sport] || D.STANDINGS.MBB;
      const rows = S2.rows.map(r => { const t = D.byKey(r[0]); const col = r[0] === sh.home.key ? sh.colors.home : r[0] === sh.away.key ? sh.colors.away : (t && t.color) || '#6b7280'; return [r[0], r[1], r[2], r[3], col, (t && t.logo) || '']; });
      return { id: 'st' + uid(), kind, label: 'Standings', title: `NEC ${sh.event}`, season: S2.season, rows, note: `Entering ${PV.todayWord(sh).toLowerCase()}'s action` };
    }
    if (kind === 'board') {
      const sb = st.sb;
      const title = (opts && opts.title) || (sb.status === 'half' ? 'Halftime' : sb.status === 'final' ? 'Final' : sb.status === 'pre' ? 'Coming up' : "We'll be right back");
      return { id: 'bb' + uid(), kind, label: title, title, mid: sb.status === 'half' ? 'HALFTIME' : sb.status === 'final' ? 'FINAL' : sb.status === 'pre' ? PV.fmtTime(sh.game.at) : G.periodText(sb, sh.rules) + ' ' + G.clockText(G.sbClockMs(sb, now())),
        leaders: { away: this.leaders('away'), home: this.leaders('home') }, next: (opts && opts.next) || '' };
    }
    if (kind === 'coming') {
      const after = sh.game.at || '';
      const list = D.GAMES.filter(g => g.at > after && g.id !== sh.game.id).slice(0, 4).map(g => {
        const A = D.byKey(g.away) || { name: g.away }, H = D.byKey(g.home) || { name: g.home };
        return { when: PV.fmtDate(g.at, { weekday: 'short', month: 'short', day: 'numeric' }) + ' · ' + PV.fmtTime(g.at), sport: D.SPORTS[g.sport] || g.sport, game: `${A.name} at ${H.name}`, al: A.logo || '', hl: H.logo || '' };
      });
      return { id: 'cu' + uid(), kind, label: 'Coming up on NEC Front Row', list };
    }
    return null;
  };
  Engine.prototype.buildTake = function (side) { return this.withText(side === 'away' ? 'fiveAway' : 'fiveHome', this.buildTake0(side)); };
  Engine.prototype.buildTake0 = function (side) {
    const sh = this.st.show;
    return { id: 'tk' + uid(), side, label: `${sh[side].code} starting five`, players: sh[side].starters.map(n => { const p = PV.player(sh, side, n) || [n, '', '']; return [p[0], p[2], p[3]]; }) };
  };
  Engine.prototype.buildTicker = function () {
    const st = this.st;
    const others = D.GAMES.filter(g => g.at.slice(0, 10) === (st.show.game.at || '').slice(0, 10) && g.id !== st.show.game.id).slice(0, 6);
    const T = PV.worldT(st);
    const items = (others.length ? others : D.GAMES.slice(0, 4)).map((g, i) => {
      const A = D.byKey(g.away) || { code: g.away.slice(0, 4).toUpperCase() }, H = D.byKey(g.home) || { code: g.home.slice(0, 4).toUpperCase() };
      const k = (i + 3) * 7.13;
      return [A.code, Math.round(T * (0.02 + (Math.sin(k) + 1) * 0.004)), H.code, Math.round(T * (0.02 + (Math.cos(k) + 1) * 0.004)), (D.SPORTS[g.sport] || '').toUpperCase() + ' · SAMPLE'];
    });
    return { v: uid(), label: 'AROUND THE NEC', items };
  };

  /* a graphic from the catalogue, by name */
  Engine.prototype.playGfx = function (ref, t) {
    const st = this.st, g = st.gfx;
    if (ref === 'ticker') { if (!PV.lookLacks('ticker', st)) { g.ticker = true; g.tickerData = this.buildTicker(); } return; }
    if (PV.isLowerRef(ref, st)) { const L = this.buildLower(PV.lowerSpec(ref)); L.at = t; g.lower = L; return; }
    if (ref === 'fiveAway' || ref === 'fiveHome') { g.take = this.buildTake(ref === 'fiveAway' ? 'away' : 'home'); g.take.at = t; return; }
    const F = this.buildFull(ref); if (F) g.full = F;
  };

  /* ---------- the tick: clock, periods, playlists, replays ---------- */
  Engine.prototype.tick = function () {
    const st = this.st, t = now(), R = this.rules();
    let dirty = false;
    const game = PV.gameFor(st.show);
    const T = PV.worldT(st, t);
    if (T > this.lastT) {
      const evs = game.events(this.lastT, T);
      if (evs.length && st.sb.running) { this.applyEvents(evs); dirty = true; }
      const p = game.find(T);
      if (st.sb.feed === 'box' && st.sb.running && st.sb.poss !== p.off) { st.sb.poss = p.off; dirty = true; }
    }
    this.lastT = T;
    const sb = st.sb;
    if (sb.running && G.sbClockMs(sb, t) <= 0) {
      sb.clock = 0; sb.running = false; sb.at = t;
      st.sugg = st.sugg.filter(s => !/^mt/.test(s.id));
      if (sb.period >= R.periods) { sb.status = 'final'; sb.flag = 'FINAL'; this.suggest({ id: 'final-board', title: 'Final board', why: 'End of game', act: ['gfx.full', 'board'] }, true); }
      else if (sb.period === R.halftimeAfter) {
        sb.status = 'half'; sb.flag = 'HALFTIME';
        this.suggest({ id: 'half-tape', title: 'Tale of the tape', why: 'First-half stats', act: ['gfx.full', 'tape'] }, true);
        this.suggest({ id: 'half-pl', title: 'Roll the Halftime playlist', why: 'End of first half', act: ['pl.play', 'half', 0] }, true);
        this.suggest({ id: 'half-board', title: 'Halftime board', why: 'End of first half', act: ['gfx.full', 'board'] }, true);
      } else { sb.status = 'break'; sb.flag = `END ${PV.ordinal(sb.period).toUpperCase()}`; this.suggest({ id: 'endq' + sb.period, title: 'Go to break', why: `End of ${PV.ordinal(sb.period)} quarter`, act: ['brk.toggle'] }, true); }
      dirty = true;
    }
    if (sb.running) {
      const ms = G.sbClockMs(sb, t);
      for (const m of R.media) {
        const id = `mt${sb.period}-${m}`;
        if (ms <= m * 60000 && ms > m * 60000 - 1500 && !st.sugg.some(s => s.id === id)) { this.suggest({ id, title: 'Media timeout: go to break', why: `Under ${m}:00`, act: ['brk.toggle'] }, true); dirty = true; }
      }
    }
    const g = st.gfx;
    // a lower third comes off on its own after its time: its own (a card, a team down a player) or the show's setting
    const hold = g.lower && (g.lower.hold || g.lowerHold);
    if (g.lower && hold > 0 && g.lower.at && t - g.lower.at > hold * 1000 && st.program !== 'replay' && !g.lower.pl) { g.lower = null; dirty = true; }
    if (g.take && g.take.at && t - g.take.at > (g.take.hold || 9) * 1000 && !g.take.pl) { g.take = null; dirty = true; }
    // a substitution that went up under the scorebug, and the scorebug's ticker, come off when the scorebug does
    if (g.take && g.take.kind === 'subs' && g.take.withBug && !g.scorebug) { g.take = null; dirty = true; }
    if (g.sbTicker && !g.scorebug) { g.sbTicker = false; dirty = true; }
    const tr = st.trans.active;
    if (tr) {
      if (tr.type === 'stinger' && !tr.cut && t - tr.start >= tr.dur * (tr.at || 0.5)) { tr.cut = true; this.setProgram(tr.to); dirty = true; }
      if (t - tr.start >= tr.dur) { st.trans.active = null; dirty = true; }
    }
    if (st.rp.playing && PV.rpTick(this, t)) dirty = true;
    const rd = st.rd, cur = rd.on && rd.items[rd.idx];
    if (cur && cur.act) {
      const [n, a] = cur.act;
      const off = (n === 'gfx.play' && !this.gfxLive(a) && !(st.trans.active)) || (n === 'pl.cue' && !(st.pl.active && st.pl.active.list === 'tray') && t - (cur.at || 0) > 1500) || (n === 'brk.toggle' && !st.brk) || (n === 'pl.play' && !st.pl.active && t - (cur.at || 0) > 1500);
      if (off && t - (cur.at || 0) > 400) { this.rundownOff(); dirty = true; }
    }
    const pa = st.pl.active;
    if (pa && !pa.done) {
      const list = st.pl.lists.find(l => l.id === pa.list), item = list && list.items[pa.idx];
      if (!item) { this.stopPlaylist(); dirty = true; }
      else if (item.type === 'reel' || item.type === 'replay') { if (!st.rp.playing && t - pa.start > 1200) { this.itemDone(); dirty = true; } }
      else if (item.dur > 0 && t - pa.start >= item.dur * 1000) { this.itemDone(); dirty = true; }
    }
    if (dirty) this.changed();
  };

  Engine.prototype.setProgram = function (src) {
    const st = this.st;
    if (src === st.program) return;
    const prev = st.program;
    st.program = src;
    if (/^cam/.test(prev)) st.lastCam = prev;
    // what was on air lands back in Preview; a video or replay never does, the camera before it does
    if (st.preview === src) st.preview = !['video', 'replay'].includes(prev) ? prev : (st.lastCam && st.lastCam !== src ? st.lastCam : (src === 'cam1' ? 'cam2' : 'cam1'));
  };
  Engine.prototype.mixTo = function (to, t) {
    const st = this.st; if (!to || to === st.program) return;
    st.trans.active = { type: 'mix', from: st.program, to, start: t || now(), dur: 500 };
    this.setProgram(to);
  };

  /* ---------- actions ---------- */
  /* ⌘Z brings back what was deleted: each delete keeps a copy of what it changed, the last 30 of them */
  const UNDO = {
    'rp.delete': ['rp.clips'], 'rp.angDel': ['rp.clips'], 'pls.rm': ['rp.lists', 'vlists'], 'pls.del': ['rp.lists', 'vlists'],
    'rd.del': ['rd.items', 'rd.cue', 'rd.idx'], 'me.del': ['me.list', 'me.sel'], 'pl.remove': ['pl.lists'],
    'vid.del': ['vids'], 'snd.del': ['snds'], 'trans.del': ['trans.wipes', 'trans.sel', 'trans.wipe']
  };
  const getPath = (o, p) => p.split('.').reduce((x, k) => x == null ? x : x[k], o);
  const setPath = (o, p, v) => { const k = p.split('.'), last = k.pop(), x = k.reduce((y, j) => y[j], o); x[last] = v; };
  const copy = v => v === undefined ? v : JSON.parse(JSON.stringify(v));
  Engine.prototype.act = function (name, a, b, c) {
    const A = this.actions[name];
    if (!A) return;
    const keep = UNDO[name] ? { name, was: UNDO[name].map(p => [p, copy(getPath(this.st, p))]) } : null;
    A.call(this, a, b, c, now());
    // only a delete that took something away can be undone
    if (keep && keep.was.some(([p, v]) => JSON.stringify(getPath(this.st, p)) !== JSON.stringify(v))) {
      this.undos = (this.undos || []).concat([keep]).slice(-30);
    }
    this.changed();
  };
  // what ⌘Z brings back, in a word or two
  PV.UNDO_WORD = { 'rp.delete': 'the replay', 'rp.angDel': 'the angle', 'pls.rm': 'the playlist item', 'pls.del': 'the playlist', 'rd.del': 'the rundown item', 'me.del': 'the M/E', 'pl.remove': 'the playlist item', 'vid.del': 'the video', 'snd.del': 'the sound', 'trans.del': 'the wipe' };
  Engine.prototype.undo = function () {
    const u = (this.undos || []).pop(); if (!u) return null;
    for (const [p, v] of u.was) setPath(this.st, p, copy(v));
    this.changed();
    return u.name;
  };

  Engine.prototype.actions = {
    'preview'(src) { if (src) this.st.preview = src; },
    'cut'(src) { const st = this.st; if (st.rp.playing && st.program === 'replay') st.rp.playing = null; st.trans.active = null; this.setProgram(src || st.preview); },
    'auto'(src, _b, _c, t) {
      const st = this.st, to = src || st.preview;
      if (to === st.program) return;
      if (st.trans.type === 'stinger') return this.actions.sting.call(this, to, 0, 0, t);
      if (st.rp.playing && st.program === 'replay') st.rp.playing = null;
      st.trans.active = { type: 'mix', from: st.program, to, start: t, dur: st.trans.dur };
      this.setProgram(to);
    },
    'sting'(src, _b, _c, t) { const st = this.st, to = src || st.preview; if (to === st.program) return; st.trans.active = PV.sting(st, { type: 'stinger', from: st.program, to, start: t, dur: 1000, cut: false }); },
    'trans.type'(type) { this.st.trans.type = type; },
    'trans.dur'(ms) { this.st.trans.dur = Math.max(100, Math.min(3000, +ms || 600)); },

    'gfx.toggle'(layer) {
      if (PV.lookLacks(layer, this.st)) return;
      const g = this.st.gfx;
      if (layer === 'ticker') { g.ticker = !g.ticker; if (g.ticker) g.tickerData = this.buildTicker(); }
      else if (layer === 'scorebug') g.scorebug = !g.scorebug;
      else if (layer === 'big') { if (g.big) g.big = false; else this.bigOn(); }
    },
    'gfx.lower'(spec, _b, _c, t) {
      const g = this.st.gfx;
      if (typeof spec === 'string') spec = { kind: spec };
      const L = this.buildLower(spec);
      if (g.lower && g.lower.key === L.key) { g.lower = null; return; }   // click again to take it off
      L.at = t; g.lower = L;
    },
    'gfx.full'(kind, opts) {
      const g = this.st.gfx;
      const k = kind === 'featAway' || kind === 'featHome' ? 'featured' : kind === 'tapeSeason' ? 'tape' : kind;
      if (g.full && g.full.kind === k && (k !== 'featured' || g.full.side === (kind === 'featAway' ? 'away' : 'home')) && (kind !== 'tapeSeason' || g.full.title === 'Inside the Matchup') && !opts) { g.full = null; return; }
      g.full = this.buildFull(kind, opts);
    },
    'gfx.play'(ref, _b, _c, t) {
      const g = this.st.gfx;
      // the same graphic again takes it off
      if (ref === 'ticker' && g.ticker) { g.ticker = false; return; }
      if ((ref === 'fiveAway' || ref === 'fiveHome') && g.take && g.take.side === (ref === 'fiveAway' ? 'away' : 'home')) { g.take = null; return; }
      if (PV.isLowerRef(ref, this.st)) {
        if (g.lower && g.lower.key === PV.lowerKeyOfRef(ref)) { g.lower = null; return; }
        return this.playGfx(ref, t);
      }
      if (['title', 'standings', 'tapeSeason', 'tape', 'lineups', 'board', 'coming', 'comingHalf', 'featAway', 'featHome'].includes(ref)) return this.actions['gfx.full'].call(this, ref);
      this.playGfx(ref, t);
    },
    'gfx.clear'(what) {
      const g = this.st.gfx;
      if (what === 'lower') g.lower = null;
      else if (what === 'full') g.full = null;
      else if (what === 'ticker') g.ticker = false;
      else if (what === 'take') g.take = null;
      else { g.lower = null; g.full = null; g.ticker = false; g.sbTicker = false; g.take = null; g.big = false; }   // the scorebug, watermark and replay burn stay
    },
    'gfx.pkg'(id) {
      const st = this.st; if (!G.PACKAGES[id] || G.PACKAGES[id].hidden) return;
      st.gfx.pkg = id;
      // the template in use follows the look: the one made for it, or none
      const cur = PV.allTemplates().find(t => t.id === st.tpl.id);
      if (!cur || cur.network !== id) { const tp = PV.allTemplates().find(t => t.network === id && !(t.locks || {}).pkg); st.tpl = { id: tp ? tp.id : null, locks: {} }; }
    },
    'gfx.burn'(k, v) { const b = this.st.gfx.burn; if (k === 'on') b.on = !!v; if (k === 'pos' && ['tl', 'tr'].includes(v)) b.pos = v; },
    'feat.set'(side, num) {
      const sh = this.st.show; if (!sh[side] || !PV.player(sh, side, num)) return;
      sh[side].featured = String(num);
      const fm = store.get('featured', {}); fm[sh[side].key + '|' + sh.sport] = String(num); store.set('featured', fm);
      this.st.rd.items.forEach(it => { if (it.act && it.act[1] === (side === 'away' ? 'featAway' : 'featHome')) { const p = PV.player(sh, side, num); it.sub = `#${p[0]} ${p[1]} ${p[2]}`; } });
    },
    'sugg.take'(id) {
      const st = this.st;
      const s = id ? st.sugg.find(x => x.id === id) : st.sugg[0];
      if (!s) return;
      st.sugg = st.sugg.filter(x => x !== s);
      const [n, a, b] = s.act;
      this.actions[n].call(this, a, b, undefined, now());
    },
    'sugg.dismiss'(id) { this.st.sugg = this.st.sugg.filter(x => x.id !== id); },

    'rd.next'(_a, _b, _c, t) { const rd = this.st.rd; const i = rd.cue != null ? rd.cue : rd.idx + 1; if (i >= 0 && i < rd.items.length) this.runRundown(i, t); else if (rd.on) this.rundownOff(); },
    'rd.run'(i, _b, _c, t) { const rd = this.st.rd; if (i < 0 || i >= rd.items.length) return; if (i === rd.idx && rd.on) this.rundownOff(); else this.runRundown(i, t); },
    'rd.off'() { if (this.st.rd.on) this.rundownOff(); },
    'rd.cue'(i) { const rd = this.st.rd; if (i >= 0 && i < rd.items.length) rd.cue = i; },
    'rd.back'() { const rd = this.st.rd; rd.cue = Math.max(0, (rd.cue || 0) - 1); },
    'rd.edit'(i, patch) {
      const rd = this.st.rd, it = rd.items[i]; if (!it || !patch) return;
      if (typeof patch.label === 'string') it.label = patch.label.slice(0, 60) || it.label;
      if (typeof patch.sub === 'string') it.sub = patch.sub.slice(0, 80);
      if (typeof patch.seg === 'string' && patch.seg) it.seg = patch.seg.slice(0, 30);
      if (patch.kind) {
        it.kind = patch.kind;
        if (patch.kind === 'gfx' && PV.GFX.some(g => g[0] === patch.ref)) it.act = ['gfx.play', patch.ref];
        else if (patch.kind === 'cam' && /^(cam\d+|me:[\w-]+)$/.test(patch.cam)) { it.act = ['auto', patch.cam]; it.cam = patch.cam; }
        else if (patch.kind === 'video' && S.CLIPS[patch.ref]) it.act = ['pl.cue', patch.ref];
        else if (patch.kind === 'cue') it.act = null;
      }
      if (patch.text && it.act && it.act[0] === 'gfx.play') {
        const ref = it.act[1], o = { title: String(patch.text.title || '').slice(0, 60), sub: String(patch.text.sub || '').slice(0, 80) };
        if (o.title || o.sub) this.st.text[ref] = o; else delete this.st.text[ref];
        const g = this.st.gfx;   // what's on air picks up the new words straight away
        if (this.gfxLive(ref)) this.playGfx(ref, now());
        else if (g.lower && g.lower.key === ref) g.lower = null;
      }
    },
    'rd.add'(after, item) {
      const rd = this.st.rd; const at = Math.max(-1, Math.min(rd.items.length - 1, +after));
      const prev = rd.items[at] || rd.items[0] || { seg: 'Open' };
      const it = { id: uid(), seg: prev.seg, label: (item && item.label) || 'New item', sub: (item && item.sub) || '', act: null, kind: 'cue' };
      rd.items.splice(at + 1, 0, it);
      if (rd.idx > at) rd.idx++;
      if (rd.cue > at) rd.cue++;
      this.actions['rd.edit'].call(this, at + 1, item || {});
    },
    'rd.del'(i) {
      const rd = this.st.rd; if (i < 0 || i >= rd.items.length || (i === rd.idx && rd.on)) return;
      rd.items.splice(i, 1);
      if (rd.idx > i) rd.idx--; else if (rd.idx === i) rd.idx = -1;
      if (rd.cue > i) rd.cue--;
      rd.cue = Math.min(rd.cue, rd.items.length);
    },
    'me.save'(m) {
      if (!m || !Array.isArray(m.layers)) return;
      const st = this.st, clean = { id: String(m.id || 'me-' + uid()).slice(0, 30), name: String(m.name || 'M/E').slice(0, 30), bg: /^(black|team|cam\d+)$/.test(m.bg) ? m.bg : 'black',
        layers: m.layers.slice(0, 6).filter(l => /^(cam\d+|replay|video)$/.test(l.src)).map(l => ({ src: l.src, spot: l.spot || 'custom', x: clamp01(l.x), y: clamp01(l.y), w: Math.max(0.05, clamp01(l.w)), h: Math.max(0.05, clamp01(l.h)), border: !!l.border })) };
      const i = st.me.list.findIndex(x => x.id === clean.id);
      if (i >= 0) st.me.list[i] = clean; else st.me.list.push(clean);
      st.me.sel = clean.id;
    },
    'me.del'(id) { const st = this.st; if (st.me.list.length <= 1) return; st.me.list = st.me.list.filter(m => m.id !== id); if (st.me.sel === id) st.me.sel = st.me.list[0].id; },
    'me.sel'(id) { if (this.st.me.list.some(m => m.id === id)) this.st.me.sel = id; },
    'me.use'(id) { if (this.st.me.list.some(m => m.id === id)) { this.st.me.sel = id; this.st.preview = 'me'; } },

    /* into: a replay playlist ('rp:<id>') open on the desk; the play goes in it as well as in All */
    'rp.mark'(into, _b, _c, t) {
      const st = this.st, game = PV.gameFor(st.show);
      const T = PV.worldT(st, t);
      const tIn = T - st.rp.back, tOut = T;
      st.rp.n++;
      let name = `Replay ${st.rp.n}`;
      const evs = game.events(tIn, tOut);
      const last = evs.filter(e => e.kind === 'shot' && e.made).pop() || evs.filter(e => e.kind === 'to').pop();
      if (last) {
        if (last.kind === 'to') name = `Steal · ${this.starter(last.stealSide, last.stealRole).p[2]}`;
        else name = `${this.starter(last.side, last.role).p[2]} ${last.three ? '3-pointer' : 'bucket'}`;
      }
      st.rp.clips.unshift({ id: uid(), name, tIn, tOut, win: [Math.max(0, T - 30), T + 10], cuts: {}, angles: st.rp.angles.slice(), speed: st.rp.speed, reel: true, rolled: false, at: t, score: `${st.show.away.code} ${st.sb.score.away}-${st.sb.score.home} ${st.show.home.code}` });
      st.rp.clips = st.rp.clips.slice(0, 40);
      if (typeof into === 'string' && /^rp:/.test(into) && this.actions['pls.paste']) this.actions['pls.paste'].call(this, into, [{ clip: st.rp.clips[0].id }]);
    },
    // 'rp.roll' (P and Roll all) is in reels.js
    'rp.stop'() { if (this.st.rp.playing) { this.st.rp.playing.stopped = true; this.endReplay(); } },
    'rp.update'(id, patch) {
      const c = this.st.rp.clips.find(x => x.id === id); if (!c || !patch) return;
      if (typeof patch.name === 'string') PV.rpRename(this.st, id, patch.name.slice(0, 40));
      if (patch.speed) c.speed = Math.max(0.25, Math.min(1, +patch.speed));
      if (Array.isArray(patch.angles)) c.angles = patch.angles.filter(a => PV.isCam(this.st, a));
      if (typeof patch.reel === 'boolean') c.reel = patch.reel;
    },
    /* in and out come as one pair [in, out]: actions only get three values (the fourth is the time) */
    'rp.cut'(id, ang, io) {
      const c = this.st.rp.clips.find(x => x.id === id); if (!c || !Array.isArray(io)) return;
      let [tIn, tOut] = io;
      const lo = c.win ? c.win[0] : c.tIn - 20, hi = Math.min(c.win ? c.win[1] : c.tOut + 10, PV.worldT(this.st));
      tIn = Math.max(lo, Math.min(hi - 0.5, +tIn)); tOut = Math.max(tIn + 0.5, Math.min(hi, +tOut));
      if (!isFinite(tIn) || !isFinite(tOut)) return;
      c.cuts = c.cuts || {};
      if (ang === 'all') { c.cuts = {}; c.tIn = tIn; c.tOut = tOut; }
      else if (PV.isCam(this.st, ang)) c.cuts[ang] = { tIn, tOut };
    },
    'rp.delete'(id) {
      const st = this.st; if (st.rp.playing && st.rp.playing.clip === id) return;
      st.rp.clips = st.rp.clips.filter(c => c.id !== id);
      if (st.pv.rp && st.pv.rp.clip === id) { st.pv.rp = null; if (st.preview === 'replay') st.preview = st.lastCam || 'cam1'; }
    },
    'rp.back'(s) { this.st.rp.back = Math.max(3, Math.min(30, +s || 8)); },
    'rp.angles'(list) { if (Array.isArray(list)) this.st.rp.angles = list.filter(a => PV.isCam(this.st, a)); },
    'rp.speed'(s) { this.st.rp.speed = Math.max(0.25, Math.min(1, +s || 1)); },

    'pl.play'(listId, idx) { this.playItem(listId, idx == null ? this.cueOf(listId) : idx); },
    'pl.next'() { const st = this.st; const id = st.pl.active ? st.pl.active.list : st.pl.left; this.playItem(id, this.cueOf(id)); },
    'pl.stop'() { this.stopPlaylist(); },
    'pl.left'(id) { if (this.st.pl.lists.some(l => l.id === id)) this.st.pl.left = id; },
    'pl.mode'(id, m) { const l = this.st.pl.lists.find(x => x.id === id); if (l && PV.PL_MODES.some(x => x[0] === m)) l.mode = m; },
    'pl.add'(id, item) {
      const l = this.st.pl.lists.find(x => x.id === id); if (!l || !item) return;
      if (item.type === 'video' && S.CLIPS[item.ref]) l.items.push(li('video', item.ref));
      else if (item.type === 'gfx' && PV.GFX.some(g => g[0] === item.ref)) l.items.push(li('gfx', item.ref, +item.dur || 0));
      else if (item.type === 'reel') l.items.push(li('reel', 'reel'));
      else if (item.type === 'replay') { const c = this.st.rp.clips.find(x => x.id === item.ref); if (c) l.items.push({ id: uid(), type: 'replay', ref: c.id, name: 'Replay · ' + c.name, dur: 0, played: false }); }
    },
    'pl.move'(id, from, to) {
      const l = this.st.pl.lists.find(x => x.id === id); if (!l) return;
      if (from < 0 || from >= l.items.length || to < 0 || to >= l.items.length) return;
      const [it] = l.items.splice(from, 1); l.items.splice(to, 0, it);
      const a = this.st.pl.active; if (a && a.list === id) { if (a.idx === from) a.idx = to; else if (from < a.idx && to >= a.idx) a.idx--; else if (from > a.idx && to <= a.idx) a.idx++; }
    },
    'pl.remove'(id, itemId) {
      const l = this.st.pl.lists.find(x => x.id === id); if (!l) return;
      const i = l.items.findIndex(x => x.id === itemId); if (i < 0) return;
      const a = this.st.pl.active; if (a && a.list === id && a.idx === i) return;
      l.items.splice(i, 1); if (a && a.list === id && i < a.idx) a.idx--;
    },
    'pl.reset'(id) { const l = this.st.pl.lists.find(x => x.id === id); if (l) { l.items.forEach(i => i.played = false); this.st.pl.cue[id] = 0; } },
    'pl.cue'(ref) {
      const st = this.st;
      let l = st.pl.lists.find(x => x.id === 'tray');
      if (!l) { l = { id: 'tray', name: 'Video', mode: 'one', hidden: true, items: [] }; st.pl.lists.push(l); }
      l.items = [S.CLIPS[ref] ? li('video', ref) : li('gfx', ref, 8)];
      this.playItem('tray', 0);
    },

    'audio.fader'(i, v) { const c = this.st.audio.ch[i]; if (c) c.fader = Math.max(0, Math.min(1, +v)); },
    'audio.mute'(i) { const c = this.st.audio.ch[i]; if (c) c.mute = !c.mute; },
    'audio.master'(v) { this.st.audio.master = Math.max(0, Math.min(1, +v)); },
    'audio.mode'(m) { if (['4ch', 'pairs', 'split'].includes(m)) this.st.audio.mode = m; },

    'brk.toggle'(_a, _b, _c, t) {
      const st = this.st;
      if (!st.brk) {
        st.brkSave = { program: st.program === 'video' || st.program === 'replay' || st.program === 'black' ? 'cam1' : st.program, mutes: st.audio.ch.map(c => c.mute), scorebug: st.gfx.scorebug, clock: false };
        if (st.sb.feed === 'box' && st.sb.running) { st.sb.clock = G.sbClockMs(st.sb, t); st.sb.running = false; st.sb.at = t; st.brkSave.clock = true; }
        st.brk = true;
        st.audio.ch.forEach(c => c.mute = true);
        st.gfx.lower = null; st.gfx.full = null; st.gfx.ticker = false; st.gfx.take = null;
        if (st.rp.playing) st.rp.playing = null;
        st.pl.cue.brk = 0;
        // into a break: a second's fade to black, then the commercials roll (never a replay wipe).
        // An end stamp covering the screen fades to black itself: the picture under it is already black.
        const tr = st.trans.active;
        if (tr && tr.type === 'stinger' && tr.stamp && tr.cut && t < tr.start + tr.dur) { tr.to = 'black'; tr.fadeAt = t; tr.fadeDur = 1000; }
        else st.trans.active = { type: 'mix', from: st.program, to: 'black', start: t, dur: 1000 };
        this.setProgram('black');
        st.brkStep = { at: t + 1000, then: 'roll' };
        st.sugg = st.sugg.filter(s => !/^(mt|endq)/.test(s.id));
      } else {
        const sv = st.brkSave || { program: 'cam1', mutes: [false, false, false, false], scorebug: true };
        st.brk = false;
        st.pl.active = null;
        st.audio.ch.forEach((c, i) => c.mute = !!sv.mutes[i]);
        st.gfx.full = null; st.gfx.scorebug = sv.scorebug;
        if (sv.clock && st.sb.status === 'live' && !st.sb.running) { st.sb.running = true; st.sb.at = t; }
        // out of a break: a second's fade to black, then a fade up to what's in Preview
        const back = /^cam|^me:/.test(st.preview) ? st.preview : sv.program;
        st.pl.last = null;
        st.trans.active = { type: 'mix', from: st.program, to: 'black', start: t, dur: 1000 };
        this.setProgram('black');
        st.brkStep = { at: t + 1000, then: 'back', to: back, prev: back === sv.program ? (st.lastCam && st.lastCam !== back ? st.lastCam : null) : sv.program };
      }
    },

    'sb.tip'(_a, _b, _c, t) { const sb = this.st.sb; if (sb.status === 'pre') { this.st.sugg = this.st.sugg.filter(x => x.id !== 'rd'); sb.status = 'live'; sb.running = true; sb.at = t; } },
    'sb.clock'(_a, _b, _c, t) {
      const sb = this.st.sb;
      if (sb.status === 'pre') return this.actions['sb.tip'].call(this, 0, 0, 0, t);
      if (sb.status !== 'live') return;
      if (sb.running) { sb.clock = G.sbClockMs(sb, t); sb.running = false; } else sb.running = true;
      sb.at = t;
    },
    'sb.adjust'(side, d) { const sb = this.st.sb; if (sb.score[side] == null) return; sb.score[side] = Math.max(0, sb.score[side] + (+d || 0)); },
    'sb.foul'(side, d) { const sb = this.st.sb, R = this.rules(); sb.fouls[side] = Math.max(0, sb.fouls[side] + (+d || 0)); sb.bonus[side === 'home' ? 'away' : 'home'] = sb.fouls[side] >= R.bonus; },
    'sb.poss'(side) { const sb = this.st.sb; sb.poss = side === 'home' || side === 'away' ? side : (sb.poss === 'home' ? 'away' : 'home'); },
    'sb.feed'(f) { if (f === 'box' || f === 'manual') { this.st.sb.feed = f; this.st.sb.op = f === 'box' ? 'box' : 'manual'; } },
    'sb.takeover'() { const sb = this.st.sb; sb.feed = 'manual'; sb.op = 'phone'; },
    'sb.release'() { const sb = this.st.sb; sb.feed = 'box'; sb.op = 'box'; },
    'sb.boxOk'(v) { const sb = this.st.sb; sb.boxOk = !!v; if (!sb.boxOk && sb.feed === 'box') { sb.feed = 'manual'; sb.op = 'manual'; } },
    'sb.setClock'(ms, _b, _c, t) { const sb = this.st.sb; sb.clock = Math.max(0, Math.min(this.rules().len * 60000, +ms || 0)); sb.at = t; },
    'sb.next'(_a, _b, _c, t) {
      const sb = this.st.sb, R = this.rules();
      if (sb.status === 'final' || sb.status === 'pre') return;
      sb.period++; sb.status = 'live'; sb.flag = ''; sb.clock = sb.period > R.periods ? R.ot * 60000 : R.len * 60000; sb.running = false; sb.at = t;
      if (sb.period > R.periods && sb.timeouts) { sb.timeouts.home++; sb.timeouts.away++; }   // each overtime adds one
      const resetFouls = R.foulsReset === 'quarter' || sb.period === R.halftimeAfter + 1;
      if (resetFouls) { sb.fouls = { home: 0, away: 0 }; sb.bonus = { home: false, away: false }; }
      this.st.sugg = this.st.sugg.filter(s => !/^(half|endq)/.test(s.id));
    },
    /* by hand: type a score, pick the half or quarter (or overtime, halftime, final), count timeouts */
    'sb.setScore'(side, v) { const sb = this.st.sb; v = Math.round(+v); if (sb.score[side] == null || !isFinite(v)) return; sb.score[side] = Math.max(0, Math.min(999, v)); },
    'sb.setPeriod'(p, _b, _c, t) {
      const sb = this.st.sb, R = this.rules();
      if (p === 'half') { sb.status = 'half'; sb.running = false; sb.clock = 0; sb.at = t; return; }
      if (p === 'final') { sb.status = 'final'; sb.running = false; sb.clock = 0; sb.at = t; return; }
      p = Math.max(1, Math.min(R.periods + 6, Math.round(+p) || 1));
      const was = sb.period;
      sb.period = p; sb.status = 'live'; sb.running = false; sb.at = t;
      if (p !== was) sb.clock = (p > R.periods ? R.ot : R.len) * 60000;
    },
    'sb.to'(side, d) { const sb = this.st.sb; sb.timeouts = sb.timeouts || { home: 4, away: 4 }; if (sb.timeouts[side] == null) return; sb.timeouts[side] = Math.max(0, Math.min(9, sb.timeouts[side] + (+d || 0))); },
    'sb.flag'(txt) { this.st.sb.flag = String(txt || '').slice(0, 24); },

    'rec.toggle'(_a, _b, _c, t) { const r = this.st.rec; r.on = !r.on; r.start = r.on ? t : 0; },
    'rec.set'(k, v) { const r = this.st.rec; if (k === 'fmt' && PV.FORMATS[v]) r.fmt = v; else if (k === 'q' && ['good', 'better', 'best'].includes(v)) r.q = v; else if (k === 'feed' && v in r.feeds) r.feeds[v] = !r.feeds[v]; else if (k === 'folder') r.folder = String(v).slice(0, 80); },
    'stream.toggle'(_a, _b, _c, t) { const s = this.st.stream; if (!s.on && !s.dests.some(d => d.on)) return; s.on = !s.on; s.start = s.on ? t : 0; },
    'stream.dest'(id) { const d = this.st.stream.dests.find(x => x.id === id); if (d && !this.st.stream.on) d.on = !d.on; },
    'stream.set'(k, v) { const s = this.st.stream; if (k === 'kbps') s.kbps = Math.max(1500, Math.min(20000, +v || 6000)); if (k === 'res') s.res = v; },
    'out.set'(k, v) { const o = this.st.out; if (k === 'device' || k === 'feed' || k === 'hdmi') o[k] = v; if (k === 'ndi' && v in o.ndi) o.ndi[v] = !o.ndi[v]; },
    /* how many camera slots the show has */
    'cams.count'(n) {
      const st = this.st; n = Math.max(1, Math.min(PV.MAX_CAMS, Math.round(+n || 4)));
      const names = { cam1: 'Wide', cam2: 'Tight' };   // the others depend on the venue
      for (let k = 1; k <= n; k++) if (!st.inputs['cam' + k]) st.inputs['cam' + k] = { name: names['cam' + k] || '', device: '', fmt: '1080p59.94' };
      for (const id of PV.camIds(st)) if (+id.slice(3) > n) delete st.inputs[id];
      const ok = s => !/^cam\d+$/.test(s) || !!st.inputs[s];
      if (!ok(st.program)) this.setProgram('cam1');
      if (!ok(st.preview)) st.preview = 'cam1';
      st.rp.angles = st.rp.angles.filter(ok);
      if (!st.rp.angles.length) st.rp.angles = PV.camIds(st).slice(0, 4);
      store.set('camCount', n);
    },
    'input.set'(id, patch) { const i = this.st.inputs[id]; if (!i || !patch) return; for (const k of ['name', 'device', 'fmt']) if (typeof patch[k] === 'string') i[k] = patch[k].slice(0, 60); },
    'show.ann'(i, patch) { const a = this.st.show.announcers[i]; if (a && patch) { if (typeof patch.name === 'string') a.name = patch.name.slice(0, 40); if (typeof patch.role === 'string') a.role = patch.role.slice(0, 30); store.set('announcers', this.st.show.announcers); } },
    'show.event'(txt) { this.st.show.event = String(txt || '').slice(0, 50); },
    /* the color a team is wearing tonight; nothing set means home in white and away in its primary */
    'show.kit'(side, hex) { const t = this.st.show[side]; if (!t) return; t.kit = /^#[0-9a-f]{6}$/i.test(hex || '') ? hex.toLowerCase() : ''; },
    // a team's place in the national poll, 1 to 25; anything else means unranked
    'show.rank'(side, n) { const t = this.st.show[side]; if (!t) return; const r = parseInt(String(n == null ? '' : n).replace(/\D/g, ''), 10); t.rank = r >= 1 && r <= 25 ? String(r) : ''; },
    'show.coach'(side, patch) { const t = this.st.show[side]; if (!t || !patch) return; if (typeof patch.coach === 'string') t.coach = patch.coach.slice(0, 40); if (patch.coachSeason != null) t.coachSeason = String(patch.coachSeason).replace(/\D/g, '').slice(0, 2); },
    'tpl.apply'(id) {
      const tp = PV.allTemplates().find(x => x.id === id); if (!tp) return;
      const st = this.st;
      st.tpl = { id: tp.id, locks: Object.assign({}, tp.locks || {}) };
      if (tp.network && G.PACKAGES[tp.network]) st.gfx.pkg = PV.lookChoice(tp.network);
      if (tp.inputs) for (const k in tp.inputs) if (st.inputs[k]) Object.assign(st.inputs[k], tp.inputs[k]);
      if (tp.rec) { st.rec.fmt = tp.rec.fmt || st.rec.fmt; st.rec.q = tp.rec.q || st.rec.q; if (tp.rec.feeds) Object.assign(st.rec.feeds, tp.rec.feeds); }
      if (tp.audio) { st.audio.mode = tp.audio.mode || st.audio.mode; if (tp.audio.names) tp.audio.names.forEach((n, i) => { if (st.audio.ch[i]) st.audio.ch[i].name = n; }); }
      if (tp.dests) st.stream.dests.forEach(d => d.on = tp.dests.includes(d.id));
      if (tp.burn) Object.assign(st.gfx.burn, tp.burn);
    },
    'tpl.unlock'() { this.st.tpl.locks = {}; },
    'profile.name'(n) { this.st.profile.name = String(n || 'Director').slice(0, 30); },
    'macro.run'(id) { PV.runMacro(this, id); },
    'macro.stop'() { PV.stopMacro(this); },
    'macro.record'() { PV.toggleRecord(this); }
  };

  /* take a rundown item: the one on air before it comes off, this one goes on, the next is cued */
  Engine.prototype.runRundown = function (i, t) {
    this.st.sugg = this.st.sugg.filter(x => x.id !== 'rd');
    const rd = this.st.rd, it = rd.items[i];
    if (rd.on && rd.idx !== i) this.rundownOff(true);
    rd.idx = i; rd.on = true; rd.cue = i + 1; rd.follow = false; it.done = true; it.at = t;
    if (!it.act) return;
    const [n, a, b] = it.act;
    if (n === 'gfx.play') this.playGfx(a, t);          // always puts it on, never toggles it off
    else if (this.actions[n]) this.actions[n].call(this, a, b, undefined, t);
  };
  Engine.prototype.rundownOff = function (keepCue) {
    const st = this.st, rd = st.rd, it = rd.items[rd.idx];
    rd.on = false;
    if (it) {
      it.done = true;
      const [n, a] = it.act || [];
      if (n === 'gfx.play' && this.gfxLive(a)) this.clearGfx(a);
      else if (n === 'pl.cue' && st.pl.active && st.pl.active.list === 'tray') this.stopPlaylist();
      else if (n === 'brk.toggle' && st.brk) this.actions['brk.toggle'].call(this, 0, 0, 0, now());
    }
    if (!keepCue) rd.cue = rd.idx + 1;
  };
  /* is this catalogue graphic on air right now? */
  Engine.prototype.gfxLive = function (ref) {
    const g = this.st.gfx, f = g.full;
    if (ref === 'ticker') return g.ticker;
    if (ref === 'fiveAway' || ref === 'fiveHome') return !!(g.take && g.take.side === (ref === 'fiveAway' ? 'away' : 'home'));
    if (PV.isLowerRef(ref, this.st)) return !!(g.lower && g.lower.key === PV.lowerKeyOfRef(ref));
    if (!f) return false;
    if (ref === 'featAway' || ref === 'featHome') return f.kind === 'featured' && f.side === (ref === 'featAway' ? 'away' : 'home');
    if (ref === 'tapeSeason') return f.kind === 'tape' && f.label === 'Inside the matchup';
    if (ref === 'tape') return f.kind === 'tape' && f.label !== 'Inside the matchup';
    if (ref === 'nextUp') return !!f.upper;
    if (ref === 'coming') return f.kind === 'coming' && !f.upper && !/^(sd|ch)/.test(f.id);
    if (ref === 'comingHalf') return f.kind === 'coming' && /^ch/.test(f.id);
    return f.kind === ref;
  };
  /* the big score has the screen to itself: every other graphic comes off, the scorebug and its ticker too
     (the watermark and the replay burn stay) */
  Engine.prototype.bigOn = function () {
    const g = this.st.gfx;
    g.big = true; g.scorebug = false; g.ticker = false; g.sbTicker = false; g.lower = null; g.full = null; g.take = null;
  };
  Engine.prototype.clearGfx = function (ref) {
    const g = this.st.gfx;
    if (ref === 'ticker') g.ticker = false;
    else if (ref === 'fiveAway' || ref === 'fiveHome') g.take = null;
    else if (PV.isLowerRef(ref, this.st)) g.lower = null;
    else g.full = null;
  };

  Engine.prototype.endReplay = function () {
    const st = this.st, rp = st.rp.playing; if (!rp) return;
    st.rp.playing = null;
    if (rp.fromPl) { this.itemDone(); return; }
    st.trans.active = PV.sting(st, { type: 'stinger', from: 'replay', to: rp.ret || 'cam1', start: now(), dur: 1000, cut: false });
  };

  /* ---------- playlists ---------- */
  Engine.prototype.cueOf = function (listId) {
    const l = this.st.pl.lists.find(x => x.id === listId); if (!l || !l.items.length) return 0;
    const c = this.st.pl.cue[listId] || 0; return Math.min(c, l.items.length - 1);
  };
  Engine.prototype.playItem = function (listId, idx, fromBreak) {
    const st = this.st, list = st.pl.lists.find(l => l.id === listId);
    if (!list || !list.items.length) return;
    idx = Math.max(0, Math.min(idx || 0, list.items.length - 1));
    // what was on before the playlist took over
    const ret = st.pl.active && st.pl.active.ret ? st.pl.active.ret : (['video', 'replay', 'black'].includes(st.program) ? st.preview : st.program);
    if (st.pl.active) this.clearItemGfx();
    st.pl.active = { list: listId, idx, start: now(), ret, done: false, brk: !!fromBreak };
    if (!list.hidden && list.id !== 'brk') st.pl.left = listId;
    this.startItem();
  };
  Engine.prototype.startItem = function () {
    const st = this.st, pa = st.pl.active; if (!pa) return;
    const list = st.pl.lists.find(l => l.id === pa.list), item = list.items[pa.idx];
    const t = now();
    pa.start = t; pa.done = false;
    item.played = true;
    st.pl.cue[pa.list] = pa.idx + 1 < list.items.length ? pa.idx + 1 : (list.mode === 'loop' ? 0 : pa.idx + 1);
    if (item.type === 'video') { st.pl.last = { ref: item.ref, start: t }; st.gfx.full = null; if (st.program !== 'video') this.mixTo('video', t); }
    else if (item.type === 'gfx') {
      this.playGfx(item.ref, t);
      const g = st.gfx;
      if (g.lower && g.lower.at === t) g.lower.pl = !!item.dur;
      if (g.take && g.take.at === t) g.take.pl = !!item.dur;
    } else if (item.type === 'reel' || item.type === 'replay') {
      const clips = item.type === 'reel' ? st.rp.clips.filter(c => c.reel).slice().reverse() : st.rp.clips.filter(c => c.id === item.ref);
      if (!clips.length) { pa.start = t - 1300; return; }
      st.gfx.full = null;
      // the highlight reel shows each play's first angle; a replay item shows every angle. Fades between them.
      const seq = [].concat(...clips.map(c => PV.clipSeq(c, item.type === 'reel' ? [c.angles[0]] : c.angles, 'fade')));
      st.rp.playing = PV.rpStart(st, seq, { start: t + 500, speed: clips[0].speed, ret: pa.ret, reel: item.type === 'reel', fromPl: true });
      st.trans.active = PV.sting(st, { type: 'stinger', from: st.program, to: 'replay', start: t, dur: 1000, cut: false });
    }
  };
  Engine.prototype.clearItemGfx = function () {
    const st = this.st, pa = st.pl.active; if (!pa) return;
    const list = st.pl.lists.find(l => l.id === pa.list), item = list && list.items[pa.idx];
    if (!item || item.type !== 'gfx' || !item.dur) return;
    const g = st.gfx, r = item.ref;
    if (r === 'ticker') g.ticker = false;
    else if (/^five/.test(r)) g.take = null;
    else if (PV.isLowerRef(r, st)) g.lower = null;
    else g.full = null;
  };
  /* an item finished: clear its graphic, then go on depending on the playlist's mode */
  Engine.prototype.itemDone = function () {
    const st = this.st, pa = st.pl.active; if (!pa) return;
    const list = st.pl.lists.find(l => l.id === pa.list);
    const item = list.items[pa.idx];
    this.clearItemGfx();
    if (st.rp.playing && st.rp.playing.fromPl) st.rp.playing = null;
    const more = pa.idx + 1 < list.items.length;
    if (list.mode === 'order' && more) { pa.idx++; this.startItem(); return; }
    if (list.mode === 'loop') { pa.idx = more ? pa.idx + 1 : 0; this.startItem(); return; }
    // one at a time (or the end of the list): bounce back to what's in Preview
    pa.done = true;
    const back = ['video', 'replay', 'black'].includes(st.preview) ? (pa.ret || 'cam1') : st.preview;
    if (st.brk && pa.list === 'brk') { st.gfx.full = this.buildFull('board', { title: "We'll be right back" }); this.setProgram('black'); st.pl.active = null; return; }
    if (item && (item.type === 'video' || item.type === 'reel' || item.type === 'replay')) {
      if (st.program === 'replay') st.trans.active = PV.sting(st, { type: 'stinger', from: 'replay', to: back, start: now(), dur: 1000, cut: false });
      else this.mixTo(back);
    }
    st.pl.active = null;
  };
  Engine.prototype.stopPlaylist = function () {
    const st = this.st, pa = st.pl.active; if (!pa) return;
    this.clearItemGfx();
    st.pl.active = null;
    if (st.rp.playing && st.rp.playing.fromPl) st.rp.playing = null;
    if (st.brk) return;
    const back = ['video', 'replay', 'black'].includes(st.preview) ? (pa.ret || 'cam1') : st.preview;
    if (st.program === 'video' || st.program === 'replay') st.trans.active = PV.sting(st, { type: 'stinger', from: st.program, to: back, start: now(), dur: 1000, cut: false });
  };

  /* ---------- macros ---------- */
  PV.DEFAULT_MACROS = [
    { id: 'm1', name: 'Replay package', key: 'Alt+1', steps: [{ a: 'mark' }, { wait: 400 }, { a: 'roll' }] },
    { id: 'm2', name: 'Top scorer spotlight', key: 'Alt+2', steps: [{ a: 'cutCam2' }, { a: 'l3TopHome' }, { wait: 6000 }, { a: 'clrLower' }, { a: 'autoCam1' }] },
    { id: 'm3', name: 'Go to break', key: 'Alt+3', steps: [{ a: 'clrAll' }, { wait: 300 }, { a: 'brk' }] },
    { id: 'm4', name: 'Run the open', key: 'Alt+4', steps: [{ a: 'plOpen' }] }
  ];
  PV.runMacro = function (E, id) {
    const m = PV.macros().find(x => x.id === id); if (!m) return;
    PV.stopMacro(E);
    const st = E.st;
    st.macro.running = { id, step: 0, name: m.name };
    const run = (i) => {
      if (!st.macro.running || st.macro.running.id !== id) return;
      if (i >= m.steps.length) { st.macro.running = null; E.changed(); return; }
      st.macro.running.step = i;
      const s = m.steps[i];
      if (s.wait) { E.macroTimer = setTimeout(() => run(i + 1), s.wait); E.changed(); return; }
      const A = PV.ACTIONS.find(x => x.id === s.a);
      if (A) { const call = A.run(E); if (call) E.act.apply(E, call); }
      E.macroTimer = setTimeout(() => run(i + 1), 30);
    };
    run(0);
  };
  PV.stopMacro = function (E) { clearTimeout(E.macroTimer); E.st.macro.running = null; };
  PV.toggleRecord = function (E) {
    const st = E.st;
    if (!st.macro.recording) { st.macro.recording = true; E.recordedIds = []; E.recLast = now(); return; }
    st.macro.recording = false;
    const steps = E.recordedIds || [];
    if (steps.length) { const list = PV.macros(); list.push({ id: 'm' + uid(), name: `Recorded macro ${list.length + 1}`, key: '', steps }); PV.saveMacros(list); }
    E.recordedIds = null;
  };

  /* ---------- shortcut registry ---------- */
  const P = (n, a, b) => () => [n, a, b];
  PV.ACTIONS = [
    { id: 'pvw1', group: 'Switcher', label: 'Camera 1 to Preview', key: '1', run: P('preview', 'cam1') },
    { id: 'pvw2', group: 'Switcher', label: 'Camera 2 to Preview', key: '2', run: P('preview', 'cam2') },
    { id: 'pvw3', group: 'Switcher', label: 'Camera 3 to Preview', key: '3', run: P('preview', 'cam3') },
    { id: 'pvw4', group: 'Switcher', label: 'Camera 4 to Preview', key: '4', run: P('preview', 'cam4') },
    { id: 'pvwR', group: 'Switcher', label: 'Replay to Preview', key: '5', run: P('preview', 'replay') },
    { id: 'pvwV', group: 'Switcher', label: 'Video to Preview', key: '6', run: P('preview', 'video') },
    { id: 'pvwM', group: 'Switcher', label: 'M/E to Preview', key: '7', run: P('preview', 'me') },
    { id: 'pvwB', group: 'Switcher', label: 'Black to Preview', key: '0', run: P('preview', 'black') },
    { id: 'cutCam1', group: 'Switcher', label: 'Cut straight to Camera 1', key: 'Shift+1', run: P('cut', 'cam1') },
    { id: 'cutCam2', group: 'Switcher', label: 'Cut straight to Camera 2', key: 'Shift+2', run: P('cut', 'cam2') },
    { id: 'cutCam3', group: 'Switcher', label: 'Cut straight to Camera 3', key: 'Shift+3', run: P('cut', 'cam3') },
    { id: 'cutCam4', group: 'Switcher', label: 'Cut straight to Camera 4', key: 'Shift+4', run: P('cut', 'cam4') },
    { id: 'autoCam1', group: 'Switcher', label: 'Mix to Camera 1', key: '', run: P('auto', 'cam1') },
    { id: 'cut', group: 'Switcher', label: 'Cut (Preview to Program)', key: 'Enter', run: P('cut') },
    { id: 'auto', group: 'Switcher', label: 'Auto transition', key: 'Space', run: P('auto') },
    { id: 'sting', group: 'Switcher', label: 'Stinger transition', key: 'T', run: P('sting') },
    { id: 'rdNext', group: 'Rundown', label: 'Rundown: take next', key: 'R', run: P('rd.next') },
    { id: 'rdEdit', group: 'Rundown', label: 'Edit the cued rundown item', key: 'Meta+E', run: () => null },
    { id: 'mark', group: 'Replay', label: 'Mark replay', key: 'Meta+A', run: P('rp.mark') },
    { id: 'roll', group: 'Replay', label: 'Roll latest replay', key: 'P', run: P('rp.roll') },
    { id: 'rpstop', group: 'Replay', label: 'Stop replay', key: 'Shift+P', run: P('rp.stop') },
    { id: 'sb', group: 'Graphics', label: 'Scorebug on/off', key: 'S', run: P('gfx.toggle', 'scorebug') },
    { id: 'tick', group: 'Graphics', label: 'Ticker on/off', key: 'O', run: P('gfx.toggle', 'ticker') },
    { id: 'gfxGo', group: 'Graphics', label: 'Selected graphic on air / off', key: 'G', run: () => null },
    { id: 'sug', group: 'Graphics', label: 'Take top suggestion', key: '', run: P('sugg.take') },
    { id: 'l3TopHome', group: 'Graphics', label: 'Lower third: home top scorer', key: 'H', run: E => ['gfx.lower', { kind: 'player', side: 'home', num: E.topScorer('home') }] },
    { id: 'l3TopAway', group: 'Graphics', label: 'Lower third: away top scorer', key: 'J', run: E => ['gfx.lower', { kind: 'player', side: 'away', num: E.topScorer('away') }] },
    { id: 'l3Ann', group: 'Graphics', label: 'Lower third: talent', key: 'V', run: P('gfx.lower', { kind: 'announcers' }) },
    { id: 'fsTitle', group: 'Graphics', label: 'Title card', key: 'Shift+C', run: P('gfx.full', 'title') },
    { id: 'fsLineups', group: 'Graphics', label: 'Starting lineups', key: 'Shift+L', run: P('gfx.full', 'lineups') },
    { id: 'fsTape', group: 'Graphics', label: 'Tale of the tape', key: 'Shift+T', run: P('gfx.full', 'tape') },
    { id: 'fsStandings', group: 'Graphics', label: 'Standings', key: 'Shift+S', run: P('gfx.full', 'standings') },
    { id: 'fsBoard', group: 'Graphics', label: 'Score board (halftime / break)', key: 'Shift+B', run: P('gfx.full', 'board') },
    { id: 'clrLower', group: 'Graphics', label: 'Clear lower third', key: 'X', run: P('gfx.clear', 'lower') },
    { id: 'clrFull', group: 'Graphics', label: 'Clear full-screen graphic', key: 'F', run: P('gfx.clear', 'full') },
    { id: 'clrAll', group: 'Graphics', label: 'Clear all graphics', key: 'Escape', run: P('gfx.clear', 'all') },
    { id: 'clrAllB', group: 'Graphics', label: 'Clear all graphics (second key)', key: 'Backspace', run: P('gfx.clear', 'all') },
    { id: 'plnext', group: 'Playlists', label: 'Playlist: play next item', key: 'N', run: P('pl.next') },
    { id: 'plstop', group: 'Playlists', label: 'Playlist: stop', key: 'Shift+N', run: P('pl.stop') },
    { id: 'trayL', group: 'Playlists', label: 'Open or close the left tray', key: '[', run: () => null },
    { id: 'trayR', group: 'Playlists', label: 'Open or close the right tray', key: ']', run: () => null },
    { id: 'plOpen', group: 'Playlists', label: 'Play the Open playlist in order', key: '', run: P('pl.play', 'open', 0) },
    { id: 'plHalf', group: 'Playlists', label: 'Roll Halftime playlist', key: '', run: P('pl.play', 'half', 0) },
    { id: 'brk', group: 'Show', label: 'Break mode on/off', key: 'B', run: P('brk.toggle') },
    { id: 'clock', group: 'Show', label: 'Game clock start/stop', key: 'C', run: P('sb.clock') },
    { id: 'rec', group: 'Show', label: 'Record on/off', key: 'Shift+R', run: P('rec.toggle') },
    { id: 'mstop', group: 'Macros', label: 'Stop running macro', key: 'K', run: P('macro.stop') }
  ];
  PV.shortcuts = function () {
    const saved = store.get('keys2', {}); const m = {};
    // G used to take the top suggestion; it now puts the selected graphic on air and takes it off again
    if (saved.sug === 'G' && !('gfxGo' in saved)) saved.sug = '';
    for (const a of PV.ACTIONS) m[a.id] = a.id in saved ? saved[a.id] : a.key;
    return m;
  };
  PV.saveShortcuts = m => store.set('keys2', m);
  PV.macros = function () { return store.get('macros2', null) || JSON.parse(JSON.stringify(PV.DEFAULT_MACROS)); };
  PV.saveMacros = list => store.set('macros2', list);

  PV.keyName = function (e) {
    let k;
    if (/^Digit\d$/.test(e.code)) k = e.code.slice(5);
    else if (/^Numpad\d$/.test(e.code)) k = 'Num' + e.code.slice(6);
    else if (/^Key[A-Z]$/.test(e.code)) k = e.code.slice(3);
    else if (/^F\d+$/.test(e.code)) k = e.code;
    else if (e.code === 'Space') k = 'Space';
    else if (e.code === 'BracketLeft') k = '[';
    else if (e.code === 'BracketRight') k = ']';
    else k = e.key === 'Esc' ? 'Escape' : e.key;
    if (['Meta', 'Control', 'Alt', 'Shift'].includes(k)) return null;
    return (e.metaKey ? 'Meta+' : '') + (e.ctrlKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey ? 'Shift+' : '') + k;
  };
  PV.keyLabel = function (k) {
    if (!k) return '';
    return k.replace('Meta+', '⌘').replace('Ctrl+', '⌃').replace('Alt+', '⌥').replace('Shift+', '⇧').replace('Escape', 'Esc').replace('Enter', '↵').replace('Backspace', '⌫').replace(/^Num/, 'Pad ');
  };

  /* ---------- templates saved on this computer ---------- */
  // each package added on this Mac gets a template of its own
  PV.allTemplates = () => PV.BUILTIN_TEMPLATES.concat(Object.values(G.PACKAGES).filter(p => p.added).map(p => ({ id: 'nec-' + p.id, name: 'NEC · ' + p.name, network: p.id, league: 'NEC', locks: {} })), store.get('templates', []));
  /* the looks on offer: Pivot Standard and Pivot Clean are retired, so a show set to one of them moves to an added package or Arena */
  PV.lookChoice = id => {
    if (G.PACKAGES[id] && !G.PACKAGES[id].hidden) return id;
    if (id && !['standard', 'clean'].includes(id)) return id;   // a package that hasn't loaded yet
    const added = Object.values(G.PACKAGES).find(p => p.added && !p.hidden);
    return added ? added.id : 'arena';
  };
  PV.saveTemplate = function (st, name) {
    const list = store.get('templates', []);
    const tp = { id: 't' + uid(), name: name || 'My template', network: st.gfx.pkg, league: 'NEC', locks: { pkg: false },
      inputs: JSON.parse(JSON.stringify(st.inputs)), rec: { fmt: st.rec.fmt, q: st.rec.q, feeds: Object.assign({}, st.rec.feeds) },
      audio: { mode: st.audio.mode, names: st.audio.ch.map(c => c.name) }, dests: st.stream.dests.filter(d => d.on).map(d => d.id),
      burn: Object.assign({}, st.gfx.burn), custom: true };
    list.push(tp);
    return store.set('templates', list) ? tp : null;
  };
  PV.deleteTemplate = function (id) { store.set('templates', store.get('templates', []).filter(t => t.id !== id)); };

  /* ======================================================================
     LINK between windows (same Mac) and control screens (iPad, phone)
     ====================================================================== */
  PV.link = (function () {
    let bc = null, room = null, net = null;
    const handlers = [];
    const me = uid();
    try { bc = new BroadcastChannel('pivot.v2'); bc.onmessage = e => dispatch(e.data, 'local'); } catch (e) { bc = null; }
    function dispatch(msg, via) { if (!msg || typeof msg !== 'object' || msg.from === me) return; for (const h of handlers) h(msg, via); }
    async function connectRoom() {
      try {
        if (!window.claude || !window.claude.use) return;
        const r = await window.claude.use('room');
        if (!r) return;
        room = r;
        for (const topic of ['pivot.state', 'pivot.act', 'pivot.hello', 'pivot.show']) r.on(topic, m => { if (m.sameTab) return; dispatch(Object.assign({}, m.data, { _peer: m.peer }), 'room'); }, () => {});
      } catch (e) { room = null; }
    }
    connectRoom();
    return {
      me,
      on(fn) { handlers.push(fn); },
      local(msg) { if (bc) try { bc.postMessage(Object.assign({ from: me }, msg)); } catch (e) { /* closed */ } },
      remote(topic, msg) {
        if (net) { net(Object.assign({ from: me, topic }, msg)); return; }
        if (room && room.connected()) room.emit(topic, Object.assign({ from: me }, msg)).catch(() => {});
      },
      hasRoom() { return !!net || !!(room && room.connected()); },
      /* the Mac app's own network: control screens on phones and iPads */
      setNet(fn) { net = fn; },
      inject(msg) { dispatch(msg, 'room'); }
    };
  })();

  /* compact state for control screens over the network (kept under the 4 KB message limit) */
  PV.compact = function (st) {
    const sh = st.show;
    const c = {
      k: 'state', eng: st.eng, v: st.v, epoch: st.epoch,
      program: st.program, preview: st.preview, trans: { type: st.trans.type, dur: st.trans.dur, on: !!st.trans.active, sel: st.trans.sel }, me: st.me && st.me.list ? st.me.list.map(m => [m.id, m.name.slice(0, 18)]) : [],
      gfx: { pkg: st.gfx.pkg, scorebug: st.gfx.scorebug, ticker: st.gfx.ticker, lower: st.gfx.lower && { id: st.gfx.lower.id, key: st.gfx.lower.key, label: st.gfx.lower.label }, full: st.gfx.full && { id: st.gfx.full.id, kind: st.gfx.full.kind, label: st.gfx.full.label, side: st.gfx.full.side }, take: st.gfx.take && { side: st.gfx.take.side } },
      sb: st.sb,
      rp: { back: st.rp.back, speed: st.rp.speed, angles: st.rp.angles, playing: st.rp.playing && { clip: st.rp.playing.clip, idx: st.rp.playing.idx }, clips: st.rp.clips.slice(0, 6).map(c => [c.id, c.name, c.speed, c.angles, c.rolled ? 1 : 0]) },
      pl: { active: st.pl.active && { list: st.pl.active.list, idx: st.pl.active.idx }, lists: st.pl.lists.filter(l => !l.hidden).map(l => [l.id, l.name, l.mode, l.items.length, l.items.reduce((s, i) => s + (i.dur || 0), 0), (l.items[st.pl.cue[l.id] || 0] || { name: '' }).name.slice(0, 24)]) },
      rd: { idx: st.rd.idx, on: st.rd.on, cue: st.rd.cue, items: st.rd.items.slice(Math.max(0, st.rd.idx - 1), Math.max(st.rd.idx, st.rd.cue) + 5).map((it, i) => [Math.max(0, st.rd.idx - 1) + i, PV.RD_TAG[it.kind] || '', it.label.slice(0, 30), it.sub.slice(0, 30), it.done ? 1 : 0]) },
      audio: { mode: st.audio.mode, master: st.audio.master, ch: st.audio.ch.map(c => [c.name, c.fader, c.mute ? 1 : 0]) },
      brk: st.brk, rec: { on: st.rec.on, start: st.rec.start }, stream: { on: st.stream.on, start: st.stream.start },
      sugg: st.sugg.slice(0, 4).map(s => [s.id, s.title.slice(0, 40), s.why]),
      macro: st.macro.running && st.macro.running.name,
      inputs: Object.fromEntries(PV.camIds(st).map(id => [id, st.inputs[id].name])),
      show: { sport: sh.sport, home: sh.home.key, away: sh.away.key, hc: sh.home.code, ac: sh.away.code, hn: sh.home.name, an: sh.away.name, col: sh.colors, len: sh.rules.len, periods: sh.rules.periods, half: sh.rules.halftimeAfter }
    };
    let s = JSON.stringify(c);
    while (s.length > 3900 && c.sugg.length) { c.sugg.pop(); s = JSON.stringify(c); }
    while (s.length > 3900 && c.rp.clips.length) { c.rp.clips.pop(); s = JSON.stringify(c); }
    while (s.length > 3900 && c.rd.items.length > 2) { c.rd.items.pop(); s = JSON.stringify(c); }
    return c;
  };
  /* rosters for control screens, sent on their own (they don't change during a show) */
  PV.rosterMsg = st => ({ k: 'show', eng: st.eng, home: st.show.home.roster.map(r => [r[0], r[2]]), away: st.show.away.roster.map(r => [r[0], r[2]]), hs: st.show.home.starters, as: st.show.away.starters });
})();
