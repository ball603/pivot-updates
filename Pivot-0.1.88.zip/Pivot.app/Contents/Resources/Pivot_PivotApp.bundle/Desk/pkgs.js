/* Graphics packages added on this Mac arrive here; the app download carries none. */
