/* Playlists in the Replays and Videos trays: tabs down the left of the tray, each playlist with its own
   speed, loop, transition between clips and sound. ⌘-click replays or videos to pick them, ⌘C, then ⌘V in a playlist. */
(function () {
  const PV = window.PV, UI = PV.UI, esc = UI.esc, ui = UI.state;
  ui.plTab = { rp: 'all', vid: 'all' };
  ui.plPick = { kind: null, refs: [] };   // what's ⌘-clicked
  ui.plClip = null;                       // what ⌘C copied
  ui.plRen = null;                        // the tab being renamed

  const lists = (st, kind) => (kind === 'vid' ? st.vlists : st.rp.lists) || [];
  const listOf = (st, kind, id) => lists(st, kind).find(l => l.id === id);
  const tabOf = (st, kind) => { const id = ui.plTab[kind]; return id !== 'all' && listOf(st, kind, id) ? id : 'all'; };
  const keyOf = (kind, id) => kind + ':' + id;
  const word = kind => kind === 'vid' ? 'video' : 'replay';
  UI.plTabOf = tabOf;

  UI.plWrap = (tabs, body) => `<div class="plwrap">${tabs}<div class="plmain">${body}</div></div>`;
  UI.plPicked = (kind, k) => ui.plPick.kind === kind && ui.plPick.refs.includes(k) ? ' multi' : '';

  /* tabs across the top of the tray: ALL, +, then the playlists (drag one to move it) */
  UI.plTabs = function (kind, st) {
    const cur = tabOf(st, kind);
    const tab = (id, name, cls, i) => {
      const k = keyOf(kind, id);
      if (ui.plRen === k) return `<span class="trtab on"><input type="text" class="inp plren" value="${esc(name)}" maxlength="30" data-plren="${k}" aria-label="Playlist name"></span>`;
      return `<button class="trtab${cur === id ? ' on' : ''}${cls || ''}" data-do="ui.plTab|${kind}|${id}"${id === 'all' ? ` title="Every ${word(kind)}"` : ` data-pltab="${k}" draggable="true" data-drag="T|${kind}|${i}" title="${esc(name)} · Double-click to rename · Drag to move · Right-click for more"`}>${esc(name)}</button>`;
    };
    const picked = ui.plPick.kind === kind ? ui.plPick.refs.length : 0;
    return `<div class="trtabs">${tab('all', 'ALL')}`
      + `<button class="trtab add" data-do="ui.plNew|${kind}" title="Make a playlist" aria-label="New playlist">+</button>`
      + lists(st, kind).map((l, i) => tab(l.id, l.name, PV.plPlaying(st, keyOf(kind, l.id)) ? ' playing' : '', i)).join('')
      + (picked ? `<button class="trtab pick" data-do="ui.plAddTo|${kind}" title="Put them in a playlist (or ⌘C, then ⌘V in a playlist)">${picked} picked · Add to…</button>` : '')
      + `</div>`;
  };

  const wipeName = (st, w) => w.id === 'replay' ? 'Wipe' : w.kind === 'team' && st.show[w.side] ? `${st.show[w.side].code} wipe` : w.name;
  UI.plBody = function (kind, st) {
    const id = tabOf(st, kind); if (id === 'all') return null;
    const l = listOf(st, kind, id), k = keyOf(kind, id), on = PV.plPlaying(st, k), rp = kind === 'rp';
    const lv = st.pl.last;
    const cur = on ? (rp ? (PV.rpSeg(st.rp.playing) || {}).item : lv.seq && lv.seq[lv.i] && lv.seq[lv.i].item) : null;
    const ctl = `<div class="plctl">${on ? `<button class="btn sm stop" data-do="pls.stop|${kind}" title="Stop the playlist and go back">■ Stop</button>`
      : `<button class="btn sm pri" data-do="pls.roll|${k}|0"${l.items.length ? '' : ' disabled'} title="Play the playlist from the top, with the transition picked beside Preview">▶ Roll</button>`}
      <div class="seg sm vert" title="${rp ? 'Playback speed' : 'Playback speed (below 100% the sound is left out)'}">${[1, 0.75, 0.5, 0.25].map(s => `<button class="${l.speed === s ? 'on' : ''}" data-do="ui.plSet|${k}|speed|${s}">${s * 100}%</button>`).join('')}</div></div>`;
    const between = [['cut', 'Cut'], ['fade', 'Fade']].concat(PV.wipesOf(st).map(w => [w.id, wipeName(st, w)]));
    const opt = `<div class="plopt">
      <div class="seg sm"><button class="${l.loop ? '' : 'on'}" data-do="ui.plSet|${k}|loop|false" title="Play through once, then go back">List</button><button class="${l.loop ? 'on' : ''}" data-do="ui.plSet|${k}|loop|true" title="Keep playing it until you take something else">Loop</button></div>
      <label class="pll"><span>Between clips</span><select class="inp" data-ch="ui.plBetween|${k}" aria-label="Transition between clips">${between.map(([v, n]) => `<option value="${esc(v)}"${l.between === v ? ' selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
      ${rp ? '' : `<label class="chk"><input type="checkbox" data-ch="ui.plMute|${k}"${l.mute ? ' checked' : ''}>Mute sound</label>`}</div>`;
    const look = window.PIVOT_GFX, stamps = look ? look.stampsOf(st.gfx.pkg) : [];
    const tiles = l.items.map((it, i) => {
      const sel = ui.sel && ui.sel.kind === 'pli' && ui.sel.b === it.id;
      const drag = `draggable="true" data-drag="l|${k}|${i}" data-plitem="${k}|${it.id}|${i}" title="Click to pick it (Delete takes it out) · Drag it to where it should play"`;
      if (it.stamp) {
        // an end stamp: a picture of its card, how long it runs, and a note when the look in use doesn't have it
        const s = look && look.stampOf(st.gfx.pkg, it.stamp);
        const pic = s ? `<img alt="" src="${s.frames[Math.min(s.frames.length - 1, (s.cover || 0) + s.fps * 2)]}">` : '<span class="stmiss">Not in this look</span>';
        const len = s ? (s.frames.length / s.fps).toFixed(1) + 's' : '';
        const tile = `<div class="${rp ? 'rt3' : 'vt3'} stamp${rp ? '' : ' pli3'}${!rp && sel ? ' sel' : ''}" data-stamp="${esc(it.stamp)}" title="Double-click: play it now, then go to what's in Preview"${rp ? '' : ' ' + drag}>${pic}${rp ? '' : `<span class="pln">${i + 1}</span>`}<span class="tln">${rp && s ? `<b>${esc(s.sport)}</b>` : esc(it.name)}</span><span class="vlen tc">${len}</span>${rp ? '' : `<button class="rpx" data-do="pls.rm|${k}|${it.id}" title="Take it out of the playlist" aria-label="Take ${esc(it.name)} out">×</button>`}</div>`;
        return rp ? `<div class="rpg rplg${sel ? ' picked' : ''}" ${drag}><div class="rpgh"><span class="pln">${i + 1}</span><b>${esc(it.name)}</b><small>${len}</small><button class="rpx" data-do="pls.rm|${k}|${it.id}" title="Take it out of the playlist" aria-label="Take ${esc(it.name)} out">×</button></div><div class="rpgt">${tile}</div></div>` : tile;
      }
      if (rp) {
        // a replay in a playlist looks the way it does in All replays: its name over a picture of each angle
        const len = it.angles.reduce((n, x) => n + PV.cutLen(it, x), 0) / l.speed;
        const name = ui.renamingItem === it.id ? `<input type="text" class="inp rpren" value="${esc(it.name)}" maxlength="40" data-iren="${it.id}" aria-label="Name">` : `<b>${esc(it.name)}</b>`;
        // its angles work as they do in All replays (while the play is still there): click for Preview,
        // double-click on air to fade to it, and the red line along the bottom of the one playing
        const live = st.rp.clips.some(c => c.id === it.src), onAir = st.program === 'replay' && st.rp.playing;
        const seg = onAir ? PV.rpSeg(st.rp.playing) : null;
        const angs = it.angles.map(a => {
          const c = PV.cut(it, a), pv = ` data-pv="rp|${it.src}|${a}" data-pli="${it.id}"`;
          const isPv = live && st.preview === 'replay' && st.pv.rp && st.pv.rp.clip === it.src && st.pv.rp.ang === a;
          const tip = live ? ` title="Click: Preview${onAir ? ' · Double-click: fade to this angle from its start' : ' · Double-click: take it'}"` : '';
          const isOn = !!seg && seg.item === it.id && seg.cam === a;
          return `<div class="rt3${isOn ? ' pgm' : ''}${isPv ? ' pvw' : ''}"${pv}${tip}><canvas data-still="rpt|${a}|${(c.tIn + (c.tOut - c.tIn) * 0.6).toFixed(1)}"></canvas><span class="tln"><b>${PV.srcShort(a)}</b> ${esc((st.inputs[a] || {}).name || '')}</span><span class="vlen tc">${(PV.cutLen(it, a) / l.speed).toFixed(1)}s</span><i class="rptl" aria-hidden="true"><i></i></i></div>`;
        }).join('');
        return `<div class="rpg rplg${cur === it.id ? ' pgm' : ''}${sel ? ' picked' : ''}" draggable="true" data-drag="l|${k}|${i}" data-plitem="${k}|${it.id}|${i}" title="Click to pick it (Delete takes it out, ⌘R renames it) · Double-click: roll from here · Drag to change the order">`
          + `<div class="rpgh"><span class="pln">${i + 1}</span>${name}<small>${len.toFixed(1)}s</small><button class="rpx" data-do="pls.rm|${k}|${it.id}" title="Take it out of the playlist" aria-label="Take ${esc(it.name)} out">×</button></div><div class="rpgt">${angs}</div></div>`;
      }
      let still, len, sub = '';
      if (rp) {
        const a = it.angles[0], c = PV.cut(it, a);
        still = `rpt|${a}|${(c.tIn + (c.tOut - c.tIn) * 0.6).toFixed(1)}`;
        len = it.angles.reduce((n, x) => n + PV.cutLen(it, x), 0) / l.speed;
        sub = it.angles.length > 1 ? `${it.angles.length} angles` : PV.srcShort(a);
      } else { still = `vref|${it.ref}|${it.tIn}`; len = Math.max(0, it.tOut - it.tIn) / l.speed; }
      return `<div class="${rp ? 'rt3' : 'vt3'} pli3${cur === it.id ? ' pgm' : ''}${sel ? ' sel' : ''}" draggable="true" data-drag="l|${k}|${i}" data-plitem="${k}|${it.id}|${i}" title="Click to pick it (Delete takes it out, ⌘R renames it) · Double-click: roll from here · Drag to change the order">`
        + `<canvas data-still="${esc(still)}"></canvas><span class="pln">${i + 1}</span><span class="tln">${ui.renamingItem === it.id ? `<input type="text" class="inp rpren" value="${esc(it.name)}" maxlength="40" data-iren="${it.id}" aria-label="Name">` : `${esc(it.name)}${sub ? ` <small>${esc(sub)}</small>` : ''}`}</span><span class="vlen tc">${rp ? len.toFixed(1) + 's' : UI.ms(len)}</span>`
        + `<button class="rpx" data-do="pls.rm|${k}|${it.id}" title="Take it out of the playlist" aria-label="Take ${esc(it.name)} out">×</button></div>`;
    }).join('');
    const clip = ui.plClip && ui.plClip.kind === kind ? ui.plClip.refs.length : 0;
    const paste = clip ? `<button class="${rp ? 'rt3' : 'vt3'} plus plpaste" data-do="ui.plPaste|${k}" title="Paste what you copied (⌘V)">+<small>Paste ${clip}</small></button>` : '';
    const addStamp = stamps.length ? `<button class="${rp ? 'rt3' : 'vt3'} plus plpaste" data-do="ui.plStamp|${k}" title="Add an end stamp: it goes at the end, and can be dragged anywhere in the playlist">+<small>End stamp</small></button>` : '';
    const empty = l.items.length ? '' : `<div class="rpempty"><span>⌘-click ${word(kind)}s in <b>${kind === 'vid' ? 'All videos' : 'All replays'}</b> to pick them, ⌘C to copy, then come back here and press ⌘V.</span></div>`;
    return ctl + opt + `<div class="plitems">${tiles}${paste}${addStamp}${empty}</div>`;
  };

  /* picks become what a playlist holds */
  const refsOf = (kind, picks) => kind === 'rp' ? picks.map(r => { const [clip, cam] = r.split('|'); return { clip, cam: cam || null }; }) : picks.slice();
  function pasteInto(k, kind, picks) {
    UI.send('pls.paste', k, refsOf(kind, picks));
    if (ui.plPick.kind === kind) ui.plPick = { kind: null, refs: [] };   // they're in now
    ui.plTab[kind] = k.split(':')[1];
    UI.dirty = true;
  }
  function newList(kind) {
    UI.send('pls.new', kind);
    const L = lists(PV.E.st, kind), l = L[L.length - 1];
    ui.plTab[kind] = l.id;
    return keyOf(kind, l.id);
  }

  UI.plLocal = function (name, args, el) {
    const st = PV.E.st;
    if (name === 'ui.plTab') { ui.plTab[args[0]] = args[1]; }
    else if (name === 'ui.plNew') { rename(newList(args[0])); return; }   // name it straight away
    else if (name === 'ui.plSet') { const [k, f, v] = args; UI.send('pls.set', k, { [f]: v }); }
    else if (name === 'ui.plBetween') UI.send('pls.set', args[0], { between: args[1] });
    else if (name === 'ui.plMute') UI.send('pls.set', args[0], { mute: !!args[1] });
    else if (name === 'ui.plStamp') {
      // the look's end stamps, the ones for this game's sport first
      const k = args[0], st = PV.E.st, look = window.PIVOT_GFX, all = look ? look.stampsOf(st.gfx.pkg) : [];
      const mine = all.filter(x => (x.sports || []).includes(st.show.sport)), rest = all.filter(x => !mine.includes(x));
      const row = x => ({ label: `${x.name} · ${x.sport}`, sub: (x.frames.length / x.fps).toFixed(1) + ' seconds', id: x.id });
      const items = mine.map(row).concat(mine.length && rest.length ? [{ sep: true }] : [], rest.map(row));
      UI.popMenu(el, items, it => UI.send('pls.addStamp', k, it.id));
    }
    else if (name === 'ui.plPaste') { const k = args[0], kind = k.split(':')[0]; if (ui.plClip && ui.plClip.kind === kind) { pasteInto(k, kind, ui.plClip.refs); UI.toast(`Pasted ${ui.plClip.refs.length}`); } }
    else if (name === 'ui.plAddTo') {
      const kind = args[0], picks = ui.plPick.refs.slice(); if (!picks.length) return;
      const items = lists(st, kind).map(l => ({ label: l.name, sub: `${l.items.length} in it`, k: keyOf(kind, l.id) })).concat([{ label: 'New playlist', k: null }]);
      UI.popMenu(el, items, it => { const k = it.k || newList(kind); pasteInto(k, kind, picks); UI.toast(`Added ${picks.length} to ${listOf(PV.E.st, kind, k.split(':')[1]).name}`); });
      return;
    }
    UI.dirty = true;
  };

  /* dragging a replay angle, a whole play or a video onto a playlist tab adds it to the end
     (with others picked, the picked ones go in) */
  UI.plDragRefs = function (d) {
    if (!d || d.kind !== 'item') return null;
    const st = PV.E.st;
    let kind, ref;
    if (d.t === 'a') { const c = st.rp.clips.find(x => x.id === d.g); if (!c || !c.angles[d.from]) return null; kind = 'rp'; ref = c.id + '|' + c.angles[d.from]; }
    else if (d.t === 'p') { const c = st.rp.clips[d.from]; if (!c) return null; kind = 'rp'; ref = c.id + '|'; }
    else if (d.t === 'v') { const v = (st.vids[d.g] || [])[d.from]; if (!v) return null; kind = 'vid'; ref = v.id; }
    else return null;
    const picks = ui.plPick.kind === kind && ui.plPick.refs.includes(ref) ? ui.plPick.refs.slice() : [ref];
    return { kind, picks };
  };
  UI.plDropIn = function (k, r) {
    const [kind, id] = k.split(':'), l = listOf(PV.E.st, kind, id); if (!l) return;
    UI.send('pls.paste', k, refsOf(kind, r.picks));
    if (ui.plPick.kind === kind) ui.plPick = { kind: null, refs: [] };
    UI.toast(`Added ${r.picks.length === 1 ? 'it' : r.picks.length} to the end of ${l.name}`);
    UI.dirty = true;
  };

  /* ⌘C copies what's picked; ⌘V pastes it into the playlist tab that's open */
  UI.plKey = function (k) {
    if (k === 'Meta+C' && ui.plPick.refs.length) {
      ui.plClip = { kind: ui.plPick.kind, refs: ui.plPick.refs.slice() };
      UI.toast(`Copied ${ui.plClip.refs.length}. Open a playlist tab and press ⌘V.`);
      UI.dirty = true; return true;
    }
    if (k === 'Meta+V' && ui.plClip) {
      const kind = ui.plClip.kind, id = tabOf(PV.E.st, kind);
      if (id === 'all') { UI.toast('Open a playlist tab first, then press ⌘V'); return true; }
      pasteInto(keyOf(kind, id), kind, ui.plClip.refs);
      UI.toast(`Pasted ${ui.plClip.refs.length} into ${listOf(PV.E.st, kind, id).name}`);
      return true;
    }
    return false;
  };

  /* ⌘-click picks a replay angle, a whole play (its name bar) or a video, without touching Preview */
  window.addEventListener('click', e => {
    if (!e.metaKey) return;
    const t = e.target.closest('[data-pv^="rp|"],[data-pv^="vid|"],.rpgh[data-clip]');
    if (!t || t.closest('.scrim') || e.target.closest('[data-do],input')) return;
    e.stopPropagation(); e.preventDefault();
    let kind, ref;
    if (t.matches('.rpgh')) { kind = 'rp'; ref = t.dataset.clip + '|'; }
    else { const [k, a, b] = t.dataset.pv.split('|'); kind = k; ref = k === 'rp' ? a + '|' + b : a; }
    if (ui.plPick.kind !== kind) ui.plPick = { kind, refs: [] };
    const i = ui.plPick.refs.indexOf(ref);
    if (i >= 0) ui.plPick.refs.splice(i, 1); else ui.plPick.refs.push(ref);
    UI.dirty = true;
  }, true);

  /* a playlist's clips: click picks one, double-click rolls from there */
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-plitem]'); if (!t || e.target.closest('[data-do],[data-pv]')) return;
    const [k, id] = t.dataset.plitem.split('|');
    ui.sel = { kind: 'pli', a: k, b: id }; UI.dirty = true;
  });
  document.addEventListener('dblclick', e => {
    // an end stamp double-clicked plays straight away, over whatever is on air
    const sp = e.target.closest('[data-stamp]'); if (sp && !e.target.closest('[data-do]')) { UI.send('pl.stamp', sp.dataset.stamp); return; }
    if (e.target.closest('[data-pv]')) return;   // an angle: handled like the ones in All replays
    const t = e.target.closest('[data-plitem]');
    if (t && !e.target.closest('[data-do]')) { const [k, , i] = t.dataset.plitem.split('|'); UI.send('pls.roll', k, +i); return; }
    const tb = e.target.closest('[data-pltab]'); if (tb) rename(tb.dataset.pltab);
  });
  document.addEventListener('contextmenu', e => {
    const tb = e.target.closest('[data-pltab]'); if (!tb) return;
    e.preventDefault();
    const k = tb.dataset.pltab, st = PV.E.st, [kind, id] = k.split(':'), l = listOf(st, kind, id); if (!l) return;
    const playing = PV.plPlaying(st, k);
    UI.popMenu(tb, [{ label: 'Rename', go: () => rename(k) }, { label: `Delete ${l.name}`, sub: playing ? 'Stop it first' : 'The replays and videos stay', disabled: playing, go: () => { UI.send('pls.del', k); ui.plTab[kind] = 'all'; UI.dirty = true; } }], x => x.go());
  });
  function rename(k) {
    ui.plRen = k; UI.dirty = true; UI.renderNow && UI.renderNow();
    setTimeout(() => {
      const f = document.querySelector(`[data-plren="${k}"]`); if (!f) return;
      f.focus(); f.select();
      let gone = false;
      const done = save => { if (gone) return; gone = true; ui.plRen = null; if (save && f.value.trim()) UI.send('pls.set', k, { name: f.value.trim() }); f.blur(); UI.dirty = true; };
      f.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Enter') { ev.preventDefault(); done(true); } else if (ev.key === 'Escape') { ev.preventDefault(); done(false); } });
      f.addEventListener('blur', () => done(true));
    }, 60);
  }

  /* Delete takes the picked clip out of its playlist */
  const oldDel = UI.deletePicked;
  UI.deletePicked = function () {
    const s = ui.sel;
    if (s && s.kind === 'pli') { UI.send('pls.rm', s.a, s.b); ui.sel = null; UI.dirty = true; return true; }
    return oldDel();
  };
})();
