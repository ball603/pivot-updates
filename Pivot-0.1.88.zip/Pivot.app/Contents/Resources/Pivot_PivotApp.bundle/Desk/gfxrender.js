/* Draws the program graphics for the stream and recordings.
   The app keeps this page out of sight and takes a picture of it every frame. */
(function () {
  const G = window.PIVOT_GFX;
  const H = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.gfx;
  const post = m => { try { H && H.postMessage(m); } catch (e) { /* closing */ } };
  const stage = G.createStage(document.getElementById('stage'));
  let show = null, st = null, active = null;

  window.PivotGfx = {
    show(s) { show = s; },
    state(s) { st = s; },
    marks(m) { window.PIVOT_MARKS = m || {}; }
  };

  /* every CSS animation is stepped from here, so each picture shows exactly where it is */
  const t0 = performance.now();
  function stepAnimations(now) {
    for (const a of document.getAnimations()) {
      if (a.__pv == null) { a.__pv = now - (a.currentTime || 0); a.pause(); }
      a.currentTime = now - a.__pv;
    }
  }

  /* the app takes a picture only when something on the page changed or is moving: a scorebug sitting still
     (or a clock ticking once a second) costs next to nothing, which matters most on older Macs */
  let dirty = true;
  new MutationObserver(() => { dirty = true; }).observe(document.body, { subtree: true, attributes: true, childList: true, characterData: true });
  const moving = () => document.getAnimations().some(a => {
    const end = a.effect && a.effect.getComputedTiming().endTime;
    return end === Infinity || (a.currentTime || 0) < (end || 0) + 50;
  });

  function frame() {
    requestAnimationFrame(frame);
    const now = performance.now();
    if (show && st) {
      const full = Object.assign({}, st, { show });
      try { stage.update(full, Date.now()); } catch (e) { post({ type: 'log', msg: 'graphics: ' + e.message }); }
    }
    stepAnimations(now);
    // only worth photographing while something is on screen
    const on = !!document.querySelector('.gfx-stage .lay:not(.hide)') || (document.querySelector('.g-sting') || {}).style && document.querySelector('.g-sting').style.display !== 'none';
    if (on !== active) { active = on; post({ type: 'active', on }); dirty = true; }
    if (active && (dirty || moving())) { dirty = false; post({ type: 'changed' }); }
  }
  requestAnimationFrame(frame);
  void t0;
  post({ type: 'ready' });
})();
