/* Basketball: men's and women's. Halves or quarters, team fouls and the bonus, timeouts, media timeouts,
   and its line from the live box score when the game comes from NEC Front Row. */
(function () {
  const PV = window.PV;
  const Eng = PV.Engine.prototype;
  const fromFR = st => !!(st && st.show && st.show.game && st.show.game.fr);
  const hoops = st => /BB$/.test((st && st.show && st.show.sport) || '');
  const rowOf = PV.liveRow;

  PV.registerSport({
    id: 'basketball', name: 'Basketball',
    codes: { MBB: "Men's Basketball", WBB: "Women's Basketball" },
    /* how each game is played: periods, length, fouls for the bonus, media timeouts */
    rules: {
      MBB: { periods: 2, len: 20, unit: 'half', halftimeAfter: 1, bonus: 7, foulsReset: 'half', media: [16, 12, 8, 4], ot: 5, timeouts: 4 },
      WBB: { periods: 4, len: 10, unit: 'quarter', halftimeAfter: 2, bonus: 5, foulsReset: 'quarter', media: [5], ot: 5, timeouts: 4 }
    },
    board: {
      steps: [1, 2, 3],
      start: 'Tip-off', banner: true, feedWord: 'scoreboard box',
      // fouls, the bonus and timeouts under each score
      teamLine: (st, side) => { const sb = st.sb; return `<span class="fl">Fouls ${sb.fouls[side]}${sb.bonus[side] ? ' · <b>BONUS</b>' : ''} · TO ${(sb.timeouts || {})[side] ?? '—'}</span>`; },
      panel: (st, side) => {
        const pm = (act, label) => `<div class="sbpm"><span>${label}</span><button class="btn sm" data-do="${act}|${side}|-1" aria-label="${label} minus one">−</button><button class="btn sm" data-do="${act}|${side}|1" aria-label="${label} plus one">+</button></div>`;
        return pm('sb.foul', 'FOUL') + pm('sb.to', 'TIMEOUT');
      }
    }
  });

  /* a basketball player's line from the live box score, in the shape the game lower thirds read */
  const oldStatFor = Eng.statFor;
  Eng.statFor = function (side, num) {
    const st = this.st;
    if (!fromFR(st) || !st.live) return oldStatFor.call(this, side, num);
    const g = rowOf(st, side, num).box; if (!g) return { pts: 0, reb: 0, ast: 0 };
    const v = c => { const i = g.cols.indexOf(c); return i >= 0 ? g.r[i] : null; };
    const pair = c => String(v(c) || '0-0').split('-').map(x => +x || 0);
    const [fgm, fga] = pair('FG'), [tpm, tpa] = pair('3PT'), [ftm, fta] = pair('FT');
    return { pts: +v('Pts') || 0, fgm, fga, tpm, tpa, ftm, fta, reb: +v('Reb') || 0, oreb: 0, ast: +v('Ast') || 0, to: +v('TO') || 0, stl: +v('Stl') || 0, blk: +v('Blk') || 0, pf: +v('PF') || 0, min: v('Min') || 0 };
  };

  /* the game's leaders from the live box score */
  const oldLeaders = Eng.leaders;
  Eng.leaders = function (side) {
    if (hoops(this.st) && fromFR(this.st)) return [PV.liveBest(this.st, side, 'Pts', 'PTS'), PV.liveBest(this.st, side, 'Reb', 'REB'), PV.liveBest(this.st, side, 'Ast', 'AST')];
    return oldLeaders.call(this, side);
  };
  const oldFull = Eng.buildFull0;
  Eng.buildFull0 = function (kind, opts) {
    const st = this.st, F = oldFull.call(this, kind, opts);
    if (kind !== 'gameLeaders' || !F || !hoops(st) || !fromFR(st) || !st.live) return F;
    const L = (s, c, u) => PV.liveBest(st, s, c, u), r = (label, a, h) => [label, `${a.name} · ${a.v}`, `${h.name} · ${h.v}`];
    F.rows = [r('Points', L('away', 'Pts', 'PTS'), L('home', 'Pts', 'PTS')), r('Rebounds', L('away', 'Reb', 'REB'), L('home', 'Reb', 'REB')), r('Assists', L('away', 'Ast', 'AST'), L('home', 'Ast', 'AST'))];
    return F;
  };
})();
