/* Soccer: men's and women's. Two halves, goals one at a time, cards, subs, penalty kicks and team stats.
   What it shares with field hockey (the starting XI, player and team numbers) is in sport-field.js. */
(function () {
  const PV = window.PV;
  const rules = { periods: 2, len: 45, unit: 'half', halftimeAfter: 1, bonus: 99, foulsReset: 'half', media: [], ot: 10, timeouts: 0, field: true, soccer: true };
  PV.registerSport({
    id: 'soccer', name: 'Soccer',
    codes: { MSOC: "Men's Soccer", WSOC: "Women's Soccer" },
    rules: { MSOC: rules, WSOC: rules },
    board: {
      start: 'Kickoff',
      // each team's panel: the shootout while it's on, who scored, subs and cards
      panel: (st, side, H) => {
        const sh = st.show, UI = PV.UI;
        const pk = sh.pk && sh.pk.on ? `<div class="sbpk"><button class="btn sm pkg" data-do="sb.pkKick|${side}|1">Scored</button><button class="btn sm pkx" data-do="sb.pkKick|${side}|0">Missed</button><button class="btn sm ghost" data-do="sb.pkUndo|${side}" ${(sh.pk[side] || []).length ? '' : 'disabled'}>Undo</button><span class="pkm">${(sh.pk[side] || []).map((k, i) => `<button class="${k === 'G' ? 'g' : 'x'}" data-do="sb.pkFlip|${side}|${i}" title="Kick ${i + 1}: ${k === 'G' ? 'scored' : 'missed'} · click to change it to ${k === 'G' ? 'missed' : 'scored'}">${k}</button>`).join('')}</span></div>` : '';
        const acts = `<div class="sbacts"><button class="btn sm" data-do="ui.sbgoal|${side}" title="Who scored: shows for ${PV.GOAL_HOLD} seconds">Goal by…</button><button class="btn sm sbg${H.tally(UI.subLive(st, side), UI.subInPv(st, side))}" data-cd="sub|${side}" title="Pick who comes on, then who goes off: it goes up under the scorebug for ${PV.CARD_HOLD} seconds (or until the scorebug comes off)">Sub…</button></div>`;
        const reds = (sh[side].reds || []).length, cards = `<div class="sbcards"><button class="btn sm ycard" data-do="ui.sbcard|${side}|yellow">Yellow card</button><button class="btn sm rcard" data-do="ui.sbcard|${side}|red">Red card</button>${reds ? `<button class="btn sm" data-do="ui.sbdown|${side}" title="Shows for ${PV.GOAL_HOLD} seconds">Down to ${11 - reds}</button><button class="btn sm" data-do="sb.full|${side}" title="The red cards no longer count: back to 11">Full strength</button>` : ''}${(sh[side].cards || []).length ? `<button class="btn sm" data-do="ui.recard|${side}" title="Put a card from this game back up for ${PV.CARD_HOLD} seconds">Cards again…</button>` : ''}</div>`;
        return pk + acts + cards;
      },
      // under the scoreboard: team stats, the scorebug ticker and the shootout
      tools: (st, H) => {
        const sh = st.show, UI = PV.UI;
        return `<span class="btng"><button class="btn sm sbg${H.tally(UI.statsLive(st), UI.statsInPv(st))}" data-cd="stats" title="Click: Preview · Double-click: on air · ⚙ or right-click: pick the stats and check the numbers">Team stats</button><button class="btn sm bgear" data-cdgear="stats" title="Pick the stats and check the numbers" aria-label="Team stats settings">⚙</button></span>`
          + `<span class="btng"><button class="btn sm${st.gfx.sbTicker ? ' on' : ''}" data-do="gfx.sbTicker" data-tkmenu aria-pressed="${!!st.gfx.sbTicker}" title="Today's other NEC games under the scorebug, six seconds each (it comes down with the scorebug) · ⚙ or right-click to pick the games">Ticker</button><button class="btn sm bgear" data-tkgear title="Pick the games" aria-label="Ticker settings">⚙</button></span>`
          + `<button class="btn sm${sh.pk && sh.pk.on ? ' on' : ''}" data-do="sb.pk" aria-pressed="${!!(sh.pk && sh.pk.on)}" title="${sh.pk && sh.pk.on ? 'Back to the scorebug' : 'The shootout takes the scorebug\'s place'}">Penalty kicks</button>`;
      }
    }
  });
})();
