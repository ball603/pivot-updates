/* Pivot inside the Mac app: connects the desk to the real video engine.
   Video is drawn by the app behind this page; the page sends the show state and where each picture goes. */
(function () {
  const H = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.pivot;
  if (!H) return;
  const PV = window.PV, UI = PV.UI;
  const esc = UI.esc;
  const N = PV.native = { status: null, levels: null, devices: [], dests: [], output: {}, recSettings: {}, services: [], snaps: {}, snapReq: {}, recInfo: null };
  document.documentElement.classList.add('native');

  const post = m => { try { H.postMessage(m); } catch (e) { /* app closing */ } };
  N.post = post;
  /* a camera slot with nothing picked for it yet */
  N.noDevice = id => { const i = ((N.status && N.status.inputs) || []).find(x => x.id === id); return !!i && !i.device; };
  N.handles = src => typeof src === 'string' && (/^cam\d+$/.test(src) || src.indexOf('me:') === 0 || src === 'black' || src === 'replay');   // bars are drawn here, so the tile always shows them

  /* ---------- pictures for editors and other places inside dialogs ---------- */
  N.drawSnap = function (ctx, w, h, src, extra) {
    const me = extra && extra.me ? meForNative(extra.me) : null;
    const key = (extra && extra.key) || src;
    const meJson = me ? JSON.stringify(me) : '';
    const r = N.snapReq[key] || (N.snapReq[key] = { t: 0, me: '', src: '', pending: false });
    const now = performance.now();
    const changed = meJson !== r.me || src !== r.src;
    // one request at a time per picture; ask again when it changes, or every tenth of a second for live pictures
    const due = r.pending ? now - r.t > 600 : (changed ? now - r.t > 40 : now - r.t > 100);
    if (due) {
      r.t = now; r.me = meJson; r.src = src; r.pending = true;
      post({ type: 'snap', id: key, src, w: Math.max(64, Math.min(960, Math.round(w))), h: Math.max(36, Math.min(540, Math.round(h))), me });
    }
    const img = N.snaps[key];
    if (img && img.complete && img.naturalWidth) { ctx.drawImage(img, 0, 0, w, h); return true; }
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    return false;
  };

  /* control screens on phones and iPads go through the app */
  PV.link.setNet(m => { if (N.server && N.server.clients) post({ type: 'link', json: JSON.stringify(m) }); });
  // the whole show once a second, for multiviews on the network
  setInterval(() => { if (PV.E && N.server && N.server.clients) PV.link.remote('pivot.state', { k: 'state', s: PV.E.st }); }, 1000);

  /* files: videos for the Videos row, sounds for the Sounds row */
  const picks = {};
  N.pickSound = cb => { const id = 'p' + Math.random().toString(36).slice(2, 8); picks[id] = cb; post({ type: 'pickSound', token: id }); };
  /* a page from NEC Front Row, read by the Mac (a page in the desk can't read another site directly) */
  const asks = {};
  N.http = url => new Promise(res => { const id = 'h' + Math.random().toString(36).slice(2, 9); asks[id] = res; post({ type: 'http', token: id, url }); setTimeout(() => { if (asks[id]) { delete asks[id]; res({ status: 0, text: '' }); } }, 20000); });
  // a color picked off anywhere on the screen
  N.sampleColor = cb => { const id = 'c' + Math.random().toString(36).slice(2, 8); picks[id] = cb; post({ type: 'sampleColor', token: id }); };
  N.pickImage = cb => { const id = 'p' + Math.random().toString(36).slice(2, 8); picks[id] = cb; post({ type: 'pickImage', token: id }); };
  UI.addVideo = seg => post({ type: 'pickVideo', seg });
  // the stream's graphics need the pictures loaded for the watermark and replay burn
  setTimeout(() => { if (PV.publishMarks) PV.publishMarks(); }, 0);

  /* sounds that come inside a graphics package: written out once as files the engine can play */
  const pkgRefs = {};
  function loadPkgSounds() {
    const P = (window.PIVOT_GFX && PIVOT_GFX.PACKAGES) || {};
    for (const id of Object.keys(P)) {
      const W = (P[id].build || {}).wipes || {}, stamps = (P[id].build || {}).stamps || [];
      for (const w of [W.in, W.out].concat(stamps)) {
        if (!w || !w.sound || pkgRefs[w.id] !== undefined) continue;
        pkgRefs[w.id] = null;
        const tok = 's' + Math.random().toString(36).slice(2, 8);
        picks[tok] = item => { pkgRefs[w.id] = item && item.ref || null; };
        post({ type: 'pkgSound', token: tok, pkg: id, name: w.id.replace(/[^a-z0-9]/g, ''), ext: w.ext || 'wav', data: String(w.sound).replace(/^data:[^,]*,/, '') });
      }
    }
  }
  setTimeout(loadPkgSounds, 0);
  window.addEventListener('pivot-packages', () => setTimeout(loadPkgSounds, 0));

  function meForNative(m) {
    return { id: m.id, name: m.name || m.id, layers: (m.layers || []).map(l => Object.assign({}, l)), bars: m.bars || [] };
  }

  /* ---------- what the engine needs to know ---------- */
  function videoState(st) {
    const tr = st.trans.active;
    let transition = null;
    if (tr && tr.type === 'mix') transition = { type: 'mix', from: tr.from, to: tr.to, start: tr.start, duration: tr.dur };
    else if (tr && tr.type === 'stinger') {
      const w = (st.trans.wipes || []).find(x => x.id === tr.wipe) || {};
      const c = st.show.colors;
      let a = c.away, b = c.home;
      if (w.kind === 'team' && w.side) { a = c[w.side]; b = c[w.side === 'away' ? 'home' : 'away']; }
      transition = { type: 'wipe', from: tr.from, to: tr.to, start: tr.start, duration: tr.dur || 1000, wipeKind: tr.stamp ? 'pkg' : (w.kind || 'pkg'), colorA: a, colorB: b, cut: tr.at || 0.5 };
    }
    const isFile = r => typeof r === 'string' && r.indexOf('file:') === 0;
    const lv = st.pl.last;
    const vidOn = st.program === 'video' || (tr && (tr.to === 'video' || tr.from === 'video'));
    const video = lv && isFile(lv.ref) && vidOn ? { ref: lv.ref, tIn: +lv.tIn || 0, tOut: +lv.tOut || 0, start: lv.start, gain: lv.gain == null ? 0.8 : lv.gain, speed: lv.speed || 1, fade: lv.xf || 0, take: lv.take || 0 } : null;
    const cv = st.preview === 'video' && st.pv && st.pv.vid ? PV.vidItem(st, st.pv.vid) : null;
    const videoCue = cv && isFile(cv.ref) ? { ref: cv.ref, tIn: +cv.tIn || 0, tOut: +cv.tOut || 0, start: 0, gain: cv.gain } : null;
    const sp = st.sndPlay, sd = sp ? (st.snds || []).find(x => x.id === sp.id) : null;
    // a package's own wipe brings its own sound
    const ow = tr && tr.type === 'stinger' && window.PIVOT_GFX && PIVOT_GFX.pkgWipe ? PIVOT_GFX.pkgWipe(st.gfx.pkg, st, tr) : null;
    // into a break during an end stamp, its sound stops there (the sound is never sent again, so it can't start over)
    const sting = ow && pkgRefs[ow.id] && !tr.fadeAt ? { ref: pkgRefs[ow.id], tIn: 0, tOut: tr.dur / 1000, start: tr.start, gain: ow.gain == null ? 0.8 : ow.gain } : null;
    const sound = sd && isFile(sd.file) ? { ref: sd.file, tIn: +sd.tIn || 0, tOut: +(sd.tOut || sd.dur) || 0, start: sp.start, gain: sd.gain == null ? 0.8 : sd.gain } : null;
    // replays: stored moments are found by the desk's clock
    const W = T => Math.round(PV.wallOf(st, T));
    const clips = st.rp.clips || [];
    let replay = null;
    const rpp = st.rp.playing;
    const seg = PV.rpSeg(rpp);
    if (seg) replay = { cam: seg.cam, tIn: W(seg.tIn), tOut: W(seg.tOut), start: rpp.start, speed: rpp.speed || 1, fade: rpp.xf || 0, take: rpp.take || 0 };
    // the last picture holds while a replay mixes or wipes away
    if (replay) lastRp = replay; else if (tr && tr.from === 'replay' && lastRp) replay = lastRp; else lastRp = null;
    let replayStill = null;
    const pvr = st.pv && st.pv.rp, cued = pvr ? clips.find(c => c.id === pvr.clip) : null;
    if (cued && pvr.ang) replayStill = { cam: pvr.ang, at: W(PV.cut(cued, pvr.ang).tIn) };
    else if (clips[0] && clips[0].angles.length) replayStill = { cam: clips[0].angles[0], at: W(PV.cut(clips[0], clips[0].angles[0]).tIn) };
    const replayKeep = clips.map(c => [W(Math.min(c.win ? c.win[0] : c.tIn, c.tIn)), W(Math.max(c.win ? c.win[1] : c.tOut, c.tOut))])
      .concat(PV.plKeep(st).map(([a, b]) => [W(a), W(b)]));
    return { program: st.program, preview: st.preview, transition, mes: (st.me.list || []).map(meForNative), fadeMs: st.trans.dur, breakOn: !!st.brk, away: st.show.colors.away, home: st.show.colors.home, video, videoCue, sound, sting, replay, replayStill, replayKeep, replayCams: PV.replayCams ? PV.replayCams(st) : null, tone: !!(st.sndPlay && st.sndPlay.tone), programMuted: !!st.audio.pgmMute, monitor: !!st.audio.hp };
  }
  let lastRp = null;
  const showName = st => `${st.show.away.code} at ${st.show.home.code} ${st.show.event || ''}`.trim();

  let lastCams = 0;
  let lastState = '', lastNames = '', prevRec = null, prevStream = null, lastShow = '', lastGfx = '';
  function sync() {
    const E = PV.E; if (!E) return;
    const st = E.st;
    const vs = videoState(st);
    const j = JSON.stringify(vs);
    if (j !== lastState) { lastState = j; post({ type: 'state', state: vs }); }
    const nc = PV.camIds(st).length;
    if (nc !== lastCams) { lastCams = nc; post({ type: 'cameras', count: nc }); }
    const names = PV.camIds(st).map(id => [id, (st.inputs[id] || {}).name || id]);
    const nj = JSON.stringify(names);
    if (nj !== lastNames) { lastNames = nj; post({ type: 'names', names }); }
    if (prevRec === null) prevRec = st.rec.on;
    if (st.rec.on !== prevRec) { prevRec = st.rec.on; post({ type: 'rec', on: st.rec.on, show: showName(st) }); }
    // what the stream's graphics need
    const showJ = JSON.stringify(st.show);
    if (showJ !== lastShow) { lastShow = showJ; post({ type: 'gfxShow', show: st.show }); }
    const gs = { program: st.program, preview: st.preview, gfx: st.gfx, sb: st.sb, trans: { active: st.trans.active, wipes: st.trans.wipes, dur: st.trans.dur }, rp: { playing: st.rp.playing ? { speed: st.rp.playing.speed } : null, clips: [] }, brk: st.brk, me: { list: st.me.list }, text: { big: (st.text || {}).big || null }, live: st.live && st.live.lines ? { lines: st.live.lines } : null };
    const gj = JSON.stringify(gs);
    if (gj !== lastGfx) { lastGfx = gj; post({ type: 'gfxState', state: gs }); }
    if (prevStream === null) prevStream = st.stream.on;
    if (st.stream.on !== prevStream) { prevStream = st.stream.on; post({ type: 'stream', on: st.stream.on }); }
  }

  /* ---------- where each picture sits on screen ---------- */
  let lastLayout = '';
  function inter(a, b) {
    const x = Math.max(a.left, b.left), y = Math.max(a.top, b.top);
    const r = Math.min(a.right, b.right), btm = Math.min(a.bottom, b.bottom);
    return [x, y, Math.max(0, r - x), Math.max(0, btm - y)];
  }
  function layout() {
    requestAnimationFrame(layout);
    const items = [];
    const seen = {};
    const add = (el, src, clip, radius) => {
      const r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) return;
      seen[src] = (seen[src] || 0) + 1;
      items.push({ id: src + '#' + seen[src], src, x: r.left, y: r.top, w: r.width, h: r.height, clip, radius });
    };
    const view = (UI.state || {}).view || 'both';
    const pg = document.querySelector('#monPgm canvas'), pv = document.querySelector('#monPvw canvas');
    if (pg && view !== 'pvw') add(pg, 'program', null, 5);
    if (pv && view !== 'pgm') add(pv, 'preview', null, 5);
    const rows = document.getElementById('rows');
    if (rows) {
      const rr = rows.getBoundingClientRect();
      rows.querySelectorAll('canvas[data-live]').forEach(c => {
        const s = c.dataset.live;
        if (!N.handles(s)) return;
        const body = c.closest('.rbody');
        const clip = body ? inter(body.getBoundingClientRect(), rr) : [rr.left, rr.top, rr.width, rr.height];
        add(c, s, clip, 5);
      });
    }
    const j = innerWidth + 'x' + innerHeight + JSON.stringify(items);
    if (j !== lastLayout) {
      lastLayout = j;
      const thumbs = [...new Set(items.filter(i => i.src.indexOf('me:') === 0 || i.src === 'replay').map(i => i.src))];
      post({ type: 'layout', items, thumbs });
    }
  }

  /* ---------- messages from the app ---------- */
  window.PivotNative = {
    snap(id, url) {
      const r = N.snapReq[id]; if (r) r.pending = false;
      const im = new Image(); im.onload = () => { N.snaps[id] = im; }; im.src = url;
    },
    devices(list) { N.devices = list || []; refreshSettings(); },
    dests(list, services) {
      N.dests = list || []; if (services) N.services = services;
      const E = PV.E;
      if (E) { E.st.stream.dests = N.dests.map(d => ({ id: d.id, name: d.name, on: !!d.enabled })); E.changed(); }
      refreshSettings();
    },
    output(o) { N.output = o || {}; refreshSettings(); },
    recSettings(r) { N.recSettings = r || {}; refreshSettings(); },
    replaySettings(r) { N.replaySettings = r || {}; refreshSettings(); PV.E.changed(); },
    displays(list) { N.displays = list || []; refreshSettings(); },
    bmd(info) { N.bmd = info || {}; refreshSettings(); },
    link(msg) { PV.link.inject(msg); },
    server(info) { N.server = info || {}; refreshSettings(); },
    status(s) { N.status = s; applyStatus(s); },
    /* a newer Pivot is ready: the header shows an Update button */
    update(u) {
      N.update = u || {};
      const b = document.getElementById('bUpdate'); if (!b) return;
      b.hidden = !N.update.version;
      b.disabled = !!N.update.busy;
      b.textContent = N.update.busy ? 'Updating…' : 'Update to ' + (N.update.version || '');
      b.title = N.update.notes || 'A newer Pivot is ready';
      if (N.update.error) UI.banner(N.update.error);
    },
    levels(l) { N.levels = l; applyLevels(l); },
    recState(r) {
      const E = PV.E; if (!E) return;
      if (!r.on && E.st.rec.on) { prevRec = false; E.act('rec.toggle'); }
      if (r.error) UI.banner(r.error);
    },
    recDone(info) {
      N.recInfo = info;
      const n = (info.files || []).length;
      if (info.errors && info.errors.length) UI.banner('Recording saved with problems: ' + info.errors.join(' · '));
      else if (n) savedToast(info);
      else UI.banner('Recording stopped, but no files were saved. Check Settings › Recording: at least one of Program or each camera needs to be on.');
    },
    streamState(s) {
      const E = PV.E; if (!E) return;
      if (!s.on && E.st.stream.on) { prevStream = false; E.act('stream.toggle'); }
      if (s.error) UI.banner(s.error);
    },
    graphicsOut(on) { document.documentElement.classList.toggle('gfxout', !!on); },
    videoAdded(seg, items) {
      const E = PV.E; if (!E) return;
      for (const it of items || []) E.act('vid.addFile', seg, it);
      if (items && items.length) UI.toast(`Added ${items.length} video${items.length === 1 ? '' : 's'}`);
    },
    picked(token, item) { const cb = picks[token]; delete picks[token]; if (cb && item) cb(item); },
    httpDone(token, r) { const cb = asks[token]; delete asks[token]; if (cb) cb(r || { status: 0, text: '' }); },
    toast(m) { UI.toast(m); },
    colorSampled(token, hex) { const cb = picks[token]; delete picks[token]; if (cb) cb(hex || null); },
    gfxPackageAdded(id) { const P = window.PIVOT_GFX.PACKAGES[id]; UI.toast(P ? `${P.name} added` : 'Package added'); refreshSettings(); },
    banner(m) { UI.banner(m); },
    run(action) { UI.runAction(action); }
  };

  function savedToast(info) {
    const el = document.createElement('div');
    el.className = 'toast saved';
    el.innerHTML = `Saved ${info.files.length} file${info.files.length === 1 ? '' : 's'} <button class="btn sm">Show in Finder</button>`;
    el.querySelector('button').onclick = () => { post({ type: 'reveal', path: info.folder }); el.remove(); };
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 9000);
  }

  /* ---------- meters and status ---------- */
  UI.levels = function (st, t, src) {
    const l = N.levels;
    const v = l ? (src ? l.preview : l.program) : null;
    // the desk meter reads 0.9 as 0 dB
    return { raw: [0, 0, 0, 0], ch: [0, 0, 0, 0], L: v ? v.peakL * 0.9 : 0, R: v ? v.peakR * 0.9 : 0 };
  };

  function dbText(g) { return g <= 0.001 ? '-∞' : (20 * Math.log10(g)).toFixed(1); }
  function meterPct(p) { if (!p || p <= 0.0001) return 0; const db = 20 * Math.log10(p); return Math.max(0, Math.min(100, (db + 60) / 60 * 100)); }

  function applyLevels(l) {
    if (!l || !l.inputs) return;
    document.querySelectorAll('[data-nmeter]').forEach(el => {
      const id = el.dataset.nmeter;
      const v = id === 'program' ? l.program : (l.inputs[id] || null);
      const bars = el.querySelectorAll('i');
      if (bars[0]) bars[0].style.height = meterPct(v && v.peakL) + '%';
      if (bars[1]) bars[1].style.height = meterPct(v && v.peakR) + '%';
    });
  }

  function applyStatus(s) {
    if (!s) return;
    // a camera picked or taken away changes its tile (the + comes and goes)
    const has = (s.inputs || []).filter(i => /^cam/.test(i.id)).map(i => i.id + (i.device ? '1' : '0')).join(',');
    if (has !== N.hadDevices) { N.hadDevices = has; if (PV.UI) PV.UI.dirty = true; }
    for (const i of s.inputs || []) {
      const tile = document.querySelector(`.tl3[data-pv="src|${i.id}"]`);
      if (!tile) continue;
      const txt = i.signal ? `${i.height}p${Math.round(i.fps) || ''}` : (i.device ? 'NO SIGNAL' : 'NO INPUT');
      if (tile.dataset.fmt !== txt) tile.dataset.fmt = txt;
      tile.classList.toggle('nosig', !i.signal);
    }
    const pill = document.getElementById('bStream');
    if (pill) {
      const bad = (s.streams || []).some(x => x.status === 'reconnecting' || x.status === 'failed');
      pill.classList.toggle('warn', bad);
      pill.title = (s.streams || []).map(x => `${x.name}: ${x.status}${x.status === 'live' ? ` · ${x.kbps} kbps` : ''}${x.error && x.status !== 'live' ? ` · ${x.error}` : ''}`).join('\n') || 'Stream';
    }
    if (UI.state && UI.state.settings) refreshSettings();
  }

  function refreshSettings() { if (UI.state && UI.state.settings && UI.renderSettings) UI.renderSettings(); }

  /* ---------- settings: real devices, destinations and recording ---------- */
  const opt = (v, label, sel) => `<option value="${esc(v)}"${sel ? ' selected' : ''}>${esc(label)}</option>`;
  const inputStatus = id => ((N.status && N.status.inputs) || []).find(i => i.id === id) || {};
  const videoDevices = () => N.devices.filter(d => d.hasVideo);
  const audioDevices = () => N.devices.filter(d => d.hasAudio);
  const TEST = 'pivot.testpattern';

  function deviceSelect(id, which, cur) {
    const list = which === 'video' ? videoDevices() : audioDevices();
    let html = opt('', 'None', !cur);
    if (which === 'video') html += opt(TEST, 'Test pattern', cur === TEST);
    if (which === 'audio') html += opt('auto', 'Same device as the video', false);
    html += list.map(d => opt(d.id, d.name, d.id === cur)).join('');
    if (cur && cur !== TEST && !list.some(d => d.id === cur)) html += opt(cur, 'Unplugged device', true);
    return `<select class="inp" data-natc="assign|${id}|${which}" aria-label="${which === 'video' ? 'Video' : 'Audio'} for ${esc(id)}">${html}</select>`;
  }
  function signalText(i) {
    if (i.error) return `<span class="status bad">${esc(i.error)}</span>`;
    if (!i.device) return '<span class="status off">Nothing selected</span>';
    if (!i.signal) return '<span class="status bad">No signal</span>';
    return `<span class="status">${i.width}×${i.height} · ${i.fps ? i.fps.toFixed(1) : '…'} fps</span>`;
  }

  function natInputs(st) {
    return `<div class="note">Any camera, capture card, capture box or phone your Mac can see shows up here. Unplug a device and plug it back in and Pivot reconnects it.</div>
      <table class="tbl"><thead><tr><th>Camera</th><th>Job</th><th>Video from</th><th>Sound from</th><th>Signal</th></tr></thead><tbody>
      ${PV.camIds(st).map(id => { const i = inputStatus(id); const nm = (st.inputs[id] || {}).name || ''; return `<tr><td><b>${PV.srcShort(id)}</b></td><td><input type="text" class="inp" value="${esc(nm)}" data-sc="input|${id}|name" style="width:130px"></td><td>${deviceSelect(id, 'video', i.device)}</td><td>${deviceSelect(id, 'audio', i.audioDevice)}</td><td>${signalText(i)}</td></tr>`; }).join('')}</tbody></table>
      <div class="row"><button class="btn sm" data-nat="refresh">Look for devices again</button><span class="hint">${videoDevices().length} video and ${audioDevices().length} audio devices found.${N.bmd && !N.bmd.installed ? ' Blackmagic UltraStudio and DeckLink boxes need Blackmagic Desktop Video installed.' : ''}</span><span class="sp" style="flex:1"></span>
      <label class="hint" for="natCams">Cameras in this show</label><select id="natCams" data-natc="cams|count" ${N.status && (N.status.recording.on || N.status.streaming) ? 'disabled title="Stop recording and streaming first"' : ''}>${[1, 2, 3, 4, 5, 6, 7, 8].map(v => opt(v, String(v), PV.camIds(st).length === v)).join('')}</select></div>`;
  }

  function audioRows(ids, compact) {
    const ins = ((N.status && N.status.inputs) || []).filter(i => ids.includes(i.id));
    return ins.map(i => {
      const name = i.id.indexOf('cam') === 0 ? `${PV.srcShort(i.id)} · ${(PV.E.st.inputs[i.id] || {}).name || ''}` : i.name;
      const off = !i.audioDevice && i.device !== TEST;
      return `<div class="nstrip${off ? ' off' : ''}"><b title="${esc(name)}">${esc(name)}</b>
        <span class="nmeter" data-nmeter="${i.id}"><i></i><i></i></span>
        <input type="range" min="0" max="2" step="0.01" value="${i.gain}" data-nati="gain|${i.id}" aria-label="${esc(name)} level" ${off ? 'disabled' : ''}>
        <span class="tc db">${dbText(i.gain)} dB</span>
        <button class="btn sm${i.muted ? ' red' : ''}" data-nat="mute|${i.id}" ${off ? 'disabled' : ''}>${i.muted ? 'Muted' : 'Mute'}</button>
        <select class="inp" data-natc="mode|${i.id}" ${off ? 'disabled' : ''}>${opt('always', 'Always on', i.mode === 'always')}${opt('follow', 'Follows video', i.mode === 'follow')}${opt('off', 'Off', i.mode === 'off')}</select>
        ${compact ? '' : `<span class="hint">${off ? 'No sound source' : i.hasAudio ? 'Sound coming in' : 'Waiting for sound'}</span>`}</div>`;
    }).join('') || '<div class="hint">No inputs with sound yet.</div>';
  }
  function masterRow() {
    const g = N.status ? N.status.masterGain : 1;
    return `<div class="nstrip master"><b>Program mix</b><span class="nmeter" data-nmeter="program"><i></i><i></i></span>
      <input type="range" min="0" max="2" step="0.01" value="${g}" data-nati="master|x" aria-label="Program mix level"><span class="tc db">${dbText(g)} dB</span></div>`;
  }

  function natAudio() {
    return `<div class="fld"><label>Audio-only inputs</label><div class="hint">For a mixer, an audio interface or a microphone.</div>
      <table class="tbl"><tbody>${['aud1', 'aud2'].map(id => { const i = inputStatus(id); return `<tr><td><b>${esc(i.name || id)}</b></td><td>${deviceSelect(id, 'audio', i.audioDevice)}</td><td>${i.hasAudio ? '<span class="status">Sound coming in</span>' : i.audioDevice ? '<span class="status warn">Waiting for sound</span>' : '<span class="status off">Not used</span>'}</td></tr>`; }).join('')}</tbody></table></div>
      <div class="sec"><div class="sech">Mix</div><div class="nmix">${audioRows(PV.camIds(PV.E.st).concat(['aud1', 'aud2']))}${masterRow()}</div></div>
      <div class="note"><b>Always on</b> plays all the time (commentary, crowd). <b>Follows video</b> only plays while that camera is on air. Everything here is in the stream and the program recording; each camera file keeps its own sound.</div>`;
  }
  N.audioPanel = () => `<div class="nmix compact">${audioRows(PV.camIds(PV.E.st).concat(['aud1', 'aud2']), true)}${masterRow()}</div><div class="row"><button class="btn sm ghost" data-do="ui.settings|audio">Audio settings</button></div>`;

  function serviceHelp(id) { const s = N.services.find(x => x.id === id); return s ? s.help : ''; }
  function natStream(st) {
    const live = st.stream.on;
    const stats = (N.status && N.status.streams) || [];
    const o = N.output || {};
    const rows = N.dests.map(d => {
      const s = stats.find(x => x.id === d.id);
      const stat = s ? (s.status === 'live' ? `<span class="status">Live · ${s.kbps.toLocaleString()} kbps${s.droppedFrames ? ` · ${s.droppedFrames} dropped` : ''}</span>` : `<span class="status ${s.status === 'connecting' ? 'warn' : 'bad'}">${esc(s.status === 'connecting' ? 'Connecting' : s.status === 'reconnecting' ? 'Reconnecting' : s.status)}${s.error ? ' · ' + esc(s.error) : ''}</span>`)
        : d.enabled ? (d.hasKey || d.url.split('/').length > 4 ? '<span class="status warn">Ready</span>' : '<span class="status bad">Needs a stream key</span>') : '<span class="status off">Off</span>';
      return `<div class="ndest${d.enabled ? ' on' : ''}">
        <button class="sw${d.enabled ? ' on' : ''}" data-nat="dest|${d.id}|enabled" ${live ? 'disabled' : ''} aria-label="Use ${esc(d.name)}"></button>
        <input type="text" class="inp nm" value="${esc(d.name)}" data-natc="dest|${d.id}|name" ${live ? 'disabled' : ''} aria-label="Name">
        <select class="inp" data-natc="dest|${d.id}|service" ${live ? 'disabled' : ''}>${N.services.map(s => opt(s.id, s.name, s.id === d.service)).join('')}</select>
        <input type="text" class="inp url" value="${esc(d.url)}" placeholder="rtmp:// or rtmps:// server address" data-natc="dest|${d.id}|url" ${live ? 'disabled' : ''} spellcheck="false" aria-label="Server address">
        <input type="password" class="inp key" value="" placeholder="${d.hasKey ? 'Stream key saved' : 'Stream key'}" data-natc="dest|${d.id}|key" ${live ? 'disabled' : ''} autocomplete="off" aria-label="Stream key">
        <button class="btn sm ghost" data-nat="destDel|${d.id}" ${live ? 'disabled' : ''} title="Remove">×</button>
        <div class="nhelp">${stat}<span class="hint">${esc(serviceHelp(d.service))}</span></div></div>`;
    }).join('');
    return `<div class="sec">${rows || '<div class="empty">No destinations yet.</div>'}
      <div class="row"><select class="inp" id="natAddSvc">${N.services.map(s => opt(s.id, s.name, s.id === 'youtube')).join('')}</select><button class="btn sm" data-nat="destAdd" ${live ? 'disabled' : ''}>Add destination</button></div></div>
      <div class="grid2"><div class="fld"><label>Picture</label><select data-natc="output|preset" ${live || (N.status && N.status.recording.on) ? 'disabled' : ''}>${[['1080p30', '1080p 30'], ['1080p60', '1080p 60'], ['720p30', '720p 30'], ['720p60', '720p 60']].map(([v, n]) => opt(v, n, o.preset === v)).join('')}</select></div>
      <div class="fld"><label>Video bitrate</label><select data-natc="output|kbps" ${live ? 'disabled' : ''}>${[2500, 3500, 4500, 6000, 8000, 9000, 12000].map(v => opt(v, v.toLocaleString() + ' kbps' + (v === 6000 ? ' (recommended for 1080p)' : ''), o.videoKbps === v)).join('')}</select></div></div>
      <div class="note">Every destination gets the same picture and sound. Stream keys are kept in your Mac's keychain. If a connection drops, Pivot keeps trying on its own and picks up where it left off.${N.status && N.status.encoderHardware ? ' Using the Mac\'s hardware encoder.' : ''}</div>`;
  }

  function natRec(st) {
    const r = N.recSettings || {};
    const rec = N.status ? N.status.recording : { on: false };
    const codecs = [['h264', 'H.264', 'Plays anywhere'], ['hevc', 'HEVC (H.265)', 'Smaller files, same quality'], ['prores422proxy', 'ProRes 422 Proxy', 'Easy editing, large files'], ['prores422', 'ProRes 422', 'Full editing quality, very large files']];
    return `<div class="fld"><label>Format</label><div class="seg">${codecs.map(([v, n]) => `<button class="${r.codec === v ? 'on' : ''}" data-nat="rec|codec|${v}" ${rec.on ? 'disabled' : ''} title="${esc(codecs.find(c => c[0] === v)[2])}">${n}</button>`).join('')}</div></div>
      <div class="fld"><label>What to record</label><label class="chk" style="color:var(--ink)"><input type="checkbox" ${r.program ? 'checked' : ''} data-natc="rec|program" ${rec.on ? 'disabled' : ''}>Program (picture and stream mix)</label>
      <div class="grid2" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:6px;margin-top:6px">${PV.camIds(st).map(id => `<label class="chk" style="color:var(--ink)"><input type="checkbox" ${(r.cams || []).includes(id) ? 'checked' : ''} data-natc="reccam|${id}" ${rec.on ? 'disabled' : ''}>${esc(PV.srcLabel(st, id).replace(/^CAM /, 'Camera '))}</label>`).join('')}</div>
      <span class="hint">Each camera picked gets a file of its own, with its own sound, all starting at the same moment.</span></div>
      <div class="fld"><label>Save to</label><div class="row"><code class="path">${esc(r.folder || '~/Movies/Pivot')}</code><button class="btn sm" data-nat="recFolder" ${rec.on ? 'disabled' : ''}>Choose…</button><button class="btn sm ghost" data-nat="reveal">Show in Finder</button></div>
      <span class="hint">Each show gets its own folder, named by game and time. Files are written so they still play if the Mac loses power.</span></div>
      ${rec.on ? `<div class="note"><b>Recording ${rec.files} file${rec.files === 1 ? '' : 's'}</b> · ${(rec.bytes / 1e9).toFixed(2)} GB so far${rec.problems && rec.problems.length ? '<br>' + rec.problems.map(esc).join('<br>') : ''}</div>` : ''}`;
  }

  function natOut() {
    const all = N.displays || [];
    const row = d => {
      const choices = d.kind === 'blackmagic' ? [['off', 'Off'], ['program', 'Program']] : [['off', 'Off'], ['program', 'Program'], ['preview', 'Preview']];
      const pick = d.desk ? '<span class="hint">The desk is on this one</span>'
        : `<select data-natc="screen|${esc(d.key)}">${choices.map(([v, n]) => opt(v, n, d.source === v)).join('')}</select>`;
      const state = d.error ? ` · <b style="color:var(--warn)">${esc(d.error)}</b>` : d.on ? ' · <b style="color:var(--ok, #3ccf7a)">Showing ' + (d.source === 'preview' ? 'Preview' : 'Program') + '</b>' : '';
      return `<div class="nstrip nscreen"><b>${esc(d.name)}</b><span class="hint">${d.width}×${d.height}${state}</span>${pick}</div>`;
    };
    const ds = all.filter(d => d.kind !== 'blackmagic'), bm = all.filter(d => d.kind === 'blackmagic');
    const more = ds.filter(d => !d.desk).length === 0;
    const b = N.bmd || {};
    return `<div class="sec"><div class="sech">Screens</div>
      <div class="nmix">${ds.map(row).join('') || '<div class="empty">Looking for displays…</div>'}</div>
      <div class="hint">${more ? 'Plug a TV, projector or monitor into this Mac (HDMI, USB-C or AirPlay) and it shows up here. ' : ''}Program fills the screen, with graphics, exactly as it goes out on the stream. Pivot remembers each screen and puts the picture back when it's plugged in again.</div></div>
      <div class="sec"><div class="sech">Blackmagic</div>
      ${bm.length ? `<div class="nmix">${bm.map(row).join('')}</div><div class="hint">Program goes out at the same size and frame rate as the stream (Settings › Streaming › Picture).</div>`
        : `<div class="hint">${b.installed ? 'No Blackmagic device that can play out is connected. UltraStudio Monitor, DeckLink and Intensity boxes show up here.' : 'To send program out of an UltraStudio, DeckLink or Intensity box, install Blackmagic Desktop Video from blackmagicdesign.com/support, then reopen Pivot.'}</div>`}</div>
      <div class="sec"><div class="sech">NDI</div><div class="hint">Sending program out as NDI on the network comes in a later update.</div></div>`;
  }

  function natScreens(st) {
    const sv = N.server || {};
    const roles = [['director', 'Director', 'Cut cameras, take, fade, wipe, break'], ['graphics', 'Graphics', 'Scorebug, lower thirds, full screens'], ['replay', 'Replay', 'Mark, roll, angles and speed'], ['audio', 'Audio', 'Faders and mutes'], ['producer', 'Producer', 'Clock, score, rundown, playlists'], ['scorebug', 'Scorebug', 'Score and clock'], ['multiview', 'Multiview', 'Every picture, live']];
    const base = (sv.urls || [])[0] || '';
    const scr = UI.state.screens ? Object.values(UI.state.screens).filter(x => Date.now() - x.at < 15000 && x.via === 'room') : [];
    const status = !sv.on ? 'Off' : sv.running ? `${sv.clients || 0} connected` : (sv.error || 'Starting…');
    return `<label class="chk" style="color:var(--ink)"><input type="checkbox" ${sv.on ? 'checked' : ''} data-natc="server|on">Let phones and iPads on this network control the show</label>
      ${sv.on && sv.running ? `<div class="row" style="gap:22px;align-items:flex-start;flex-wrap:wrap">
        ${sv.qr ? `<img src="${sv.qr}" alt="QR code" style="width:150px;height:150px;border-radius:8px;background:#fff;padding:6px;image-rendering:pixelated">` : ''}
        <div style="display:flex;flex-direction:column;gap:10px;min-width:260px;flex:1">
          <div><div class="lbl">Open on the phone or iPad</div><div class="tc" style="font:700 22px var(--mono);user-select:text">${esc(base.replace('http://', ''))}</div>
          ${(sv.urls || []).slice(1).map(u => `<div class="hint" style="user-select:text">or ${esc(u.replace('http://', ''))}</div>`).join('')}</div>
          <div class="row" style="gap:16px"><div><div class="lbl">PIN for this show</div><div class="pin tc">${esc(st.pin)}</div></div><button class="btn" data-s="pin">New PIN</button></div>
          <div class="hint">Scan the code with the phone's camera, or type the address into Safari or Chrome. The phone has to be on the same Wi-Fi or network as this Mac. Each person picks their screen and types the PIN once.</div>
        </div></div>
        <div class="sec"><div class="sech">Screens</div><div class="nmix">${roles.map(([id, n, d]) => `<div class="nstrip nscreen"><b>${n}</b><span class="hint">${d}</span><code style="user-select:text;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(base.replace('http://', ''))}/#${id}</code></div>`).join('')}</div></div>` : ''}
      <div class="note">${esc(status)}${scr.length ? ' · ' + scr.map(x => x.role[0].toUpperCase() + x.role.slice(1)).join(', ') : ''}</div>
      ${sv.on ? '<div class="hint">If a phone can\'t connect, check that this Mac\'s firewall lets Pivot accept incoming connections (System Settings › Network › Firewall).</div>' : ''}`;
  }

  /* the Outputs button: what is actually going out */
  // what pressing REC will record, in a few words: "Program and 2 cameras · H.264 · Movies/Pivot"
  const CODEC_NAME = { h264: 'H.264', hevc: 'HEVC', prores422proxy: 'ProRes Proxy', prores422: 'ProRes 422' };
  function recPlan() {
    const r = N.recSettings || {}, n = (r.cams || []).length, camsTxt = n ? n + ' camera' + (n === 1 ? '' : 's') : '';
    const what = r.program && n ? 'Program and ' + camsTxt : r.program ? 'Program' : n ? camsTxt : 'Nothing picked';
    return [what, CODEC_NAME[r.codec] || r.codec, String(r.folder || '').replace(/^\/Users\/[^/]+\//, '')].filter(Boolean).join(' · ');
  }
  UI.outputsHtml = function (st) {
    const s = N.status || {}, rec = s.recording || {}, rp = s.replay;
    const dests = (N.dests || []).filter(d => d.enabled).map(d => d.name).join(', ') || 'None';
    const live = (s.streams || []);
    const kbps = live.length ? Math.round(live.reduce((a, x) => a + (x.kbps || 0), 0) / live.length).toLocaleString() + ' kbps' : '—';
    const scr = (N.displays || []).filter(d => d.on).map(d => d.name + (d.source === 'preview' ? ' (Preview)' : '')).join(', ') || 'None';
    return `<div class="cardh">Outputs<span class="sp"></span><button class="btn sm" data-do="ui.settings|out">Settings</button></div>
      <dl class="kv"><dt>Recording</dt><dd>${rec.on ? rec.files + ' file' + (rec.files === 1 ? '' : 's') + ' · ' + (rec.bytes / 1e9).toFixed(2) + ' GB' : 'Off · ' + recPlan()}</dd>
      <dt>Stream</dt><dd>${esc(dests)}${s.streaming ? ' · live' : ''}</dd><dt>Bitrate</dt><dd>${kbps}</dd>
      <dt>Screens</dt><dd>${esc(scr)}</dd>
      <dt>Replay</dt><dd>${rp && rp.on ? (rp.cameras ? Math.floor(rp.seconds / 60) + ' min kept · ' + (rp.bytes / 1e9).toFixed(1) + ' GB' : 'Waiting for cameras') : 'Off'}</dd></dl>`;
  };

  function natAbout() {
    const s = N.status || {};
    return `<div class="note"><b>Pivot is running on this Mac.</b> Cameras, the switcher, M/Es, sound, graphics, video files, instant replay, recording and streaming are real.</div>
      <dl class="kv" style="max-width:560px"><dt>Program</dt><dd>${s.width || '…'}×${s.height || '…'} at ${s.targetFps || '…'} fps</dd><dt>Running at</dt><dd>${s.fps || '…'} fps · ${s.renderMs || '…'} ms a frame</dd>
      <dt>Graphics chip</dt><dd>${s.gpu ? 'In use' : 'Not available'}</dd></dl>
      <div class="sec"><div class="sech">Still to come</div><div class="hint">Program out to a Blackmagic box, HDMI or NDI · control screens on phones and iPads.</div></div>
      <div class="hint">Menu › Run System Check tests devices, the encoder, recording, streaming and your connection, and gives you a report to copy.</div>`;
  }

  function hookSettings() {
    if (!UI.SEC) return false;
    UI.SEC.inputs = natInputs;
    UI.SEC.audio = natAudio;
    UI.SEC.stream = natStream;
    UI.SEC.rec = natRec;
    UI.SEC.out = natOut;
    UI.SEC.about = natAbout;
    UI.SEC.screens = natScreens;
    if (UI.SECTIONS && !UI.SECTIONS.__native) {
      UI.SECTIONS.__native = true;
      for (let i = UI.SECTIONS.length - 1; i >= 0; i--) if (['mv'].includes(UI.SECTIONS[i][0])) UI.SECTIONS.splice(i, 1);
      const a = UI.SECTIONS.find(x => x[0] === 'about'); if (a) a[1] = 'About Pivot';
      const o = UI.SECTIONS.find(x => x[0] === 'out'); if (o) o[1] = 'Outputs';
    }
    return true;
  }

  /* control changes inside our settings pages and panels */
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-nat]'); if (!b || b.disabled) return;
    const [name, a, c] = b.dataset.nat.split('|');
    if (name === 'refresh') post({ type: 'refreshDevices' });
    else if (name === 'mute') { const i = inputStatus(a); post({ type: 'audio', input: a, muted: !i.muted }); }
    else if (name === 'dest' && c === 'enabled') { const d = N.dests.find(x => x.id === a); if (d) post({ type: 'dest', id: a, patch: { enabled: !d.enabled } }); }
    else if (name === 'destDel') post({ type: 'destDel', id: a });
    else if (name === 'destAdd') { const sel = document.getElementById('natAddSvc'); post({ type: 'destAdd', service: sel ? sel.value : 'custom' }); }
    else if (name === 'rec') post({ type: 'recSettings', patch: { [a]: c } });
    else if (name === 'recFolder') post({ type: 'chooseFolder' });
    else if (name === 'reveal') post({ type: 'reveal', path: (N.recSettings || {}).folder || '' });
  });
  document.addEventListener('change', e => {
    const el = e.target.closest('[data-natc]'); if (!el) return;
    const [name, a, c] = el.dataset.natc.split('|');
    const v = el.type === 'checkbox' ? el.checked : el.value;
    if (name === 'assign') {
      const i = inputStatus(a);
      const video = c === 'video' ? (v || null) : (i.device || null);
      let audio = c === 'audio' ? (v || null) : (i.audioDevice || null);
      if (c === 'video' && v && !i.audioDevice) audio = 'auto';
      post({ type: 'assign', input: a, video, audio });
    } else if (name === 'mode') post({ type: 'audio', input: a, mode: v });
    else if (name === 'dest') { if (c === 'key') { post({ type: 'destKey', id: a, key: v }); el.value = ''; } else post({ type: 'dest', id: a, patch: { [c]: v } }); }
    else if (name === 'output') post({ type: 'output', patch: { [a]: a === 'kbps' ? +v : v } });
    else if (name === 'rec') post({ type: 'recSettings', patch: { [a]: v } });
    else if (name === 'reccam') { const cur = (N.recSettings && N.recSettings.cams) || []; post({ type: 'recSettings', patch: { cams: v ? cur.concat(a) : cur.filter(x => x !== a) } }); }
    else if (name === 'cams') { UI.send('cams.count', +v); setTimeout(refreshSettings, 300); }
    else if (name === 'server') post({ type: 'controlServer', on: !!v });
    else if (name === 'screen') post({ type: 'screenOut', display: a, source: v });
    else if (name === 'replay') post({ type: 'replaySettings', patch: { [a]: a === 'minutes' ? +v : v } });
  });
  document.addEventListener('input', e => {
    const el = e.target.closest('[data-nati]'); if (!el) return;
    const [name, a] = el.dataset.nati.split('|');
    const g = +el.value;
    const db = el.parentElement.querySelector('.db'); if (db) db.textContent = dbText(g) + ' dB';
    if (name === 'gain') post({ type: 'audio', input: a, gain: g });
    else if (name === 'master') post({ type: 'master', gain: g });
  });

  /* camera gear: real devices */
  /* a Blackmagic box with both kinds of input: pick SDI or HDMI here instead of in Blackmagic's settings app */
  function bmdConns(dev) {
    const d = (N.devices || []).find(x => x.id === dev);
    if (!d || !d.conns) return '';
    const opts = [[1, 'SDI'], [2, 'HDMI']].filter(([b]) => d.conns & b);
    if (opts.length < 2) return '';
    return `<div class="fld"><label>Blackmagic input</label><div class="seg">${opts.map(([b, n]) => `<button class="${d.conn === b ? 'on' : ''}" data-bmdconn="${b}">${n}</button>`).join('')}</div></div>`;
  }
  UI.inputMenu = function (anchor, cam) {
    UI.closeMenus();
    const st = PV.E.st, i = inputStatus(cam), nm = (st.inputs[cam] || {}).name || '';
    const m = document.createElement('div'); m.className = 'menu inmenu';
    m.innerHTML = `<div class="cardh">${PV.srcShort(cam)} settings<span class="sp"></span><button class="btn sm ghost" data-x="close">Done</button></div>
      <div class="fld"><label>Name</label><input type="text" value="${esc(nm)}" data-f="name" maxlength="24"></div>
      <div class="fld"><label>Video from</label>${deviceSelect(cam, 'video', i.device)}</div>${bmdConns(i.device)}
      <div class="fld"><label>Sound from</label>${deviceSelect(cam, 'audio', i.audioDevice)}</div>
      <div class="hint">${i.signal ? `${i.width}×${i.height} at ${i.fps ? i.fps.toFixed(1) : '…'} fps. Any format works; Pivot converts it.` : 'Pick any camera, capture card or capture box your Mac sees.'}</div>${UI.camExtras(cam)}`;
    document.body.appendChild(m);
    UI.wireCamExtras(m, cam);
    const r = anchor.getBoundingClientRect(), mh = m.getBoundingClientRect().height;
    m.style.left = Math.max(8, Math.min(r.left - 120, window.innerWidth - 300)) + 'px';
    m.style.top = (r.bottom + 6 + mh < window.innerHeight ? r.bottom + 6 : Math.max(8, r.top - mh - 6)) + 'px';
    const setName = () => { const n = m.querySelector('[data-f=name]'); if (n && n.value.trim() && n.value.trim() !== nm) UI.send('input.set', cam, { name: n.value.trim() }); };
    m.addEventListener('keydown', e => { if (e.key === 'Enter') { setName(); UI.closeMenus(); } });
    m.addEventListener('click', e => {
      const bc = e.target.closest('[data-bmdconn]');
      if (bc) { post({ type: 'bmdConn', device: i.device, conn: +bc.dataset.bmdconn }); m.querySelectorAll('[data-bmdconn]').forEach(b => b.classList.toggle('on', b === bc)); return; }
      if (e.target.closest('[data-x]')) { setName(); UI.closeMenus(); }
    });
    setTimeout(() => document.addEventListener('pointerdown', function off(e) { if (!m.contains(e.target)) { setName(); UI.closeMenus(); document.removeEventListener('pointerdown', off, true); } }, true), 0);
  };

  /* ---------- start ---------- */
  const css = document.createElement('style');
  css.textContent = `
    html.native, html.native body, html.native #app { background: transparent !important; }
    html.native .mon, html.native .tl3:not(.plus) { background: transparent; }
    html.native .row3, html.native .rbody { background: transparent; }
    html.native .tl3[data-fmt]::before { content: attr(data-fmt); position: absolute; right: 4px; top: 4px; z-index: 3; font: 700 9.5px var(--mono); padding: 1px 4px; border-radius: 3px; background: rgba(0,0,0,.6); color: #cfd6e0; }
    html.native .tl3.nosig::before { background: #3a1214; color: #ffb4b4; }
    html.native .pill.live.warn { border-color: var(--warn); }
    html.native #bScreens { display: none; }
    html.native.gfxout #monPgm .gfxhost { display: none; }
    html.native .fld label.chk { text-transform: none; letter-spacing: 0; font-family: inherit; font-size: 13px; font-weight: 500; }
    .nstrip.nscreen { grid-template-columns: minmax(120px, .8fr) minmax(140px, 1.2fr) minmax(0, 1.4fr); }
    .nmix { display: flex; flex-direction: column; gap: 6px; }
    .nstrip { display: grid; grid-template-columns: 160px 18px minmax(120px, 1fr) 62px 70px 130px auto; gap: 10px; align-items: center; padding: 6px 10px; border-radius: 8px; background: var(--raise); border: 1px solid var(--line); }
    .nmix.compact .nstrip { grid-template-columns: 130px 18px 180px 58px 64px 120px; }
    .nstrip.off { opacity: .5; }
    .nstrip.master { background: #1f1a10; border-color: #4a3810; grid-template-columns: 160px 18px minmax(120px, 1fr) 62px; }
    .nmix.compact .nstrip.master { grid-template-columns: 130px 18px 180px 58px; }
    .nstrip b { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 13px; }
    .nstrip input[type=range] { accent-color: var(--brand); width: 100%; }
    .nstrip .db { font: 500 11.5px var(--mono); color: var(--mute); }
    .nstrip .inp { height: 28px; }
    .nmeter { display: flex; gap: 2px; height: 26px; align-items: flex-end; }
    .nmeter i { flex: 1; height: 0; border-radius: 1px; background: linear-gradient(to top, #28d070 0%, #28d070 70%, #ffd43b 85%, #ff3b3b 100%); background-size: 100% 26px; background-position: bottom; transition: height .07s linear; }
    .ndest { display: grid; grid-template-columns: 38px 150px 130px minmax(180px, 1fr) 170px 28px; gap: 8px; align-items: center; padding: 8px 10px; border-radius: 8px; background: var(--raise); border: 1px solid var(--line); }
    .ndest.on { border-color: #4a3810; }
    .ndest .inp { height: 30px; font-size: 12.5px; }
    .ndest .nhelp { grid-column: 2 / -1; display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
    code.path { font: 500 12px var(--mono); background: var(--raise); border: 1px solid var(--line2); border-radius: 6px; padding: 5px 8px; }
    .toast.saved { pointer-events: auto; display: flex; gap: 10px; align-items: center; }
  `;
  document.head.appendChild(css);

  let tries = 0;
  const boot = setInterval(() => {
    const ok = hookSettings();
    if (PV.E && !PV.E.__native) {
      PV.E.__native = true;
      PV.E.listeners.push(sync);
      sync();
    }
    if ((ok && PV.E) || ++tries > 600) { /* keep polling only until both are ready */ }
  }, 100);
  setInterval(sync, 100);
  requestAnimationFrame(layout);
  post({ type: 'ready' });
  void boot;
})();
