/* Pivot on a phone or iPad, opened from the production Mac over the local network.
   Messages go through the Mac app; pictures come from it as small JPEGs. */
(function () {
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.pivot) return;
  if (!/^https?:$/.test(location.protocol) || !location.port) return;
  const PV = window.PV, UI = PV.UI;
  PV.netScreen = true;

  /* ---------- messages ---------- */
  let ws = null, wait = 800;
  const wsPort = (+location.port) + 1;
  function open() {
    try { ws = new WebSocket(`ws://${location.hostname}:${wsPort}/`); } catch (e) { ws = null; setTimeout(open, wait); return; }
    ws.onopen = () => { wait = 800; if (PV.netHello) PV.netHello(); };
    ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } PV.link.inject(m); };
    ws.onclose = () => { ws = null; wait = Math.min(5000, wait * 1.5); setTimeout(open, wait); };
    ws.onerror = () => { try { ws.close(); } catch (x) { /* closing */ } };
  }
  PV.link.setNet(m => { if (ws && ws.readyState === 1) try { ws.send(JSON.stringify(m)); } catch (e) { /* reconnecting */ } });
  open();
  // come straight back after the phone wakes up
  document.addEventListener('visibilitychange', () => { if (!document.hidden && (!ws || ws.readyState > 1)) { wait = 800; open(); } });

  /* ---------- real pictures from the Mac ---------- */
  const snaps = {}, req = {};
  const live = src => typeof src === 'string' && (/^cam\d+$/.test(src) || src.indexOf('me:') === 0 || src === 'replay' || src === 'program' || src === 'preview' || src === 'black' || src === 'bars');
  function drawLive(ctx, w, h, src) {
    const now = performance.now();
    const r = req[src] || (req[src] = { t: 0, busy: false });
    // about four pictures a second for each source, one request at a time
    if (!r.busy && now - r.t > 250) {
      r.busy = true; r.t = now;
      const im = new Image();
      im.onload = () => { snaps[src] = im; r.busy = false; };
      im.onerror = () => { r.busy = false; r.t = performance.now() + 1500; };
      im.src = `/snap/${encodeURIComponent(src)}?w=${Math.max(160, Math.min(960, Math.round(w)))}&n=${Math.round(now)}`;
    }
    const im = snaps[src];
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    if (im && im.naturalWidth) {
      // keep the picture's shape inside tall boxes
      const k = Math.min(w / im.naturalWidth, h / im.naturalHeight), dw = im.naturalWidth * k, dh = im.naturalHeight * k;
      ctx.drawImage(im, (w - dw) / 2, (h - dh) / 2, dw, dh);
    }
  }
  const orig = UI.drawSource;
  UI.drawSource = function (ctx, w, h, src) {
    if (live(src)) { drawLive(ctx, w, h, src); return; }
    return orig.apply(this, arguments);
  };
})();
