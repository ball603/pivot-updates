/* Pivot replays and playlists.
   A replay plays as a list of shots: one play's angles (Roll all), or many plays (a highlight playlist).
   Each shot comes in with a cut, a fade or a wipe; the angles of one play always fade into each other.
   Playlists live in the Replays and Videos trays, each with its own name, speed, loop, transition and sound. */
(function () {
  const PV = window.PV, S = window.PIVOT_SIM;
  const Eng = PV.Engine.prototype, A = Eng.actions;
  const uid = () => 'i' + Math.random().toString(36).slice(2, 9);
  const now = () => Date.now();
  let takes = Math.floor(Math.random() * 1e6);   // each shot gets its own number, so the Mac knows a new one began

  /* ---------- replays as shots ---------- */
  // one play (or a playlist copy of it) as shots, one per angle
  PV.clipSeq = (clip, angles, into, item) => (angles || []).filter(Boolean).map((cam, i) => {
    const k = PV.cut(clip, cam);
    return { clip: clip.src || clip.id, item: item || null, cam, tIn: k.tIn, tOut: k.tOut, into: i ? 'fade' : (into || null), name: clip.name };
  });
  PV.rpStart = (st, seq, o) => Object.assign({ seq, idx: 0, take: ++takes, clip: seq[0].clip, only: seq.length === 1 ? seq[0].cam : null, xf: 0 }, o);
  PV.rpSeg = rp => rp && rp.seq && rp.seq.length ? rp.seq[Math.min(rp.idx, rp.seq.length - 1)] : null;
  PV.fadeMs = st => Math.max(200, Math.min(2000, st.trans.dur || 600));
  const wipeOf = (st, id) => st.trans.wipes.some(w => w.id === id) ? id : (st.trans.wipe || 'replay');
  const isWipe = into => into && into !== 'cut' && into !== 'fade';
  // an end stamp placed in a playlist plays as the way into the next clip (or back out to the live shot)
  const stampIn = into => typeof into === 'string' && into.indexOf('stamp:') === 0 ? into.slice(6) : null;
  const wipeTo = (st, from, to, t, into) => { const sid = stampIn(into); return PV.sting(st, { type: 'stinger', from, to, start: t, dur: 1000, cut: false, wipe: sid ? 'replay' : wipeOf(st, into), stamp: sid }); };
  PV.stampIn = stampIn;

  function goTo(st, rp, i, t, fade) {
    const s = rp.seq[i];
    rp.prev = Object.assign({}, PV.rpSeg(rp), { start: rp.start, speed: rp.speed });
    rp.idx = i; rp.start = t; rp.take = ++takes; rp.clip = s.clip; rp.xf = fade || 0;
    if (rp.seq.length === 1) rp.only = s.cam;
  }
  /* the clock moves the replay along; true when something changed */
  PV.rpTick = function (eng, t) {
    const st = eng.st, rp = st.rp.playing;
    if (!rp.seq) { eng.endReplay(); return true; }
    if (rp.pend) {   // a wipe between plays: the next one starts under the middle of the wipe
      if (t < rp.pend.at) return false;
      const i = rp.pend.i; rp.pend = null; goTo(st, rp, i, t, 0); return true;
    }
    if (t < rp.start) return false;
    const seg = PV.rpSeg(rp), len = seg.tOut - seg.tIn, pos = (t - rp.start) / 1000 * rp.speed;
    const ni = rp.idx + 1 < rp.seq.length ? rp.idx + 1 : rp.loop ? 0 : -1, nx = ni >= 0 ? rp.seq[ni] : null;
    const fade = PV.fadeMs(st);
    // a fade starts before the shot ends, so both are moving while it mixes
    const lead = nx && nx.into === 'fade' ? Math.min(len / 2, fade / 1000 * rp.speed) : 0;
    if (pos < len - lead) return false;
    const c = st.rp.clips.find(x => x.id === seg.clip); if (c) c.rolled = true;
    if (!nx) { eng.endReplay(); return true; }
    if (isWipe(nx.into)) {
      st.trans.active = wipeTo(st, 'replay', 'replay', t, nx.into);
      rp.pend = { at: t + st.trans.active.dur * st.trans.active.at, i: ni };
      return true;
    }
    goTo(st, rp, ni, t, nx.into === 'fade' ? fade : 0);
    return true;
  };

  /* P / Roll all: every angle of the play, fading from one to the next */
  A['rp.roll'] = function (id, _b, _c, t) {
    const st = this.st; t = t || now();
    if (st.rp.playing) return;
    const clip = id ? st.rp.clips.find(c => c.id === id) : st.rp.clips[0];
    if (!clip || !clip.angles.length) return;
    let how = PV.spaceHow(Object.assign({}, st, { preview: 'replay' })), wid = null;
    if (how !== 'fade') { wid = st.trans.wipes.some(w => w.id === how) ? how : (st.trans.wipe || 'replay'); how = 'wipe'; }
    const ret = ['video', 'replay', 'black'].includes(st.program) ? (st.lastCam || 'cam1') : st.program;
    st.rp.playing = PV.rpStart(st, PV.clipSeq(clip, clip.angles), { start: t + (how === 'wipe' ? PV.wipeHalf(st, 'replay', wid) : 0), speed: clip.speed, ret, how, wid });
    this.switchTo('replay', t, how, wid);
    PV.afterWipe(st, wid);
  };
  /* one angle, taken from Preview */
  Eng.startRp = function (sel, t, how, wid) {
    const st = this.st, clip = st.rp.clips.find(c => c.id === sel.clip); if (!clip) return;
    const ret = ['video', 'replay', 'black'].includes(st.program) ? (st.lastCam || 'cam1') : st.program;
    st.rp.playing = PV.rpStart(st, PV.clipSeq(clip, [sel.ang]), { start: t + (how === 'wipe' ? PV.wipeHalf(st, 'replay', wid) : 0), speed: clip.speed, ret, how, wid });
    if (st.program === 'replay') { if (how === 'wipe') this.switchTo('replay', t, how, wid); else st.trans.active = null; }
    else this.switchTo('replay', t, how, wid);
  };
  PV.rpAngles = (rp, clip) => { const s = PV.rpSeg(rp); return s ? [s.cam] : clip.angles; };

  /* while a replay is on air: double-click an angle and it fades to that angle, from its beginning */
  A['rp.live'] = function (clipId, cam, pli, t) {
    const st = this.st, rp = st.rp.playing; t = t || now();
    if (!rp || !rp.seq || st.program !== 'replay') return;
    // a play in a playlist: its own copy there (which keeps working after the play is deleted from All replays)
    const item = pli ? [].concat(...(st.rp.lists || []).map(l => l.items)).find(x => x.id === pli) : null;
    const c = item ? Object.assign({}, item, { id: item.src }) : st.rp.clips.find(x => x.id === clipId); if (!c || !c.angles.includes(cam)) return;
    const seg = PV.rpSeg(rp), k = PV.cut(c, cam);
    if (seg.clip === clipId && seg.cam === cam) return;
    // the angle picked plays from its own beginning
    const T = k.tIn;
    if (rp.pend) { rp.idx = rp.pend.i; rp.pend = null; }
    rp.seq = rp.seq.slice(); rp.seq[rp.idx] = { clip: c.id, item: item ? item.id : seg.item, cam, tIn: k.tIn, tOut: k.tOut, into: 'fade', name: c.name };
    // the angle picked is now on: it doesn't come round again later in the roll
    rp.seq = rp.seq.filter((s, i) => i <= rp.idx || !(s.clip === c.id && s.cam === cam));
    rp.prev = Object.assign({}, seg, { start: rp.start, speed: rp.speed });
    rp.start = t - (T - k.tIn) / rp.speed * 1000; rp.take = ++takes; rp.clip = c.id; rp.xf = PV.fadeMs(st);
    if (rp.seq.length === 1) rp.only = cam;
  };
  /* speed: the replay on air changes right away; otherwise the picked play, or the next replays */
  const oldSpeed = A['rp.speed'];
  A['rp.speed'] = function (s, id, _c, t) {
    const st = this.st, rp = st.rp.playing;
    if (id === 'live') {
      if (!rp || !rp.seq) return;
      t = t || now(); s = Math.max(0.25, Math.min(1, +s || 1));
      if (t > rp.start) rp.start = t - (t - rp.start) * rp.speed / s;   // the picture carries on from where it is
      rp.speed = s;
      return;
    }
    oldSpeed.call(this, s, id);
  };

  /* ---------- playlists ---------- */
  const lists = (st, kind) => kind === 'vid' ? (st.vlists = st.vlists || []) : (st.rp.lists = st.rp.lists || []);
  const find = (st, key) => { const [kind, id] = String(key || '').split(':'); const l = lists(st, kind).find(x => x.id === id); return l ? { kind, l } : null; };
  PV.plFind = find;
  PV.plKinds = { rp: 'Highlights', vid: 'Playlist' };
  A['pls.new'] = function (kind) {
    if (kind !== 'rp' && kind !== 'vid') return;
    const L = lists(this.st, kind), base = PV.plKinds[kind];
    let n = L.length + 1; while (L.some(l => l.name === `${base} ${n}`)) n++;
    L.push({ id: uid(), name: `${base} ${n}`, items: [], speed: 1, loop: false, between: kind === 'rp' ? 'fade' : 'cut', mute: false });
  };
  A['pls.del'] = function (key) {
    const f = find(this.st, key); if (!f || PV.plPlaying(this.st, key)) return;
    const L = lists(this.st, f.kind); L.splice(L.indexOf(f.l), 1);
  };
  A['pls.set'] = function (key, patch) {
    const f = find(this.st, key); if (!f || !patch) return;
    const l = f.l;
    if (typeof patch.name === 'string' && patch.name.trim()) l.name = patch.name.trim().slice(0, 30);
    if (patch.speed) l.speed = Math.max(0.25, Math.min(1, +patch.speed));
    if (typeof patch.loop === 'boolean') l.loop = patch.loop;
    if (typeof patch.mute === 'boolean') l.mute = patch.mute;
    if (patch.between && (['cut', 'fade'].includes(patch.between) || this.st.trans.wipes.some(w => w.id === patch.between))) l.between = patch.between;
  };
  /* a play has one name: in All replays and in every playlist it was copied into */
  PV.rpRename = (st, clipId, name) => {
    const c = st.rp.clips.find(x => x.id === clipId); if (c) c.name = name;
    for (const l of st.rp.lists || []) for (const it of l.items) if (it.src === clipId) it.name = name;
  };
  // renaming it in a playlist renames it everywhere (a play since deleted from All keeps the name in its playlists)
  A['pls.itemName'] = function (key, itemId, name) {
    const f = find(this.st, key); if (!f || typeof name !== 'string' || !name.trim()) return;
    const it = f.l.items.find(x => x.id === itemId); if (!it) return;
    name = name.trim().slice(0, 40);
    if (f.kind === 'rp' && it.src) PV.rpRename(this.st, it.src, name); else it.name = name;
  };
  /* copies go in, so a playlist keeps working when the replay it came from is deleted */
  A['pls.paste'] = function (key, refs) {
    const st = this.st, f = find(st, key); if (!f || !Array.isArray(refs)) return;
    for (const r of refs) {
      if (f.kind === 'rp') {
        const c = st.rp.clips.find(x => x.id === (r && r.clip)); if (!c) continue;
        const angles = r.cam ? (c.angles.includes(r.cam) ? [r.cam] : []) : c.angles.slice(); if (!angles.length) continue;
        f.l.items.push({ id: uid(), src: c.id, name: c.name, angles, tIn: c.tIn, tOut: c.tOut, cuts: JSON.parse(JSON.stringify(c.cuts || {})), win: c.win ? c.win.slice() : null });
      } else {
        const v = PV.vidItem(st, r); if (!v) continue;
        f.l.items.push({ id: uid(), src: v.id, ref: v.ref, name: v.name, tIn: +v.tIn || 0, tOut: +v.tOut || 0, gain: v.gain == null ? 0.8 : v.gain });
      }
    }
  };
  A['pls.move'] = function (key, from, to) {
    const f = find(this.st, key); if (!f) return; const L = f.l.items; from = +from; to = +to;
    if (!L[from] || !L[to] || from === to) return; const [x] = L.splice(from, 1); L.splice(to, 0, x);
  };
  A['pls.order'] = function (kind, from, to) {
    const L = lists(this.st, kind); from = +from; to = +to;
    if (!L[from] || !L[to] || from === to) return; const [x] = L.splice(from, 1); L.splice(to, 0, x);
  };
  /* after an end stamp: whatever camera or M/E is in Preview, or the shot from before */
  PV.stampBack = (st, fallback) => /^cam|^me:/.test(st.preview || '') ? st.preview : (fallback || st.lastCam || 'cam1');
  /* an end stamp double-clicked: it plays now, over whatever is on air, and once it covers the screen
     the replay or video playlist ends and what's in Preview comes up underneath */
  A['pl.stamp'] = function (sid, _b, _c, t) {
    const st = this.st, G = window.PIVOT_GFX; t = t || now();
    if (!G || !G.stampOf(st.gfx.pkg, sid)) return;
    const rp = st.rp.playing;
    if (st.program === 'replay' && rp) {
      rp.outStamp = sid; rp.outTo = PV.stampBack(st, rp.ret); rp.stopped = false;
      if (rp.pend) rp.pend = null;
      this.endReplay(); return;
    }
    const lv = st.pl.last;
    if (st.program === 'video' && lv) { lv.seq = null; lv.pend = null; }
    const to = PV.stampBack(st, st.program);
    this.switchTo(to, t, 'wipe', null, sid);
  };
  /* an end stamp from the look goes in at the end of the playlist; it can be dragged anywhere in it */
  A['pls.addStamp'] = function (key, sid) {
    const st = this.st, f = find(st, key), G = window.PIVOT_GFX; if (!f || !G) return;
    const s = G.stampOf(st.gfx.pkg, sid); if (!s) return;
    f.l.items.push({ id: uid(), stamp: s.id, name: `${s.name} · ${s.sport}` });
  };
  A['pls.rm'] = function (key, itemId) { const f = find(this.st, key); if (f) f.l.items = f.l.items.filter(i => i.id !== itemId); };
  PV.plPlaying = (st, key) => {
    const [kind, id] = String(key).split(':');
    if (kind === 'rp') return !!(st.rp.playing && st.rp.playing.list === id && st.program === 'replay');
    return !!(st.pl.last && st.pl.last.list === id && st.pl.last.seq && st.program === 'video');
  };
  /* the transition into a playlist: the one picked in the column (a replay playlist never just cuts in) */
  function howIn(st, replay) {
    let how = replay ? PV.spaceHow(Object.assign({}, st, { preview: 'replay' })) : (st.trans.sel || 'cut'), wid = null;
    if (how !== 'fade' && how !== 'cut') { wid = st.trans.wipes.some(w => w.id === how) ? how : (st.trans.wipe || 'replay'); how = 'wipe'; }
    return { how, wid };
  }
  A['pls.roll'] = function (key, from, _c, t) {
    const st = this.st, f = find(st, key); t = t || now(); if (!f || !f.l.items.length) return;
    const l = f.l, i0 = Math.max(0, Math.min(+from || 0, l.items.length - 1));
    const all = l.items.slice(i0).concat(l.loop ? l.items.slice(0, i0) : []);
    // end stamps become the way into the clip after them; one at the very end takes the playlist back out to the live shot
    const look = window.PIVOT_GFX, ok = it => look && look.stampOf(st.gfx.pkg, it.stamp);
    const order = [], intoOf = {}; let pending = null, first = null;
    for (const it of all) {
      if (it.stamp) { if (ok(it)) pending = it.stamp; continue; }
      if (pending) { if (order.length) intoOf[it.id] = 'stamp:' + pending; else first = pending; pending = null; }
      order.push(it);
    }
    if (!order.length) return;
    const outStamp = pending;
    let { how, wid } = howIn(st, f.kind === 'rp');
    if (first) { how = 'wipe'; wid = null; }
    const delay = to => how === 'wipe' ? (first ? PV.stampCut(st, first) : PV.wipeHalf(st, to, wid)) : 0;
    // between the clips: what was picked, unless it's a team wipe the look doesn't have
    const between = ['cut', 'fade'].includes(l.between) || PV.wipeOk(st, l.between) ? l.between : 'replay';
    const ret = ['video', 'replay', 'black'].includes(st.program) ? (st.lastCam || 'cam1') : st.program;
    if (f.kind === 'rp') {
      const seq = [].concat(...order.map(it => PV.clipSeq(it, it.angles, intoOf[it.id] || between, it.id)));
      if (!seq.length) return;
      if (st.rp.playing && st.program === 'replay') st.rp.playing = null;
      st.rp.playing = PV.rpStart(st, seq, { start: t + delay('replay'), speed: l.speed, ret, how, wid, list: l.id, loop: l.loop, outStamp });
      this.switchTo('replay', t, how, wid, first);
    } else {
      const seq = order.map(it => ({ src: it.src, item: it.id, ref: it.ref, name: it.name, tIn: it.tIn, tOut: it.tOut, gain: l.mute ? 0 : it.gain, into: intoOf[it.id] || between }));
      if (st.pl.active) st.pl.active = null;
      st.gfx.full = null;
      st.pl.last = Object.assign(vidOf(seq[0]), { start: t + delay('video'), bounce: false, seq, i: 0, list: l.id, loop: l.loop, speed: l.speed, how, wid, take: ++takes, xf: 0, outStamp });
      if (st.program === 'video') { if (how === 'wipe') this.switchTo('video', t, how, wid, first); else st.trans.active = null; }
      else this.switchTo('video', t, how, wid, first);
    }
    PV.afterWipe(st, wid);
  };
  A['pls.stop'] = function (kind) {
    const st = this.st;
    if (kind === 'rp') { if (st.rp.playing && st.rp.playing.list) { st.rp.playing.stopped = true; this.endReplay(); } return; }
    const lv = st.pl.last; if (!lv || !lv.seq) return;
    lv.seq = null; lv.stopped = true; vidOut(this, lv, now());
  };
  const vidOf = s => ({ ref: s.ref, name: s.name, id: s.src, tIn: s.tIn, tOut: s.tOut, gain: s.gain });
  function vidOut(eng, lv, t) {
    const st = eng.st; if (st.program !== 'video') return;
    const back = /^cam|^me:/.test(st.preview) ? st.preview : (st.lastCam || 'cam1');
    if (lv.outStamp && lv.seq === null && !lv.stopped) { eng.switchTo(PV.stampBack(st, back), t, 'wipe', null, lv.outStamp); return; }
    eng.switchTo(back, t, lv.how === 'cut' ? 'cut' : lv.how === 'wipe' ? 'wipe' : 'fade', lv.wid);
  }

  /* video playlists move along with the clock */
  const oldTick = Eng.tick;
  Eng.tick = function () {
    oldTick.call(this);
    const st = this.st, lv = st.pl.last, t = now();
    if (!lv || !lv.seq || st.program !== 'video') return;
    let dirty = false;
    const go = (i, fade) => { const s = lv.seq[i]; lv.prev = { ref: lv.ref, tIn: lv.tIn, tOut: lv.tOut, start: lv.start, speed: lv.speed }; Object.assign(lv, vidOf(s), { start: t, i, take: ++takes, xf: fade || 0 }); dirty = true; };
    if (lv.pend) { if (t >= lv.pend.at) { const i = lv.pend.i; lv.pend = null; go(i, 0); } }
    else if (t >= lv.start) {
      const len = Math.max(0.2, lv.tOut - lv.tIn) / (lv.speed || 1) * 1000;
      const ni = lv.i + 1 < lv.seq.length ? lv.i + 1 : lv.loop ? 0 : -1, nx = ni >= 0 ? lv.seq[ni] : null;
      const fade = PV.fadeMs(st), lead = nx && nx.into === 'fade' ? Math.min(len / 2, fade) : 0;
      if (t - lv.start >= len - lead) {
        if (!nx) { lv.seq = null; vidOut(this, lv, t); dirty = true; }
        else if (isWipe(nx.into)) { st.trans.active = wipeTo(st, 'video', 'video', t, nx.into); lv.pend = { at: t + st.trans.active.dur * st.trans.active.at, i: ni }; dirty = true; }
        else go(ni, nx.into === 'fade' ? fade : 0);
      }
    }
    if (dirty) this.changed();
  };

  /* the footage behind every playlist is kept, like the marked replays */
  PV.plKeep = st => [].concat(...(st.rp.lists || []).map(l => l.items.filter(it => !it.stamp).map(it => {
    const ins = it.angles.map(a => PV.cut(it, a).tIn), outs = it.angles.map(a => PV.cut(it, a).tOut);
    return [Math.min(...ins, it.win ? it.win[0] : Infinity), Math.max(...outs, it.win ? it.win[1] : -Infinity)];
  })));

  /* the desk's own picture of a replay or video mixing into the next one */
  PV.mixAlpha = (o, t) => o && o.xf && t - o.start < o.xf ? Math.max(0, Math.min(1, (t - o.start) / o.xf)) : 1;
})();
