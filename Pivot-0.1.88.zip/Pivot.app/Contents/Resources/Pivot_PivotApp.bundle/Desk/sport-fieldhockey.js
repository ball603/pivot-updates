/* Field hockey: four quarters, goals one at a time. What it shares with soccer is in sport-field.js. */
(function () {
  const PV = window.PV;
  PV.registerSport({
    id: 'fieldhockey', name: 'Field Hockey',
    codes: { FH: 'Field Hockey' },
    rules: { periods: 4, len: 15, unit: 'quarter', halftimeAfter: 2, bonus: 99, foulsReset: 'quarter', media: [], ot: 10, timeouts: 0, field: true },
    board: { start: 'Start', banner: true }
  });
})();
