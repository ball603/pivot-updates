/* Replay trim window: double-click a play's bar in the Replays row.
   Opens over the lower rows, below the Favs. Name field first, then the four angles
   on the left and one angle big beside them, with one timeline across the bottom.
   The timeline works on ALL ANGLES until you click an angle's picture; then it's that
   angle's own in and out (click the picture again, or the label, to go back to all).
   Move the mouse along the timeline to scrub. I and O set the in and out. Drag a handle,
   or click it and use the arrow keys to move it a tenth of a second. */
(function () {
  const PV = window.PV, UI = PV.UI, S = window.PIVOT_SIM;
  const esc = UI.esc;
  const STEP = 0.1, MIN = 0.5;
  const fmt = v => { v = Math.max(0, v); const m = Math.floor(v / 60), r = v - m * 60; return `${m}:${r.toFixed(1).padStart(4, '0')}`; };
  let P = null;   // the open window

  UI.rpPanelOpen = () => !!P;
  UI.rpPanelState = () => P && { ang: P.ang, mode: P.mode, lo: P.lo, hi: P.hi, ph: P.ph, cuts: JSON.parse(JSON.stringify(P.cuts)), handle: P.handle };

  UI.rpPanel = function (clipId, ang) {
    const st = PV.E.st, clip = st.rp.clips.find(c => c.id === clipId);
    if (!clip) return;
    if (P && P.id === clipId) { if (ang) pick(ang, true); return; }
    UI.rpPanelClose();
    UI.closeMenus && UI.closeMenus();
    const angles = (clip.angles.length ? clip.angles : PV.camIds(st)).slice(0, 4);
    const big = angles.includes('cam2') ? 'cam2' : angles[0];
    const cuts = {}; for (const a of angles) { const k = PV.cut(clip, a); cuts[a] = [k.tIn, k.tOut]; }
    const host = document.querySelector('.lower3');
    const el = document.createElement('div');
    el.className = 'rpp'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Trim replay');
    el.innerHTML = `<div class="rpph"><b>REPLAY</b><input type="text" class="inp" id="rppName" value="${esc(clip.name)}" maxlength="40" aria-label="Replay name">
        <button class="btn sm" data-r="play" id="rppPlay" title="Play from the in point">▶ Play <kbd>K</kbd></button>
        <span class="hint">Move along the timeline to scrub · <kbd>I</kbd> <kbd>O</kbd> set in and out · click a handle, then <kbd>←</kbd> <kbd>→</kbd> move it 0.1 s · click an angle to trim it on its own</span>
        <span class="sp"></span><button class="btn sm ghost red" data-r="del" id="rppDel" hidden title="Take this angle out of the play">Delete</button><button class="btn sm" data-r="close" title="Close (Esc)">Done <kbd>Esc</kbd></button></div>
      <div class="rppb">
        <div class="rppq">${angles.map(a => `<div class="rppt" role="button" tabindex="0" data-a="${a}" title="Trim ${PV.srcShort(a)} on its own (click again for all angles)"><canvas></canvas><span>${PV.srcShort(a)}</span><button class="rpx" data-xa="${a}" title="Delete this angle" aria-label="Delete ${PV.srcShort(a)}">×</button></div>`).join('')}</div>
        <div class="rppv"><canvas id="rppBig"></canvas><span class="rppbl" id="rppBigL"></span><span class="rpptc tc" id="rppTc"></span></div>
      </div>
      <div class="rppr"><button class="rppn" id="rppMode" data-r="all" title="Back to all angles"></button><div class="rppk"><div class="rpps"></div><i class="rpphd in" data-h="in" title="In point: drag it, or click it and use the arrow keys"></i><i class="rpphd out" data-h="out" title="Out point: drag it, or click it and use the arrow keys"></i><i class="rppp"></i></div><span class="rppd tc"></span></div>`;
    host.appendChild(el);
    P = { id: clipId, el, angles, cuts, ang: big, mode: 'all', ph: cuts[big][0], handle: null, playing: false, t0: 0, ph0: 0, raf: 0, lo: 0, hi: 1 };
    range();
    if (ang && angles.includes(ang)) pick(ang, true); else pick(null);
    place();
    wire();
    const nm = el.querySelector('#rppName');
    nm.focus(); nm.select();
    P.raf = requestAnimationFrame(draw);
  };

  UI.rpPanelClose = function () {
    if (!P) return;
    cancelAnimationFrame(P.raf);
    saveName();
    P.el.remove();
    P = null;
  };

  /* the stretch of time this play covers: from its window's start to now, or the window's end */
  function range() {
    const st = PV.E.st, clip = st.rp.clips.find(c => c.id === P.id);
    if (!clip) return false;
    P.lo = clip.win ? clip.win[0] : clip.tIn - 20;
    P.hi = Math.max(P.lo + 1, Math.min(clip.win ? clip.win[1] : clip.tOut + 10, PV.worldT(st)));
    return true;
  }
  /* sits under the Favs and covers the rows below them */
  function place() {
    const host = document.querySelector('.lower3'), rows = document.getElementById('rows'), bar = rows && rows.querySelector('.row3.favs');
    if (!host || !rows) return;
    const hr = host.getBoundingClientRect(), rr = rows.getBoundingClientRect();
    const top = bar ? Math.max(rr.top, bar.getBoundingClientRect().bottom + 6) : rr.top;
    const s = P.el.style;
    s.left = (rr.left - hr.left) + 'px'; s.width = rr.width + 'px';
    s.top = (top - hr.top) + 'px'; s.height = Math.max(220, rr.bottom - top) + 'px';
  }
  /* null: the timeline works on every angle; an angle: just that one (and it shows big) */
  function pick(a, toggle) {
    if (a && toggle && P.mode === a) a = null;
    P.mode = a || 'all';
    if (a) P.ang = a;
    P.el.querySelectorAll('.rppt').forEach(x => x.classList.toggle('on', x.dataset.a === a));
    const m = P.el.querySelector('#rppMode');
    m.textContent = a ? PV.srcShort(a) : 'ALL ANGLES';
    m.classList.toggle('one', !!a);
    const del = P.el.querySelector('#rppDel'); del.hidden = !a; del.innerHTML = a ? `Delete ${PV.srcShort(a)} <kbd>⌫</kbd>` : '';
    P.el.querySelector('#rppBigL').textContent = PV.srcShort(P.ang) + ((PV.E.st.inputs[P.ang] || {}).name ? ' · ' + PV.E.st.inputs[P.ang].name : '');
    selHandle(null);
  }
  const editing = () => P.mode === 'all' ? P.angles : [P.mode];
  /* what the timeline shows: one angle's points, or for all angles the earliest in and latest out */
  function shown() {
    if (P.mode !== 'all') return P.cuts[P.mode];
    return [Math.min(...P.angles.map(a => P.cuts[a][0])), Math.max(...P.angles.map(a => P.cuts[a][1]))];
  }
  function selHandle(h) {
    P.handle = h || null;
    P.el.querySelectorAll('.rpphd').forEach(x => x.classList.toggle('sel', !!h && x.dataset.h === h));
  }
  const now = () => P.playing ? Math.min(P.hi, P.ph0 + (Date.now() - P.t0) / 1000 * speed()) : P.ph;
  const speed = () => { const c = PV.E.st.rp.clips.find(x => x.id === P.id); return c ? c.speed || 1 : 1; };
  function setPlay(on) {
    if (on) { const [i, o] = shown(); if (P.ph < i || P.ph >= o - 0.05) P.ph = i; P.ph0 = P.ph; P.t0 = Date.now(); P.playing = true; }
    else { P.ph = now(); P.playing = false; }
    P.el.querySelector('#rppPlay').innerHTML = `${P.playing ? '❚❚ Pause' : '▶ Play'} <kbd>K</kbd>`;
  }

  /* every change goes straight to the show */
  function send(a) { const [i, o] = P.cuts[a]; UI.send('rp.cut', P.id, a, [i, o]); }
  function setIn(v) { for (const a of editing()) { const c = P.cuts[a]; c[0] = Math.max(P.lo, Math.min(v, P.hi - MIN)); if (c[1] < c[0] + MIN) c[1] = Math.min(P.hi, c[0] + MIN); } }
  function setOut(v) { for (const a of editing()) { const c = P.cuts[a]; c[1] = Math.min(P.hi, Math.max(v, P.lo + MIN)); if (c[0] > c[1] - MIN) c[0] = Math.max(P.lo, c[1] - MIN); } }
  const sendAll = () => { for (const a of editing()) send(a); };
  let nameT = 0;
  function saveName() {
    clearTimeout(nameT);
    const v = P && P.el.querySelector('#rppName').value.trim();
    const c = P && PV.E.st.rp.clips.find(x => x.id === P.id);
    if (v && c && c.name !== v) UI.send('rp.name', P.id, v);
  }

  function wire() {
    const el = P.el;
    const nm = el.querySelector('#rppName');
    nm.addEventListener('input', () => { clearTimeout(nameT); nameT = setTimeout(saveName, 300); });
    nm.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); saveName(); nm.blur(); } });
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-r]');
      if (b) { const r = b.dataset.r; if (r === 'close') UI.rpPanelClose(); else if (r === 'play') setPlay(!P.playing); else if (r === 'all') pick(null); else if (r === 'del') dropAngle(); return; }
      const x = e.target.closest('[data-xa]'); if (x) { dropAngle(x.dataset.xa); return; }
      const t = e.target.closest('.rppt'); if (t) pick(t.dataset.a, true);
    });
    const k = el.querySelector('.rppk');
    const at = ev => { const r = k.getBoundingClientRect(); return P.lo + Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)) * (P.hi - P.lo); };
    k.addEventListener('pointerdown', e => {
      e.preventDefault();
      if (document.activeElement === nm) { saveName(); nm.blur(); }
      const h = e.target.dataset && e.target.dataset.h;
      selHandle(h || null);
      setPlay(false);
      P.drag = true;
      const mv = ev => { const v = at(ev); if (h === 'in') setIn(v); else if (h === 'out') setOut(v); P.ph = h ? shown()[h === 'in' ? 0 : 1] : v; };
      mv(e);
      k.setPointerCapture(e.pointerId);
      const up = () => { P.drag = false; k.removeEventListener('pointermove', mv); k.removeEventListener('pointerup', up); k.removeEventListener('pointercancel', up); if (h) sendAll(); };
      k.addEventListener('pointermove', mv); k.addEventListener('pointerup', up); k.addEventListener('pointercancel', up);
    });
    // just moving the mouse along the timeline scrubs
    k.addEventListener('pointermove', e => {
      if (!P || P.drag || e.buttons) return;
      if (P.playing) setPlay(false);
      P.ph = at(e);
    });
  }

  /* the angle picked comes out of the play (the play goes when its last angle does) */
  function dropAngle(which) {
    const a = which || P.mode;
    if (a === 'all') return;
    const st = PV.E.st;
    if (st.rp.playing && st.rp.playing.clip === P.id) { UI.toast('That replay is on air'); return; }
    UI.send('rp.angDel', P.id, a);
    UI.toast(`Removed ${PV.srcShort(a)}`);
    P.angles = P.angles.filter(x => x !== a); delete P.cuts[a];
    if (!P.angles.length) { UI.rpPanelClose(); return; }
    const t = P.el.querySelector(`.rppt[data-a="${a}"]`); if (t) t.remove();
    if (P.ang === a) P.ang = P.angles.includes('cam2') ? 'cam2' : P.angles[0];
    pick(null);
  }

  /* keys win over the desk's shortcuts while the window is open (not while typing the name) */
  window.addEventListener('keydown', e => {
    if (!P || e.metaKey || e.ctrlKey || e.altKey) return;
    const tg = e.target;
    if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.isContentEditable)) return;
    if (document.querySelector('.scrim')) return;
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    let done = true;
    if (k === 'Escape') UI.rpPanelClose();
    else if (k === 'i') { setIn(now()); sendAll(); }
    else if (k === 'o') { setOut(now()); sendAll(); }
    else if (k === 'k') setPlay(!P.playing);
    else if ((k === 'Backspace' || k === 'Delete') && P.mode !== 'all') dropAngle();
    else if (k === 'ArrowLeft' || k === 'ArrowRight') {
      const d = (k === 'ArrowLeft' ? -STEP : STEP) * (e.shiftKey ? 10 : 1);
      if (P.handle) {
        // the handle moves; with all angles, each angle's point moves by the same amount
        for (const a of editing()) { const c = P.cuts[a]; if (P.handle === 'in') c[0] = Math.max(P.lo, Math.min(c[0] + d, c[1] - MIN)); else c[1] = Math.min(P.hi, Math.max(c[1] + d, c[0] + MIN)); }
        P.ph = shown()[P.handle === 'in' ? 0 : 1]; sendAll();
      } else { setPlay(false); P.ph = Math.max(P.lo, Math.min(P.hi, P.ph + d)); }
    } else done = false;
    if (done) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);

  function paint(ctx, w, h, a, T, key) {
    const st = PV.E.st;
    if (PV.native) PV.native.drawSnap(ctx, w, h, `replay:${a}@${Math.round(PV.wallOf(st, T))}`, { key });
    else S.drawCamera(ctx, w, h, a, T, PV.gameFor(st.show), PV.lookFor(st.show));
    const [i, o] = P.cuts[a];
    if (T < i - 0.01 || T > o + 0.01) { ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(0, 0, w, h); }
  }
  function draw() {
    if (!P) return;
    if (!document.body.contains(P.el) || !range()) { UI.rpPanelClose(); return; }
    place();
    let v = now();
    if (P.playing && v >= shown()[1]) { P.ph = shown()[1]; setPlay(false); v = P.ph; }
    v = Math.max(P.lo, Math.min(P.hi, v));
    const big = P.el.querySelector('#rppBig');
    { const [w, h] = UI.fit(big, 1280); paint(big.getContext('2d'), w, h, P.ang, v, 'rpp:big'); }
    // the quad: a few frames apart so the Mac isn't asked for five pictures at once
    P.n = (P.n || 0) + 1;
    P.el.querySelectorAll('.rppt canvas').forEach((c, i) => { if ((P.n + i) % 2) return; const [w, h] = UI.fit(c, 480); paint(c.getContext('2d'), w, h, P.angles[i], v, 'rpp:' + P.angles[i]); });
    const pos = t => ((t - P.lo) / (P.hi - P.lo) * 100).toFixed(3) + '%';
    const [i, o] = shown(), r = P.el.querySelector('.rppr');
    const sl = r.querySelector('.rpps'); sl.style.left = pos(i); sl.style.width = `calc(${pos(o)} - ${pos(i)})`;
    r.querySelector('.rpphd.in').style.left = pos(i); r.querySelector('.rpphd.out').style.left = pos(o);
    r.querySelector('.rppp').style.left = pos(v);
    const d = r.querySelector('.rppd'), txt = `${fmt(i - P.lo)} – ${fmt(o - P.lo)}  ${(o - i).toFixed(1)}s`;
    if (d.textContent !== txt) d.textContent = txt;
    const tc = P.el.querySelector('#rppTc'), t2 = fmt(v - P.lo); if (tc.textContent !== t2) tc.textContent = t2;
    P.raf = requestAnimationFrame(draw);
  }

  /* double-click a play's bar in the Replays row */
  document.addEventListener('dblclick', e => {
    const h = e.target.closest('.rpgh[data-clip]'); if (!h || e.target.closest('button')) return;
    e.preventDefault();
    UI.rpPanel(h.dataset.clip);
  });
})();
