/* Pivot graphics engine.
   One set of graphic slots, fed the same data; a package only changes the look.
   Everything here is drawn from the show state, so every window shows the same graphics. */
(function () {
  const S = window.PIVOT_SIM;

  const PACKAGES = {
    // Standard stays as the base an added package draws on for anything it doesn't draw itself; it and Clean aren't offered as looks
    standard: { id: 'standard', name: 'Pivot Standard', desc: 'Slate bars, team color chips. Clean and readable.', accent: '#ffb020', hidden: true },
    arena: { id: 'arena', name: 'Pivot Arena', desc: 'Angled panels in full team color. Loud and big-game.', accent: '#ff3d5a' },
    clean: { id: 'clean', name: 'Pivot Clean', desc: 'Light glass panels, rounded. Quiet and modern.', accent: '#2b7cff', hidden: true }
  };

  const CSS = `
.gfx-wrap{position:absolute;inset:0;overflow:hidden;pointer-events:none;container-type:size}
.gfx-stage{position:absolute;left:0;top:0;width:1920px;height:1080px;transform-origin:0 0;transform:scale(var(--k,0.5));font-family:"Barlow Condensed","Arial Narrow",sans-serif;color:#fff;--acc:#ffb020}
.gfx-stage *{box-sizing:border-box}
.gfx-stage .lay{position:absolute;transition:opacity .35s ease}
.gfx-stage .lay.hide{opacity:0!important}
.gfx-stage .lay.in{animation:gIn .55s cubic-bezier(.2,.8,.2,1) both}
.gfx-stage .lay.out{animation:gOut .4s ease both}
.gfx-stage .lay.g-split{animation:none;transition:none}
@keyframes gIn{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
@keyframes gOut{to{opacity:0;transform:translateY(16px)}}
.gfx-stage .tc{font-variant-numeric:tabular-nums}

/* a look's picture (a rules graphic) is placed on the whole frame, not where the built-in lower third sits */
.gfx-stage .lay.g-l3.pic{left:0;top:0;right:auto;bottom:auto;width:1920px;height:1080px;transform:none;background:none;padding:0;border:0;border-radius:0;box-shadow:none;filter:none;min-width:0;display:block}
/* the scorebug ticker (built-in looks): just above the bug */
.gfx-stage .lay.g-sbtk{left:0;top:0;width:1920px;height:1080px}
.gfx-stage .g-sbtk .stk{position:absolute;left:72px;bottom:206px;min-width:440px;display:grid;background:#11151c;color:#fff;border-radius:6px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.45)}
.gfx-stage .g-sbtk .tkf{grid-area:1/1;opacity:0}
.gfx-stage .stk-h{padding:8px 16px;background:var(--acc,#1f3a8a);font-size:22px;font-weight:700;letter-spacing:.02em}
.gfx-stage .stk-b{display:flex}.gfx-stage .stk-t{flex:1;padding:6px 16px}
.gfx-stage .stk-t div{display:flex;justify-content:space-between;gap:24px;font-size:26px;line-height:38px}.gfx-stage .stk-t b{font-weight:700}
.gfx-stage .stk-s{display:flex;align-items:center;justify-content:center;padding:0 18px;border-left:1px solid #232a35;font-size:20px;font-weight:700;color:#c9d1dc;text-align:center;min-width:110px}

/* ---------- STANDARD ---------- */
.pkg-standard .g-sb{left:72px;bottom:64px;display:grid;grid-template-columns:auto auto;grid-template-areas:"away meta" "home meta";background:#11151c;border-radius:6px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.45)}
.pkg-standard .sb-row{display:flex;align-items:center;height:62px;padding:0 18px 0 0;gap:14px;border-bottom:1px solid #232a35}
.pkg-standard .sb-row.home{border-bottom:0}
.pkg-standard .sb-row.away{grid-area:away}.pkg-standard .sb-row.home{grid-area:home}
.pkg-standard .sb-chip{width:12px;align-self:stretch;background:var(--c)}
.pkg-standard .sb-code{font-size:40px;font-weight:700;letter-spacing:.02em;width:110px}
.pkg-standard .sb-rec{font-size:20px;color:#8e99aa;width:62px;font-weight:600}
.pkg-standard .sb-pts{font-size:50px;font-weight:700;width:76px;text-align:right}
.pkg-standard .sb-tags{display:flex;flex-direction:column;align-items:flex-start;gap:3px;width:78px}
.pkg-standard .sb-tos{display:flex;gap:3px}.pkg-standard .sb-tos i{width:15px;height:4px;border-radius:2px;background:#2c3440}.pkg-standard .sb-tos i.on{background:#fff}
.pkg-standard .sb-fouls{display:flex;gap:4px}.pkg-standard .sb-fouls i{width:9px;height:9px;border-radius:50%;background:#2c3440}.pkg-standard .sb-fouls i.on{background:var(--acc)}
.pkg-standard .sb-bonus{font-size:15px;font-weight:700;letter-spacing:.08em;color:var(--acc);visibility:hidden}.pkg-standard .sb-bonus.on{visibility:visible}
.pkg-standard .sb-poss{width:0;height:0;border-top:9px solid transparent;border-bottom:9px solid transparent;border-right:12px solid var(--acc);opacity:0}.pkg-standard .sb-poss.on{opacity:1}
.pkg-standard .sb-meta{grid-area:meta;display:flex;flex-direction:column;justify-content:center;align-items:center;min-width:170px;background:#1a2029;border-left:1px solid #232a35;gap:2px}
.pkg-standard .sb-per{font-size:24px;font-weight:600;color:#aeb7c4;letter-spacing:.06em}
.pkg-standard .sb-clk{font-size:46px;font-weight:700}
.pkg-standard .sb-flag{position:absolute;left:0;right:0;top:-38px;height:38px;display:none;align-items:center;justify-content:center;background:var(--acc);color:#111;font-size:24px;font-weight:700;letter-spacing:.12em}
.pkg-standard .sb-flag.on{display:flex}

.pkg-standard .g-l3{left:72px;bottom:240px;display:flex;align-items:stretch;min-width:760px;box-shadow:0 10px 30px rgba(0,0,0,.4)}
.pkg-standard .l3-badge{width:128px;background:var(--c);color:var(--ci);display:flex;flex-direction:column;align-items:center;justify-content:center}
.pkg-standard .l3-num{font-size:64px;font-weight:700;line-height:1}
.pkg-standard .l3-code{font-size:22px;font-weight:700;letter-spacing:.1em;opacity:.85}
.pkg-standard .l3-main{background:#11151c;padding:16px 30px 16px 26px;display:flex;flex-direction:column;justify-content:center;flex:1}
.pkg-standard .l3-name{font-size:54px;font-weight:600;line-height:1;white-space:nowrap}
.pkg-standard .l3-name b{font-weight:800;text-transform:uppercase}
.pkg-standard .l3-sub{font-family:"Barlow",sans-serif;font-size:24px;color:#a8b2c1;margin-top:8px;white-space:nowrap}
.pkg-standard .l3-stat{display:flex;background:#1a2029;border-left:4px solid var(--acc)}
.pkg-standard .l3-stat div{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0 24px}
.pkg-standard .l3-stat b{font-size:52px;font-weight:700;line-height:1}.pkg-standard .l3-stat span{font-size:20px;color:#a8b2c1;letter-spacing:.1em;font-weight:600}
.pkg-standard .l3-duo{display:flex;gap:0}
.pkg-standard .l3-duo>div{padding:0 30px 0 0}
.pkg-standard .l3-role{font-family:"Barlow",sans-serif;font-size:20px;letter-spacing:.14em;text-transform:uppercase;color:var(--acc);font-weight:700}

.pkg-standard .g-full{left:50%;top:50%;width:1340px;transform:translate(-50%,-50%);background:rgba(13,16,22,.94);border-radius:8px;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,.55)}
.pkg-standard .g-full.in{animation:fIn .55s cubic-bezier(.2,.8,.2,1) both}.pkg-standard .g-full.out{animation:fOut .35s ease both}
@keyframes fIn{from{opacity:0;transform:translate(-50%,-46%)}to{opacity:1;transform:translate(-50%,-50%)}}
@keyframes fOut{to{opacity:0;transform:translate(-50%,-48%)}}
.pkg-standard .fs-head{display:flex;align-items:center;justify-content:space-between;padding:22px 40px;border-bottom:3px solid var(--acc);background:#11151c}
.pkg-standard .fs-title{font-size:52px;font-weight:700;letter-spacing:.02em;text-transform:uppercase}
.pkg-standard .fs-kicker{font-family:"Barlow",sans-serif;font-size:22px;letter-spacing:.16em;color:#9aa5b5;text-transform:uppercase;font-weight:600}

/* the ticker looks the same in every package: NEC Front Row's */
.gfx-stage .g-tick.lay{left:0!important;right:0!important;bottom:0!important;top:auto!important;height:64px!important;border-radius:0!important;box-shadow:none!important;background:#050a14!important;border-top:1px solid rgba(43,140,230,.42)!important;display:flex;align-items:stretch;overflow:hidden;font-family:"Barlow Condensed","Arial Narrow",sans-serif;color:#fff}
.gfx-stage .g-tick .tk-label{flex:none;height:auto!important;display:flex;align-items:center;gap:8px;padding:0 18px!important;background:#2b8ce6!important;color:#fff!important;clip-path:none!important;font-weight:800!important;font-style:italic!important;font-size:30px!important;letter-spacing:.03em!important}
.gfx-stage .g-tick .tk-label small{font-family:"Barlow",sans-serif;font-style:normal;font-weight:600;font-size:18px;letter-spacing:.1em;text-transform:uppercase;opacity:.85}
.gfx-stage .g-tick .tk-track{height:auto}
.gfx-stage .g-tick .tk-run{gap:0!important;padding-left:0!important;font-size:30px!important;font-weight:700!important;height:100%}
.gfx-stage .tk-g{display:flex;align-items:center;gap:12px;height:100%;padding:0 24px;border-right:1px solid rgba(43,140,230,.42);white-space:nowrap;font-variant-numeric:tabular-nums}
.gfx-stage .tk-sp{font-family:"Barlow",sans-serif;font-weight:700;font-size:18px;letter-spacing:.08em;text-transform:uppercase;color:#97aac6}
.gfx-stage .tk-tm{display:flex;align-items:center;gap:7px}
.gfx-stage .tk-tm i{width:6px;height:28px;border-radius:2px}
.gfx-stage .tk-tm.lead{color:#fff}.gfx-stage .tk-tm.trail{color:#97aac6}
.gfx-stage .tk-st{font-family:"Barlow",sans-serif;font-weight:600;font-size:19px;color:#97aac6;text-transform:uppercase;letter-spacing:.05em}
.gfx-stage .tk-st.live{color:#ffb4b5}
.pkg-standard .g-tick{left:0;right:0;bottom:0;height:52px;background:#0d1016;display:flex;align-items:center;border-top:2px solid var(--acc)}
.pkg-standard .tk-label{height:100%;display:flex;align-items:center;padding:0 26px;background:var(--acc);color:#111;font-size:26px;font-weight:700;letter-spacing:.06em}
.pkg-standard .g-rbug{left:72px;top:58px;background:#11151c;border-left:8px solid var(--acc);padding:10px 22px;font-size:34px;font-weight:700;letter-spacing:.14em}

/* ---------- ARENA ---------- */
.pkg-arena{font-family:"Saira Condensed","Barlow Condensed",sans-serif;--acc:#ff3d5a}
.pkg-arena .g-sb{left:50%;bottom:48px;transform:translateX(-50%);display:flex;align-items:stretch;height:84px;filter:drop-shadow(0 12px 24px rgba(0,0,0,.5))}
.pkg-arena .g-sb.in{animation:aSbIn .6s cubic-bezier(.2,.8,.2,1) both}
@keyframes aSbIn{from{opacity:0;transform:translate(-50%,30px)}to{opacity:1;transform:translateX(-50%)}}
.pkg-arena .g-sb.out{animation:aSbOut .4s ease both}@keyframes aSbOut{to{opacity:0;transform:translate(-50%,20px)}}
.pkg-arena .sb-row{display:flex;align-items:center;gap:16px;padding:0 34px;background:linear-gradient(100deg,var(--c),color-mix(in srgb,var(--c) 70%,#000));color:var(--ci);min-width:360px}
.pkg-arena .sb-row.away{order:1;clip-path:polygon(28px 0,100% 0,100% 100%,0 100%);justify-content:flex-end}
.pkg-arena .sb-row.home{order:3;clip-path:polygon(0 0,100% 0,calc(100% - 28px) 100%,0 100%);flex-direction:row-reverse;justify-content:flex-end}
.pkg-arena .sb-chip{display:none}
.pkg-arena .sb-code{font-size:46px;font-weight:800;letter-spacing:.02em;font-style:italic}
.pkg-arena .sb-rec{font-size:20px;font-weight:600;opacity:.75;white-space:nowrap}
.pkg-arena .sb-pts{font-size:66px;font-weight:800;min-width:90px;text-align:center;background:rgba(0,0,0,.28);align-self:stretch;display:flex;align-items:center;justify-content:center;margin:0 -6px}
.pkg-arena .sb-tags{display:flex;flex-direction:column;gap:4px;align-items:center}
.pkg-arena .sb-tos{display:flex;gap:3px}.pkg-arena .sb-tos i{width:13px;height:4px;transform:skewX(-14deg);background:rgba(255,255,255,.22)}.pkg-arena .sb-tos i.on{background:var(--acc)}
.pkg-arena .sb-fouls{display:flex;gap:4px}.pkg-arena .sb-fouls i{width:8px;height:14px;transform:skewX(-14deg);background:rgba(255,255,255,.25)}.pkg-arena .sb-fouls i.on{background:#fff}
.pkg-arena .sb-bonus{font-size:15px;font-weight:800;letter-spacing:.1em;background:#fff;color:#111;padding:0 6px;visibility:hidden}.pkg-arena .sb-bonus.on{visibility:visible}
.pkg-arena .sb-poss{width:12px;height:12px;border-radius:50%;background:#fff;opacity:0}.pkg-arena .sb-poss.on{opacity:1}
.pkg-arena .sb-meta{order:2;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#0c0e12;min-width:190px;padding:0 20px;margin:0 -14px;clip-path:polygon(14px 0,calc(100% - 14px) 0,100% 100%,0 100%);z-index:1}
.pkg-arena .sb-per{font-size:22px;font-weight:700;letter-spacing:.14em;color:var(--acc)}
.pkg-arena .sb-clk{font-size:48px;font-weight:800;line-height:1}
.pkg-arena .sb-flag{position:absolute;left:50%;top:-40px;transform:translateX(-50%);padding:2px 30px;background:var(--acc);font-size:26px;font-weight:800;letter-spacing:.14em;display:none;clip-path:polygon(12px 0,100% 0,calc(100% - 12px) 100%,0 100%)}
.pkg-arena .sb-flag.on{display:block}

.pkg-arena .g-l3{left:110px;bottom:170px;display:flex;align-items:stretch;filter:drop-shadow(0 12px 24px rgba(0,0,0,.45))}
.pkg-arena .g-l3.in{animation:aL3 .6s cubic-bezier(.2,.8,.2,1) both}@keyframes aL3{from{opacity:0;transform:translateX(-60px)}to{opacity:1;transform:none}}
.pkg-arena .l3-badge{width:150px;background:#0c0e12;display:flex;flex-direction:column;align-items:center;justify-content:center;clip-path:polygon(0 0,100% 0,calc(100% - 22px) 100%,0 100%);padding-right:16px}
.pkg-arena .l3-num{font-size:84px;font-weight:800;font-style:italic;line-height:.9;color:var(--c2)}
.pkg-arena .l3-code{font-size:22px;font-weight:700;letter-spacing:.12em}
.pkg-arena .l3-main{background:linear-gradient(100deg,var(--c),color-mix(in srgb,var(--c) 65%,#000));color:var(--ci);padding:18px 60px 18px 44px;margin-left:-22px;clip-path:polygon(22px 0,100% 0,calc(100% - 22px) 100%,0 100%);display:flex;flex-direction:column;justify-content:center}
.pkg-arena .l3-name{font-size:62px;font-weight:600;line-height:.95;white-space:nowrap;text-transform:uppercase}
.pkg-arena .l3-name b{font-weight:800}
.pkg-arena .l3-sub{font-size:26px;font-weight:600;opacity:.85;margin-top:6px;white-space:nowrap;letter-spacing:.04em}
.pkg-arena .l3-stat{display:flex;margin-left:-22px;background:#fff;color:#0c0e12;clip-path:polygon(22px 0,100% 0,calc(100% - 22px) 100%,0 100%);padding:0 40px}
.pkg-arena .l3-stat div{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0 16px}
.pkg-arena .l3-stat b{font-size:58px;font-weight:800;line-height:1}.pkg-arena .l3-stat span{font-size:18px;font-weight:700;letter-spacing:.14em;color:var(--acc)}
.pkg-arena .l3-duo{display:flex;gap:46px}
.pkg-arena .l3-role{font-size:22px;letter-spacing:.16em;text-transform:uppercase;font-weight:700;opacity:.8}

.gfx-stage .cr{padding:28px 40px 34px;font-size:30px;line-height:1.35;font-weight:500;letter-spacing:.01em;opacity:.92}
.pkg-arena .g-full{left:0;right:0;top:120px;bottom:120px;display:flex;flex-direction:column;justify-content:center;padding:0 200px}
.pkg-arena .g-full::before{content:"";position:absolute;inset:0;background:linear-gradient(100deg,rgba(8,9,12,.94) 0%,rgba(8,9,12,.86) 100%);clip-path:polygon(0 0,100% 4%,100% 100%,0 96%);z-index:-1}
.pkg-arena .g-full.in{animation:aF .6s cubic-bezier(.2,.8,.2,1) both}@keyframes aF{from{opacity:0;clip-path:inset(0 100% 0 0)}to{opacity:1;clip-path:inset(0 0 0 0)}}
.pkg-arena .g-full.out{animation:aFo .35s ease both}@keyframes aFo{to{opacity:0}}
.pkg-arena .fs-head{display:flex;align-items:baseline;justify-content:space-between;margin-bottom:26px;border-bottom:6px solid var(--acc);padding-bottom:10px}
.pkg-arena .fs-title{font-size:78px;font-weight:800;font-style:italic;text-transform:uppercase;line-height:1}
.pkg-arena .fs-kicker{font-size:26px;font-weight:700;letter-spacing:.2em;color:var(--acc);text-transform:uppercase}

.pkg-arena .g-tick{left:0;right:0;bottom:0;height:48px;background:#0c0e12;display:flex;align-items:center}
.pkg-arena .tk-label{height:100%;display:flex;align-items:center;padding:0 34px 0 26px;background:var(--acc);font-size:26px;font-weight:800;font-style:italic;letter-spacing:.04em;clip-path:polygon(0 0,100% 0,calc(100% - 18px) 100%,0 100%)}
.pkg-arena .g-rbug{right:80px;top:56px;background:var(--acc);padding:8px 40px;font-size:40px;font-weight:800;font-style:italic;letter-spacing:.1em;clip-path:polygon(16px 0,100% 0,calc(100% - 16px) 100%,0 100%)}

/* ---------- CLEAN ---------- */
.pkg-clean{font-family:"Sora","Barlow",sans-serif;color:#0e131b;--acc:#2b7cff}
.pkg-clean .g-sb{left:64px;top:52px;display:grid;grid-template-columns:auto auto;grid-template-areas:"away meta" "home meta";background:rgba(250,251,253,.92);border-radius:16px;padding:8px;box-shadow:0 14px 40px rgba(0,0,0,.25)}
.pkg-clean .sb-row{display:flex;align-items:center;gap:12px;height:50px;padding:0 14px 0 8px}
.pkg-clean .sb-row.away{grid-area:away}.pkg-clean .sb-row.home{grid-area:home}
.pkg-clean .sb-chip{width:16px;height:16px;border-radius:50%;background:var(--c);box-shadow:inset 0 0 0 2px rgba(0,0,0,.08)}
.pkg-clean .sb-code{font-size:26px;font-weight:700;width:86px;letter-spacing:.01em}
.pkg-clean .sb-rec{font-size:15px;color:#6b7686;width:50px;font-weight:500}
.pkg-clean .sb-pts{font-size:32px;font-weight:700;width:58px;text-align:right}
.pkg-clean .sb-tags{display:flex;flex-direction:column;align-items:flex-start;gap:2px;width:64px}
.pkg-clean .sb-tos{display:flex;gap:2px}.pkg-clean .sb-tos i{width:11px;height:3px;border-radius:2px;background:#dfe4ea}.pkg-clean .sb-tos i.on{background:#0e131b}
.pkg-clean .sb-fouls{display:flex;gap:3px}.pkg-clean .sb-fouls i{width:8px;height:8px;border-radius:50%;background:#dfe4ea}.pkg-clean .sb-fouls i.on{background:var(--acc)}
.pkg-clean .sb-bonus{font-size:11px;font-weight:700;letter-spacing:.08em;color:var(--acc);visibility:hidden}.pkg-clean .sb-bonus.on{visibility:visible}
.pkg-clean .sb-poss{width:7px;height:7px;border-radius:50%;background:#0e131b;opacity:0}.pkg-clean .sb-poss.on{opacity:1}
.pkg-clean .sb-meta{grid-area:meta;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:132px;background:#0e131b;color:#fff;border-radius:11px;margin-left:6px}
.pkg-clean .sb-per{font-size:15px;font-weight:600;letter-spacing:.1em;color:#9fb2cc}
.pkg-clean .sb-clk{font-size:32px;font-weight:700}
.pkg-clean .sb-flag{position:absolute;left:8px;right:8px;bottom:-40px;height:32px;border-radius:9px;background:var(--acc);color:#fff;font-size:16px;font-weight:700;letter-spacing:.14em;display:none;align-items:center;justify-content:center}
.pkg-clean .sb-flag.on{display:flex}

.pkg-clean .g-l3{left:50%;bottom:84px;transform:translateX(-50%);display:flex;align-items:center;gap:22px;background:rgba(250,251,253,.94);border-radius:22px;padding:16px 30px 16px 16px;box-shadow:0 14px 40px rgba(0,0,0,.25)}
.pkg-clean .g-l3.in{animation:cL3 .5s cubic-bezier(.2,.8,.2,1) both}@keyframes cL3{from{opacity:0;transform:translate(-50%,20px) scale(.97)}to{opacity:1;transform:translateX(-50%)}}
.pkg-clean .g-l3.out{animation:cL3o .35s ease both}@keyframes cL3o{to{opacity:0;transform:translate(-50%,12px)}}
.pkg-clean .l3-badge{width:96px;height:96px;border-radius:16px;background:var(--c);color:var(--ci);display:flex;flex-direction:column;align-items:center;justify-content:center}
.pkg-clean .l3-num{font-size:44px;font-weight:700;line-height:1}
.pkg-clean .l3-code{font-size:14px;font-weight:700;letter-spacing:.12em;opacity:.85}
.pkg-clean .l3-main{display:flex;flex-direction:column}
.pkg-clean .l3-name{font-size:40px;font-weight:400;white-space:nowrap;letter-spacing:-.01em}
.pkg-clean .l3-name b{font-weight:700}
.pkg-clean .l3-sub{font-size:19px;color:#5d6878;margin-top:4px;white-space:nowrap}
.pkg-clean .l3-stat{display:flex;gap:6px;margin-left:12px;padding-left:24px;border-left:1px solid #dfe4ea}
.pkg-clean .l3-stat div{display:flex;flex-direction:column;align-items:center;padding:0 12px}
.pkg-clean .l3-stat b{font-size:40px;font-weight:700;line-height:1.05}.pkg-clean .l3-stat span{font-size:13px;color:#6b7686;letter-spacing:.12em;font-weight:600}
.pkg-clean .l3-duo{display:flex;gap:40px;padding-left:10px}
.pkg-clean .l3-role{font-size:14px;letter-spacing:.14em;text-transform:uppercase;color:var(--acc);font-weight:700}

.pkg-clean .g-full{left:50%;top:50%;width:1280px;transform:translate(-50%,-50%);background:rgba(250,251,253,.95);border-radius:28px;padding:36px 46px 40px;box-shadow:0 30px 80px rgba(0,0,0,.35)}
.pkg-clean .g-full.in{animation:cF .5s cubic-bezier(.2,.8,.2,1) both}@keyframes cF{from{opacity:0;transform:translate(-50%,-48%) scale(.98)}to{opacity:1;transform:translate(-50%,-50%)}}
.pkg-clean .g-full.out{animation:cFo .35s ease both}@keyframes cFo{to{opacity:0;transform:translate(-50%,-49%)}}
.pkg-clean .fs-head{display:flex;align-items:baseline;justify-content:space-between;margin-bottom:24px}
.pkg-clean .fs-title{font-size:46px;font-weight:700;letter-spacing:-.01em}
.pkg-clean .fs-kicker{font-size:17px;letter-spacing:.14em;color:var(--acc);text-transform:uppercase;font-weight:700}
.pkg-clean .g-tick{left:64px;right:64px;bottom:28px;height:48px;border-radius:14px;background:rgba(250,251,253,.94);display:flex;align-items:center;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.2)}
.pkg-clean .tk-label{height:100%;display:flex;align-items:center;padding:0 22px;background:#0e131b;color:#fff;font-size:16px;font-weight:700;letter-spacing:.12em}
.pkg-clean .g-rbug{left:64px;top:52px;background:#0e131b;color:#fff;border-radius:12px;padding:10px 20px;font-size:20px;font-weight:700;letter-spacing:.16em;display:flex;align-items:center;gap:10px}
.pkg-clean .g-rbug::before{content:"";width:10px;height:10px;border-radius:50%;background:var(--acc)}

/* ---------- shared body pieces ---------- */
.gfx-stage .tk-track{flex:1;overflow:hidden;height:100%;position:relative}
.gfx-stage .tk-run{position:absolute;top:0;bottom:0;display:flex;align-items:center;white-space:nowrap;gap:56px;padding-left:40px;font-size:26px;font-weight:600}
.pkg-clean .tk-run{font-size:18px}
.gfx-stage .tk-item b{font-weight:800;margin:0 6px}.gfx-stage .tk-item em{font-style:normal;opacity:.6;margin-left:10px;font-size:.8em;letter-spacing:.06em}
.gfx-stage .lu{display:grid;grid-template-columns:1fr 1fr;gap:0}
.gfx-stage .lu-col{padding:24px 40px 34px}
.pkg-arena .lu-col{padding:0 30px}
.pkg-clean .lu-col{padding:0 16px}
.gfx-stage .lu-team{display:flex;align-items:center;gap:16px;height:70px;padding:0 20px;background:var(--c);color:var(--ci);font-size:36px;font-weight:700;margin-bottom:10px;text-transform:uppercase}
.pkg-clean .lu-team{border-radius:14px;font-size:26px;height:58px}
.pkg-arena .lu-team{font-style:italic;font-size:44px;clip-path:polygon(0 0,100% 0,calc(100% - 20px) 100%,0 100%)}
.gfx-stage .lu-team small{font-size:.6em;opacity:.8;margin-left:auto;font-weight:600}
.gfx-stage .lu-p{display:grid;grid-template-columns:70px 1fr auto;align-items:center;height:64px;border-bottom:1px solid rgba(255,255,255,.08);padding:0 10px;gap:12px}
.pkg-clean .lu-p{border-color:#e4e8ee;height:56px}
.gfx-stage .lu-n{font-size:36px;font-weight:700;color:var(--acc)}
.gfx-stage .lu-nm{font-size:34px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pkg-clean .lu-nm{font-size:24px}.pkg-clean .lu-n{font-size:26px}
.gfx-stage .lu-nm b{font-weight:700;text-transform:uppercase}
.gfx-stage .lu-meta{font-family:"Barlow",sans-serif;font-size:22px;opacity:.65;white-space:nowrap}
.pkg-clean .lu-meta{font-family:inherit;font-size:16px}
.gfx-stage .lu.many .lu-team{height:58px;font-size:32px;margin-bottom:6px}.pkg-arena .lu.many .lu-team{font-size:36px}
.gfx-stage .lu.many .lu-p{height:48px}.pkg-clean .lu.many .lu-p{height:44px}
.gfx-stage .lu.many .lu-n{font-size:28px}.gfx-stage .lu.many .lu-nm{font-size:28px}.gfx-stage .lu.many .lu-meta{font-size:18px}
.pkg-clean .lu.many .lu-nm{font-size:21px}.pkg-clean .lu.many .lu-n{font-size:22px}.pkg-clean .lu.many .lu-meta{font-size:14px}
.gfx-stage .lu.many .lu-col{padding-top:12px;padding-bottom:18px}
.pkg-arena .g-full:has(.lu.many){top:40px;bottom:120px}.pkg-arena .g-full:has(.lu.many) .fs-head{margin-bottom:14px}
.gfx-stage .tt{padding:20px 60px 40px}
.pkg-arena .tt,.pkg-clean .tt{padding:0}
.gfx-stage .tt-teams{display:grid;grid-template-columns:1fr 1fr;gap:0 40px;margin-bottom:18px}
.gfx-stage .tt-team{height:64px;display:flex;align-items:center;padding:0 22px;font-size:36px;font-weight:700;background:var(--c);color:var(--ci);text-transform:uppercase}
.gfx-stage .tt-team.home{justify-content:flex-end}
.pkg-clean .tt-team{border-radius:14px;font-size:26px;height:54px}
.gfx-stage .tt-row{display:grid;grid-template-columns:120px 1fr 260px 1fr 120px;align-items:center;height:62px;gap:14px}
.pkg-clean .tt-row{height:54px}
.gfx-stage .tt-v{font-size:40px;font-weight:700;text-align:center}
.pkg-clean .tt-v{font-size:28px}
.gfx-stage .tt-l{text-align:center;font-family:"Barlow",sans-serif;font-size:22px;letter-spacing:.14em;text-transform:uppercase;opacity:.75;font-weight:600}
.pkg-clean .tt-l{font-family:inherit;font-size:15px}
.gfx-stage .tt-bar{height:16px;background:rgba(255,255,255,.1);position:relative;overflow:hidden}
.pkg-clean .tt-bar{background:#e8ecf1;border-radius:8px}
.gfx-stage .tt-bar i{position:absolute;top:0;bottom:0;background:var(--c)}
.gfx-stage .tt-bar.a i{right:0}.gfx-stage .tt-bar.h i{left:0}
.gfx-stage .st{padding:14px 50px 36px}
.pkg-arena .st,.pkg-clean .st{padding:0}
.gfx-stage .st-r{display:grid;grid-template-columns:70px 56px 1fr 150px 150px;align-items:center;height:56px;font-size:32px;border-bottom:1px solid rgba(255,255,255,.07);padding:0 14px}
.pkg-clean .st-r{font-size:22px;height:46px;border-color:#e8ecf1}
.gfx-stage .st-r.hd{font-family:"Barlow",sans-serif;font-size:18px;letter-spacing:.16em;opacity:.6;height:40px;font-weight:600}
.pkg-clean .st-r.hd{font-family:inherit;font-size:13px}
.gfx-stage .st-r.hi{background:color-mix(in srgb,var(--acc) 22%,transparent)}
.gfx-stage .st-r .rk{opacity:.6}.gfx-stage .st-r .dot{width:12px;height:12px;border-radius:50%;background:var(--c)}
.gfx-stage .st-r .c{text-align:center}
.gfx-stage .st-note{font-family:"Barlow",sans-serif;font-size:18px;opacity:.55;margin-top:14px;padding:0 14px}
.pkg-clean .st-note{font-family:inherit;font-size:14px}
.gfx-stage .bb{display:flex;flex-direction:column;align-items:center;padding:30px 60px 46px;gap:26px}
.pkg-arena .bb,.pkg-clean .bb{padding:10px 0 0}
.gfx-stage .bb-score{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:40px;width:100%}
.gfx-stage .bb-t{display:flex;align-items:center;gap:22px;font-size:46px;font-weight:700;text-transform:uppercase}
.gfx-stage .bb-t.home{flex-direction:row-reverse}
.pkg-clean .bb-t{font-size:32px}
.gfx-stage .bb-chip{width:22px;height:84px;background:var(--c)}
.pkg-clean .bb-chip{border-radius:8px;height:64px}
.gfx-stage .bb-pts{font-size:120px;font-weight:800;line-height:1}
.pkg-clean .bb-pts{font-size:84px}
.gfx-stage .bb-mid{font-size:30px;letter-spacing:.2em;color:var(--acc);font-weight:700;text-align:center}
.gfx-stage .bb-lead{display:grid;grid-template-columns:1fr 1fr;width:100%;gap:40px}
.gfx-stage .bb-lc{border-top:4px solid var(--c);padding-top:14px}
.gfx-stage .bb-ll{font-family:"Barlow",sans-serif;font-size:18px;letter-spacing:.16em;opacity:.6;font-weight:600;text-transform:uppercase}
.pkg-clean .bb-ll{font-family:inherit;font-size:13px}
.gfx-stage .bb-lv{font-size:36px;font-weight:600;margin-top:6px}.pkg-clean .bb-lv{font-size:24px}
.gfx-stage .bb-lv b{font-weight:800}
.gfx-stage .bb-next{font-family:"Barlow",sans-serif;font-size:22px;opacity:.7;letter-spacing:.08em}
.pkg-clean .bb-next{font-family:inherit;font-size:16px}
.gfx-stage .g-full.board{}
/* logo plates */
.gfx-stage .lgp{--s:64px;display:inline-flex;align-items:center;justify-content:center;flex:none;width:var(--s);height:var(--s);border-radius:50%;background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.25);overflow:hidden}
.gfx-stage .lgp img{width:80%;height:80%;object-fit:contain;display:block}
.gfx-stage .lgp.nol{background:var(--c);color:var(--ci);box-shadow:inset 0 0 0 3px rgba(255,255,255,.35)}
.gfx-stage .lgp.nol b{font-size:calc(var(--s) * .3);font-weight:800;letter-spacing:.02em}
.gfx-stage .lg-40{--s:40px}.gfx-stage .lg-48{--s:48px}.gfx-stage .lg-56{--s:56px}.gfx-stage .lg-96{--s:96px}.gfx-stage .lg-160{--s:168px;margin-bottom:8px}
.pkg-clean .lgp{box-shadow:0 0 0 1px rgba(0,0,0,.08)}
/* Arena: logos as cut-outs, bigger, no white disc */
.pkg-arena .lgp:not(.nol){background:none;box-shadow:none;border-radius:0;overflow:visible;width:calc(var(--s) * 1.3);height:calc(var(--s) * 1.3)}
.pkg-arena .lgp:not(.nol) img{width:100%;height:100%}
.pkg-arena .lgp img.edge-soft{filter:drop-shadow(0 2px 4px rgba(0,0,0,.35))}
.pkg-arena .lgp img.edge-shade{filter:drop-shadow(0 0 2px rgba(0,0,0,.9)) drop-shadow(0 3px 8px rgba(0,0,0,.6))}
.pkg-arena .lgp img.edge-glow{filter:drop-shadow(0 0 2px rgba(255,255,255,.95)) drop-shadow(0 0 9px rgba(255,255,255,.55))}
.gfx-stage .sb-lg{--s:48px}
.pkg-standard .sb-row{padding-left:0}.pkg-standard .sb-row .sb-lg{margin-left:-2px}.pkg-standard .sb-code{width:104px}
.pkg-arena .sb-lg{--s:60px}
.pkg-clean .sb-lg{--s:36px}.pkg-clean .sb-row .sb-chip{display:none}
.gfx-stage .l3-lg{--s:96px}
.pkg-clean .l3-lg{--s:80px}
.gfx-stage .l3-badge.pl{gap:6px}.gfx-stage .l3-sm{--s:52px}
.pkg-standard .l3-badge.pl .l3-num{font-size:52px}
.pkg-arena .l3-badge.pl .l3-num{font-size:58px}
.pkg-clean .l3-badge.pl{width:auto;padding:0 12px;flex-direction:row;gap:10px}.pkg-clean .l3-sm{--s:56px}
.gfx-stage .lu-team .lgp,.gfx-stage .tt-team .lgp{margin:0 14px 0 -6px}
.gfx-stage .tt-team.home .lgp{margin:0 -6px 0 14px}
.gfx-stage .cu-g{display:flex;align-items:center;gap:10px}.gfx-stage .cu-g .lgp+.lgp{margin-left:-14px}.gfx-stage .cu-g .lgp:last-of-type{margin-right:8px}
.gfx-stage .st-r .lgp{justify-self:center}
.pkg-clean .st-r .lg-40{--s:32px}
.gfx-stage .fp-side .lgp{margin-bottom:6px}
/* lists, duels, scores */
.gfx-stage .ls{display:flex;align-items:center;gap:40px;padding:26px 60px 44px}
.pkg-arena .ls,.pkg-clean .ls{padding:10px 0}
.gfx-stage .ls-rows{flex:1;display:flex;flex-direction:column}
.gfx-stage .ls-r{display:grid;grid-template-columns:300px 1fr;align-items:center;height:68px;border-bottom:1px solid rgba(255,255,255,.08);font-size:36px}
.pkg-clean .ls-r{border-color:#e8ecf1;font-size:26px;height:54px;grid-template-columns:230px 1fr}
.gfx-stage .ls-k{font-family:"Barlow",sans-serif;font-size:.6em;letter-spacing:.16em;text-transform:uppercase;opacity:.65;font-weight:600}
.gfx-stage .ls-v{font-weight:700}
.gfx-stage .du{padding:20px 60px 40px}.pkg-arena .du,.pkg-clean .du{padding:0}
.gfx-stage .du-h{display:grid;grid-template-columns:1fr 220px 1fr;gap:20px;margin-bottom:14px}
.gfx-stage .du-t{display:flex;align-items:center;gap:14px;height:64px;padding:0 16px;background:var(--c);color:var(--ci);font-size:32px;font-weight:700;text-transform:uppercase}
.gfx-stage .du-t.h{justify-content:flex-end}.pkg-clean .du-t{border-radius:14px;font-size:24px;height:54px}
.gfx-stage .du-r{display:grid;grid-template-columns:1fr 220px 1fr;gap:20px;align-items:center;height:70px;border-bottom:1px solid rgba(255,255,255,.08);font-size:36px}
.pkg-clean .du-r{border-color:#e8ecf1;font-size:26px;height:56px}
.gfx-stage .du-v{font-weight:700}.gfx-stage .du-v.h{text-align:right}
.gfx-stage .du-k{text-align:center;font-family:"Barlow",sans-serif;font-size:.55em;letter-spacing:.16em;text-transform:uppercase;opacity:.65;font-weight:600}
/* watermark */
.gfx-stage .g-wm{right:64px;top:52px;width:250px;opacity:.82}.gfx-stage .g-wm img{width:100%;display:block;filter:drop-shadow(0 2px 6px rgba(0,0,0,.6))}
.pkg-arena .g-wm:not([data-pos]){left:80px;right:auto}
/* big score */
.gfx-stage .g-big{left:50%;bottom:60px;transform:translateX(-50%);display:flex;align-items:stretch;height:132px;box-shadow:0 16px 50px rgba(0,0,0,.5)}
.gfx-stage .g-big.in{animation:aSbIn .6s cubic-bezier(.2,.8,.2,1) both}
.gfx-stage .bs-t{display:flex;align-items:center;gap:20px;padding:0 28px;background:var(--c);color:var(--ci);min-width:560px}
.gfx-stage .bs-t.home{flex-direction:row-reverse}
.gfx-stage .bs-n{flex:1;font-size:44px;font-weight:800;text-transform:uppercase;white-space:nowrap}
.gfx-stage .bs-t.home .bs-n{text-align:right}
.gfx-stage .bs-p{font-size:92px;font-weight:800;line-height:1}
.gfx-stage .bs-m{display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:200px;background:#0c0e12;color:#fff}
.gfx-stage .bs-per{font-size:26px;font-weight:700;letter-spacing:.14em;color:var(--acc)}.gfx-stage .bs-clk{font-size:52px;font-weight:800}
.pkg-clean .bs-t:first-child{border-radius:22px 0 0 22px}.pkg-clean .bs-t.home{border-radius:0 22px 22px 0}
/* wipe centre */
.gfx-stage .sg-c{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;gap:22px;opacity:0;z-index:2;font-size:64px;font-weight:800;text-transform:uppercase;color:#fff;text-shadow:0 4px 18px rgba(0,0,0,.4);white-space:nowrap}
/* replay burn corner */
.gfx-stage .g-rbug.pos-tr{left:auto;right:72px}
.gfx-stage .g-rbug.own{left:0!important;top:0!important;right:auto!important;width:1920px;height:1080px;background:none!important;border:0!important;padding:0!important;clip-path:none!important;transform:none!important}.gfx-stage .g-rbug.own::before{display:none}
.gfx-stage .g-sting.own>i,.gfx-stage .g-sting.own>.sg-c{display:none}.gfx-stage .g-sting .sg-img{display:none}.gfx-stage .g-sting.own .sg-img{display:block;position:absolute;left:0;top:0;width:100%;height:100%}
.gfx-stage .g-rbug.img{background:none!important;border:0!important;padding:0!important;clip-path:none!important}.gfx-stage .g-rbug.img::before{display:none}.gfx-stage .g-rbug.img img{width:240px;display:block;filter:drop-shadow(0 2px 6px rgba(0,0,0,.6))}
.gfx-stage .g-wm[data-pos=tl]{left:64px;right:auto}.gfx-stage .g-wm[data-pos=bl]{left:64px;right:auto;top:auto;bottom:52px}.gfx-stage .g-wm[data-pos=br]{top:auto;bottom:52px}
.gfx-stage .g-wm.own[data-pos][data-size]{left:0;top:0;right:auto;bottom:auto;width:1920px;height:1080px;opacity:1}.gfx-stage .g-wm.own img{width:auto;filter:none}
.gfx-stage .g-wm[data-size=s]{width:160px}.gfx-stage .g-wm[data-size=l]{width:380px}
.pkg-arena .g-rbug:not(.pos-tr){right:auto;left:80px}
/* starting five scorebug takeover */
.gfx-stage .g-take{min-width:420px;overflow:hidden}
.pkg-standard .g-take{left:72px;bottom:200px;background:#11151c;border-radius:6px 6px 0 0;box-shadow:0 10px 30px rgba(0,0,0,.45)}
.pkg-arena .g-take{left:50%;bottom:146px;transform:translateX(-50%);background:#0c0e12;min-width:620px}
.pkg-arena .g-take.in{animation:aSbIn .5s cubic-bezier(.2,.8,.2,1) both}
.pkg-clean .g-take{left:64px;top:190px;background:rgba(250,251,253,.95);border-radius:16px;padding-bottom:6px}
.gfx-stage .tk-h{display:flex;align-items:center;gap:16px;padding:10px 20px;background:var(--c);color:var(--ci)}
.gfx-stage .tk-h b{font-size:30px;font-weight:700;text-transform:uppercase}
.gfx-stage .tk-h span:not(.lgp){margin-left:auto;font-size:18px;letter-spacing:.14em;text-transform:uppercase;font-weight:600;opacity:.85}
.pkg-clean .tk-h b{font-size:22px}.pkg-clean .tk-h span{font-size:13px}
.gfx-stage .tk-p{display:grid;grid-template-columns:56px 1fr 60px;align-items:center;height:44px;padding:0 20px;border-bottom:1px solid rgba(255,255,255,.07);font-size:28px}
.pkg-clean .tk-p{border-color:#e8ecf1;font-size:20px;height:38px}
.gfx-stage .tk-n{font-weight:800;color:var(--acc)}
.gfx-stage .tk-nm{font-weight:600;text-transform:uppercase}
.gfx-stage .tk-pos{text-align:right;opacity:.6;font-size:.75em}
/* title card */
.gfx-stage .tcard{display:flex;flex-direction:column;align-items:center;gap:22px;padding:46px 50px 54px}
.pkg-arena .tcard,.pkg-clean .tcard{padding:20px 0}
.gfx-stage .tc-ev{font-family:"Barlow",sans-serif;font-size:24px;letter-spacing:.24em;text-transform:uppercase;color:var(--acc);font-weight:700}
.pkg-clean .tc-ev{font-family:inherit;font-size:17px}
.gfx-stage .tc-row{display:grid;grid-template-columns:1fr auto 1fr;gap:30px;align-items:stretch;width:100%}
.gfx-stage .tc-t{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;padding:28px 20px;background:var(--c);color:var(--ci)}
.pkg-clean .tc-t{border-radius:20px}
.pkg-arena .tc-t.away{clip-path:polygon(0 0,100% 0,calc(100% - 30px) 100%,0 100%)}.pkg-arena .tc-t.home{clip-path:polygon(30px 0,100% 0,100% 100%,0 100%)}
.gfx-stage .tc-code{font-size:110px;font-weight:800;line-height:.9;letter-spacing:.02em}
.pkg-arena .tc-code{font-style:italic;font-size:130px}
.pkg-clean .tc-code{font-size:84px}
.gfx-stage .tc-name{font-size:34px;font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.pkg-clean .tc-name{font-size:24px}
.gfx-stage .tc-rec{font-family:"Barlow",sans-serif;font-size:20px;opacity:.8}
.pkg-clean .tc-rec{font-family:inherit;font-size:15px}
.gfx-stage .tc-at{align-self:center;font-size:44px;font-weight:600;opacity:.6;text-transform:uppercase}
.gfx-stage .tc-when{font-size:40px;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.pkg-clean .tc-when{font-size:28px}
.gfx-stage .tc-where{font-family:"Barlow",sans-serif;font-size:24px;opacity:.75}
.pkg-clean .tc-where{font-family:inherit;font-size:18px}
/* featured player */
.gfx-stage .fp{display:grid;grid-template-columns:330px 1fr;min-height:420px}
.gfx-stage .fp-side{background:var(--c);color:var(--ci);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:30px}
.pkg-clean .fp-side{border-radius:20px}
.pkg-arena .fp-side{clip-path:polygon(0 0,100% 0,calc(100% - 40px) 100%,0 100%)}
.gfx-stage .fp-num{font-size:210px;font-weight:800;line-height:.85}
.pkg-arena .fp-num{font-style:italic}
.pkg-clean .fp-num{font-size:150px}
.gfx-stage .fp-team{font-size:30px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;text-align:center}
.pkg-clean .fp-team{font-size:20px}
.gfx-stage .fp-main{display:flex;flex-direction:column;justify-content:center;gap:16px;padding:36px 50px}
.gfx-stage .fp-kick{font-family:"Barlow",sans-serif;font-size:22px;letter-spacing:.22em;text-transform:uppercase;color:var(--acc);font-weight:700}
.pkg-clean .fp-kick{font-family:inherit;font-size:15px}
.gfx-stage .fp-name{font-size:86px;line-height:.95;font-weight:500}
.pkg-clean .fp-name{font-size:60px;font-weight:400}
.gfx-stage .fp-name b{font-weight:800;text-transform:uppercase}
.pkg-clean .fp-name b{font-weight:700;text-transform:none}
.gfx-stage .fp-meta{font-family:"Barlow",sans-serif;font-size:26px;opacity:.75}
.pkg-clean .fp-meta{font-family:inherit;font-size:19px}
.gfx-stage .fp-stats{display:flex;gap:44px;margin-top:10px}
.gfx-stage .fp-stats div{display:flex;flex-direction:column}
.gfx-stage .fp-stats b{font-size:76px;font-weight:800;line-height:1}
.pkg-clean .fp-stats b{font-size:54px;font-weight:700}
.gfx-stage .fp-stats span{font-family:"Barlow",sans-serif;font-size:18px;letter-spacing:.16em;opacity:.6;font-weight:600}
.pkg-clean .fp-stats span{font-family:inherit;font-size:13px}
.gfx-stage .fp-note{font-family:"Barlow",sans-serif;font-size:18px;opacity:.5}
.pkg-clean .fp-note{font-family:inherit;font-size:14px}
/* coming up */
.gfx-stage .cu{padding:16px 50px 40px}
.pkg-arena .cu,.pkg-clean .cu{padding:0}
.gfx-stage .cu-r{display:grid;grid-template-columns:330px 1fr auto;gap:24px;align-items:center;height:78px;border-bottom:1px solid rgba(255,255,255,.08);font-size:34px}
.pkg-clean .cu-r{border-color:#e8ecf1;font-size:24px;height:62px;grid-template-columns:250px 1fr auto}
.gfx-stage .cu.many .cu-r{height:auto;padding:6px 0;font-size:24px;grid-template-columns:250px 1fr auto}
.gfx-stage .cu.many .lgp{display:none}
.gfx-stage .cu.two{display:grid;grid-template-columns:1fr 1fr;column-gap:40px;grid-auto-flow:column;grid-template-rows:repeat(var(--rows,10),auto)}
.gfx-stage .cu-r.now{background:var(--acc);color:#111;box-shadow:-14px 0 0 var(--acc),14px 0 0 var(--acc)}.gfx-stage .cu-r.now .cu-s,.gfx-stage .cu-r.now .cu-w{color:inherit;opacity:1}
.gfx-stage .cu.two .cu-r{font-size:20px;grid-template-columns:200px 1fr auto}
.gfx-stage .cu-w{color:var(--acc);font-weight:700;text-transform:uppercase;font-size:.8em;letter-spacing:.04em}
.gfx-stage .cu-g{font-weight:700;text-transform:uppercase}
.gfx-stage .cu-s{font-family:"Barlow",sans-serif;font-size:.6em;opacity:.6;letter-spacing:.06em}

.gfx-stage .g-sting{position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:10}
.gfx-stage .g-sting i{position:absolute;top:-10%;bottom:-10%;width:60%;will-change:transform}
`;

  let cssDone = false;
  function injectCss() { if (cssDone) return; const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st); cssDone = true; }

  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function clockText(ms) {
    ms = Math.max(0, ms);
    if (ms < 60000) return (Math.floor(ms / 100) / 10).toFixed(1);
    const s = Math.ceil(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  }
  function periodText(sb, R) {
    R = R || { periods: 2 };
    const name = p => { if (p > R.periods) { const n = p - R.periods; return n === 1 ? 'OT' : n + 'OT'; } return ['1ST', '2ND', '3RD', '4TH'][p - 1]; };
    if (sb.status === 'half') return 'HALF';
    if (sb.status === 'final') return 'FINAL';
    if (sb.status === 'break') return 'END ' + name(sb.period);
    return name(sb.period);
  }
  function sbClockMs(sb, now) { return sb.running ? sb.clock - (now - sb.at) : sb.clock; }

  /* a team logo on a white plate; teams without one get their code on their color */
  /* A cut-out logo has to stand out from whatever it sits on: a dark logo on a dark color gets a
     light glow, a light logo on a light color gets a dark shadow. The logo's brightness is measured once. */
  const LOGO_LUM = {};
  function measureLogo(src) {
    if (src in LOGO_LUM) return;
    LOGO_LUM[src] = null;
    const im = new Image();
    im.onload = () => {
      try {
        const c = document.createElement('canvas'); c.width = c.height = 32;
        const x = c.getContext('2d'); x.drawImage(im, 0, 0, 32, 32);
        const d = x.getImageData(0, 0, 32, 32).data; let sum = 0, n = 0;
        for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 128) { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; sum += 0.2126 * f(d[i]) + 0.7152 * f(d[i + 1]) + 0.0722 * f(d[i + 2]); n++; }
        LOGO_LUM[src] = n ? sum / n : null;
      } catch (e) { LOGO_LUM[src] = null; }
      document.querySelectorAll('img[data-lg]').forEach(el => { if (el.dataset.lg === src) el.className = lgEdge(src, el.dataset.bg); });
    };
    im.src = src;
  }
  function lgEdge(src, bg) {
    measureLogo(src);
    const L = LOGO_LUM[src], B = S.lum(bg || '#0c0e12');
    if (L == null) return B < 0.2 ? 'edge-glow' : 'edge-shade';   // until it's measured: whichever suits the background
    const contrast = (Math.max(L, B) + 0.05) / (Math.min(L, B) + 0.05);
    if (contrast >= 2.2) return 'edge-soft';
    return B < 0.35 ? 'edge-glow' : 'edge-shade';
  }
  function plate(t, color, cls) {
    if (t && t.logo) { const bg = /^#[0-9a-f]{6}$/i.test(color || '') ? color : '#0c0e12'; return `<span class="lgp ${cls || ''}"><img src="${esc(t.logo)}" alt="" data-lg="${esc(t.logo)}" data-bg="${bg}" class="${lgEdge(t.logo, bg)}"></span>`; }
    return `<span class="lgp nol ${cls || ''}" style="${teamVars(t, color || (t && t.color) || '#5b6474')}"><b>${esc((t && t.code) || '')}</b></span>`;
  }
  const PV_player = (sh, side, num) => (window.PV && window.PV.player) ? window.PV.player(sh, side, num) : null;
  function teamVars(t, color) { return `--c:${color};--ci:${S.inkOn(color)};--c2:${S.lum(color) < 0.12 ? '#ffffff' : color}`; }

  /* ---------- graphic builders (data in, HTML out) ---------- */
  function sbHtml(st) {
    const sh = st.show, hoops = !(sh.rules && sh.rules.field);   // soccer and field hockey have no fouls, bonus or timeouts to show
    const row = side => {
      const t = sh[side];
      return `<div class="sb-row ${side}" style="${teamVars(t, sh.colors[side])}"><i class="sb-chip"></i>${plate(t, sh.colors[side], 'sb-lg')}<b class="sb-code">${esc(t.code)}</b><span class="sb-rec">${esc(t.rec || '')}</span><span class="sb-tags"${hoops ? '' : ' style="display:none"'}><span class="sb-tos"></span><span class="sb-fouls">${'<i></i>'.repeat(5)}</span><span class="sb-bonus">BONUS</span></span><span class="sb-pts tc">0</span><span class="sb-poss"></span></div>`;
    };
    return `${row('away')}${row('home')}<div class="sb-meta"><span class="sb-per">1ST</span><span class="sb-clk tc">20:00</span></div><div class="sb-flag"></div>`;
  }
  function sbTick(el, st, now) {
    const sb = st.sb;
    for (const side of ['away', 'home']) {
      const r = el.querySelector('.sb-row.' + side); if (!r) continue;
      const pts = r.querySelector('.sb-pts'); const v = String(sb.score[side]); if (pts.textContent !== v) pts.textContent = v;
      const f = sb.fouls[side];
      r.querySelectorAll('.sb-fouls i').forEach((d, i) => d.classList.toggle('on', i < Math.min(5, f)));
      r.querySelector('.sb-bonus').classList.toggle('on', sb.bonus[side]);
      // possession only means something in football
      r.querySelector('.sb-poss').classList.toggle('on', /^FB/.test(st.show.sport || '') && sb.poss === side);
      // timeouts left, one bar each
      const tos = r.querySelector('.sb-tos'), left = Math.max(0, +(sb.timeouts || {})[side] || 0), full = Math.max(left, +(st.show.rules || {}).timeouts || 4);
      if (tos.childElementCount !== full) tos.innerHTML = '<i></i>'.repeat(full);
      tos.querySelectorAll('i').forEach((d, i) => d.classList.toggle('on', i < left));
    }
    const per = periodText(sb, st.show.rules), clk = ['half', 'final', 'break'].includes(sb.status) ? '' : clockText(sbClockMs(sb, now));
    const pe = el.querySelector('.sb-per'), ce = el.querySelector('.sb-clk');
    if (pe.textContent !== per) pe.textContent = per;
    if (ce.textContent !== clk) ce.textContent = clk;
    ce.style.display = clk ? '' : 'none';
    const fl = el.querySelector('.sb-flag'); const ft = sb.flag || '';
    if (fl.textContent !== ft) fl.textContent = ft; fl.classList.toggle('on', !!ft);
  }

  function l3Html(g, st) {
    const sh = st.show;
    if (g.kind === 'announcers') {
      return `<div class="l3-main" style="${teamVars(sh.home, sh.colors.home)}"><div class="l3-duo">${g.people.map(p => `<div><div class="l3-role">${esc(p.role)}</div><div class="l3-name">${nameHtml(p.name)}</div></div>`).join('')}</div></div>`;
    }
    if (g.kind === 'scene') {
      return `<div class="l3-badge" style="${teamVars(sh.home, sh.colors.home)}">${plate(sh.home, sh.colors.home, 'l3-lg')}</div><div class="l3-main" style="${teamVars(sh.home, sh.colors.home)}"><div class="l3-name"><b>${esc(g.title)}</b></div><div class="l3-sub">${esc(g.sub || '')}</div></div>`;
    }
    const side = g.side, t = sh[side];
    const vars = teamVars(t, sh.colors[side]);
    if (g.kind === 'coach') {
      return `<div class="l3-badge" style="${vars}">${plate(t, sh.colors[side], 'l3-lg')}</div><div class="l3-main" style="${vars}"><div class="l3-name">${nameHtml(g.name)}</div><div class="l3-sub">${esc(g.title)}</div></div>`;
    }
    if (g.kind === 'team') {
      return `<div class="l3-badge" style="${vars}">${plate(t, sh.colors[side], 'l3-lg')}</div><div class="l3-main" style="${vars}"><div class="l3-name"><b>${esc(g.title)}</b></div><div class="l3-sub">${esc(g.sub || '')}</div></div>`;
    }
    const stats = (g.stats || []).map(s => `<div><b class="tc">${esc(s[0])}</b><span>${esc(s[1])}</span></div>`).join('');
    return `<div class="l3-badge pl" style="${vars}">${plate(t, sh.colors[side], 'l3-sm')}<span class="l3-num">${esc(g.num)}</span></div><div class="l3-main" style="${vars}"><div class="l3-name">${nameHtml(g.name)}</div><div class="l3-sub">${esc(g.sub || '')}</div></div>${stats ? `<div class="l3-stat">${stats}</div>` : ''}`;
  }
  function nameHtml(n) { const parts = String(n || '').split(' '); if (parts.length < 2) return `<b>${esc(n)}</b>`; return `${esc(parts[0])} <b>${esc(parts.slice(1).join(' '))}</b>`; }

  function fullHtml(g, st) {
    const sh = st.show;
    const head = (title, kicker) => `<div class="fs-head"><div class="fs-title">${esc(g.otitle || title)}</div><div class="fs-kicker">${esc(g.okicker || kicker)}</div></div>`;
    const tv = side => teamVars(sh[side], sh.colors[side]);
    if (g.kind === 'lineups') {
      const col = side => `<div class="lu-col"><div class="lu-team" style="${tv(side)}">${plate(sh[side], sh.colors[side], 'lg-56')}${esc(sh[side].name)}<small>${esc(sh[side].rec || '')}</small></div>${g[side].map(p => `<div class="lu-p" style="${tv(side)}"><span class="lu-n tc">${esc(p[0])}</span><span class="lu-nm">${esc(p[1])} <b>${esc(p[2])}</b></span><span class="lu-meta">${esc([p[3], p[4], p[5]].filter(Boolean).join(' · '))}</span></div>`).join('')}</div>`;
      const many = Math.max(g.away.length, g.home.length) > 6;
      return head('Starting Lineups', sh.event) + `<div class="lu${many ? ' many' : ''}">${col('away')}${col('home')}</div>`;
    }
    if (g.kind === 'tape') {
      const rows = g.rows.map(r => {
        const a = r[1], h = r[2], max = Math.max(a.v, h.v, 0.0001);
        return `<div class="tt-row"><span class="tt-v tc">${esc(a.t)}</span><span class="tt-bar a" style="${tv('away')}"><i style="width:${(a.v / max) * 100}%"></i></span><span class="tt-l">${esc(r[0])}</span><span class="tt-bar h" style="${tv('home')}"><i style="width:${(h.v / max) * 100}%"></i></span><span class="tt-v tc">${esc(h.t)}</span></div>`;
      }).join('');
      return head(g.title || 'Tale of the Tape', g.kicker || 'Game stats') + `<div class="tt"><div class="tt-teams"><div class="tt-team away" style="${tv('away')}">${plate(sh.away, sh.colors.away, 'lg-48')}${esc(sh.away.name)}</div><div class="tt-team home" style="${tv('home')}">${esc(sh.home.name)}${plate(sh.home, sh.colors.home, 'lg-48')}</div></div>${rows}</div>`;
    }
    if (g.kind === 'standings') {
      const rows = g.rows.map((r, i) => {
        const hi = r[0] === sh.home.key || r[0] === sh.away.key;
        return `<div class="st-r ${hi ? 'hi' : ''}" style="--c:${esc(r[4] || '#777')}"><span class="rk tc">${i + 1}</span>${r[5] ? `<span class="lgp lg-40"><img src="${esc(r[5])}" alt=""></span>` : '<span class="dot"></span>'}<span>${esc(r[1])}</span><span class="c tc">${esc(r[2])}</span><span class="c tc">${esc(r[3])}</span></div>`;
      }).join('');
      return head(g.title || 'NEC Standings', g.sub || g.season + ' final') + `<div class="st"><div class="st-r hd"><span></span><span></span><span>TEAM</span><span class="c">NEC</span><span class="c">OVERALL</span></div>${rows}<div class="st-note">${esc(g.note || '')}</div></div>`;
    }
    if (g.kind === 'board') {
      const lead = side => { const L = g.leaders[side]; return `<div class="bb-lc" style="${tv(side)}"><div class="bb-ll">${esc(sh[side].name)} leaders</div>${L.map(l => `<div class="bb-lv">${esc(l.name)} <b class="tc">${esc(l.v)}</b></div>`).join('')}</div>`; };
      const sb = st.sb;
      return head(g.title, sh.event) + `<div class="bb"><div class="bb-score"><div class="bb-t away" style="${tv('away')}">${plate(sh.away, sh.colors.away, 'lg-96')}${esc(sh.away.name)}<span class="bb-pts tc">${sb.score.away}</span></div><div class="bb-mid">${esc(g.mid || '')}</div><div class="bb-t home" style="${tv('home')}">${plate(sh.home, sh.colors.home, 'lg-96')}${esc(sh.home.name)}<span class="bb-pts tc">${sb.score.home}</span></div></div><div class="bb-lead">${lead('away')}${lead('home')}</div>${g.next ? `<div class="bb-next">${esc(g.next)}</div>` : ''}</div>`;
    }
    if (g.kind === 'title') {
      const side = s => `<div class="tc-t ${s}" style="${tv(s)}">${sh[s].logo ? plate(sh[s], sh.colors[s], 'lg-160') : `<span class="tc-code">${esc(sh[s].code)}</span>`}<span class="tc-name">${esc(sh[s].name)}</span><span class="tc-rec">${esc(sh[s].rec ? sh[s].rec + (sh[s].conf ? ' · ' + sh[s].conf + ' NEC' : '') : sh[s].mascot || '')}</span></div>`;
      return `<div class="tcard"><div class="tc-ev">${esc(g.otitle || sh.event)}</div><div class="tc-row">${side('away')}<div class="tc-at">at</div>${side('home')}</div><div class="tc-when">${esc([g.date, g.time].filter(Boolean).join(' · '))}</div><div class="tc-where">${esc(g.okicker || [g.venue, g.where].filter(Boolean).join(' · '))}</div></div>`;
    }
    if (g.kind === 'featured') {
      const s = g.side, t = sh[s];
      return `<div class="fp" style="${tv(s)}"><div class="fp-side">${plate(t, sh.colors[s], 'lg-96')}<span class="fp-num">${esc(g.num)}</span><span class="fp-team">${esc(t.name)}</span></div><div class="fp-main"><div class="fp-kick">${esc(g.otitle || 'Featured player')}</div><div class="fp-name">${esc(g.first)} <b>${esc(g.last)}</b></div><div class="fp-meta">${esc([g.pos, g.cls, g.ht, g.home].filter(Boolean).join(' · '))}</div>${g.stats.length ? `<div class="fp-stats">${g.stats.map(x => `<div><b class="tc">${esc(x[0])}</b><span>${esc(x[1])}</span></div>`).join('')}</div>` : ''}<div class="fp-note">${esc(g.okicker || g.note)}</div></div></div>`;
    }
    if (g.kind === 'copyright') return head(`© ${g.year} ${g.owner}`, 'All rights reserved') + `<div class="cr">${esc(g.notice || '')}</div>`;
    if (g.kind === 'report') return fullHtml(Object.assign({}, g, { kind: 'list', kicker: g.sub, rows: (g.lines || []).filter(Boolean).map(l => [l, '']) }), st);
    if (g.kind === 'capsule') return fullHtml(Object.assign({}, g, { kind: 'list', kicker: g.sub, rows: (g.lines || []).map(l => { const i = l.indexOf(': '); return i > 0 ? [l.slice(0, i), l.slice(i + 2)] : [l, '']; }) }), st);
    if (g.kind === 'list') {
      const vars = g.side ? tv(g.side) : '';
      return head(g.title, g.kicker) + `<div class="ls" style="${vars}">${g.side ? `<div class="ls-lg">${plate(sh[g.side], sh.colors[g.side], 'lg-160')}</div>` : ''}<div class="ls-rows">${g.rows.map(r => `<div class="ls-r"><span class="ls-k">${esc(r[0])}</span><span class="ls-v">${esc(r[1])}</span></div>`).join('')}</div></div>`;
    }
    if (g.kind === 'duel') {
      return head(g.title, g.kicker) + `<div class="du"><div class="du-h"><span class="du-t" style="${tv('away')}">${plate(sh.away, sh.colors.away, 'lg-48')}${esc(sh.away.name)}</span><span></span><span class="du-t h" style="${tv('home')}">${esc(sh.home.name)}${plate(sh.home, sh.colors.home, 'lg-48')}</span></div>${g.rows.map(r => `<div class="du-r"><span class="du-v">${esc(r[1])}</span><span class="du-k">${esc(r[0])}</span><span class="du-v h">${esc(r[2])}</span></div>`).join('')}</div>`;
    }
    if (g.kind === 'coming') {
      // a whole season: closer rows past eight games, two columns past sixteen
      const many = g.list.length > 16 ? ' many two' : g.list.length > 8 ? ' many' : '';
      return head(g.otitle || 'Coming up', g.okicker || 'NEC Front Row') + `<div class="cu${many}" style="--rows:${Math.ceil(g.list.length / 2)}">${g.list.map(x => `<div class="cu-r${x.now ? ' now' : ''}"><span class="cu-w">${esc(x.when)}</span><span class="cu-g">${x.al ? `<span class="lgp lg-48"><img src="${esc(x.al)}" alt=""></span>` : ''}${x.hl ? `<span class="lgp lg-48"><img src="${esc(x.hl)}" alt=""></span>` : ''}${esc(x.game)}</span><span class="cu-s">${esc(x.sport)}</span></div>`).join('') || '<div class="cu-r">More games soon</div>'}</div>`;
    }
    return head(g.title || '', '');
  }

  /* a picture a look brings (a rules graphic): drawn where it sits in its 1280×720 frame */
  function picHtml(g, B) {
    const [s, i] = String(g.pic || '').split(':'), set = (B.sets || []).find(x => x.id === s), p = set && set.items.find(x => x.id === i);
    if (!p) return '';
    const k = 1920 / 1280;
    return `<img class="lpic" alt="" src="${esc(p.src)}" style="position:absolute;left:${p.x * k}px;top:${p.y * k}px;width:${p.w * k}px;height:${p.h * k}px">`;
  }
  /* the scorebug ticker in the built-in looks: the sport on top, the two teams with their scores, the game's status beside */
  // every game is a face in the same box (stacked, the box as wide as the widest); the stage fades them in turn
  function sbTickerHtml(list) {
    return `<div class="stk">${list.map(t => `<div class="tkf"><div class="stk-h">${esc(t.head)}</div><div class="stk-b"><div class="stk-t"><div><span>${esc(t.a)}</span><b class="tc">${esc(t.as)}</b></div><div><span>${esc(t.h)}</span><b class="tc">${esc(t.hs)}</b></div></div><div class="stk-s">${esc(t.st)}</div></div></div>`).join('')}</div>`;
  }
  function takeHtml(g, st) {
    const sh = st.show, s = g.side;
    return `<div class="tk-h" style="${teamVars(sh[s], sh.colors[s])}">${plate(sh[s], sh.colors[s], 'lg-48')}<b>${esc(sh[s].name)}</b><span>${esc(g.otitle || g.title || 'Starting five')}</span></div>${g.players.map(p => `<div class="tk-p"><span class="tk-n tc">${esc(p[0])}</span><span class="tk-nm">${esc(p[1])}</span><span class="tk-pos">${esc(p[2])}</span></div>`).join('')}`;
  }
  /* pictures the operator loaded for the watermark and replay burn, by id */
  window.PIVOT_MARKS = window.PIVOT_MARKS || {};
  /* where a watermark or burn picture comes from: the built-in ones, a team logo, or one the operator loaded */
  function markSrc(st, src) {
    if (!src || src === 'nfr') return 'logos/nfr.webp';
    if (src === 'league') return 'logos/nec.svg';
    if ((src === 'home' || src === 'away') && st.show[src]) return st.show[src].logo || '';
    if (/^img:/.test(src)) return window.PIVOT_MARKS[src.slice(4)] || '';
    return '';
  }
  function wmHtml(st) { const s = markSrc(st, (st.gfx.wm || {}).src); return s ? `<img src="${esc(s)}" alt="">` : ''; }
  function bigHtml(st) {
    const sh = st.show;
    const side = s => `<div class="bs-t ${s}" style="${teamVars(sh[s], sh.colors[s])}">${plate(sh[s], sh.colors[s], 'lg-96')}<span class="bs-n">${esc(sh[s].name)}</span><span class="bs-p tc">0</span></div>`;
    return `${side('away')}<div class="bs-m"><span class="bs-per"></span><span class="bs-clk tc"></span></div>${side('home')}`;
  }
  function bigTick(el, st, now) {
    const sb = st.sb, ps = el.querySelectorAll('.bs-p');
    if (ps.length === 2) { ps[0].textContent = sb.score.away; ps[1].textContent = sb.score.home; }
    const per = periodText(sb, st.show.rules), clk = ['half', 'final', 'break'].includes(sb.status) ? '' : clockText(sbClockMs(sb, now));
    const a = el.querySelector('.bs-per'), b = el.querySelector('.bs-clk');
    if (a.textContent !== per) a.textContent = per; if (b.textContent !== clk) b.textContent = clk;
  }
  /* the score ticker, drawn like NEC Front Row's full-screen ticker: the NEC tab, then each game with its
     sport, the two teams (color mark, code, score) and where the game is */
  function tickItems(g) {
    return (g.items || []).map(it => {
      if (Array.isArray(it)) return `<span class="tk-item">${esc(it[0])} <b class="tc">${esc(it[1])}</b> ${esc(it[2])} <b class="tc">${esc(it[3])}</b><em>${esc(it[4])}</em></span>`;
      const tm = (t, lead) => `<span class="tk-tm ${lead ? 'lead' : 'trail'}"><i style="background:${esc(t.col || '#5b6474')}"></i>${esc(t.c)}${t.s != null && t.s !== '' ? ' ' + esc(t.s) : ''}</span>`;
      const pre = it.a.s == null || it.a.s === '', a = +it.a.s || 0, h = +it.h.s || 0;
      return `<span class="tk-g"><span class="tk-sp">${esc(it.sp)}</span>${tm(it.a, pre || a >= h)}${tm(it.h, pre || h >= a)}<span class="tk-st${it.live ? ' live' : ''}">${esc(it.st || '')}</span></span>`;
    }).join('');
  }
  function tickHtml(g) {
    const items = tickItems(g);
    return `<div class="tk-label">NEC <small>Scores</small></div><div class="tk-track"><div class="tk-run">${items}${items}</div></div>`;
  }

  /* ---------- the stage ---------- */
  function createStage(container, opts) {
    injectCss();
    opts = opts || {};
    const wrap = document.createElement('div'); wrap.className = 'gfx-wrap';
    const stage = document.createElement('div'); stage.className = 'gfx-stage';
    wrap.appendChild(stage); container.appendChild(wrap);
    const sting = document.createElement('div'); sting.className = 'g-sting'; sting.innerHTML = '<i></i><i></i><i></i><b class="sg-c"></b>'; stage.appendChild(sting);
    const fit = () => { const w = wrap.clientWidth; if (w) stage.style.setProperty('--k', w / 1920); };
    let ro = null; try { ro = new ResizeObserver(fit); ro.observe(wrap); } catch (e) { /* older browsers */ }
    fit();
    const layers = {};   // slot -> {key, el}
    let pkg = '';

    function setLayer(slot, key, build, visible) {
      const cur = layers[slot];
      if (cur && cur.key === key) { cur.el.classList.toggle('hide', !visible); return cur.el; }
      // a graphic going off gets 0.4 seconds, or as long as it says it needs (a package's own way off)
      if (cur) { const old = cur.el, own = old.firstElementChild && +old.firstElementChild.dataset.out; old.classList.remove('in'); old.classList.add('out'); setTimeout(() => old.remove(), own > 0 ? own + 20 : 420); delete layers[slot]; }
      if (key == null) return null;
      const el = document.createElement('div'); el.className = 'lay g-' + slot + ' in';
      el.innerHTML = build();
      if (!visible) el.classList.add('hide');
      stage.insertBefore(el, sting);
      layers[slot] = { key, el };
      setTimeout(() => el.classList.remove('in'), 650);
      return el;
    }

    function update(st, now) {
      const p = PACKAGES[st.gfx.pkg] ? st.gfx.pkg : 'standard';
      const P = PACKAGES[p], B = P.build || {};
      if (p !== pkg) {
        // an added package wears its base look underneath, for anything it doesn't draw itself
        stage.className = 'gfx-stage ' + (P.added ? 'pkg-' + P.base + ' pkg-' + p : 'pkg-' + p);
        stage.style.setProperty('--acc', P.accent);
        // rebuild everything in the new look
        for (const k in layers) { layers[k].el.remove(); delete layers[k]; }
        pkg = p;
      }
      const g = window.PV && window.PV.effGfx ? window.PV.effGfx(st, st.program) : st.gfx;
      const onReplay = st.program === 'replay' && !opts.clean;
      const inBreak = st.brk;
      // a look can put its own strip down the split of a split-screen M/E (where the M/E has a vertical bar)
      // it's part of the picture: it goes the moment the picture changes, and mixes with it in a fade
      const barsOf = src => { const m = /^me:/.test(src || '') && ((st.me && st.me.list) || []).find(x => 'me:' + x.id === src); return m && B.split ? (m.bars || []).filter(b => b.o === 'v') : []; };
      const mix = st.trans && st.trans.active && st.trans.active.type === 'mix' ? st.trans.active : null;
      const u = mix ? Math.max(0, Math.min(1, (now - mix.start) / (mix.dur || 1))) : 1;
      const onB = barsOf(st.program), fromB = mix && u < 1 ? barsOf(mix.from) : [];
      const vbars = onB.length ? onB : fromB, spOp = onB.length ? (fromB.length ? 1 : u) : fromB.length ? 1 - u : 0;
      if (!vbars.length && layers.split) { layers.split.el.remove(); delete layers.split; }
      const spEl = setLayer('split', vbars.length ? 'sp' + st.show.sport + '|' + vbars.map(b => b.at).join(',') : null, () => B.split(st, vbars, HELP) || '', !opts.clean && !inBreak);
      if (spEl) {
        if (stage.firstChild !== spEl) stage.insertBefore(spEl, stage.firstChild);   // under every other graphic
        spEl.classList.remove('in'); const o = spOp.toFixed(3); if (spEl.style.opacity !== o) spEl.style.opacity = o;
      }
      // during a replay everything steps aside and only the replay burn shows
      const vis = () => !opts.clean && !inBreak && !onReplay;
      const showKey = st.show.home.key + st.show.away.key + st.show.colors.home + st.show.colors.away + st.show.sport;
      // a look whose lower thirds or full pages sit where its scorebug is can ask for the bug to step aside while they're up
      const aside = !!(B.bugAside && B.bugAside(g, st));
      const sbEl = setLayer('sb', g.scorebug ? 'sb' + showKey : null, () => (B.sb && B.sb(st, HELP)) || sbHtml(st), vis() && !g.big && !aside);
      // the watermark only shows on cameras and M/Es: never on breaks, videos, replays, black or bars
      // (and a look can ask for it to step aside while the scorebug is up)
      const wm = st.gfx.wm || {};
      // a look can bring its own watermark, used in place of the built-in one (a picture the operator picked still comes first)
      const ownWm = B.wm && (!wm.src || wm.src === 'nfr');
      const wEl = setLayer('wm', g.water ? `wm|${wm.src || 'nfr'}|${(wm.src || '').startsWith('img:') && window.PIVOT_MARKS[wm.src.slice(4)] ? 1 : 0}|${ownWm ? p : ''}` : null, () => ownWm ? B.wm(st, HELP) : wmHtml(st), !opts.clean && !inBreak && !(B.wmWithBug === false && g.scorebug && !g.big) && /^(cam\d+|me:)/.test(st.program || ''));
      if (wEl) { wEl.dataset.pos = wm.pos || 'tr'; wEl.dataset.size = wm.size || 'm'; wEl.classList.toggle('own', !!ownWm); }
      const bigEl = setLayer('big', g.big ? 'big' + showKey : null, () => (B.big && B.big(st, HELP)) || bigHtml(st), vis());
      if (bigEl) (B.bigTick || bigTick)(bigEl, st, now, HELP);
      if (sbEl) (B.sbTick || sbTick)(sbEl, st, now, HELP);
      // the scorebug ticker: one box that stays up, the picked games taking turns in it (six seconds each, a one-second
      // crossfade between them) while nothing else sits by the bug. New scores slot in without the box going again.
      const tks = g.sbTicker && g.scorebug && g.sbTickData && g.sbTickData.length ? g.sbTickData : null;
      const tkHtml = () => (B.sbTicker && B.sbTicker(tks, st, HELP)) || sbTickerHtml(tks);
      const tkEl = setLayer('sbtk', tks ? 'tk' + tks.map(x => x.id).join(',') : null, tkHtml, vis() && !g.big && !g.take && !g.lower && !g.full);
      if (tkEl) {
        const d = JSON.stringify(tks); if (tkEl.dataset.d !== d) { if (tkEl.dataset.d != null) tkEl.innerHTML = tkHtml(); tkEl.dataset.d = d; }
        const P = 6000, F = 1000, n = tks.length, t = Math.max(0, now - (g.sbTickAt || 0)) % (n * P), c = Math.floor(t / P), u = t - c * P;
        const out = n > 1 && u > P - F ? (u - (P - F)) / F : 0;
        tkEl.querySelectorAll('.tkf').forEach((f, i) => { const o = (i === c ? 1 - out : i === (c + 1) % n ? out : 0).toFixed(3); if (f.style.opacity !== o) f.style.opacity = o; });
      }
      setLayer('take', g.take ? g.take.id : null, () => (B.take && B.take(g.take, st, HELP)) || takeHtml(g.take, st), vis() && g.scorebug !== undefined);
      const l3El = setLayer('l3', g.lower ? g.lower.id : null, () => g.lower.kind === 'pic' ? picHtml(g.lower, B) : (B.l3 && B.l3(g.lower, st, HELP)) || l3Html(g.lower, st), vis());
      if (l3El) l3El.classList.toggle('pic', g.lower.kind === 'pic');
      const fullVis = !opts.clean && !onReplay && (!inBreak || (g.full && g.full.kind === 'board'));
      const fEl = setLayer('full', g.full ? g.full.id : null, () => (B.full && B.full(g.full, st, HELP)) || fullHtml(g.full, st), fullVis);
      if (fEl && B.fullTick && fEl.querySelector('[data-pkg]')) B.fullTick(fEl, g.full, st, now, HELP);
      else if (fEl && g.full.kind === 'board') {
        const pts = fEl.querySelectorAll('.bb-pts'); if (pts.length === 2) { pts[0].textContent = st.sb.score.away; pts[1].textContent = st.sb.score.home; }
      }
      const tEl = setLayer('tick', g.ticker && !(B.without || []).includes('ticker') ? 'tick' + (g.tickerData ? g.tickerData.v : '') : null, () => (B.ticker && B.ticker(g.tickerData || { items: [] }, st, HELP)) || tickHtml(g.tickerData || { items: [] }), vis());
      if (tEl) {
        const run = tEl.querySelector('.tk-run');
        // scores change while the ticker is up: new numbers slot in without starting it again
        const ij = g.tickerData ? JSON.stringify(g.tickerData.items) : '';
        if (run && tEl.dataset.items !== ij) { if (tEl.dataset.items != null) { const it = tickItems(g.tickerData); run.innerHTML = it + it; } tEl.dataset.items = ij; }
        if (run && run.scrollWidth) { const half = run.scrollWidth / 2; const x = -((now / 1000 * 90) % half); run.style.transform = `translateX(${x}px)`; }
      }
      const rp = st.rp && st.rp.playing;
      const burn = g.burn || { on: true, pos: 'tl' };
      const bimg = burn.src && burn.src !== 'text' ? markSrc(st, burn.src) : '';
      // the burn never shows the playback speed
      // a package can bring its own burn; a picture the operator picked still comes first
      const pburn = !bimg && B.burn;
      const bEl = setLayer('rbug', onReplay && rp && burn.on ? 'rb' + burn.pos + (burn.src || '') + (pburn ? p : '') : null, () => bimg ? `<img src="${esc(bimg)}" alt="">` : pburn ? B.burn(st, HELP) : 'REPLAY', !opts.clean);
      if (bEl) { bEl.classList.toggle('pos-tr', burn.pos === 'tr' && !pburn); bEl.classList.toggle('img', !!bimg); bEl.classList.toggle('own', !!pburn); }
      // a package's own upkeep each frame (lines placed once its fonts are in, and the like)
      if (B.tick) B.tick(stage, st, now, HELP);
      // stinger
      const tr = st.trans && st.trans.active;
      const bars = sting.children;
      if (tr && tr.type === 'stinger' && !opts.clean) {
        const u = (now - tr.start) / tr.dur;
        if (u >= 0 && u <= 1) {
          const own = pkgWipe(p, st, tr);
          sting.classList.toggle('own', !!own);
          if (own) drawOwn(own, u, tr.dur, tr.fadeAt ? Math.max(0, 1 - (now - tr.fadeAt) / (tr.fadeDur || 1000)) : 1); else drawSting(p, bars, u, st, tr);
          sting.style.display = '';
        } else sting.style.display = 'none';
      } else sting.style.display = 'none';
    }
    // a package's own wipe: its frames in order, the picture changing underneath at the halfway point
    function drawOwn(wp, u, dur, keep) {
      let img = sting.querySelector('.sg-img');
      if (!img) { img = document.createElement('img'); img.className = 'sg-img'; img.alt = ''; img.decoding = 'sync'; sting.appendChild(img); }
      const i = Math.min(wp.frames.length - 1, Math.max(0, Math.floor(u * wp.frames.length)));
      if (img.dataset.i !== wp.id + i) { img.src = wp.frames[i]; img.dataset.i = wp.id + i; }
      // an end stamp holds on its card to the end, then fades off the last half second
      // (or sooner, into a break: it fades to the black under it)
      const left = (1 - u) * (dur || 0), k = Math.min(keep == null ? 1 : keep, wp.cover != null && left < 500 ? Math.max(0, left) / 500 : 1), o = k < 1 ? k.toFixed(3) : '';
      if (img.style.opacity !== o) img.style.opacity = o;
    }
    function drawSting(p, bars, u, st, tr) {
      const sh = st.show, w = ((st.trans && st.trans.wipes) || []).find(x => x.id === (tr && tr.wipe)) || { kind: 'pkg' };
      let cols = [sh.colors.home, pkgOf(p).accent, p === 'clean' ? '#f5f7fa' : '#0c0e12'], center = '';
      if (w.kind === 'team' || w.kind === 'player') { const t = sh[w.side]; cols = [S.shade(sh.colors[w.side], -0.35), sh.colors[w.side], '#0c0e12'];
        center = w.kind === 'team' ? `${plate(t, sh.colors[w.side], 'lg-160')}<span>${esc(t.name)}</span>` : `${plate(t, sh.colors[w.side], 'lg-96')}<span>#${esc(t.featured || '')} ${esc((PV_player(sh, w.side, t.featured) || ['', '', ''])[2])}</span>`; }
      else if (w.kind === 'logo') { cols = ['#00205b', '#006ba3', '#0c0e12']; center = '<img src="logos/nec.svg" alt="" style="width:360px">'; }
      else if (w.kind === 'sponsor') { cols = ['#1a1f29', pkgOf(p).accent, '#0c0e12']; center = '<span>Presented by our partners</span>'; }
      // out of a replay the wipe runs back the way it came in
      const rev = !!tr && tr.from === 'replay' && tr.to !== 'replay';
      const c = bars[3];
      if (c.dataset.k !== (w.id || 'pkg')) { c.innerHTML = center; c.dataset.k = w.id || 'pkg'; }
      c.style.opacity = center && u > 0.3 && u < 0.7 ? Math.min(1, (0.2 - Math.abs(u - 0.5)) / 0.08) : 0;
      for (let i = 0; i < 3; i++) {
        const b = bars[i];
        const d = i * 0.07;
        const k = Math.max(0, Math.min(1, (u - d) / (1 - 0.14)));
        // ease in to cover, ease out to reveal
        const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        const x = (rev ? 105 - e * 210 : -105 + e * 210); // bar is wider than the frame, so it fully covers the picture at the midpoint
        b.style.background = cols[i];
        b.style.left = '-25%'; b.style.width = '150%';
        if (p === 'arena') b.style.transform = `translateX(${x}%) skewX(${rev ? 18 : -18}deg)`;
        else if (p === 'clean') { b.style.transform = `translateX(${x}%)`; b.style.borderRadius = rev ? '600px 0 0 600px' : '0 600px 600px 0'; }
        else b.style.transform = `translateX(${x}%)`;
      }
    }
    function destroy() { if (ro) ro.disconnect(); wrap.remove(); }
    return { update, destroy, el: wrap };
  }

  /* A graphics package added on one Mac: its own look, and its own scorebug and boards where it has them.
     It names the builders it replaces; everything else is drawn as Pivot Standard draws it. */
  const pkgCss = {};
  function addPackage(def) {
    if (!def || !/^[a-z][a-z0-9]{1,23}$/.test(def.id || '') || ['standard', 'arena', 'clean'].includes(def.id)) return false;
    PACKAGES[def.id] = { id: def.id, name: String(def.name || def.id), desc: String(def.desc || ''), accent: def.accent || '#ffb020', added: true, build: def.build || {}, base: def.base || 'standard',
      // pictures a second its animations were made at (After Effects renders, say); 0: smooth, any rate
      fps: +def.fps > 0 ? +def.fps : 0, };
    if (def.css) {
      let el = pkgCss[def.id];
      if (!el) { el = pkgCss[def.id] = document.createElement('style'); el.dataset.pkg = def.id; (document.head || document.documentElement).appendChild(el); }
      el.textContent = def.css;
    }
    try { window.dispatchEvent(new CustomEvent('pivot-packages')); } catch (e) { /* older pages */ }
    return true;
  }
  const pkgOf = id => PACKAGES[id] || PACKAGES.standard;
  /* A package's own replay wipe, if it has one: in to a replay, or back out of one. Only the look's own wipe
     (not a team, player, logo or sponsor wipe) is replaced. */
  function pkgWipe(id, st, tr) {
    if (tr && tr.stamp) return stampOf(id, tr.stamp);
    const W = (pkgOf(id).build || {}).wipes; if (!W || !tr) return null;
    const w = ((st.trans && st.trans.wipes) || []).find(x => x.id === tr.wipe);
    if (w && w.kind && w.kind !== 'pkg') return null;
    const out = tr.from === 'replay' && tr.to !== 'replay';
    return (out ? W.out : W.in) || null;
  }
  const wipeMs = (st, tr) => { const w = pkgWipe(st.gfx.pkg, st, tr); return w ? Math.round(w.frames.length / (w.fps || 60) * 1000) : 1000; };
  /* end stamps a look brings: an animation over the picture that covers the whole screen, then holds on a card.
     The picture underneath changes once it's covered. */
  const stampsOf = id => (pkgOf(id).build || {}).stamps || [];
  const stampOf = (id, sid) => stampsOf(id).find(x => x.id === sid) || null;
  // how far through the stamp the picture underneath changes: the first frame that covers everything
  const wipeAt = (st, tr) => { const w = pkgWipe(st.gfx.pkg, st, tr); return w && w.cover != null ? Math.min(0.95, (w.cover + 1) / w.frames.length) : 0.5; };
  function removePackage(id) {
    if (!PACKAGES[id] || !PACKAGES[id].added) return;
    delete PACKAGES[id];
    if (pkgCss[id]) { pkgCss[id].remove(); delete pkgCss[id]; }
    const E = window.PV && window.PV.E;
    if (E && E.st.gfx.pkg === id) E.act('gfx.pkg', 'standard');
    try { window.dispatchEvent(new CustomEvent('pivot-packages')); } catch (e) { /* older pages */ }
  }
  // what a package's own builders can use; the Standard ones are here for whatever a package leaves to them
  const HELP = { esc, plate, teamVars, clockText, periodText, sbClockMs, nameHtml: (...a) => nameHtml(...a), sim: S, sbTick: (...a) => sbTick(...a), bigTick: (...a) => bigTick(...a) };

  window.PIVOT_GFX = { PACKAGES, pkgWipe, wipeMs, wipeAt, stampsOf, stampOf, createStage, clockText, periodText, sbClockMs, teamVars, plate, addPackage, removePackage, pkgOf };
  // a package installed on this Mac may have arrived before this file did
  (window.__pivotPackages || []).forEach(addPackage);
  window.__pivotPackages = { push: addPackage };
})();
