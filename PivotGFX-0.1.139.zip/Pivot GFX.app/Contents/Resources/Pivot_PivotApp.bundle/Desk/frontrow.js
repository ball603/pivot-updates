/* Pivot run from NEC Front Row's data, for every sport: the schedule, rosters and season numbers come from
   Front Row when a game loads; the score, clock, period, starters and player stats come from the school's
   live stats feed (Front Row reads it). What a sport needs of its own lives in its sport file. */
(function () {
  const PV = window.PV, D = window.PIVOT_DATA;
  const Eng = PV.Engine.prototype, A = Eng.actions;
  const store = PV.store;

  PV.isField = sh => !!(sh && sh.rules && sh.rules.field);
  const field = st => PV.isField(st && st.show);
  const fromFR = st => !!(st && st.show && st.show.game && st.show.game.fr);
  const hoops = st => /BB$/.test((st && st.show && st.show.sport) || '');

  /* ---------- NEC Front Row ---------- */
  // where Front Row's data is served (the site's own address first; the domain as a fallback)
  const HOSTS = ['https://necfrontrow.netlify.app', 'https://necfrontrow.com'];
  let hostAt = 0;
  const getOne = url => PV.native && PV.native.http
    ? PV.native.http(url).then(r => { if (!r || r.status !== 200) throw new Error('Front Row answered ' + (r ? r.status : 'nothing')); return r.text; })
    : fetch(url, { cache: 'no-store' }).then(r => { if (!r.ok) throw new Error('Front Row answered ' + r.status); return r.text(); });
  PV.fr = {
    text(path) {
      const tryFrom = i => getOne(HOSTS[i] + path).then(j => { hostAt = i; return j; },
        e => { if (i + 1 < HOSTS.length) return tryFrom(i + 1); throw e; });
      return tryFrom(hostAt);
    },
    get(path) { return PV.fr.text(path).then(t => JSON.parse(t)); }
  };

  /* every game's score, for the ticker: Front Row's list of the games on now or just finished */
  PV.frScores = {};
  PV.frScoresPoll = function () {
    return PV.fr.text('/api/fr-stats').then(x => {
      const doc = new DOMParser().parseFromString(x, 'application/xml');
      for (const g of doc.querySelectorAll('game')) {
        const team = vh => { const t = g.querySelector(`team[vh="${vh}"]`); return t ? t.getAttribute('score') : null; };
        PV.frScores[g.getAttribute('id')] = { status: g.getAttribute('status'), period: +g.getAttribute('period') || 0, regs: +g.getAttribute('regs') || 0,
          clock: g.getAttribute('clock') || '', plabel: g.getAttribute('plabel') || '', away: team('V'), home: team('H') };
      }
      const E = PV.E;
      if (E && E.st.gfx.ticker) { E.st.gfx.tickerData = E.buildTicker(); E.changed(); }
      if (E && E.st.gfx.sbTicker) { E.st.gfx.sbTickData = E.buildSbTicker(); E.changed(); }
      return true;
    }).catch(() => false);
  };
  setInterval(() => { if (PV.E && D.liveSchedule) PV.frScoresPoll(); }, 30000);
  const pad = n => String(n).padStart(2, '0');
  const local = iso => { const d = new Date(iso); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };

  /* the schedule: Front Row's own list (with its game ids, so the live numbers can be found) replaces the copy built in */
  PV.frSchedule = function () {
    if (PV.frSchedule.p) return PV.frSchedule.p;
    PV.frTeams();
    PV.frSchedule.p = PV.fr.get('/api/data?what=schedule').then(j => {
      const list = (j && j.games || []).filter(g => g.kind === 'game' && g.home && g.away && g.sportKey && g.kickoff).map(g => {
        const [city, state] = String(g.city || '').split(/,\s*/);
        return { id: g.id, fr: g.id, at: local(g.kickoff), sport: g.sportKey, home: g.home, away: g.away, venue: g.venue || '', city: city || '', state: state || '' };
      });
      if (list.length) { D.GAMES.splice(0, D.GAMES.length, ...list.sort((a, b) => a.at.localeCompare(b.at))); D.liveSchedule = true; }
      return list.length;
    }).catch(() => { PV.frSchedule.p = null; return 0; });
    return PV.frSchedule.p;
  };

  /* ---------- every school's colors, as NEC Front Row keeps them ---------- */
  const FR_DEFAULT = '#3a4a63';   // what Front Row sends for a school with no color on file
  const hex = c => /^#[0-9a-f]{6}$/i.test(c || '') ? c : '';
  PV.frTeams = function () {
    if (PV.frTeams.p) return PV.frTeams.p;
    PV.frTeams.p = PV.fr.get('/api/data?what=games').then(j => {
      const list = (j && j.teams) || {};
      let n = 0;
      for (const [key, t] of Object.entries(list)) {
        const color = hex(t.color) && t.color.toLowerCase() !== FR_DEFAULT ? t.color : '', accent = hex(t.accent);
        const row = D.SNAP.teams[key];
        if (t.short) D.SHORT[key] = t.short;
        if (row) { if (color) row[3] = color; if (accent) row[4] = accent; }
        else D.SNAP.teams[key] = [t.name || key, t.abbr || key.slice(0, 4).toUpperCase(), t.mascot || '', color, accent, '', '', t.nec ? 'associate' : 'opponent'];
        n++;
      }
      // a game already open picks up colors it didn't have
      const E = PV.E, sh = E && E.st.show;
      if (sh && sh.home && sh.away) {
        let changed = false;
        for (const side of ['away', 'home']) {
          const t = sh[side], row = D.SNAP.teams[t.key]; if (!row) continue;
          if (t.needsColor && hex(row[3])) { t.color = row[3]; t.needsColor = false; changed = true; }
          if (!t.accent && hex(row[4])) { t.accent = row[4]; changed = true; }
          if (!t.short && D.SHORT[t.key]) { t.short = D.SHORT[t.key]; changed = true; }
        }
        if (changed) { sh.colors = window.PIVOT_SIM.teamColors(sh.home, sh.away); E.changed(); }
      }
      return n;
    }).catch(() => { PV.frTeams.p = null; return 0; });
    return PV.frTeams.p;
  };

  /* ---------- the teams: rosters and season numbers ---------- */
  const splitName = (n, ln) => { n = String(n || '').trim(); if (ln && n.endsWith(ln)) return [n.slice(0, n.length - ln.length).trim(), ln]; const i = n.lastIndexOf(' '); return i > 0 ? [n.slice(0, i), n.slice(i + 1)] : ['', n]; };
  const posShort = p => { p = String(p || '').toUpperCase(); return /GOAL|^GK$/.test(p) ? 'GK' : /DEF|^D$|BACK/.test(p) ? 'D' : /MID|^M$/.test(p) ? 'M' : /FORW|^F$|ATT|STRIK/.test(p) ? 'F' : p.slice(0, 3); };
  // basketball positions as the rest of Pivot writes them: G, F, C, G/F
  const hoopsPos = p => { p = String(p || '').toUpperCase().trim(); if (/^[GFC](\/[GFC])?$/.test(p)) return p; const parts = p.split(/[\/,-]|\s+/).map(x => /^G|GUARD/.test(x) ? 'G' : /^F|FORWARD/.test(x) ? 'F' : /^C|CENTER|CENTRE/.test(x) ? 'C' : '').filter(Boolean); return [...new Set(parts)].join('/'); };
  function teamFrom(t, side, sport) {
    if (!side) return;
    const rows = [], lines = {}, pics = {};
    for (const p of side.players || []) {
      if (!p.no) continue;
      // the headshot on the school's site: Pivot cuts the player out of it for the graphics
      if (p.pic && /^https:\/\//.test(p.pic)) pics[String(p.no)] = p.pic;
      const [first, last] = splitName(p.n, p.ln);
      rows.push([String(p.no), first, last, /BB$/.test(sport) ? hoopsPos(p.pos) : posShort(p.pos), p.cls || '', p.ht || '', p.town || '']);
      if (p.lines && p.lines.length) lines[String(p.no)] = p.lines;
    }
    if (rows.length) {
      rows.sort(D.byNum);
      t.roster = rows; t.placeholder = false;
      t.starters = /BB$/.test(sport) ? D.starters(rows) : rows.slice(0, 11).map(r => r[0]);
    }
    t.frLines = lines;
    t.pics = pics;
    if (side.record) t.rec = String(side.record).replace(/-0$/, '');
    if (side.conf) t.conf = String(side.conf).replace(/-0$/, '');
    t.tape = side.tape || [];
    // the regular season, game by game, with the result of each one played
    if (Array.isArray(side.schedule) && side.schedule.length) { t.sched = side.schedule; t.schedSeason = side.scheduleSeason || ''; }
    const top = (side.top || [])[0];
    if (top && top.no && t.roster.some(r => r[0] === String(top.no))) t.featured = String(top.no);
  }
  PV.frPlayers = function (eng) {
    const sh = eng.st.show; if (!sh.game.fr) return Promise.resolve(false);
    return PV.fr.get('/api/players?game=' + encodeURIComponent(sh.game.fr)).then(j => {
      if (!j || !j.sides) return false;
      const s = eng.st.show;
      teamFrom(s.away, j.sides.away, s.sport); teamFrom(s.home, j.sides.home, s.sport);
      // the head coach, unless the operator typed a different name
      for (const side of ['away', 'home']) {
        const c = (j.sides[side] || {}).coach, t = s[side];
        if (c && c.n && (!t.coach || t.coach === t.coachFr)) { t.coach = c.n; t.coachFr = c.n; }
      }
      // the whole league table
      if (Array.isArray(j.standings) && j.standings.length) s.frStand = { title: j.standingsTitle || '', rows: j.standings };
      eng.changed();
      return true;
    }).catch(() => false);
  };

  /* ---------- the live stats feed ---------- */
  const clockMs = c => { const m = /^(\d+):(\d{2})/.exec(String(c || '')); return m ? (+m[1] * 60 + +m[2]) * 1000 : null; };
  let lastClock = null, lastRead = 0;
  PV.frLive = function (eng) {
    const st = eng.st, sh = st.show; if (!sh.game.fr) return Promise.resolve(false);
    return PV.fr.get('/api/fr-stats?box=' + encodeURIComponent(sh.game.fr)).then(b => {
      if (!b || b.error) { st.liveErr = (b && b.error) || 'No stats yet'; eng.changed(); return false; }
      const t = Date.now();
      st.live = { at: t, status: b.status, period: b.period, plabel: b.plabel || '', clock: b.clock || '', totals: b.totals || {}, sections: b.sections || {}, scoring: b.scoring || [], lines: b.lines || null };
      st.liveErr = null;
      // the officials, as the scorers entered them, unless the operator typed different names
      const offs = (b.officials || []).filter(Boolean).slice(0, 4);
      if (offs.length) { const cur = (sh.officials || []).filter(Boolean).join('|'); if (!cur || cur === sh.officialsFr) { sh.officials = offs; sh.officialsFr = offs.join('|'); } }
      // the starting lineups, as the scorers entered them
      for (const side of ['away', 'home']) {
        const list = (b.starters || {})[side] || [];
        if (!list.length) continue;
        const team = sh[side];
        for (const p of list) {
          const no = String(p.no || '').replace(/^0+(?=\d)/, '');
          const pos = hoops(st) ? hoopsPos(p.pos) : posShort(p.pos);
          if (no && !team.roster.some(r => r[0] === no)) { const [f, l] = splitName(p.n); team.roster.push([no, f, l, pos, '', '', '']); }
          const r = team.roster.find(x => x[0] === no); if (r && !r[3] && pos) r[3] = pos;
        }
        team.roster.sort(D.byNum);
        team.starters = list.map(p => String(p.no || '').replace(/^0+(?=\d)/, '')).filter(Boolean);
        team.placeholder = false;
      }
      const sb = st.sb;
      if (sb.feed === 'stats') {
        const s = b.score || {};
        if (s.away != null) sb.score.away = +s.away || 0;
        if (s.home != null) sb.score.home = +s.home || 0;
        const ms = clockMs(b.clock);
        if (b.period) sb.period = +b.period || sb.period;
        if (b.status === 'final') { sb.status = 'final'; sb.running = false; sb.clock = 0; sb.at = t; sb.flag = 'FINAL'; }
        else if (b.status === 'half') { sb.status = 'half'; sb.running = false; sb.clock = 0; sb.at = t; }
        else if (b.status === 'live' && ms != null) {
          // the clock runs when it moved since the last read
          const moved = lastClock != null && ms !== lastClock && t - lastRead < 60000;
          const half = ms === 0 && sb.period === sh.rules.halftimeAfter;
          sb.status = half ? 'half' : ms === 0 ? 'break' : 'live';
          if (sb.status === 'live' && sb.flag && /HALF|END/.test(sb.flag)) sb.flag = '';
          sb.clock = ms; sb.at = t; sb.running = moved && ms > 0;
          lastClock = ms; lastRead = t;
        }
      }
      eng.changed();
      return true;
    }).catch(e => { st.liveErr = String(e.message || e); eng.changed(); return false; });
  };

  /* a game from Front Row: its numbers come in, and the feed keeps the scorebug up to date */
  let timer = null;
  PV.fieldStart = function (eng) {
    clearInterval(timer); timer = null; lastClock = null;
    const st = eng.st;
    if (!field(st) && !fromFR(st)) return;
    if (st.show.game.fr) {
      if (st.sb.feed === 'box') st.sb.feed = 'stats';
      st.sb.op = st.sb.feed; st.sb.boxOk = true;
      PV.frPlayers(eng).then(() => PV.frLive(eng));
      timer = setInterval(() => { if (PV.E === eng) PV.frLive(eng); else clearInterval(timer); }, 8000);
    } else if (st.sb.feed === 'box') { st.sb.feed = 'manual'; st.sb.op = 'manual'; }
  };

  /* ---------- the engine, for a field game ---------- */
  // basketball's practice game never touches a field game's score or lineups
  const oldApply = Eng.applyEvents;
  Eng.applyEvents = function (evs) { if (field(this.st) || fromFR(this.st)) return; return oldApply.call(this, evs); };
  const oldFeed = A['sb.feed'];
  A['sb.feed'] = function (f) {
    const sb = this.st.sb;
    if (f === 'stats') { sb.feed = 'stats'; sb.op = 'stats'; return; }
    if (f === 'auto') { const s = fromFR(this.st) ? 'stats' : field(this.st) ? 'manual' : 'box'; sb.feed = s; sb.op = s; return; }
    return oldFeed.call(this, f);
  };
  // replays are named by number (the practice game's plays are basketball)
  const oldMark = A['rp.mark'];
  A['rp.mark'] = function (a, b, c, t) {
    oldMark.call(this, a, b, c, t);
    if ((field(this.st) || fromFR(this.st)) && this.st.rp.clips[0]) PV.rpRename(this.st, this.st.rp.clips[0].id, `Replay ${this.st.rp.n}`);
  };


  /* a line of this game's live stats for one player, by table (Players, Goalkeeping, Box score) */
  const rowOf = (st, side, num) => {
    const secs = ((st.live || {}).sections || {})[side] || [];
    const find = title => { const s = secs.find(x => x.title === title); if (!s) return null; const r = s.rows.find(r => new RegExp('^#0*' + num + '\\b').test(String(r[0]))); return r ? { cols: s.cols, r } : null; };
    return { player: find('Players'), keeper: find('Goalkeeping'), box: find('Box score') };
  };
  PV.liveRow = rowOf;
  PV.posShort = posShort;

  /* full-screen graphics filled in from Front Row's numbers, for every sport (each sport adds its own on top) */
  const pairs = items => (items || []).filter(([k]) => k !== 'GP').slice(0, 4).map(([k, v]) => [v, k]);
  const nm = s => { const m = /^#?\d+\s+(.*)$/.exec(String(s || '')); const n = (m ? m[1] : String(s || '')).trim(); const i = n.indexOf(' '); return i > 0 ? `${n[0]}. ${n.slice(i + 1)}` : n; };
  // the player with the most of a column in this game's live stats
  PV.liveBest = function (st, side, col, unit) {
    const hoops = /BB$/.test(st.show.sport || '');
    const sec = (((st.live || {}).sections || {})[side] || []).find(x => x.title === (hoops ? 'Box score' : col === 'Saves' ? 'Goalkeeping' : 'Players'));
    if (!sec) return { name: '—', v: '' };
    const i = sec.cols.indexOf(col); if (i < 0) return { name: '—', v: '' };
    const best = sec.rows.filter(r => r[0] !== 'Team').sort((a, b) => (+b[i] || 0) - (+a[i] || 0))[0];
    return best && +best[i] > 0 ? { name: nm(best[0]), v: `${best[i]} ${unit}` } : { name: '—', v: '' };
  };
  const oldFull = Eng.buildFull0;
  Eng.buildFull0 = function (kind, opts) {
    const st = this.st, sh = st.show;
    if (!fromFR(st) && !field(st)) return oldFull.call(this, kind, opts);
    if (kind === 'standings' && sh.frStand && sh.frStand.rows.length) {
      const rows = sh.frStand.rows.map(r => {
        const t = D.byKey(r.school), col = r.school === sh.home.key ? sh.colors.home : r.school === sh.away.key ? sh.colors.away : (t && t.color) || '#6b7280';
        return [r.school, (t && t.name) || r.team, r.conf || '—', r.overall || '—', col, (t && t.logo) || ''];
      });
      return { id: 'st' + Date.now(), kind: 'standings', label: 'Standings', title: `NEC ${sh.event}`, season: '', sub: 'Conference standings', rows, note: `Entering ${PV.todayWord(sh).toLowerCase()}'s action` };
    }
    const F = oldFull.call(this, kind, opts);
    if (!F) return F;
    const cell = x => ({ v: parseFloat(x) || 0, t: x == null || x === '' ? '—' : String(x) });
    if (kind === 'featAway' || kind === 'featHome') {
      const side = kind === 'featAway' ? 'away' : 'home', line = ((sh[side].frLines || {})[String(F.num)] || [])[0];
      if (line) { F.stats = pairs(line.items); F.note = 'This season'; }
    } else if (kind === 'tapeSeason' && (sh.away.tape || []).concat(sh.home.tape || []).length) {
      const labels = [];
      // the record and four of the season's numbers (five lines in all; shutouts left out)
      for (const s of ['away', 'home']) for (const [l] of sh[s].tape || []) if (!labels.includes(l) && !/shutout/i.test(l)) labels.push(l);
      const val = (s, l) => ((sh[s].tape || []).find(x => x[0] === l) || [])[1];
      F.kicker = 'Season'; F.note = `Entering ${PV.todayWord(sh).toLowerCase()}'s action`;
      F.rows = [['Record', cell(sh.away.rec || '—'), cell(sh.home.rec || '—')]].concat(labels.slice(0, 4).map(l => [l, cell(val('away', l)), cell(val('home', l))]));
    } else if (kind === 'tape' && st.live) {
      const T = (st.live || {}).totals || {}, labels = (T.away || T.home || []).map(x => x[0]).filter(l => !/^\s/.test(l));
      const val = (s, l) => ((T[s] || []).find(x => x[0] === l) || [])[1];
      F.kicker = 'Game stats';
      F.rows = labels.slice(0, 6).map(l => [l, cell(val('away', l)), cell(val('home', l))]);
    }
    return F;
  };

  /* the ticker: the day's other games, with Front Row's scores */
  const ord = p => ['', '1st', '2nd', '3rd', '4th'][p] || (p ? 'OT' : '');
  const short = l => String(l || '').replace(/\s+(half|quarter|qtr|period)$/i, '');
  const statusOf = (g, sc) => {
    if (sc && sc.status === 'half') return { st: 'Half', live: true };
    if (sc && sc.status === 'final') { const x = sc.regs && sc.period > sc.regs ? sc.period - sc.regs : 0; return { st: x ? `Final (${x > 1 ? x : ''}OT)` : 'Final' }; }
    if (sc && sc.status === 'live') return { st: [short(sc.plabel) || ord(sc.period), sc.clock].filter(Boolean).join(' ') || 'Live', live: true };
    const d = new Date(g.at); return { st: d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) };
  };
  const oldTicker = Eng.buildTicker;
  Eng.buildTicker = function () {
    if (!D.liveSchedule) return oldTicker.call(this);   // the sample schedule keeps its sample scores
    const st = this.st, day = (st.show.game.at || '').slice(0, 10);
    const games = D.GAMES.filter(g => g.at.slice(0, 10) === day && g.id !== st.show.game.id);
    const team = (k, s) => { const t = D.byKey(k); return { c: t ? t.code : String(k).slice(0, 4).toUpperCase(), col: t && t.color ? t.color : '#5b6474', s: s == null ? '' : String(s) }; };
    const items = games.map(g => {
      const sc = PV.frScores[g.fr || g.id], pre = !sc || sc.status === 'pre';
      const s = statusOf(g, sc);
      return { sp: g.sport, a: team(g.away, pre ? null : sc.away), h: team(g.home, pre ? null : sc.home), st: s.st, live: !!s.live };
    });
    return { v: 'fr', label: 'NEC', items };
  };
  /* the scorebug ticker: today's other league games, one at a time under the scorebug (any game can be left out) */
  Eng.buildSbTicker = function () {
    const st = this.st, day = (st.show.game.at || '').slice(0, 10), off = st.show.tickOff || [];
    const name = k => { const t = D.byKey(k); return t ? (t.short || t.name) : String(k).charAt(0).toUpperCase() + String(k).slice(1); };
    return PV.tickGames(st).filter(g => !off.includes(String(g.id))).map(g => {
      const sc = PV.frScores[g.fr || g.id], pre = !sc || sc.status === 'pre' || !D.liveSchedule, s = statusOf(g, D.liveSchedule ? sc : null);
      const v = x => x == null ? '' : String(x);
      return { id: String(g.id), head: `NEC ${D.SPORTS[g.sport] || g.sport}`, a: name(g.away), h: name(g.home), as: pre ? '' : v(sc.away), hs: pre ? '' : v(sc.home), st: s.live && sc.plabel ? sc.plabel : s.st, live: !!s.live };   // the half while it's on ("2nd Half"), as ESPN shows it
    });
  };
  PV.tickGames = st => { const day = (st.show.game.at || '').slice(0, 10); return D.GAMES.filter(g => g.at.slice(0, 10) === day && g.id !== st.show.game.id).sort((a, b) => a.at.localeCompare(b.at)); };
  A['gfx.sbTicker'] = function (on) {
    const g = this.st.gfx; g.sbTicker = on == null ? !g.sbTicker : !!on;
    // it hangs off the scorebug: putting it up brings the bug up too
    if (g.sbTicker) { g.scorebug = true; g.big = false; g.sbTickData = this.buildSbTicker(); g.sbTickAt = Date.now(); if (D.liveSchedule) PV.frScoresPoll(); }
  };
  // leave a game out of the ticker, or put it back
  A['show.tickOff'] = function (id) {
    const sh = this.st.show, l = (sh.tickOff || []).slice(), i = l.indexOf(String(id));
    if (i >= 0) l.splice(i, 1); else l.push(String(id));
    sh.tickOff = l;
    if (this.st.gfx.sbTicker) this.st.gfx.sbTickData = this.buildSbTicker();
  };
  const oldPlayGfx = Eng.playGfx;
  Eng.playGfx = function (ref, t) { const r = oldPlayGfx.call(this, ref, t); if (ref === 'ticker' && D.liveSchedule) PV.frScoresPoll(); return r; };


  /* ---------- rehearsal: streaming stays locked off ---------- */
  PV.rehearsal = () => store.get('rehearsal', true) !== false;
  const oldStream = A['stream.toggle'];
  A['stream.toggle'] = function (a, b, c, t) {
    if (!this.st.stream.on && PV.rehearsal()) { if (PV.UI && PV.UI.toast) PV.UI.toast('Rehearsal mode: streaming is locked off. Settings › Streaming turns it off.'); return; }
    return oldStream.call(this, a, b, c, t);
  };
})();
