/* Pivot start screen: pick tonight's game from the NEC Front Row schedule,
   fill in anything the database doesn't know about a team, then load the show. */
(function () {
  const PV = window.PV, UI = PV.UI, D = window.PIVOT_DATA, S = window.PIVOT_SIM;
  const esc = UI.esc, $ = UI.$;
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const addDays = (s, n) => { const d = new Date(s + 'T12:00'); d.setDate(d.getDate() + n); return ymd(d); };
  let day = null, moved = false;
  /* the day the picker opens on: today's date when it has games, otherwise the next day that does */
  function gameDay() {
    const today = ymd(new Date());
    if (gamesOn(today).length) return today;
    const next = D.GAMES.map(g => g.at.slice(0, 10)).filter(d => d > today).sort()[0];
    return next || today;
  }

  /* the schedule comes from NEC Front Row as it is today; the copy built in is the fallback */
  UI.startPicker = function () {
    day = gameDay(); moved = false;
    render();
    if (PV.frSchedule && !D.liveSchedule) PV.frSchedule().then(n => { if (n && $('.games')) { if (!moved) day = gameDay(); render(); } });
  };

  function teamChip(key) {
    const t = D.byKey(key);
    const name = t ? t.name : key;
    return `<span class="tchip">${t && t.logo ? `<span class="tlogo" style="width:26px;height:26px;margin:0"><img src="${esc(t.logo)}" alt=""></span>` : `<i style="background:${esc((t && t.color) || '#5b6474')}"></i>`}${esc(name)}</span>`;
  }
  function gamesOn(d) { return D.GAMES.filter(g => g.at.slice(0, 10) === d).sort((a, b) => a.at.localeCompare(b.at)); }

  function render() {
    const list = gamesOn(day);
    const saved = PV.store.get('game', null);
    if (!day) day = gameDay();
    const label = PV.fmtDate(day + 'T12:00', { weekday: 'long', month: 'long', day: 'numeric' });
    $('#app').innerHTML = `<header class="top"><div class="brand"><span class="mark"></span>PIVOT${PV.GFX_ONLY ? '<em>GFX</em>' : ''}</div><div class="showinfo"><b>Pick your game</b><span>Schedule from NEC Front Row</span></div><span class="sp"></span><button class="btn" id="pScreens">Control screens</button></header>
    <div class="pick"><div class="inner">
      ${saved && saved.game ? `<div class="resume"><span style="flex:1;min-width:0"><b style="font:700 18px var(--cond);letter-spacing:.04em">${esc(teamName(saved.game.away))} at ${esc(teamName(saved.game.home))}</b><br><span class="hint">${esc(D.SPORTS[saved.game.sport] || '')} · ${esc(PV.fmtDate(saved.game.at, { weekday: 'short', month: 'short', day: 'numeric' }))} · ${esc(PV.fmtTime(saved.game.at))}</span></span><button class="btn" id="pFresh" title="Clears this show: cameras, scoreboard, rundown, replays. Your graphics, M/Es, sounds and settings stay.">Start a new production</button><button class="btn pri" id="pResume" title="Everything as you left it: cameras, scoreboard, rundown, replays">Pick up where you left off</button></div>` : ''}
      <div class="daynav"><button class="btn arrow" data-day="-1" aria-label="Previous day">‹</button><span class="day">${esc(label)}</span><button class="btn arrow" data-day="1" aria-label="Next day">›</button>
        ${day !== gameDay() ? '<button class="btn" data-day="today">Today</button>' : ''}<span class="sp" style="flex:1"></span></div>
      <div class="games">${list.length ? list.map(g => {
        const ok = PV.sportReady(g.sport);
        const v = D.venueFor(g);
        return `<div class="gcard ${ok ? 'ok' : 'no'}"><span class="gt tc">${esc(PV.fmtTime(g.at))}</span><span class="gm"><b>${teamChip(g.away)} <span style="color:var(--mute);font-weight:600">at</span> ${teamChip(g.home)}</b><small><span class="sportchip ${ok ? 'bb' : ''}">${esc(D.SPORTS[g.sport] || g.sport)}</span> ${esc([v.venue, [v.city, v.state].filter(Boolean).join(', ')].filter(Boolean).join(' · ') || 'Venue to be added')}</small></span>
          ${ok ? `<button class="btn pri" data-load="${g.id}">Load game</button>` : `<span class="hint" style="text-align:right">${/ih$/.test(g.sport) ? 'Hockey is next' : 'Coming later'}</span>`}</div>`;
      }).join('') : `<div class="empty">No games on the NEC Front Row schedule this day.</div>`}</div>
      <div class="row" style="justify-content:space-between"><span class="hint">${D.liveSchedule ? 'Live schedule from NEC Front Row. Basketball, soccer and field hockey are ready.' : `Schedule copy from NEC Front Row, taken ${esc(PV.fmtDate(D.SNAP_DATE + 'T12:00', { month: 'long', day: 'numeric' }))}. Basketball, soccer and field hockey are ready.`}</span><button class="btn" id="pManual">Set up a game by hand</button></div>
    </div></div>`;
    $('.pick').addEventListener('click', onClick);
    $('#pScreens').onclick = () => PV.go('screens');
    const r = $('#pResume'); if (r) r.onclick = () => loadGame(saved.game, saved.edits || {}, true);
    const f = $('#pFresh'); if (f) f.onclick = () => { PV.newProduction(); render(); };
    $('#pManual').onclick = manualForm;
  }
  function teamName(k) { const t = D.byKey(k); return t ? t.name : k; }
  function onClick(e) {
    const d = e.target.closest('[data-day]'), l = e.target.closest('[data-load]');
    if (d) { day = d.dataset.day === 'today' ? gameDay() : addDays(day, +d.dataset.day); moved = d.dataset.day !== 'today'; render(); }
    else if (l) { const g = D.GAMES.find(x => x.id === l.dataset.load); if (g) loadGame(g, {}); }
  }

  /* fill in what the database is missing, then go */
  function loadGame(game, edits, resume) {
    const saved = PV.store.get('teamEdits', {});
    edits = Object.assign({}, edits);
    for (const k of [game.home, game.away]) if (saved[k] && !edits[k]) edits[k] = saved[k];
    // a Front Row game brings its own rosters when it loads
    const need = game.fr && D.RULES[game.sport] && D.RULES[game.sport].field ? [] : [game.away, game.home].filter(k => { const t = D.team(k, game.sport, edits[k]); return t.needsColor || t.placeholder; });
    if (need.length && !resume) return teamForm(game, edits, need);
    go(game, edits, resume);
  }
  /* last step: how many cameras this show has. The desk is laid out for that number; more can be added with + later. */
  function go(game, edits, resume) {
    // picking up where you left off: straight back in, with the same cameras
    const sess = PV.store.get('session', null);
    if (resume) { const cams = sess && sess.game === game.id ? sess.cams : null;
      UI.startDirector(PV.makeShow(game, edits), PV.store.get('setup', null), cams || null, { resume: true }); return; }
    PV.newProduction();
    PV.store.set('game', { game, edits });
    // Pivot GFX has no cameras to ask about: straight to the desk
    if (PV.GFX_ONLY) { UI.startDirector(PV.makeShow(game, edits), PV.store.get('setup', null), 1); return; }
    const last = Math.max(1, Math.min(4, +PV.store.get('camCount', 4) || 4));
    $('#app').innerHTML = `<header class="top"><div class="brand"><span class="mark"></span>PIVOT${PV.GFX_ONLY ? '<em>GFX</em>' : ''}</div><div class="showinfo"><b>How many cameras?</b><span>${esc(teamName(game.away))} at ${esc(teamName(game.home))}</span></div></header>
    <div class="pick"><div class="inner" style="width:min(720px,100%)">
      <h1>How many cameras are you using?</h1>
      <p class="lead">Pivot sets up the camera row, the M/Es and replay for that many. You can add more cameras later with <b>+</b> on the camera row.</p>
      <div class="camcount">${[1, 2, 3, 4].map(n => `<button class="ccb" data-cams="${n}"><b>${n}</b><span>${n === 1 ? 'camera' : 'cameras'}</span></button>`).join('')}</div>
      <div class="row" style="justify-content:flex-start"><button class="btn" id="ccBack">Back to the schedule</button></div>
    </div></div>`;
    $('#ccBack').onclick = render;
    $('.camcount').addEventListener('click', e => {
      const b = e.target.closest('[data-cams]'); if (!b) return;
      const show = PV.makeShow(game, edits);
      UI.startDirector(show, PV.store.get('setup', null), +b.dataset.cams);
    });
  }

  function teamForm(game, edits, need) {
    const t = k => D.team(k, game.sport, edits[k]);
    $('#app').innerHTML = `<header class="top"><div class="brand"><span class="mark"></span>PIVOT${PV.GFX_ONLY ? '<em>GFX</em>' : ''}</div><div class="showinfo"><b>Team info needed</b><span>${esc(teamName(game.away))} at ${esc(teamName(game.home))}</span></div></header>
    <div class="pick"><div class="inner">
      <h1>A little more about ${need.length > 1 ? 'these teams' : 'this team'}</h1>
      <p class="lead">NEC Front Row doesn't have ${need.length > 1 ? 'everything' : 'everything'} Pivot needs yet. Fill in what you can. It's saved, so you only do this once per team.</p>
      <div class="teamform">${need.map(k => { const x = t(k); return `<div class="tf" data-team="${k}"><h3>${esc(x.name)}</h3>
        <div class="grid2" style="grid-template-columns:2fr 1fr;gap:10px"><div class="fld"><label>Name on graphics</label><input type="text" name="name" value="${esc(x.name)}"></div><div class="fld"><label>Short code</label><input type="text" name="code" value="${esc(x.code)}" maxlength="5"></div></div>
        <div class="colors"><label class="lbl">Main color</label><input type="color" name="color" value="${esc(/^#[0-9a-f]{6}$/i.test(x.color) ? x.color : '#5b6474')}"><label class="lbl">Second color</label><input type="color" name="accent" value="${esc(/^#[0-9a-f]{6}$/i.test(x.accent) ? x.accent : '#cccccc')}"></div>
        <div class="fld"><label>Head coach</label><input type="text" name="coach" value="${esc(x.coach)}"></div>
        <div class="fld"><label>Roster ${x.placeholder ? '(none on file)' : '(on file, edit if needed)'}</label><textarea name="roster" placeholder="One player per line: number, name, position&#10;3, Jordan Smith, G&#10;12, Alex Brown, F">${x.placeholder ? '' : esc(x.roster.map(r => `${r[0]}, ${r[1]} ${r[2]}, ${r[3]}`).join('\n'))}</textarea><span class="hint">Leave it empty to use numbered placeholders for now.</span></div></div>`; }).join('')}</div>
      <div class="row" style="justify-content:flex-end"><button class="btn" id="tfBack">Back to the schedule</button><button class="btn" id="tfSkip">Skip for now</button><button class="btn pri" id="tfGo">Save and load game</button></div>
    </div></div>`;
    $('#tfBack').onclick = render;
    $('#tfSkip').onclick = () => go(game, edits);
    $('#tfGo').onclick = () => {
      const saved = PV.store.get('teamEdits', {});
      document.querySelectorAll('.tf').forEach(f => {
        const k = f.dataset.team, v = n => f.querySelector(`[name=${n}]`).value.trim();
        const e = { name: v('name'), code: v('code'), color: v('color'), accent: v('accent'), coach: v('coach') };
        const roster = parseRoster(v('roster'));
        if (roster.length) e.roster = roster;
        edits[k] = Object.assign({}, edits[k] || {}, e);
        saved[k] = edits[k];
      });
      PV.store.set('teamEdits', saved);
      go(game, edits);
    };
  }
  function parseRoster(text) {
    const out = [];
    for (const line of String(text || '').split(/\n/)) {
      const m = /^\s*#?\s*(\d{1,2})\s*[,\t ]\s*([^,\t]+?)\s*(?:[,\t]\s*([A-Za-z/]{1,4}))?\s*$/.exec(line);
      if (!m) continue;
      const parts = m[2].trim().split(/\s+/);
      out.push([m[1], parts[0], parts.slice(1).join(' ') || parts[0], (m[3] || '').toUpperCase(), '', '', '']);
    }
    return out;
  }
  UI.parseRoster = parseRoster;

  function manualForm() {
    const teams = Object.keys(D.SNAP.teams).map(k => [k, D.SNAP.teams[k][0]]).sort((a, b) => a[1].localeCompare(b[1]));
    const opts = sel => teams.map(([k, n]) => `<option value="${k}" ${k === sel ? 'selected' : ''}>${esc(n)}</option>`).join('');
    $('#app').innerHTML = `<header class="top"><div class="brand"><span class="mark"></span>PIVOT${PV.GFX_ONLY ? '<em>GFX</em>' : ''}</div><div class="showinfo"><b>Set up a game by hand</b><span>For a game that isn't on the schedule</span></div></header>
    <div class="pick"><div class="inner" style="width:min(720px,100%)">
      <div class="grid2"><div class="fld"><label>Sport</label><select id="mSport"><option value="MBB">Men's Basketball</option><option value="WBB">Women's Basketball</option></select></div>
      <div class="fld"><label>Date and time</label><input type="text" id="mAt" value="${esc(day)} 19:00" placeholder="2026-11-12 19:00"></div>
      <div class="fld"><label>Away team</label><select id="mAway">${opts('wagner')}<option value="new">New team…</option></select></div>
      <div class="fld"><label>Home team</label><select id="mHome">${opts('liu')}<option value="new">New team…</option></select></div>
      <div class="fld"><label>Venue</label><input type="text" id="mVenue" placeholder="Arena name"></div>
      <div class="grid2" style="grid-template-columns:2fr 1fr;gap:10px"><div class="fld"><label>City</label><input type="text" id="mCity"></div><div class="fld"><label>State</label><input type="text" id="mState" maxlength="2"></div></div></div>
      <div class="hint">Picking "New team…" asks for its name, colors and roster on the next step.</div>
      <div class="row" style="justify-content:flex-end"><button class="btn" id="mBack">Back to the schedule</button><button class="btn pri" id="mGo">Continue</button></div>
    </div></div>`;
    $('#mBack').onclick = render;
    $('#mGo').onclick = () => {
      const at = $('#mAt').value.trim().replace(' ', 'T');
      if (!/^\d{4}-\d{2}-\d{2}T\d{1,2}:\d{2}$/.test(at)) { UI.toast('Type the date like 2026-11-12 19:00'); return; }
      let home = $('#mHome').value, away = $('#mAway').value;
      if (home === 'new') home = 'custom-home'; if (away === 'new') away = 'custom-away';
      if (home === away) { UI.toast('Pick two different teams'); return; }
      const game = { id: 'manual' + PV.uid(), at, sport: $('#mSport').value, home, away, venue: '', city: '', state: '', manual: true, manualVenue: $('#mVenue').value.trim(), manualCity: $('#mCity').value.trim(), manualState: $('#mState').value.trim().toUpperCase() };
      const edits = {};
      if (home === 'custom-home') edits[home] = { name: 'Home team', code: 'HOME' };
      if (away === 'custom-away') edits[away] = { name: 'Away team', code: 'AWAY' };
      loadGame(game, edits);
    };
  }
})();
