/* Pivot main window: drawing sources, the director desk and keyboard control. */
(function () {
  const PV = window.PV, S = window.PIVOT_SIM, G = window.PIVOT_GFX;
  const UI = PV.UI = {};
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  UI.esc = esc;
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  UI.$ = $; UI.$$ = $$;

  /* ---------- time formats ---------- */
  UI.hms = ms => { ms = Math.max(0, ms); const s = Math.floor(ms / 1000); return `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
  UI.ms = sec => { sec = Math.max(0, Math.round(sec)); return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`; };
  UI.ago = t => { const s = Math.round((Date.now() - t) / 1000); return s < 60 ? `${s}s ago` : `${Math.floor(s / 60)}m ago`; };

  UI.banner = function (msg) {
    const el = document.createElement('div');
    el.setAttribute('role', 'alert');
    el.style.cssText = 'position:fixed;left:50%;top:60px;transform:translateX(-50%);z-index:80;max-width:min(680px,calc(100% - 32px));background:#3a2a08;border:1px solid var(--brand);color:#ffe2a6;border-radius:10px;padding:10px 14px;display:flex;gap:12px;align-items:center;font-weight:600;box-shadow:0 10px 30px rgba(0,0,0,.5)';
    el.innerHTML = `<span style="flex:1">${esc(msg)}</span><button class="btn sm">Close</button>`;
    el.querySelector('button').onclick = () => el.remove();
    document.body.appendChild(el);
  };
  let toastT = 0;
  UI.toast = function (msg) {
    let el = $('.toast'); if (!el) { el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = msg; el.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { el.hidden = true; }, 2200);
  };

  /* ======================================================================
     Drawing any source into any canvas. Used by every window.
     ====================================================================== */
  const off = { c: null };
  function offscreen(w, h) { if (!off.c) off.c = document.createElement('canvas'); if (off.c.width !== w || off.c.height !== h) { off.c.width = w; off.c.height = h; } return off.c; }

  UI.drawSource = function (ctx, w, h, src, st, t, depth) {
    if (PV.native && PV.native.handles(src)) { PV.native.drawSnap(ctx, w, h, src); return; }
    const show = st.show;
    const game = PV.gameFor(show), look = PV.lookFor(show);
    if (/^cam\d+$/.test(src)) { if (S.CAMS[src]) S.drawCamera(ctx, w, h, src, PV.worldT(st, t), game, look); else blank(ctx, w, h, PV.srcShort(src)); return; }
    if (PV.isME(src)) { drawME(ctx, w, h, PV.meById(st, src.slice(3)), st, t, { depth: depth || 0 }); return; }
    if (src === 'replay') {
      const rp = st.rp.playing;
      const clips = st.rp.clips || [];
      const seg = PV.rpSeg(rp);
      if (seg) {
        const at = (s, o) => Math.min(s.tIn + Math.max(0, (t - o.start) / 1000) * o.speed, s.tOut);
        S.drawCamera(ctx, w, h, seg.cam, at(seg, rp), game, look);
        // the angle before it, mixing away
        const k = PV.mixAlpha(rp, t);
        if (k < 1 && rp.prev) { ctx.save(); ctx.globalAlpha = 1 - k; S.drawCamera(ctx, w, h, rp.prev.cam, at(rp.prev, rp.prev), game, look); ctx.restore(); }
        if (h > 200) label(ctx, w, h, `${PV.srcShort(seg.cam)} · ${rp.speed === 1 ? 'REAL TIME' : Math.round(rp.speed * 100) + '%'}`);
        return;
      }
      if (clips.length && clips[0].angles.length) {
        const c = clips[0];
        S.drawCamera(ctx, w, h, c.angles[0], PV.cut(c, c.angles[0]).tIn, game, look);
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(0, 0, w, h);
        if (h > 200) label(ctx, w, h, 'CUED · ' + c.name.toUpperCase());
        return;
      }
      blank(ctx, w, h, 'NO REPLAYS YET'); return;
    }
    if (src === 'video') {
      const lv = st.pl.last;
      const vAt = o => Math.min((o.tIn || 0) + Math.max(0, t - o.start) / 1000 * (o.speed || 1), o.tOut || S.CLIPS[o.ref].dur);
      if (lv && S.CLIPS[lv.ref]) {
        S.drawClip(ctx, w, h, lv.ref, vAt(lv), look);
        const k = PV.mixAlpha(lv, t);
        if (k < 1 && lv.prev && S.CLIPS[lv.prev.ref]) { ctx.save(); ctx.globalAlpha = 1 - k; S.drawClip(ctx, w, h, lv.prev.ref, vAt(lv.prev), look); ctx.restore(); }
        return;
      }
      blank(ctx, w, h, 'NO VIDEO'); return;
    }
    if (src === 'bars') { UI.drawBars(ctx, w, h); return; }
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
  };
  /* color bars, the same layout the Mac draws */
  UI.drawBars = function (ctx, w, h) {
    const top = ['#bfbfbf', '#bfbf00', '#00bfbf', '#00bf00', '#bf00bf', '#bf0000', '#0000bf'];
    const mid = ['#0000bf', '#131313', '#bf00bf', '#131313', '#00bfbf', '#131313', '#bfbfbf'];
    const bw = w / 7, h1 = Math.round(h * 0.67), h2 = Math.round(h * 0.75);
    top.forEach((c, i) => { ctx.fillStyle = c; ctx.fillRect(Math.floor(i * bw), 0, Math.ceil(bw) + 1, h1); });
    mid.forEach((c, i) => { ctx.fillStyle = c; ctx.fillRect(Math.floor(i * bw), h1, Math.ceil(bw) + 1, h2 - h1); });
    const low = [['#00214c', 1.25], ['#ffffff', 1.25], ['#32006a', 1.25], ['#131313', 1.25], ['#090909', 1 / 3], ['#131313', 1 / 3], ['#1d1d1d', 1 / 3], ['#131313', 1]];
    let x = 0; for (const [c, n] of low) { ctx.fillStyle = c; ctx.fillRect(Math.floor(x), h2, Math.ceil(bw * n) + 1, h - h2); x += bw * n; }
  };
  /* Preview shows the shot being built: a cued video or replay angle sits at its in point */
  UI.drawPreview = function (ctx, w, h, st, t) {
    const pv = st.pv || {}, look = PV.lookFor(st.show);
    if (st.preview === 'video' && pv.vid) { const v = PV.vidItem(st, pv.vid); if (v) { S.drawClip(ctx, w, h, v.ref, v.tIn, look); return; } }
    if (st.preview === 'replay' && pv.rp) { const c = st.rp.clips.find(x => x.id === pv.rp.clip); if (c) { S.drawCamera(ctx, w, h, pv.rp.ang, PV.cut(c, pv.rp.ang).tIn, PV.gameFor(st.show), look); if (h > 200) label(ctx, w, h, `CUED · ${c.name.toUpperCase()} · ${PV.srcShort(pv.rp.ang)}`); return; } }
    UI.drawSource(ctx, w, h, st.preview, st, t);
  };

  /* league bar between boxes: NEC blue with a light edge and the conference mark */
  const necImg = new Image(); necImg.src = 'logos/nec.svg';
  function leagueBar(ctx, w, h, b) {
    const th = Math.max(3, Math.round(Math.min(w, h * 16 / 9) * 0.011)), e = Math.max(1, th * 0.18);
    if (b.o === 'v') {
      const x = b.at * w;
      ctx.fillStyle = '#004f7a'; ctx.fillRect(x - th / 2, 0, th, h);
      ctx.fillStyle = '#7cc6ee'; ctx.fillRect(x - th / 2, 0, e, h); ctx.fillRect(x + th / 2 - e, 0, e, h);
    } else {
      const y = b.at * h;
      ctx.fillStyle = '#004f7a'; ctx.fillRect(0, y - th / 2, w, th);
      ctx.fillStyle = '#7cc6ee'; ctx.fillRect(0, y - th / 2, w, e); ctx.fillRect(0, y + th / 2 - e, w, e);
    }
  }
  function barBadge(ctx, w, h, bars) {
    if (!bars.length || !necImg.complete || !necImg.naturalWidth || h < 60) return;
    const v = bars.filter(b => b.o === 'v'), hz = bars.find(b => b.o === 'h');
    const spots = v.length ? v.map(b => [b.at * w, hz ? hz.at * h : h * 0.5]) : [[w / 2, hz.at * h]];
    const bw = Math.min(w, h * 16 / 9) * 0.075, bh = bw * necImg.naturalHeight / necImg.naturalWidth;
    for (const [x, y] of spots) {
      const pw = bw * 1.3, ph = bh + bw * 0.3;
      ctx.fillStyle = '#006ba3'; ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x - pw / 2, y - ph / 2, pw, ph, bw * 0.12); else ctx.rect(x - pw / 2, y - ph / 2, pw, ph);
      ctx.fill(); ctx.strokeStyle = '#7cc6ee'; ctx.lineWidth = Math.max(1, bw * 0.03); ctx.stroke();
      ctx.drawImage(necImg, x - bw / 2, y - bh / 2, bw, bh);
    }
  }
  /* the look's strip for a split screen, as a loaded picture (none for a look without one) */
  const stripImgs = {};
  UI.splitStrip = st => {
    const B = (G.pkgOf(st.gfx.pkg) || {}).build || {};
    const src = B.splitSrc ? B.splitSrc(st) : null; if (!src) return null;
    let im = stripImgs[src]; if (!im) { im = stripImgs[src] = new Image(); im.src = src; }
    return im;
  };
  function drawStrip(ctx, w, h, b, im) {
    if (!im.complete || !im.naturalWidth) return;
    const sw = h * im.naturalWidth / im.naturalHeight;
    ctx.drawImage(im, b.at * w - sw / 2, 0, sw, h);
  }
  /* an M/E: sources cropped to fill their boxes, then league bars on top */
  function drawME(ctx, w, h, me, st, t, o) {
    o = o || {};
    if (!me) { blank(ctx, w, h, 'NO M/E'); return; }
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    for (const l of me.layers) {
      if (l.k === 'snd') continue;
      const bx = l.x * w, by = l.y * h, bw = l.w * w, bh = l.h * h;
      if (bw < 2 || bh < 2) continue;
      if (l.k === 'gfx') { if (o.thumb) gfxStub(ctx, bx, by, bw, bh, l.g, st); continue; }
      if (PV.isME(l.src) && (l.src.slice(3) === me.id || (o.depth || 0) > 1)) continue;
      const dw = Math.max(bw, bh * 16 / 9), dh = dw * 9 / 16;
      ctx.save(); ctx.beginPath(); ctx.rect(bx, by, bw, bh); ctx.clip();
      ctx.translate(bx + (bw - dw) / 2, by + (bh - dh) / 2);
      if (PV.isME(l.src)) drawME(ctx, dw, dh, PV.meById(st, l.src.slice(3)), st, t, { depth: (o.depth || 0) + 1, thumb: o.thumb });
      else UI.drawSource(ctx, dw, dh, l.src, st, t, (o.depth || 0) + 1);
      ctx.restore();
      if (l.border) { ctx.strokeStyle = 'rgba(255,255,255,.92)'; ctx.lineWidth = Math.max(2, w / 320); ctx.strokeRect(bx, by, bw, bh); }
    }
    // a look with its own split strip draws that over the split (and on these small pictures too)
    const strip = UI.splitStrip(st);
    for (const b of me.bars || []) { if (strip && b.o === 'v') { if (o.thumb || o.depth) drawStrip(ctx, w, h, b, strip); } else leagueBar(ctx, w, h, b); }
    barBadge(ctx, w, h, strip ? (me.bars || []).filter(b => b.o !== 'v') : me.bars || []);
  }
  /* a stand-in for a graphic on small thumbnails and in the M/E editor */
  function gfxStub(ctx, x, y, w, h, kind, st) {
    const c = st.show.colors;
    if (kind === 'scorebug') {
      const bw = w * 0.2, bh = h * 0.1, bx = x + w * 0.04, by = y + h * 0.84;
      ctx.fillStyle = 'rgba(17,21,28,.92)'; ctx.fillRect(bx, by, bw, bh);
      ctx.fillStyle = c.away; ctx.fillRect(bx, by, bw * 0.05, bh / 2);
      ctx.fillStyle = c.home; ctx.fillRect(bx, by + bh / 2, bw * 0.05, bh / 2);
      ctx.fillStyle = '#ffb020'; ctx.fillRect(bx + bw * 0.74, by, bw * 0.26, bh);
    } else if (kind === 'ticker') { ctx.fillStyle = 'rgba(13,16,22,.92)'; ctx.fillRect(x, y + h * 0.94, w, h * 0.06); ctx.fillStyle = '#ffb020'; ctx.fillRect(x, y + h * 0.94, w * 0.14, h * 0.06); }
    else if (kind === 'watermark') { ctx.fillStyle = 'rgba(255,255,255,.7)'; ctx.fillRect(x + w * 0.84, y + h * 0.05, w * 0.12, h * 0.04); }
    else if (kind === 'big') { ctx.fillStyle = c.away; ctx.fillRect(x + w * 0.2, y + h * 0.8, w * 0.27, h * 0.12); ctx.fillStyle = '#0c0e12'; ctx.fillRect(x + w * 0.47, y + h * 0.8, w * 0.06, h * 0.12); ctx.fillStyle = c.home; ctx.fillRect(x + w * 0.53, y + h * 0.8, w * 0.27, h * 0.12); }
  }
  UI.drawME = function (ctx, w, h, me, st, t, o) {
    if (PV.native && me) { PV.native.drawSnap(ctx, w, h, 'me:__draft', { me }); return; }
    drawME(ctx, w, h, me, st, t, o);
  };
  UI.gfxStub = gfxStub;
  function blank(ctx, w, h, txt) {
    ctx.fillStyle = '#06080b'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#4b5565'; ctx.font = `700 ${Math.max(10, h / 14)}px "Barlow Condensed", sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(txt, w / 2, h / 2);
  }
  function label(ctx, w, h, txt) {
    const fs = Math.max(9, h / 22);
    ctx.font = `700 ${fs}px "Barlow Condensed", sans-serif`;
    const tw = ctx.measureText(txt).width;
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(w - tw - fs * 1.6, h - fs * 2.2, tw + fs * 1.2, fs * 1.6);
    ctx.fillStyle = '#ffd38a'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(txt, w - tw - fs, h - fs * 1.4);
  }

  /* program: the live source, plus a dissolve while a fade is running */
  UI.drawProgram = function (ctx, w, h, st, t) {
    const tr = st.trans.active;
    if (tr && tr.type === 'mix') {
      const u = Math.max(0, Math.min(1, (t - tr.start) / tr.dur));
      if (u < 1) {
        UI.drawSource(ctx, w, h, tr.from, st, t);
        const o = offscreen(w, h), octx = o.getContext('2d');
        UI.drawSource(octx, w, h, tr.to, st, t);
        ctx.globalAlpha = u; ctx.drawImage(o, 0, 0); ctx.globalAlpha = 1;
        return;
      }
    }
    if (tr && tr.type === 'stinger' && !tr.cut && (t - tr.start) < tr.dur / 2) { UI.drawSource(ctx, w, h, tr.from, st, t); return; }
    UI.drawSource(ctx, w, h, st.program, st, t);
  };

  UI.fit = function (c, max) {
    const r = c.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = Math.max(16, Math.round(r.width * dpr)), h = Math.max(9, Math.round(r.height * dpr));
    if (max && w > max) { h = Math.round(h * max / w); w = max; }
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    return [w, h];
  };

  /* audio levels (0..1); pass a source to meter something other than Program */
  UI.levels = function (st, t, src) {
    const game = PV.gameFor(st.show);
    const T = PV.worldT(st, t);
    const on = src || st.program;
    const rp = st.rp.playing;
    let natT = T;
    const seg = on === 'replay' && PV.rpSeg(rp);
    if (seg) natT = seg.tIn + Math.max(0, (t - rp.start) / 1000) * rp.speed;
    const raw = [S.voiceLevel(0, T), S.voiceLevel(1, T), S.natLevel(0, natT, game), S.natLevel(1, natT, game)];
    const ch = st.audio.ch.map((c, i) => c.mute ? 0 : raw[i] * (0.35 + c.fader * 0.8));
    let L, R;
    const m = st.audio.master;
    if (st.audio.mode === 'split') { L = ch[0]; R = ch[2]; }
    else { L = Math.max(ch[0], ch[1]) * 0.8 + Math.max(ch[2], ch[3]) * 0.45; R = L * 0.96 + (ch[3] - ch[2]) * 0.1; }
    if (on === 'video') { const g = (st.pl.last && st.pl.last.gain != null ? st.pl.last.gain : 0.8) * (st.pl.last && st.pl.last.speed && st.pl.last.speed !== 1 ? 0 : 1); const v = (0.45 + 0.2 * S.noise(t / 300)) * (g / 0.8); L = Math.max(L, v); R = Math.max(R, v * 0.97); }
    if (!src && st.sndPlay) { const v = (0.5 + 0.25 * S.noise(t / 210)) * ((st.sndPlay.gain || 0.8) / 0.8); L = Math.max(L, v); R = Math.max(R, v * 0.96); }
    const off = !src && st.audio.pgmMute ? 0 : 1;   // program sound switched off: nothing goes out
    return { raw, ch, L: Math.min(1, L * m * 1.15) * off, R: Math.min(1, R * m * 1.15) * off };
  };

  /* ======================================================================
     DIRECTOR (main window, runs the engine)
     ====================================================================== */
  const ui = { drag: null, last: {}, frame: 0, listening: null, settings: null, trayL: false, popR: false,
    view: PV.store.get('view', 'both'), monH: PV.store.get('monH', 0), rdOpen: PV.store.get('rdOpen', true), drawer: null,
    segOpen: { gfx: null, vid: null }, sel: null, panel: null, open: { sug: true, sb: true } };
  UI.state = ui;

  /* ---------- the show itself is remembered (cameras, scoreboard, rundown, replays, what's on air), so a crash or a
     restart can pick up where it left off. A new production clears it; the operator's own setup stays. ---------- */
  PV.newProduction = function () {
    for (const k of ['session', 'replays', 'startAt']) PV.store.set(k, null);
    PV.store.set('game', null);
  };
  function saveSession(st) {
    const g = st.show.game && st.show.game.id; if (!g) return;
    const sb = JSON.parse(JSON.stringify(st.sb)); sb.clock = G.sbClockMs(st.sb, Date.now()); sb.running = false;
    PV.store.set('session', { game: g, cams: PV.camIds(st).length, sb, rd: st.rd,
      gfx: { scorebug: st.gfx.scorebug, ticker: st.gfx.ticker, water: st.gfx.water, big: st.gfx.big },
      text: st.text, l3text: st.l3text || {}, l3pick: st.l3pick, vlists: st.vlists || [], program: st.program, preview: st.preview, sel: st.trans.sel, rpSpeed: st.rp.speed });
  }
  function loadSession(base) {
    const s = PV.store.get('session', null); if (!s || s.game !== (base.show.game || {}).id) return;
    if (s.sb) { Object.assign(base.sb, s.sb); base.sb.at = Date.now(); base.sb.running = false; }
    if (s.rd && Array.isArray(s.rd.items)) base.rd = s.rd;
    if (s.gfx) Object.assign(base.gfx, s.gfx);
    for (const k of ['text', 'l3pick']) if (s[k]) base[k] = s[k];
    if (Array.isArray(s.vlists)) base.vlists = s.vlists;
    if (s.l3text) base.l3text = Object.assign({}, base.l3text, s.l3text);
    if (s.program) base.program = s.program;
    if (s.preview) base.preview = s.preview;
    if (s.sel) base.trans.sel = s.sel;
    if (s.rpSpeed) base.rp.speed = s.rpSpeed;
  }

  /* what each control screen may do. Only the Director brings things to air; the others build Preview
     (graphics, replays) or work their own area (the score, the sound, the order of the rundown). */
  const MAY = {
    graphics: n => /^(pv\.gfx|pv\.gfxClear|l3\.text|l3\.pick)$/.test(n),
    scorebug: n => /^sb\./.test(n),
    replay: (n, a) => /^(rp\.mark|rp\.back|rp\.angles|rp\.name|rp\.cut|pv\.rp)$/.test(n) || (n === 'rp.speed' && a[2] !== 'live'),
    audio: n => /^audio\.(fader|mute|master|mode)$/.test(n),
    producer: n => /^(rd\.move|rd\.cue)$/.test(n)
  };
  PV.screenMay = (role, a) => role === 'director' || (!!MAY[role] && MAY[role](a[0], a));

  UI.startDirector = function (show, saved, cams, opts) {
    const resume = !!(opts && opts.resume);
    const base = PV.defaultState(show);
    if (saved) restore(base, saved, resume);
    PV.fitReplay(base);   // shows saved with more replay angles keep the first two
    if (!resume) base.audio.ch.forEach(c => { c.mute = true; });   // a new production: nothing is heard until the operator turns it on
    if (resume) { loadReplays(base); loadSession(base); } else PV.store.set('replays', null);
    // bios the operator corrected before, for these teams' players
    const bios = PV.store.get('bios', {}); base.l3text = base.l3text || {};
    for (const side of ['away', 'home']) for (const k in bios) { const [tk, num] = k.split('|'); if (tk === base.show[side].key) base.l3text[`${side}|${num}|bio`] = bios[k]; }
    const E = PV.E = new PV.Engine(base);
    if (cams) E.act('cams.count', cams);   // the number picked at the start (or the one the show had)
    // the Mac puts the cameras back as they were, or starts them empty
    if (PV.native) PV.native.post({ type: resume ? 'resume' : 'fresh' });
    if (PV.fieldStart) PV.fieldStart(E);   // soccer and field hockey: Front Row's rosters and live stats
    E.listeners.push(() => { UI.dirty = true; });
    buildDirector();
    setInterval(() => E.tick(), 100);
    let lastBc = 0, lastRoom = 0, lastV = -1, saveT = 0, lastShow = 0, savedV = -1;
    setInterval(() => {
      const t = Date.now();
      if (E.st.v !== lastV || t - lastBc > 1000) { PV.link.local({ k: 'state', s: E.st }); lastBc = t; }
      if ((E.st.v !== lastV && t - lastRoom > 250) || t - lastRoom > 2000) { PV.link.remote('pivot.state', PV.compact(E.st)); lastRoom = t; }
      if (t - lastShow > 8000) { PV.link.remote('pivot.show', PV.rosterMsg(E.st)); lastShow = t; }
      if (E.st.v !== savedV && t - saveT > 1500) { saveSetup(E.st); saveT = t; savedV = E.st.v; }   // a change just after a save is saved on the next pass
      lastV = E.st.v;
    }, 60);
    PV.link.on((msg, via) => {
      if (msg.k === 'state' && ((msg.s && msg.s.eng !== E.st.eng) || (msg.eng && msg.eng !== E.st.eng))) {
        if (!ui.otherWarned) { ui.otherWarned = true; UI.banner('Pivot is also open as a main screen in another window or on another computer. Close one of them so control screens stay connected to the right one.'); }
        return;
      }
      if (msg.k === 'act' && Array.isArray(msg.a) && msg.eng === E.st.eng) {
        if (msg.mid) { ui.mids = ui.mids || []; if (ui.mids.includes(msg.mid)) return; ui.mids.push(msg.mid); if (ui.mids.length > 200) ui.mids.shift(); }
        if (via === 'room' && msg.pin !== E.st.pin) return;
        if (!E.actions[msg.a[0]]) return;
        if (via === 'room' && /^(tpl\.|profile|input\.set|stream\.|rec\.set|out\.set)/.test(msg.a[0])) return;
        // only the Director's screen puts things on air; everyone else works in Preview (or their own area)
        const scr = ui.screens && ui.screens[msg.from], role = scr && scr.role;
        if (!PV.screenMay(role, msg.a)) return;
        E.act.apply(E, msg.a);
      } else if (msg.k === 'hello') {
        const ok = via === 'local' || msg.pin === E.st.pin;
        const reply = { k: 'welcome', to: msg.from, ok, eng: E.st.eng, role: msg.role };
        if (via === 'local') PV.link.local(reply); else { PV.link.remote('pivot.hello', reply); PV.link.remote('pivot.show', PV.rosterMsg(E.st)); }
        if (ok) { ui.screens = ui.screens || {}; ui.screens[msg.from] = { role: msg.role, via, at: Date.now() }; UI.dirty = true; }
      }
    });
    document.addEventListener('keydown', onKey, true);
    requestAnimationFrame(frame);
  };

  function restore(base, saved, resume) {
    try {
      for (const k of ['inputs', 'audio', 'rec', 'out']) if (saved[k]) base[k] = Object.assign(base[k], saved[k]);
      // only the camera slots this Mac is set up for
      for (const id of Object.keys(base.inputs)) if (/^cam\d+$/.test(id) && +id.slice(3) > (+PV.store.get('camCount', 4) || 4)) delete base.inputs[id];
      // cameras 3 and 4 used to come named Baseline and Reverse; those depend on the venue
      if (saved.gfxOrder && typeof saved.gfxOrder === 'object') base.gfxOrder = saved.gfxOrder;
      for (const [id, old] of [['cam3', 'Baseline'], ['cam4', 'Reverse']]) if (base.inputs[id] && base.inputs[id].name === old) base.inputs[id].name = '';
      for (const id of Object.keys(base.inputs)) if (/^Camera \d+$/.test(base.inputs[id].name || '')) base.inputs[id].name = '';
      if (saved.stream) { base.stream.kbps = saved.stream.kbps || base.stream.kbps; base.stream.res = saved.stream.res || base.stream.res; if (saved.stream.dests) base.stream.dests.forEach(d => { const s = saved.stream.dests.find(x => x.id === d.id); if (s) d.on = s.on; }); }
      if (saved.gfx) { base.gfx.pkg = PV.lookChoice(saved.gfx.pkg || base.gfx.pkg); if (saved.gfx.burn) base.gfx.burn = Object.assign(base.gfx.burn, saved.gfx.burn); if (saved.gfx.wm) base.gfx.wm = Object.assign(base.gfx.wm || {}, saved.gfx.wm); }
      if (saved.rp) { base.rp.back = saved.rp.back || 8; base.rp.angles = saved.rp.angles || base.rp.angles; /* new replays always start at 75% */ }
      if (saved.trans) { base.trans.dur = saved.trans.dur || 600; if (Array.isArray(saved.trans.custom)) base.trans.wipes = base.trans.wipes.concat(saved.trans.custom.filter(w => w && w.id && w.kind && !base.trans.wipes.some(x => x.id === w.id))); }
      if (saved.lists) base.pl.lists.forEach(l => { const s = saved.lists.find(x => x.id === l.id); if (s && Array.isArray(s.items)) { l.mode = s.mode || l.mode; l.items = s.items.filter(i => i.type !== 'replay').map(i => Object.assign(i, { played: false })); } });
      if (saved.tpl) base.tpl = saved.tpl;
      if (saved.profile) { base.profile.name = saved.profile.name || base.profile.name; base.profile.trialEnds = saved.profile.trialEnds || base.profile.trialEnds; }
      if (saved.pin) base.pin = saved.pin;
      if (Array.isArray(saved.me2) && saved.me2.length >= 8 && saved.me2.every(m => m && Array.isArray(m.layers) && m.layers.every(l => l && l.k))) base.me.list = saved.me2;
      for (const m of base.me.list) m.name = { 'Split screen': 'Split', 'Picture in picture': 'PiP' }[m.name] || m.name;
      if (saved.gfxNames && typeof saved.gfxNames === 'object') base.gfxNames = saved.gfxNames;
      if (Array.isArray(saved.snds) && saved.snds.length) base.snds = PV.withTone(saved.snds.filter(s => s.id !== 'tone').map(s => ({ id: s.id, name: s.name, gain: s.gain == null ? 0.8 : s.gain, tIn: 0, tOut: 0, dur: 0, file: '' })));
      if (saved.l3pick) base.l3pick = saved.l3pick;
      if (resume && saved.show && saved.show.game === base.show.game.id) {   // this show's own rundown, text and videos
        if (Array.isArray(saved.show.rd) && saved.show.rd.length) base.rd.items = saved.show.rd.map(i => Object.assign(i, { done: false }));
        if (saved.show.text) base.text = saved.show.text;
        if (saved.show.vids && typeof saved.show.vids === 'object' && Object.values(saved.show.vids).every(Array.isArray)) base.vids = saved.show.vids;
        if (Array.isArray(saved.show.officials)) base.show.officials = saved.show.officials;
      }
      PV.updateShow(base);
    } catch (e) { /* start clean */ }
  }
  /* the game's replays are kept, so closing or reloading Pivot doesn't lose them.
     Their times are stored against the desk clock and moved onto the new clock when the game opens again. */
  function saveReplays(st) {
    const g = st.show.game && st.show.game.id; if (!g) return;
    const clips = st.rp.clips.map(c => Object.assign({}, c));
    const cur = PV.store.get('replays', null);
    if (!clips.length && !(st.rp.lists || []).length && !(cur && cur.game === g)) return;
    PV.store.set('replays', { game: g, epoch: st.epoch, n: st.rp.n, clips, lists: st.rp.lists || [] });
  }
  function loadReplays(st) {
    const r = PV.store.get('replays', null), g = st.show.game && st.show.game.id;
    if (!r || !g || r.game !== g || !Array.isArray(r.clips)) return;
    const d = (r.epoch - st.epoch) / 1000;   // seconds to move each time by
    const mv = v => +v + d;
    const shift = c => {
      if (c.stamp) return c;   // an end stamp in a playlist has no footage
      const o = Object.assign({}, c, { tIn: mv(c.tIn), tOut: mv(c.tOut) });
      if (c.win) o.win = [mv(c.win[0]), mv(c.win[1])];
      if (c.cuts) { o.cuts = {}; for (const a in c.cuts) o.cuts[a] = { tIn: mv(c.cuts[a].tIn), tOut: mv(c.cuts[a].tOut) }; }
      return o;
    };
    st.rp.clips = r.clips.map(shift);
    // highlight playlists hold their own copies of the plays
    if (Array.isArray(r.lists)) st.rp.lists = r.lists.filter(l => l && Array.isArray(l.items)).map(l => Object.assign({}, l, { items: l.items.map(shift) }));
    st.rp.n = Math.max(st.rp.n || 0, r.n || 0, st.rp.clips.length);
  }
  function saveSetup(st) {
    saveReplays(st);
    saveSession(st);
    PV.store.set('setup', { inputs: st.inputs, audio: st.audio, rec: Object.assign({}, st.rec, { on: false }), out: st.out, stream: Object.assign({}, st.stream, { on: false }), gfx: { pkg: st.gfx.pkg, burn: st.gfx.burn, wm: st.gfx.wm },
      rp: { back: st.rp.back, angles: st.rp.angles, speed: st.rp.speed }, trans: { dur: st.trans.dur, custom: st.trans.wipes.filter(w => !['replay', 'home', 'away'].includes(w.id)) },
      lists: st.pl.lists.filter(l => !l.hidden).map(l => ({ id: l.id, mode: l.mode, items: l.items })), tpl: st.tpl, profile: st.profile, pin: st.pin,
      me2: st.me.list, gfxOrder: st.gfxOrder || null, gfxNames: st.gfxNames || {}, snds: st.snds.map(s => ({ id: s.id, name: s.name, gain: s.gain })), l3pick: st.l3pick,
      show: { game: st.show.game.id, rd: st.rd.items.map(i => ({ id: i.id, seg: i.seg, label: i.label, sub: i.sub, act: i.act, kind: i.kind, cam: i.cam })), text: st.text, vids: st.vids, officials: st.show.officials } });
  }

  /* saving replay footage: on or off, and how far back, kept by the Mac app (or here, in the sample) */
  PV.replayCfg = function () {
    const n = PV.native && PV.native.replaySettings;
    const r = n && n.minutes ? n : PV.store.get('replayCfg', null) || {};
    return { enabled: r.enabled !== false, minutes: r.minutes || 6 };
  };
  PV.setReplay = function (patch) {
    if (PV.native && PV.native.post) PV.native.post({ type: 'replaySettings', patch });
    else { PV.store.set('replayCfg', Object.assign(PV.replayCfg(), patch)); if (UI.renderSettings) UI.renderSettings(); }
    PV.E.changed();
  };
  UI.send = function (...a) {
    // a replay marked while one of the replay playlists is open goes into it too (and into All)
    if (a[0] === 'rp.mark' && a[1] == null && UI.plTabOf) { const tab = UI.plTabOf(PV.E.st, 'rp'); if (tab !== 'all') a[1] = 'rp:' + tab; }
    PV.E.act.apply(PV.E, a);
  };

  /* ---------- keyboard ---------- */
  function onKey(e) {
    if (ui.listening) return;
    const tg = e.target;
    if (tg && (tg.isContentEditable || tg.tagName === 'TEXTAREA' || (tg.tagName === 'INPUT' && /^(text|search|password|number|email|url|tel|)$/i.test(tg.type || '')))) {
      if (e.key === 'Escape') tg.blur();
      // ⌘A selects all of what's being typed (the Mac's Select All leaves ⌘A free for Mark replay everywhere else)
      if ((e.metaKey || e.ctrlKey) && !e.altKey && String(e.key).toLowerCase() === 'a') { e.preventDefault(); e.stopPropagation(); if (tg.select) tg.select(); else document.execCommand('selectAll'); }
      return;
    }
    if ($('.scrim')) { if (e.key === 'Escape' && !$('.dlg')) UI.closeSettings(); return; }
    if (tg && tg.closest && tg.closest('.menu')) { if (e.key === 'Escape') UI.closeMenus(); return; }
    if (tg && /^(SELECT|INPUT|BUTTON)$/.test(tg.tagName)) { if (e.key !== 'Tab') tg.blur(); }
    if ($('.menu') && e.key === 'Escape') { UI.closeMenus(); return; }
    if (e.key === 'Escape' && ui.drawer) { ui.drawer = null; UI.dirty = true; e.preventDefault(); return; }
    const k = PV.keyName(e); if (!k) return;
    if ((k === 'Backspace' || k === 'Delete') && UI.deletePicked()) { e.preventDefault(); return; }
    if (k === 'Meta+R' && ui.sel && (ui.sel.kind === 'rp' || ui.sel.kind === 'rpclip')) { e.preventDefault(); UI.renamePlay(ui.sel.a); return; }
    if (k === 'Meta+R' && ui.sel && ui.sel.kind === 'pli') { e.preventDefault(); UI.renameItem(ui.sel.a, ui.sel.b); return; }
    if (k === 'Meta+R' && ui.sel && (ui.sel.kind === 'cat' || ui.sel.kind === 'snd')) { e.preventDefault(); UI.renameTile(ui.sel.kind, ui.sel.a); return; }
    if (k === 'Meta+Z' && !PV.native) { e.preventDefault(); UI.undo(); return; }   // in the Mac app, Edit › Undo (⌘Z) calls UI.undoKey
    if (UI.plKey && UI.plKey(k)) { e.preventDefault(); return; }   // ⌘C / ⌘V for playlists
    const map = PV.shortcuts();
    const id = Object.keys(map).find(a => map[a] === k);
    if (id) { e.preventDefault(); e.stopPropagation(); UI.runAction(id); return; }
    const m = PV.macros().find(x => x.key === k);
    if (m) { e.preventDefault(); UI.send('macro.run', m.id); UI.toast(`Macro: ${m.name}`); }
  }
  UI.runAction = function (id) {
    if (id === 'trayL') return UI.tray();
    if (id === 'rdEdit') return UI.editSelected();
    if (id === 'gfxGo') return UI.gfxGo();
    if (id === 'drawV') return UI.drawer('away');
    if (id === 'drawH') return UI.drawer('home');
    if (id === 'drawC') return UI.drawer('canned');
    const A = PV.ACTIONS.find(x => x.id === id); if (!A) return;
    const E = PV.E;
    if (E.st.macro.recording && id !== 'mstop') {
      const t = Date.now(); const gap = t - (E.recLast || t);
      if (E.recordedIds.length && gap > 250) E.recordedIds.push({ wait: Math.min(gap, 15000) });
      E.recordedIds.push({ a: id }); E.recLast = t;
    }
    const call = A.run(E); if (call) UI.send.apply(UI, call);
  };
  /* G: the graphic you're on (picked in a tray, the rundown or the suggestions, or in Preview) goes on air; G again takes it off */
  UI.gfxItemOf = function (st, s) {
    if (!s) return null;
    if (s.kind === 'cat') return { t: 'cat', ref: s.a };
    if (s.kind === 'tog') return { t: 'tog', k: s.a };
    if (s.kind === 'pic') return { t: 'pic', pic: s.a };
    if (s.kind === 'l3') return { t: 'l3', spec: { kind: s.a, side: s.b, num: s.c } };
    if (s.kind === 'sbg' && s.a === 'stats') return compsItem();
    if (s.kind === 'rd') { const it = st.rd.items[+s.a]; return it && it.act && it.act[0] === 'gfx.play' ? { t: 'cat', ref: it.act[1] } : null; }
    return null;
  };
  UI.gfxGo = function () {
    const st = PV.E.st;
    let item = UI.gfxItemOf(st, ui.sel);
    if (!item && st.pv.gfx.length) item = st.pv.gfx[st.pv.gfx.length - 1];
    if (!item && ui.gLast && PV.itemLive(st, ui.gLast)) item = ui.gLast;
    if (!item) {
      const cue = st.rd.items[st.rd.cue];
      if (cue && cue.act && cue.act[0] === 'gfx.play') item = { t: 'cat', ref: cue.act[1] };
    }
    if (!item) {
      const sg = st.sugg[0], a = sg && sg.act;
      if (a && a[0] === 'gfx.play') item = { t: 'cat', ref: a[1] };
      else if (sg) { UI.send('sugg.take'); return; }
    }
    if (!item) { UI.toast('Pick a graphic first'); return; }
    ui.gLast = item;
    if (PV.itemLive(st, item)) UI.send('gfx.off', item);
    else { UI.send('gfx.air', item); if (st.sugg.length && st.sugg[0].act && st.sugg[0].act[0] === 'gfx.play' && st.sugg[0].act[1] === item.ref) st.sugg.shift(); }
    UI.dirty = true;
  };
  UI.tray = function (force) { ui.trayL = force == null ? !ui.trayL : force; UI.dirty = true; };
  UI.drawer = function (which) { ui.drawer = ui.drawer === which ? null : which; UI.dirty = true; };

  /* the playlists tray and the scoreboard pop-out follow the mouse to the screen edges */
  function edgeHover() {
    let tL = 0, tR = 0;
    document.addEventListener('mousemove', e => {
      if (!$('#trayL') || $('.scrim')) return;
      const w = window.innerWidth;
      if (e.clientX <= 4 && !ui.trayL) { clearTimeout(tL); tL = setTimeout(() => { ui.trayL = 'hover'; UI.dirty = true; }, 60); } else if (e.clientX > 4) clearTimeout(tL);
      const rd = $('#rdock'), top = rd ? rd.getBoundingClientRect().top : window.innerHeight;
      if (e.clientX >= w - 5 && e.clientY < top - 4 && !ui.popR && !PV.store.get('sbPinned', false)) { clearTimeout(tR); tR = setTimeout(() => { ui.popR = 'hover'; UI.dirty = true; }, 60); } else if (e.clientX < w - 5) clearTimeout(tR);
    });
    const leave = (el, key) => el.addEventListener('mouseleave', e => {
      if (ui[key] !== 'hover' || ui.drag) return;
      if (e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('.menu,.scrim')) return;
      ui[key] = false; UI.dirty = true;
    });
    leave($('#trayL'), 'trayL'); leave($('#popR'), 'popR');
  }

  /* ---------- build the desk ---------- */
  function buildDirector() {
    $('#app').innerHTML = `
<header class="top">
  <div class="brand"><span class="mark"></span>PIVOT${PV.GFX_ONLY ? '<em>GFX</em>' : ''}</div>
  <button class="showinfo" id="hGame" title="Pick a different game"><b id="hShow"></b><span id="hTpl"></span></button>
  <button class="cdown" id="hCount" title="Time to the start. Click to change the start time."><small>STARTS IN</small><b class="tc"></b></button>
  <button class="cdown cams" id="hCams" title="Cameras in this show. Click to change."><small>CAMERAS</small><b class="tc"></b></button>
  <div class="sp"></div>
  <button class="pill" id="bProto" hidden></button>
  <button class="pill" id="bOut" title="Outputs">OUTPUTS ▾</button>
  <span class="wifiw" id="ndiWifi" hidden title="Wi-Fi can't be counted on to deliver every frame">ON WI-FI: PLUG IN A CABLE</span>
  <button class="pill ndi" id="bNdi" title="NDI output"><i class="dot"></i>NDI<span id="tNdi">OFF</span></button>
  <span class="pillg"><button class="pill rec" id="bRec" title="Record"><i class="dot"></i>REC<span id="tRec">Off</span></button><button class="pgear" id="gRec" title="Recording settings" aria-label="Recording settings">⚙</button></span>
  <span class="pillg"><button class="pill live" id="bStream" title="Stream"><i class="dot"></i>STREAM<span id="tStream">Off</span></button><button class="pgear" id="gStream" title="Streaming settings" aria-label="Streaming settings">⚙</button></span>
  <span class="pillg"><button class="pill rply" id="bReplay" title="Replays: click to stop or start saving replay footage"><i class="dot"></i>REPLAYS<span id="tReplay">On</span></button><button class="pgear" id="gReplay" title="Replay settings" aria-label="Replay settings">⚙</button></span>
  <button class="pill brk" id="bBreak" title="Break mode">BREAK</button>
  <span class="tod tc" id="tod"></span>
  <button class="btn" id="bAudio">Audio</button>
  <button class="btn" id="bMacros">Macros</button>
  <button class="btn" id="bScreens">Screens ▾</button>
  <button class="btn upd" id="bUpdate" hidden>Update</button>
  <button class="btn" id="bSettings">Settings</button>
  <button class="prof" id="bProf"><i id="pInit">KJ</i><span><span id="pName"></span> <small id="pTrial"></small></span></button>
</header>
<div class="desk3" id="desk">
  <section class="stage3" id="stage3">
    <div class="mrow" id="mrow">
      <div class="meterv" id="mtrPvw" title="Preview audio"></div>
      <div class="mcol pvwc"><div class="mhd pvw"><b>PREVIEW</b><span id="lPvw"></span><span class="sp"></span><span class="mbadge" id="bdPvw"></span></div><div class="mon pvw" id="monPvw"><canvas></canvas><div class="gfxhost"></div></div></div>
      <div class="tcol" id="tcol"></div>
      <div class="mcol pgmc"><div class="mhd pgm"><b>PROGRAM</b><span id="lPgm"></span><span class="sp"></span><span class="ndicount tc" id="ndiCount"></span><span class="mbadge" id="bdPgm"></span><span class="abtns" id="aBtns"></span></div><div class="mon pgm" id="monPgm"><canvas></canvas><div class="gfxhost"></div></div></div>
      <div class="meterv r" id="mtrPgm" title="Program audio"></div>
      <aside class="card sbpin" id="sbPin" hidden></aside>
    </div>
  </section>
  <div class="rsz" id="rsz" title="Drag to make the monitors bigger or smaller. Double-click to reset."><i></i>
    <div class="vbtns" role="group" aria-label="Monitors"><button data-view="both" title="Preview and Program"><i class="g"></i><i class="r"></i></button><button data-view="pvw" title="Preview only"><i class="g"></i></button><button data-view="pgm" title="Program only"><i class="r"></i></button></div></div>
  <section class="lower3">
    <div class="rows" id="rows"></div>
    <aside class="rdock" id="rdock"></aside>
  </section>
</div>
<button class="trayhandle l" id="thL" title="Playlists"><span>PLAYLISTS</span></button>
<section class="tray l" id="trayL" aria-label="Playlists"></section>
<aside class="popR" id="popR" aria-label="Scoreboard"><div class="card" id="cSb"></div></aside>
<button class="trayhandle r popRtab" id="popRtab" title="Scoreboard (or move the mouse to the right edge)"></button>`;
    UI.stage = G.createStage($('#monPgm .gfxhost'));
    UI.pvStage = G.createStage($('#monPvw .gfxhost'));
    buildMeters($('#mtrPvw')); buildMeters($('#mtrPgm'));
    wire();
    edgeHover();
    applyView();
    UI.dirty = true;
  }
  function buildMeters(el) {
    const ticks = [6, 0, -6, -12, -18, -24, -30, -36, -42, -48, -54, -60];
    el.innerHTML = `<div class="mscale">${ticks.map(d => `<span style="top:${((6 - d) / 66 * 100).toFixed(2)}%">${d > 0 ? '+' + d : d}</span>`).join('')}</div><div class="mbars"><span class="mb"><i></i></span><span class="mb"><i></i></span></div>`;
  }
  /* 0..1 level to a dB scale of +6 to -60 (0.9 reads as 0 dB) */
  const dbPct = v => { if (v <= 0.001) return 0; const db = 20 * Math.log10(v / 0.9); return Math.max(0, Math.min(100, (db + 60) / 66 * 100)); };

  function applyView() {
    const st = $('#stage3'); if (!st) return;
    const v = ui.view;
    st.dataset.view = v;
    $$('.vbtns button').forEach(b => b.classList.toggle('on', b.dataset.view === v));
    const avail = window.innerHeight - 52;
    const def = Math.round(Math.min(avail * 0.37 + 40, (window.innerWidth - 230) / 2 * 9 / 16));   // the transitions sit beside the monitors now, so they get that height
    let h = ui.monH || def;
    h = Math.max(140, Math.min(avail - 250, h));
    st.style.setProperty('--monH', h + 'px');
  }

  function wire() {
    const E = PV.E;
    $('#bRec').onclick = () => UI.send('rec.toggle');
    $('#bStream').onclick = () => { if (!E.st.stream.on && !E.st.stream.dests.some(d => d.on)) { UI.toast('Turn on a destination in Settings › Streaming first'); return; } UI.send('stream.toggle'); };
    $('#bBreak').onclick = () => UI.send('brk.toggle');
    $('#gRec').onclick = () => UI.openSettings('rec');
    $('#gStream').onclick = () => UI.openSettings('stream');
    $('#bReplay').onclick = () => { const on = PV.replayCfg().enabled; PV.setReplay({ enabled: !on }); UI.toast(on ? 'Replays off: no new footage is saved' : 'Replays on'); };
    $('#gReplay').onclick = () => UI.openSettings('replay');
    $('#bSettings').onclick = () => UI.openSettings();
    $('#bUpdate').onclick = () => { if (PV.native) PV.native.post({ type: 'installUpdate' }); };
    if (PV.native && PV.native.update && window.PivotNative) window.PivotNative.update(PV.native.update);
    $('#bProf').onclick = () => UI.openSettings('profile');
    $('#bScreens').onclick = e => { e.stopPropagation(); UI.screensMenu(e.currentTarget); };
    $('#bOut').onclick = e => { e.stopPropagation(); UI.outputsMenu(e.currentTarget); };
    $('#bProto').onclick = () => UI.protocols();
    $('#bAudio').onclick = () => UI.panel('audio');
    $('#bMacros').onclick = () => UI.panel('macros');
    $('#hGame').onclick = () => UI.confirmChangeGame();
    $('#hCount').onclick = e => { e.stopPropagation(); UI.startTimeMenu(e.currentTarget); };
    $('#hCams').onclick = e => {
      e.stopPropagation();
      const n = PV.camIds(E.st).length;
      popMenu(e.currentTarget, Array.from({ length: Math.max(4, n) }, (_, i) => i + 1).map(k => ({ label: `${k} camera${k === 1 ? '' : 's'}`, k, on: k === n, sub: k < n ? `Takes away CAM ${k + 1}${n > k + 1 ? '–' + n : ''}` : '' })), it => { if (it.k !== n) UI.send('cams.count', it.k); });
    };
    $('#thL').onclick = () => UI.tray();
    $('#popRtab').onclick = () => { ui.popR = ui.popR ? false : 'hover'; UI.dirty = true; };   // closes again when the mouse leaves it
    $$('.vbtns button').forEach(b => b.onclick = e => { e.stopPropagation(); ui.view = b.dataset.view; PV.store.set('view', ui.view); applyView(); });
    // drag the bar to resize the monitors
    $('#rsz').addEventListener('pointerdown', e => {
      if (e.target.closest('.vbtns')) return;
      e.preventDefault();
      const y0 = e.clientY, h0 = parseFloat(getComputedStyle($('#stage3')).getPropertyValue('--monH')) || 300;
      document.body.classList.add('resizing');
      const mv = ev => { ui.monH = h0 + (ev.clientY - y0); applyView(); };
      const up = () => { document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); document.body.classList.remove('resizing'); PV.store.set('monH', ui.monH); };
      document.addEventListener('pointermove', mv); document.addEventListener('pointerup', up);
    });
    $('#rsz').addEventListener('dblclick', e => { if (e.target.closest('.vbtns')) return; ui.monH = 0; PV.store.set('monH', 0); applyView(); });
    window.addEventListener('resize', () => { applyView(); UI.dirty = true; });

    // anything that can go to Preview: click puts it there, Shift adds it to the shot
    document.addEventListener('click', e => {
      const p = e.target.closest('[data-pv]'); if (!p || p.closest('.scrim') || e.target.closest('[data-do],[data-gear]')) return;
      const [kind, a, b, c] = p.dataset.pv.split('|');
      const add = e.shiftKey;
      // a click that just took a graphic off air: the rest of a double-click must not bring it back
      if (ui.offAt && ui.offAt.pv === p.dataset.pv && Date.now() - ui.offAt.t < 500) return;
      const gItem = kind === 'cat' ? { t: 'cat', ref: a } : kind === 'tog' ? { t: 'tog', k: a } : kind === 'l3' ? { t: 'l3', spec: { kind: a, side: b, num: c } } : kind === 'pic' ? { t: 'pic', pic: a } : null;
      if (gItem && !add && PV.itemLive(PV.E.st, gItem) && !PV.itemInPv(PV.E.st, gItem)) ui.offAt = { pv: p.dataset.pv, t: Date.now() };
      ui.sel = { kind, a, b, c };
      // a replay on air: its angles are for switching to (double-click), so a click only picks one; Preview stays as it is
      if (kind === 'rp' && PV.E.st.program === 'replay' && PV.E.st.rp.playing) { UI.dirty = true; return; }
      if (kind === 'src') UI.send('pv.src', a, add);
      else if (kind === 'vid') UI.send('pv.vid', a, add);
      else if (kind === 'rp') UI.send('pv.rp', a, b, add);
      else if (kind === 'snd') UI.send('pv.snd', a, add);
      else if (kind === 'cat') UI.send('pv.gfx', { t: 'cat', ref: a }, add);
      else if (kind === 'tog') UI.send('pv.gfx', { t: 'tog', k: a }, add);
      else if (kind === 'pic') UI.send('pv.gfx', { t: 'pic', pic: a }, add);
      else if (kind === 'l3' && a === 'text' && !PV.l3words(PV.E.st, b, c, 'text')) UI.l3Editor(b, c, 'text', () => UI.send('pv.gfx', { t: 'l3', spec: { kind: a, side: b, num: c } }, add));   // type the note first
      else if (kind === 'l3') UI.send('pv.gfx', { t: 'l3', spec: { kind: a, side: b, num: c } }, add);
      UI.dirty = true;
    });
    // double-click takes it straight away
    document.addEventListener('dblclick', e => {
      const p = e.target.closest('[data-pv]'); if (!p || p.closest('.scrim') || e.target.closest('[data-do],[data-gear]')) return;
      if (ui.offAt && ui.offAt.pv === p.dataset.pv && Date.now() - ui.offAt.t < 700) return;   // that double-click took a graphic off air
      // a replay on air: double-clicking one of its angles fades straight to it
      const st = PV.E.st;
      if (/^rp\|/.test(p.dataset.pv) && st.program === 'replay' && st.rp.playing) { const [, id, a] = p.dataset.pv.split('|'); UI.send('rp.live', id, a, p.dataset.pli || null); return; }
      // a graphic goes to air on its own, over whatever Program shows; the shot in Preview stays as it was
      // (the double-click's two clicks put it in Preview and took it back out)
      const [kind, a, b, c] = p.dataset.pv.split('|');
      const item = kind === 'cat' ? { t: 'cat', ref: a } : kind === 'tog' ? { t: 'tog', k: a } : kind === 'l3' ? { t: 'l3', spec: { kind: a, side: b, num: c } } : kind === 'pic' ? { t: 'pic', pic: a } : null;
      if (item) { if (!(item.t === 'tog' && item.k === 'watermark')) UI.send('gfx.air', item); return; }
      UI.send('take');
    });
    // right-click edits
    document.addEventListener('contextmenu', e => {
      // the scorebug ticker: which of today's games it shows
      const tkb = e.target.closest('[data-tkmenu]');
      if (tkb) { e.preventDefault(); UI.tickMenu(tkb); return; }
      const tm = e.target.closest('[data-tmenu]');
      if (tm) { e.preventDefault(); const k = tm.dataset.tmenu; if (k === 'fade') UI.fadeMenu(tm); else if (k === 'wipe') UI.wipeMenu(tm); else if (k.startsWith('del|')) UI.popMenu(tm, [{ label: 'Remove this wipe', id: k.slice(4) }], it => UI.send('trans.del', it.id)); return; }
      // graphics: a menu with Edit and the Favs star
      const fv = e.target.closest('[data-fav]');
      if (fv && !fv.closest('.scrim')) { e.preventDefault(); UI.gfxMenu(fv, UI.favItem(+fv.dataset.fav)); return; }
      const rh = e.target.closest('.rpgh[data-clip]'), rt = e.target.closest('[data-pv^="rp|"]');
      if ((rh || rt) && !(rh || rt).closest('.scrim')) {
        e.preventDefault();
        const st = PV.E.st;
        if (rt) {
          const [, id, a] = rt.dataset.pv.split('|'); ui.sel = { kind: 'rp', a: id, b: a }; UI.dirty = true;
          popMenu(rt, [{ label: 'Trim…', go: () => UI.rpPanel(id, a) }, { label: `Delete ${PV.srcShort(a)} from this play`, sub: 'Delete key', go: () => UI.deletePicked() }], x => x.go());
        } else {
          const id = rh.dataset.clip; ui.sel = { kind: 'rpclip', a: id }; UI.dirty = true;
          const c = st.rp.clips.find(x => x.id === id);
          popMenu(rh, [{ label: 'Trim and rename…', go: () => UI.rpPanel(id) }, { label: `Delete ${c ? c.name : 'this play'}`, sub: 'Every angle · Delete key', go: () => UI.deletePicked() }], x => x.go());
        }
        return;
      }
      const gp = e.target.closest('[data-pv^="cat|"],[data-pv^="l3|"],[data-pv^="tog|"]');
      if (gp && !gp.closest('.scrim')) {
        e.preventDefault();
        const [kind, a, b, c] = gp.dataset.pv.split('|');
        ui.sel = { kind, a, b, c }; UI.dirty = true;
        UI.gfxMenu(gp, kind === 'cat' ? { t: 'cat', ref: a } : kind === 'tog' ? { t: 'tog', k: a } : { t: 'l3', spec: { kind: a, side: b, num: c } });
        return;
      }
      const p = e.target.closest('[data-pv],[data-rdi]'); if (!p || p.closest('.scrim')) return;
      e.preventDefault();
      if (p.dataset.rdi != null) { UI.editRundown(+p.dataset.rdi); return; }
      const [kind, a, b, c] = p.dataset.pv.split('|');
      ui.sel = { kind, a, b, c }; UI.dirty = true; UI.editSelected();
    });
    document.addEventListener('click', e => {
      const gb = e.target.closest('[data-gear]'); if (gb && !gb.closest('.scrim')) { e.stopPropagation(); UI.inputMenu(gb, gb.dataset.gear); return; }
      const b = e.target.closest('[data-do]'); if (!b || b.disabled || b.closest('.scrim')) return;
      const parts = b.dataset.do.split('|').map(x => x === '' ? undefined : (x === 'true' ? true : x === 'false' ? false : (/^-?\d+(\.\d+)?$/.test(x) && !/^0\d/.test(x) ? +x : x)));
      const name = parts.shift();
      if (name.startsWith('ui.')) { e.stopPropagation(); UI.local(name, parts, b, e); return; }
      if (name === 'rd.run') ui.sel = { kind: 'rd', a: parts[0] };
      if (name === 'run') { UI.runAction(parts[0]); return; }
      UI.send(name, ...parts);
    });
    document.addEventListener('change', e => {
      const el = e.target.closest('[data-ch]'); if (!el || el.closest('.scrim')) return;
      const [name, a] = el.dataset.ch.split('|');
      const v = el.type === 'checkbox' ? el.checked : el.value;
      if (name.startsWith('ui.')) { UI.local(name, [a, v], el); return; }
      if (a !== undefined) UI.send(name, isNaN(+a) ? a : +a, v); else UI.send(name, v);
    });
    document.addEventListener('input', e => {
      const el = e.target.closest('[data-in]'); if (!el || el.closest('.scrim')) return;
      const [name, a] = el.dataset.in.split('|');
      if (a !== undefined) UI.send(name, +a, +el.value); else UI.send(name, +el.value);
    });
    document.addEventListener('pointerdown', e => {
      ui.pdown = true;
      const ae = document.activeElement;
      if (ae && ae !== e.target && ae.matches && ae.matches('input[type=text],input:not([type]),textarea') && !ae.contains(e.target)) ae.blur();
    }, true);
    document.addEventListener('pointerup', () => { ui.pdown = false; UI.dirty = true; }, true);
    document.addEventListener('pointercancel', () => { ui.pdown = false; }, true);
  }

  UI.local = function (name, args, el) {
    const E = PV.E;
    if (name.startsWith('ui.pl') && UI.plLocal) { UI.plLocal(name, args, el); return; }
    if (name === 'ui.seg') { const [row, seg] = args; ui.segOpen[row] = (ui.segOpen[row] || curSeg(E.st)) === seg ? '-' : seg; UI.dirty = true; }
    else if (name === 'ui.drawer') UI.drawer(args[0]);
    else if (name === 'ui.rdOpen') { ui.rdOpen = !ui.rdOpen; PV.store.set('rdOpen', ui.rdOpen); UI.dirty = true; }
    else if (name === 'ui.rdEdit') UI.editRundown(args[0]);
    else if (name === 'ui.card') { ui.open[args[0]] = !ui.open[args[0]]; UI.dirty = true; }
    else if (name === 'ui.meNew') UI.meEditor(null);
    else if (name === 'ui.sbPin') { PV.store.set('sbPinned', !PV.store.get('sbPinned', false)); ui.last = {}; applyView(); UI.dirty = true; }
    else if (name === 'ui.addCam') { const n = PV.camIds(E.st).length + 1; const full = PV.replayFull(E.st); popMenu(el, [{ label: `Add CAM ${n} for replay`, sub: full ? `Replay already saves ${PV.MAX_REPLAY} angles. Turn one off first.` : 'Recorded so its angle is in every replay', r: true, disabled: full }, { label: `Add CAM ${n}, live only`, sub: 'Not recorded for replay', r: false }], it => UI.send('cams.add', it.r)); }
    else if (name === 'ui.vidAdd') UI.addVideo(args[0], el);
    else if (name === 'ui.sndAdd') { UI.send('snd.add', 'New sound'); const s = E.st.snds[E.st.snds.length - 1]; ui.sel = { kind: 'snd', a: s.id }; UI.editSelected(); }
    else if (name === 'ui.fadeMenu') UI.fadeMenu(el);
    else if (name === 'ui.wipeMenu') UI.wipeMenu(el);
    else if (name === 'ui.addWipe') UI.addWipeMenu(el);
    else if (name === 'ui.sbdown') UI.send('gfx.lower', { kind: 'down', side: args[0] });
    else if (name === 'ui.sbcard') {
      // pick the player from the team's roster
      const side = args[0], color = args[1], t = E.st.show[side];
      UI.pickPlayer(el, color === 'red' ? 'Red card' : 'Yellow card', (t.roster || []).map(p => UI.playerItem(p, { on: color === 'red' && (t.reds || []).some(r => r.num === String(p[0])) })), it => UI.send('sb.card', side, it.num, color));
    }
    else if (name === 'ui.sbgoal') {
      const side = args[0], sh = E.st.show, t = sh[side];
      UI.pickPlayer(el, 'Goal by', (t.roster || []).map(p => UI.playerItem(p)), it => UI.send('sb.goal', side, it.num));
    }
    else if (name === 'ui.recard') {
      const side = args[0], t = E.st.show[side], sh = E.st.show;
      const list = (t.cards || []).map((c, i) => { const p = PV.player(sh, side, c.num) || [c.num, '', '']; return { label: `${c.color === 'red' ? 'Red' : 'Yellow'} · #${p[0]} ${p[1]} ${p[2]}`.trim(), sub: `${c.minute}'`, i }; }).reverse();
      popMenu(el, list, it => UI.send('sb.recard', side, it.i));
    }
    else if (name === 'ui.kits') { PV.store.set('sbKits', !PV.store.get('sbKits', false)); ui.last = {}; UI.dirty = true; }
    else if (name === 'ui.manual') UI.send('sb.feed', E.st.sb.feed === 'manual' ? 'auto' : 'manual');
    else if (name === 'ui.settings') UI.openSettings(args[0]);
    else if (name === 'ui.flag') UI.send('sb.flag', args[1]);
    else if (name === 'ui.tray') UI.tray();
    else if (name === 'ui.panelClose') UI.panel(null);
    else if (name === 'ui.setclock') {
      const s = String(args[1]).trim();
      let m = /^(\d{1,2}):(\d{2})$/.exec(s), ms;
      if (m) ms = (+m[1] * 60 + +m[2]) * 1000; else if ((m = /^(\d{1,2})(?:\.(\d))?$/.exec(s))) ms = (+m[1]) * 1000 + (+(m[2] || 0)) * 100;
      if (ms == null) { UI.toast('Type the time like 12:00 or 45.3'); return; }
      UI.send('sb.setClock', ms); el.value = ''; el.blur();
    }
  };

  /* ---------- per-frame drawing ---------- */
  const thumbs = { i: 0 };
  function pvState(st) {
    return Object.assign({}, st, { program: st.preview, gfx: PV.pvGfx(st), trans: Object.assign({}, st.trans, { active: null }), rp: Object.assign({}, st.rp, { playing: null }), brk: false });
  }
  function frame() {
    requestAnimationFrame(frame);
    const E = PV.E, st = E.st, t = Date.now();
    ui.frame++;
    if (document.hidden) return;
    const pg = $('#monPgm canvas'), pv = $('#monPvw canvas');
    // in the Mac app the real video sits behind the page, so the monitors stay see-through
    if (!PV.native) {
      if (pg && ui.view !== 'pvw') { const [w, h] = UI.fit(pg, 1600); UI.drawProgram(pg.getContext('2d'), w, h, st, t); }
      if (pv && ui.view !== 'pgm' && ui.frame % 2 === 0) { const [w, h] = UI.fit(pv, 1280); UI.drawPreview(pv.getContext('2d'), w, h, st, t); }
    }
    if (UI.stage && ui.view !== 'pvw') UI.stage.update(st, t);
    // the replay on air: a line along the bottom of its angle's tile shows how far through it is
    const sg = st.program === 'replay' && st.rp.playing && PV.rpSeg(st.rp.playing);
    const playKey = sg ? `rp|${sg.clip}|${sg.cam}` : '';
    document.querySelectorAll('.rt3 .rptl').forEach(el => {
      // a playlist's angle: the playlist item and camera playing (its play may be gone from All replays)
      const tile = el.parentNode, on = !!sg && (tile.dataset.pli ? tile.dataset.pli === sg.item && tile.dataset.pv.split('|')[2] === sg.cam : tile.dataset.pv === playKey);
      tile.classList.toggle('playing', on);
      let u = 0;
      if (on) { const rp = st.rp.playing, len = Math.max(0.1, sg.tOut - sg.tIn); u = Math.max(0, Math.min(1, (t - rp.start) / 1000 * rp.speed / len)); }
      const w = (u * 100).toFixed(2) + '%', bar = el.firstChild;
      if (bar.style.width !== w) bar.style.width = w;
    });
    if (UI.pvStage && ui.view !== 'pgm') UI.pvStage.update(pvState(st), t);
    // live thumbnails: a few per frame
    const live = $$('canvas[data-live]');
    for (let n = 0; n < 3 && live.length; n++) {
      thumbs.i = (thumbs.i + 1) % live.length;
      const c = live[thumbs.i];
      const src = c.dataset.live;
      if (PV.native && PV.native.handles(src)) continue;
      const [w, h] = UI.fit(c, 320);
      if (PV.isME(src)) drawME(c.getContext('2d'), w, h, PV.meById(st, src.slice(3)), st, t, { thumb: true });
      else UI.drawSource(c.getContext('2d'), w, h, src, st, t);
    }
    if (ui.frame % 15 === 0) drawStill(st);
    if (ui.view !== 'pgm' && ui.frame % 2 === 0) meters($('#mtrPvw'), UI.levels(st, t, st.preview));
    if (ui.view !== 'pvw' && ui.frame % 2 === 1) meters($('#mtrPgm'), UI.levels(st, t));
    live2(st, t);
    if (UI.dirty) { UI.dirty = false; render(); }
    if (ui.settings && ui.frame % 6 === 0 && UI.settingsFrame) UI.settingsFrame(t);
  }
  function meters(el, L) {
    if (!el) return;
    const b = el.querySelectorAll('.mb i'); if (b.length < 2) return;
    b[0].style.height = (100 - dbPct(L.L)) + '%'; b[1].style.height = (100 - dbPct(L.R)) + '%';
  }
  /* stills for videos and replay angles, drawn once per in point */
  function drawStill(st) {
    const look = PV.lookFor(st.show), game = PV.gameFor(st.show);
    $$('canvas[data-still]').forEach(c => {
      const key = c.dataset.still; if (c.dataset.drawn === key) return;
      c.width = 256; c.height = 144;
      const [kind, a, b] = key.split('|');
      if (kind === 'vid') {
        const v = PV.vidItem(st, a);
        if (v && /^file:/.test(v.ref)) { if (!(PV.native && PV.native.drawSnap(c.getContext('2d'), 256, 144, `${v.ref}@${(+v.tIn + 1).toFixed(2)}`, { key: 'still:' + key }))) return; }
        else if (v) S.drawClip(c.getContext('2d'), 256, 144, v.ref, Math.min(v.tOut, v.tIn + 1.2), look);
      }
      else if (kind === 'rpt') {   // a camera's replay footage at a moment (playlist copies)
        if (PV.native) { if (!PV.native.drawSnap(c.getContext('2d'), 256, 144, `replay:${a}@${Math.round(PV.wallOf(st, +b))}`, { key: 'still:' + key })) return; }
        else S.drawCamera(c.getContext('2d'), 256, 144, a, +b, game, look);
      }
      else if (kind === 'vref') {   // a video file or clip at a moment (playlist copies)
        if (/^file:/.test(a)) { if (!(PV.native && PV.native.drawSnap(c.getContext('2d'), 256, 144, `${a}@${(+b + 1).toFixed(2)}`, { key: 'still:' + key }))) return; }
        else if (S.CLIPS[a]) S.drawClip(c.getContext('2d'), 256, 144, a, +b + 1.2, look);
      }
      else if (kind === 'rp') {
        const cl = st.rp.clips.find(x => x.id === a);
        if (cl) {
          const ct = PV.cut(cl, b), at = ct.tIn + (ct.tOut - ct.tIn) * 0.6;
          if (PV.native) { if (!PV.native.drawSnap(c.getContext('2d'), 256, 144, `replay:${b}@${Math.round(PV.wallOf(st, at))}`, { key: 'still:' + key })) return; }
          else S.drawCamera(c.getContext('2d'), 256, 144, b, at, game, look);
        }
      }
      c.dataset.drawn = key;
    });
  }

  function live2(st, t) {
    const sb = st.sb;
    const clk = ['half', 'final', 'break'].includes(sb.status) ? G.periodText(sb, st.show.rules) : G.clockText(G.sbClockMs(sb, t));
    $$('[data-clk]').forEach(ck => { if (ck.dataset.editing) return; if (ck.textContent !== clk) ck.textContent = clk; ck.classList.toggle('stop', !sb.running); });
    countdown(st, t);
    const tod = $('#tod'); if (tod && ui.frame % 15 === 0) tod.textContent = new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const r = $('#tRec'); if (r) r.textContent = st.rec.on ? UI.hms(t - st.rec.start) : 'Off';
    const s = $('#tStream'); if (s) s.textContent = st.stream.on ? UI.hms(t - st.stream.start) : 'Off';
    const recGb = $('#recGb'); if (recGb) recGb.textContent = st.rec.on ? (recRate(st) * (t - st.rec.start) / 3600000).toFixed(2) + ' GB' : '—';
    const kb = $('#kbps'); if (kb && ui.frame % 15 === 0) kb.textContent = st.stream.on ? Math.round(st.stream.kbps * (0.94 + 0.08 * S.noise(t / 900))) + ' kbps' : '—';
    const pa = st.pl.active;
    $$('[data-itemleft]').forEach(el => { if (!pa) { el.textContent = ''; return; } const list = st.pl.lists.find(l => l.id === pa.list); const it = list && list.items[pa.idx]; el.textContent = it && it.dur ? '-' + UI.ms(it.dur - (t - pa.start) / 1000) : 'On'; });
    const lv = st.pl.last;
    $$('[data-vidleft]').forEach(el => { const on = st.program === 'video' && lv && lv.id === el.dataset.vidleft; const txt = on ? '-' + UI.ms(Math.max(0, ((lv.tOut - lv.tIn) - (t - lv.start) / 1000 * (lv.speed || 1)) / (lv.speed || 1))) : el.dataset.len; if (el.textContent !== txt) el.textContent = txt; });
    if ($('.fpanel [data-meter]')) {
      const L = UI.levels(st, t);
      $$('.fpanel [data-meter]').forEach(m => {
        const k = m.dataset.meter; let v;
        if (k === 'L') v = L.L; else if (k === 'R') v = L.R; else if (k === 'v') v = Math.max(L.ch[0], L.ch[1]); else if (k === 'n') v = Math.max(L.ch[2], L.ch[3]); else v = L.ch[+k];
        m.firstElementChild.style.height = Math.round(Math.min(1, v) * 100) + '%';
      });
    }
    if (ui.frame % 30 === 0) $$('[data-ago]').forEach(el => { el.textContent = UI.ago(+el.dataset.ago); });
    const mon = $('#bdPgm');
    if (mon && ui.frame % 10 === 0) {
      const b = [];
      if (st.brk) b.push('<em>BREAK</em>');
      if (st.program === 'replay' && st.rp.playing) b.push('<em class="r">REPLAY</em>');
      if (st.sndPlay) b.push(`<em>♪ ${esc((st.snds.find(x => x.id === st.sndPlay.id) || {}).name || '')}</em>`);
      if (st.macro.running) b.push(`<em>MACRO · ${esc(st.macro.running.name)}</em>`);
      if (st.macro.recording) b.push('<em class="r">RECORDING MACRO</em>');
      if (st.sb.op === 'phone') b.push('<em>SCOREBUG FROM PHONE</em>');
      const html = b.join(''); if (mon.innerHTML !== html) mon.innerHTML = html;
    }
  }
  /* ---------- countdown to the start time, in the title bar ---------- */
  // the start time for this game: what the schedule says, unless the operator moved it
  UI.startAt = function (st) {
    const o = PV.store.get('startAt', null), g = st.show.game || {};
    if (o && o.game === g.id && isFinite(o.at)) return o.at;
    const t = Date.parse(g.at || ''); return isFinite(t) ? t : null;
  };
  let cdLast = '';
  function countdown(st, t) {
    const el = $('#hCount'); if (!el) return;
    const at = UI.startAt(st);
    if (at == null) { el.hidden = true; return; }
    const ms = at - t;
    // a game more than a day away isn't counted
    if (ms > 864e5) { el.hidden = true; return; }
    el.hidden = false;
    const s = Math.ceil(ms / 1000), a = Math.abs(s);
    const h = Math.floor(a / 3600), m = Math.floor(a / 60) % 60, sec = a % 60;
    const txt = s > 10 ? (h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`)
      : s > 0 ? String(s) : `+${h ? h + ':' + String(m).padStart(2, '0') : m}:${String(sec).padStart(2, '0')}`;
    const cls = s <= 0 ? 'past' : s <= 10 ? 'final' : s <= 600 ? 'soon' : '';
    const key = txt + '|' + cls;
    if (key === cdLast) return;
    cdLast = key;
    el.className = 'cdown' + (cls ? ' ' + cls : '');
    el.querySelector('small').textContent = s > 0 ? 'STARTS IN' : 'SINCE START';
    el.querySelector('b').textContent = txt;
  }
  UI.startTimeMenu = function (anchor) {
    closeMenus();
    const st = PV.E.st, at = UI.startAt(st), d = new Date(at || Date.now());
    const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    const listed = Date.parse((st.show.game || {}).at || '');
    const m = document.createElement('div'); m.className = 'menu inmenu';
    m.innerHTML = `<div class="cardh">Start time<span class="sp"></span><button class="btn sm ghost" data-x="close">Done</button></div>
      <div class="fld"><label>Count down to</label><input type="time" id="stTime" value="${hm}"></div>
      <div class="row" style="gap:6px;flex-wrap:wrap">${[5, 10, 15, 30].map(n => `<button class="btn sm" data-add="${n}">+${n} min</button>`).join('')}</div>
      ${isFinite(listed) ? `<button class="btn sm ghost" data-reset="1">Back to the listed time (${esc(PV.fmtTime(new Date(listed).toISOString()))})</button>` : ''}`;
    document.body.appendChild(m);
    const r = anchor.getBoundingClientRect();
    m.style.left = Math.max(8, Math.min(r.left, window.innerWidth - 300)) + 'px'; m.style.top = (r.bottom + 6) + 'px';
    const set = ms => { PV.store.set('startAt', { game: (st.show.game || {}).id, at: ms }); cdLast = ''; const i = m.querySelector('#stTime'); const dd = new Date(ms); i.value = `${String(dd.getHours()).padStart(2, '0')}:${String(dd.getMinutes()).padStart(2, '0')}`; };
    m.querySelector('#stTime').addEventListener('change', e => {
      const [hh, mm] = e.target.value.split(':').map(Number); if (!isFinite(hh) || !isFinite(mm)) return;
      const base = new Date(UI.startAt(st) || Date.now()); base.setHours(hh, mm, 0, 0); set(base.getTime());
    });
    m.addEventListener('click', e => {
      const a = e.target.closest('[data-add]'); if (a) { set((UI.startAt(st) || Date.now()) + +a.dataset.add * 60000); return; }
      if (e.target.closest('[data-reset]')) { PV.store.set('startAt', null); cdLast = ''; closeMenus(); return; }
      if (e.target.closest('[data-x]')) closeMenus();
    });
    setTimeout(() => document.addEventListener('pointerdown', function off(ev) { if (!m.contains(ev.target)) { closeMenus(); document.removeEventListener('pointerdown', off, true); } }, true), 0);
  };

  function recRate(st) { const f = PV.FORMATS[st.rec.fmt]; const n = Object.values(st.rec.feeds).filter(Boolean).length; return PV.gbPerHour(f.mbps[st.rec.q]) * n; }
  UI.recRate = recRate;

  function put(el, html, key) {
    if (!el) return;
    if (ui.last[key] === html) return;
    const ae = document.activeElement;
    if (ae && el.contains(ae) && (ae.matches('input[type=text],input:not([type]),textarea') || (ae.matches('input[type=range]') && ui.pdown))) return;
    if (ui.last[key] != null && MORPH.has(key)) { const t = document.createElement('div'); t.innerHTML = html; morph(el, t); }
    else el.innerHTML = html;
    ui.last[key] = html;
  }
  /* Busy areas are updated in place: only what changed is touched, so pictures don't blank and redraw on every click. */
  const MORPH = new Set(['rows', 'tcol']);
  const KEEP_ATTR = new Set(['width', 'height', 'data-drawn', 'data-fmt', 'style']);
  const KEEP_CLASS = ['nosig'];
  function morph(a, b) {
    const an = a.childNodes, bn = b.childNodes;
    if (an.length !== bn.length) { a.innerHTML = b.innerHTML; return; }
    for (let i = 0; i < bn.length; i++) {
      const x = an[i], y = bn[i];
      if (x.nodeType !== y.nodeType || (x.nodeType === 1 && x.tagName !== y.tagName)) { a.replaceChild(y.cloneNode(true), x); continue; }
      if (x.nodeType !== 1) { if (x.nodeValue !== y.nodeValue) x.nodeValue = y.nodeValue; continue; }
      if (x.outerHTML === y.outerHTML) continue;
      for (const at of [...x.attributes]) if (!y.hasAttribute(at.name) && !KEEP_ATTR.has(at.name)) x.removeAttribute(at.name);
      for (const at of [...y.attributes]) {
        if (at.name === 'class') { const keep = KEEP_CLASS.filter(c => x.classList.contains(c)); const v = [at.value].concat(keep.filter(c => !y.classList.contains(c))).join(' ').trim(); if (x.getAttribute('class') !== v) x.setAttribute('class', v); }
        else if (x.getAttribute(at.name) !== at.value) x.setAttribute(at.name, at.value);
      }
      if (x.tagName === 'CANVAS') continue;
      if (x.innerHTML !== y.innerHTML) morph(x, y);
    }
  }
  /* re-render without losing the scroll position of the rows */
  function keepScroll(el, html, key) {
    if (!el) return;
    const sc = {};
    el.querySelectorAll('[data-scroll]').forEach(s => { sc[s.dataset.scroll] = [s.scrollLeft, s.scrollTop]; });
    const top = el.scrollTop;
    put(el, html, key);
    el.scrollTop = top;
    el.querySelectorAll('[data-scroll]').forEach(s => { const v = sc[s.dataset.scroll]; if (v) { s.scrollLeft = v[0]; s.scrollTop = v[1]; } });
  }

  function render() {
    const E = PV.E, st = E.st, sh = st.show;
    const map = PV.shortcuts();
    document.body.classList.toggle('recording', st.rec.on);
    // matchup and sport; then the date, the league and the graphics package ("NEC on Pivot Arena")
    $('#hShow').textContent = `${sh.away.code} at ${sh.home.code}`;
    const tpl = PV.allTemplates().find(x => x.id === st.tpl.id);
    const pk = (G.PACKAGES[st.gfx.pkg] || G.PACKAGES.standard).name;
    $('#hCams b').textContent = PV.camIds(st).length;
    // a look can bring its network's protocols (ESPN's: transmission, changes, weather delays, the close and the watermark)
    const proto = (G.pkgOf(st.gfx.pkg) || {}).build, pr = proto && proto.protocols, pb = $('#bProto');
    if (pb) { pb.hidden = !pr; if (pr && pb.textContent !== pr.title.toUpperCase()) { pb.textContent = pr.title.toUpperCase(); pb.title = pr.title; } }
    $('#hTpl').textContent = [(window.PIVOT_DATA.SPORTS || {})[sh.sport] || '', PV.fmtDate(sh.game.at, { weekday: 'short', month: 'short', day: 'numeric' }), `${(tpl && tpl.league) || 'NEC'} on ${pk}`].filter(Boolean).join(' · ');
    $('#bRec').classList.toggle('on', st.rec.on);
    $('#bStream').classList.toggle('on', st.stream.on);
    { const rc = PV.replayCfg(), t = $('#tReplay'); $('#bReplay').classList.toggle('on', rc.enabled); if (t) t.textContent = rc.enabled ? rc.minutes + ' min' : 'Off'; }
    $('#bBreak').classList.toggle('on', st.brk);
    $('#pName').textContent = st.profile.name;
    $('#pInit').textContent = (st.profile.name || 'D').slice(0, 2).toUpperCase();
    const days = Math.max(0, Math.ceil((st.profile.trialEnds - Date.now()) / 864e5));
    $('#pTrial').textContent = `Trial · ${days} day${days === 1 ? '' : 's'} left`;
    $('#lPvw').textContent = pvLabel(st);
    $('#lPgm').textContent = PV.srcLabel(st, st.program);
    put($('#tcol'), transCol(st, map), 'tcol');
    put($('#aBtns'), audioBtns(st), 'abtns');
    keepScroll($('#rows'), rowsHtml(st, map), 'rows');
    const dock = $('#rdock'); dock.classList.toggle('closed', !ui.rdOpen);
    const L0 = $('#rdList'), sTop = L0 ? L0.scrollTop : 0;
    // Suggested sits above the rundown's list
    put(dock, (ui.rdOpen ? `<div class="card rdsug" id="cSug">${sugCard(st, map)}</div>` : '') + rdDock(st, map), 'rd');
    const Lr = $('#rdList');
    if (Lr) {
      if (L0) Lr.scrollTop = sTop;
      const f = st.pv.rd != null ? st.pv.rd : st.rd.on && !st.rd.follow ? st.rd.idx : st.rd.cue;   // the clock moved it: show where it went
      const key = f + '|' + ui.rdOpen;
      if (ui.rdKey !== key) { ui.rdKey = key; const el = Lr.querySelector(`[data-i="${Math.max(0, f - 1)}"]`); if (el) Lr.scrollTo({ top: Math.max(0, el.offsetTop - 34), behavior: L0 ? 'smooth' : 'auto' }); }
    }
    $('#trayL').classList.toggle('open', !!ui.trayL); $('#thL').classList.toggle('open', !!ui.trayL);
    if (ui.popR && PV.store.get('sbPinned', false)) ui.popR = false;   // pinned: the scoreboard isn't in the pop-out
    $('#popR').classList.toggle('open', !!ui.popR);
    put($('#trayL'), trayLeft(st, map), 'trayL');
    // the scoreboard can be pinned beside Program (for running it by hand); then it leaves the pop-out
    const pin = !!PV.store.get('sbPinned', false), pinEl = $('#sbPin');
    $('#stage3').classList.toggle('pinned', pin);
    pinEl.hidden = !pin; $('#cSb').hidden = pin;
    if (pin) put(pinEl, sbCard(st, map, true), 'sbpin');
    if (ui.popR && !pin) put($('#cSb'), sbCard(st, map), 'sb');
    $('#popRtab').hidden = pin;
    put($('#popRtab'), `<span>SCOREBUG</span>${!st.sb.boxOk ? '<b class="bad">!</b>' : ''}`, 'poptab');
    if ($('.menu.outputs')) put($('.menu.outputs'), (UI.outputsHtml || outputsHtml)(st), 'outmenu');
    if (ui.panel) renderPanel(st, map);
    if (ui.settings && UI.renderSettings) UI.renderSettings();
  }
  UI.render = () => { ui.last = {}; render(); };
  const K = (map, id) => map[id] ? `<kbd>${esc(PV.keyLabel(map[id]))}</kbd>` : '';
  UI.K = K;

  function pvLabel(st) {
    const pv = st.pv || {};
    let base = PV.srcLabel(st, st.preview);
    if (st.preview === 'video' && pv.vid) base = 'VIDEO · ' + ((PV.vidItem(st, pv.vid) || {}).name || '');
    if (st.preview === 'replay' && pv.rp) base = `REPLAY · ${PV.srcShort(pv.rp.ang)}`;
    const extra = (pv.gfx || []).map(it => it.t === 'raw' ? (it.obj.label || 'Graphic') : it.t === 'pic' ? ((PV.lookPic(st, it.pic) || {}).name || 'Graphic') : it.t === 'cat' ? PV.gfxName(it.ref) : it.t === 'tog' ? ({ scorebug: 'Scorebug', watermark: 'Watermark', ticker: 'Ticker', big: 'Big score' }[it.k]) : 'Lower third');
    if (pv.snd) extra.push('♪ ' + ((st.snds.find(s => s.id === pv.snd) || {}).name || ''));
    return base + (extra.length ? '  +  ' + extra.join(' + ') : '');
  }

  /* ---------- transitions row ---------- */
  const WIPE_KIND = { pkg: 'Graphics package wipe', team: 'Team colors and logo', logo: 'League logo', player: 'Player interstitial', sponsor: 'Sponsor' };
  /* the transitions: a narrow column between Preview and Program. Right-click Fade for its length, Wipe for every wipe. */
  /* like a switcher's two speaker buttons: the program sound going out, and the sound you hear on this Mac */
  const ICON = {
    spk: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    spkOff: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16.5 9.5l5 5m0-5l-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    hp: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 15v-3a8 8 0 0 1 16 0v3" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="3" y="14" width="5" height="7" rx="1.5" fill="currentColor"/><rect x="16" y="14" width="5" height="7" rx="1.5" fill="currentColor"/></svg>',
    hpOff: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 15v-3a8 8 0 0 1 16 0v3" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="3" y="14" width="5" height="7" rx="1.5" fill="currentColor"/><rect x="16" y="14" width="5" height="7" rx="1.5" fill="currentColor"/><path d="M3 3l18 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
  };
  function audioBtns(st) {
    const a = st.audio, pOn = !a.pgmMute, hOn = !!a.hp;
    return `<button class="abtn${pOn ? ' on' : ' off'}" data-do="audio.pgm" aria-pressed="${pOn}" title="${pOn ? 'Program sound is going to the stream and recording. Click to mute it.' : 'Program sound is MUTED on the stream and recording. Click to turn it back on.'}">${pOn ? ICON.spk : ICON.spkOff}</button>`
      + `<button class="abtn${hOn ? ' on' : ''}" data-do="audio.hp" aria-pressed="${hOn}" title="${hOn ? 'You hear the program on this Mac. Click to stop.' : 'Click to hear the program on this Mac (speakers or headphones)'}">${hOn ? ICON.hp : ICON.hpOff}</button>`;
  }
  function transCol(st, map) {
    const tr = st.trans, sel = tr.sel || 'cut', sh = st.show;
    const wipes = PV.wipesOf(st), main = wipes.find(w => w.id === 'replay') || wipes[0];
    const extra = wipes.filter(w => w !== main);
    const label = w => w.kind === 'team' && sh[w.side] ? sh[w.side].code : w.kind === 'player' && sh[w.side] ? sh[w.side].code + ' #' : w.kind === 'logo' ? 'LEAGUE' : w.kind === 'sponsor' ? 'SPONSOR' : w.name;
    const b = (id, text, tip, extraAttr) => `<button class="tcb${sel === id ? ' on' : ''}" data-do="trans.sel|${id}" title="${esc(tip)}"${extraAttr || ''}>${text}</button>`;
    return b('cut', 'CUT', 'Enter always cuts. With Cut picked, Space cuts too (but replays wipe)')
      + b('fade', `FADE<small>${(tr.dur / 1000).toFixed(1)}s</small>`, 'Fade on Take · right-click for the length', ' data-tmenu="fade"')
      + b(main.id, `WIPE${K(map, 'wipeSel')}`, `${main.name} on Take · right-click for every wipe`, ' data-tmenu="wipe"')
      + extra.map(w => b(w.id, esc(label(w)), `${w.name} wipe on Take${['away', 'home'].includes(w.id) ? '' : ' · right-click to remove'}`, ['away', 'home'].includes(w.id) ? '' : ` data-tmenu="del|${esc(w.id)}"`)).join('')
      + `<button class="tcb add" data-do="ui.addWipe" title="Add a transition">+</button>`
      + `<button class="tgo" data-do="take" title="Take Preview to Program with the picked transition (Space)">TAKE</button>`;
  }

  /* a team's players to pick from (goal, sub, card): number and name, nothing else, in a tight list */
  UI.playerItem = (p, extra) => Object.assign({ label: [p[1], p[2]].filter(Boolean).join(' '), num: p[0] }, extra);
  UI.pickPlayer = (el, title, list, onPick) => popMenu(el, [{ label: title, disabled: true, head: true }].concat(list), onPick, 'pmenu' + (list.length > 14 ? ' two' : ''));

  /* ---------- the layer rows ---------- */
  /* Team stats and Sub… in the scorebug panel work like any graphic: click for Preview, double-click for air,
     right-click or ⌘E to change what's in them */
  const compsItem = () => ({ t: 'l3', spec: { kind: 'comps', picks: PV.store.get('compsPick', ['Corner kicks']), side: 'both', num: '' } });
  UI.statsLive = st => !!(st.gfx.lower && /^comps/.test(st.gfx.lower.key || ''));
  UI.statsInPv = st => (st.pv.gfx || []).some(x => x.t === 'l3' && x.spec.kind === 'comps');
  const subPv = (st, side) => (st.pv.gfx || []).find(x => x.t === 'raw' && x.obj && x.obj.kind === 'subs' && x.obj.side === side);
  UI.subLive = (st, side) => !!(st.gfx.take && st.gfx.take.kind === 'subs' && st.gfx.take.side === side);
  UI.subInPv = (st, side) => !!subPv(st, side);
  UI.pickSub = function (el, side, then) {
    const t = PV.E.st.show[side];
    UI.pickPlayer(el, 'Coming on', (t.roster || []).map(p => UI.playerItem(p)), on => setTimeout(() => {
      UI.pickPlayer(el, `Going off for #${on.num}`, (t.roster || []).filter(p => p[0] !== on.num).map(p => UI.playerItem(p)), off => then(on.num, off.num));
    }, 0));
  };
  const cdSingle = (el, what, side) => {
    const st = PV.E.st;
    ui.sel = { kind: 'sbg', a: what, b: side }; UI.dirty = true;
    if (what === 'stats') UI.send('pv.gfx', compsItem(), false);
    else UI.pickSub(el, side, (a, b) => UI.send('sb.sub', side, a, b));   // picking who goes off puts it up
  };
  const cdDouble = (el, what, side) => {
    const st = PV.E.st;
    if (what === 'stats') { if (UI.statsInPv(st)) UI.send('pv.gfx', compsItem(), false); UI.send('gfx.air', compsItem()); }
    else { const it = subPv(st, side); if (it) UI.send('gfx.air', it); else UI.pickSub(el, side, (a, b) => UI.send('sb.sub', side, a, b)); }
  };
  UI.sbgEdit = (el, what, side) => {
    if (what === 'stats') UI.teamStats();
    else UI.pickSub(el || document.querySelector(`[data-cd="sub|${side}"]`) || document.body, side, (a, b) => UI.send('sb.sub', side, a, b));
  };
  // a click waits a moment to see whether a second one makes it a double-click
  let cdTimer = null;
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-cd]'); if (!b) return;
    const [what, side] = b.dataset.cd.split('|');
    if (e.detail >= 2) { clearTimeout(cdTimer); cdTimer = null; if (e.detail === 2) cdDouble(b, what, side); return; }
    clearTimeout(cdTimer); cdTimer = setTimeout(() => { cdTimer = null; cdSingle(b, what, side); }, 260);
  });
  document.addEventListener('click', e => {
    const g = e.target.closest('[data-cdgear],[data-tkgear]'); if (!g) return;
    e.stopPropagation();
    if (g.hasAttribute('data-tkgear')) UI.tickMenu(g); else UI.sbgEdit(g.previousElementSibling, g.dataset.cdgear);
  }, true);
  document.addEventListener('contextmenu', e => {
    const b = e.target.closest('[data-cd]'); if (!b) return;
    e.preventDefault(); const [what, side] = b.dataset.cd.split('|'); UI.sbgEdit(b, what, side);
  });
  const tally = (onPgm, inPvw) => (onPgm ? ' pgm' : '') + (inPvw ? ' pvw' : '');
  const isSel = (kind, a, b, c) => { const s = ui.sel; return s && s.kind === kind && s.a === a && (b == null || s.b === b) && (c == null || s.c === c) ? ' sel' : ''; };
  function rowsHtml(st, map) {
    const pvBase = st.preview, pgm = st.program;
    const keyFor = { cam1: 'pvw1', cam2: 'pvw2', cam3: 'pvw3', cam4: 'pvw4', black: 'pvwB' };
    const empty = id => PV.native && PV.native.noDevice && PV.native.noDevice(id);
    const camIds = PV.camIds(st);
    const addCam = camIds.length < PV.MAX_CAMS ? `<button class="tl3 plus" data-do="ui.addCam" title="Add a camera">+<small>Add camera</small></button>` : '';
    const tile = id => `<div class="tl3${tally(pgm === id, pvBase === id)}${isSel('src', id)}" data-pv="src|${id}" title="Click: Preview · Shift-click: add to the shot · Double-click: take">
      <canvas data-live="${id}"></canvas>${/^cam/.test(id) ? `<button class="gear" data-gear="${id}" title="Camera settings" aria-label="Settings for ${PV.srcShort(id)}">⚙</button>` : ''}${/^cam/.test(id) && empty(id) ? `<button class="addcam" data-gear="${id}" title="Choose the camera for ${PV.srcShort(id)}" aria-label="Choose the camera for ${PV.srcShort(id)}">+</button>` : ''}
      ${/^cam/.test(id) && !PV.replayCams(st).includes(id) ? '<span class="noreplay" title="Not recorded for replay">LIVE ONLY</span>' : ''}<span class="tln"><b>${PV.srcShort(id)}</b>${/^cam/.test(id) ? ' ' + esc(st.inputs[id].name) : ''}${K(map, keyFor[id])}</span></div>`;
    const camT = camIds.map(tile).join('') + addCam + `<div class="tlstack">${['black', 'bars'].map(tile).join('')}</div>`;
    // M/Es are named buttons: a thumbnail this small can't show what a layout is
    const meT = st.me.list.map(m => `<button class="meb${tally(pgm === 'me:' + m.id, pvBase === 'me:' + m.id)}${isSel('src', 'me:' + m.id)}" data-pv="src|me:${esc(m.id)}" title="Click: Preview · Double-click: take · Right-click or ⌘E: edit">${esc(m.name)}</button>`).join('') + `<button class="meb add" data-do="ui.meNew" title="Build a new M/E">+ New M/E</button>`;
    // Pivot GFX: graphics only
    if (PV.GFX_ONLY) {
      // the Graphics tray, then a notes tray for each team; V or H opens a team's tray into everything for that team
      const other = ui.drawer && ui.drawer !== 'away' && ui.drawer !== 'home' ? drawerHtml(st, map) : '';
      return shortcutBar(st, map) + gfxRow(st) + other + teamTray(st, map, 'away') + teamTray(st, map, 'home');
    }
    let html = row('Cameras', camT, 'cams') + row('M/E', meT, 'mes') + shortcutBar(st, map);
    // double-click a row's name and that row takes the whole lower area, with bigger pictures
    const lower = { gfx: () => gfxRow(st), vid: () => vidRow(st), rps: () => rpRow(st, map), snds: () => sndRow(st) };
    html += ui.drawer ? drawerHtml(st, map) : ui.expand && lower[ui.expand] ? lower[ui.expand]() : gfxRow(st) + rpRow(st, map) + vidRow(st) + sndRow(st);
    return html;
  }
  const EXPANDS = ['gfx', 'vid', 'rps', 'snds'];
  const row = (label, body, key) => { const x = EXPANDS.includes(key), big = x && ui.expand === key;
    return `<div class="row3 ${key}${big ? ' big' : ''}"><div class="rlab"${x ? ` data-expand="${key}" title="Double-click to ${big ? 'shrink it back' : 'make this row bigger'}"` : ''}><span>${label}</span></div><div class="rbody" data-scroll="${key}">${body}</div></div>`; };
  /* click a play's name bar to pick the whole play (Delete removes it) */
  document.addEventListener('click', e => {
    const h = e.target.closest('.rpgh[data-clip]'); if (!h || e.target.closest('button')) return;
    ui.sel = { kind: 'rpclip', a: h.dataset.clip }; UI.dirty = true;
  });
  /* by hand: click the clock or a score and type over it; Enter or clicking away puts it on air */
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-sbedit].editable'); if (!el || el.querySelector('input')) return;
    const [what, side] = el.dataset.sbedit.split('|');
    const f = document.createElement('input'); f.type = 'text'; f.className = 'inp sbin tc';
    f.value = what === 'clock' ? el.textContent.trim() : String(PV.E.st.sb.score[side]);
    if (what === 'clock') { const sb = PV.E.st.sb; if (sb.running) UI.send('sb.clock'); }   // the clock stops while it's typed
    el.dataset.editing = '1'; el.textContent = ''; el.appendChild(f); f.focus(); f.select();
    let gone = false;
    const done = save => {
      if (gone) return; gone = true; delete el.dataset.editing;
      const v = f.value.trim(); f.remove();
      if (save && v) {
        if (what === 'score') UI.send('sb.setScore', side, v);
        else UI.local('ui.setclock', ['x', v], { value: '', blur() {} });
      }
      ui.last = {}; UI.dirty = true;
    };
    f.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Enter') { ev.preventDefault(); done(true); } else if (ev.key === 'Escape') { ev.preventDefault(); done(false); } });
    f.addEventListener('blur', () => done(true));
  });
  UI.renderNow = () => render();
  /* ⌘R on a graphic or a sound: its name becomes a field, ready to type over */
  UI.renameTile = function (kind, id) {
    const st = PV.E.st;
    if (kind === 'snd' && (!st.snds.some(s => s.id === id) || id === 'tone')) return;
    ui.renTile = kind + '|' + id; render();
    const f = document.querySelector(`[data-tren="${kind}|${id}"]`); if (!f) { ui.renTile = null; return; }
    f.focus(); f.select();
    let gone = false;
    const done = save => {
      if (gone) return; gone = true; ui.renTile = null;
      const v = f.value.trim();
      if (save && v) { if (kind === 'cat') UI.send('gfx.name', id, v); else UI.send('snd.edit', id, { name: v }); }
      f.blur(); UI.dirty = true;
    };
    f.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') { e.preventDefault(); done(true); } else if (e.key === 'Escape') { e.preventDefault(); done(false); } });
    f.addEventListener('blur', () => done(true));
    f.addEventListener('click', e => e.stopPropagation());
  };
  const renField = (kind, id, name) => `<input type="text" class="inp tren" value="${esc(name)}" maxlength="40" data-tren="${kind}|${esc(id)}" aria-label="Name">`;
  /* ⌘R: the play's name becomes a field, ready to type over */
  UI.renamePlay = function (id) {
    if (!PV.E.st.rp.clips.some(c => c.id === id)) return;
    ui.renaming = id; render();
    const f = document.querySelector(`[data-ren="${id}"]`); if (!f) return;
    f.focus(); f.select();
    const done = save => {
      if (ui.renaming !== id) return;
      ui.renaming = null;
      if (save && f.value.trim()) UI.send('rp.name', id, f.value.trim());
      UI.dirty = true;
    };
    f.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); done(true); f.blur(); } else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(false); f.blur(); } e.stopPropagation(); });
    f.addEventListener('blur', () => done(true));
  };
  /* ⌘R on a play or video in a playlist: its name becomes a field (a replay's new name shows in All replays too) */
  UI.renameItem = function (key, itemId) {
    ui.renamingItem = itemId; render();
    const f = document.querySelector(`[data-iren="${itemId}"]`); if (!f) { ui.renamingItem = null; return; }
    f.focus(); f.select();
    const done = save => {
      if (ui.renamingItem !== itemId) return;
      ui.renamingItem = null;
      if (save && f.value.trim()) UI.send('pls.itemName', key, itemId, f.value.trim());
      UI.dirty = true;
    };
    f.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); done(true); f.blur(); } else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(false); f.blur(); } e.stopPropagation(); });
    f.addEventListener('blur', () => done(true));
    f.addEventListener('click', e => e.stopPropagation());
  };
  /* Delete (the Mac's delete key) removes the replay angle or play that's picked */
  // Edit › Undo in the Mac app: undo the typing in a text field, otherwise bring back the last thing deleted
  UI.undoKey = function () {
    const a = document.activeElement;
    if (a && (a.isContentEditable || a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search|number|email|url|tel|)$/i.test(a.type || '')))) { document.execCommand('undo'); return; }
    UI.undo();
  };
  /* ⌘Z: bring back the last thing deleted */
  UI.undo = function () {
    const E = PV.E, n = E.undo ? E.undo() : null;
    UI.toast(n ? `Brought back ${PV.UNDO_WORD[n] || 'what was deleted'}` : 'Nothing to bring back');
    UI.dirty = true;
  };
  UI.deletePicked = function () {
    const s = ui.sel, st = PV.E.st; if (!s) return false;
    if (s.kind === 'rp') {
      const c = st.rp.clips.find(x => x.id === s.a); if (!c) return false;
      if (st.rp.playing && st.rp.playing.clip === c.id) { UI.toast('That replay is on air'); return true; }
      UI.send('rp.angDel', s.a, s.b); ui.sel = null; UI.toast(`Removed ${PV.srcShort(s.b)} from ${c.name}`); return true;
    }
    if (s.kind === 'rpclip') {
      const c = st.rp.clips.find(x => x.id === s.a); if (!c) return false;
      if (st.rp.playing && st.rp.playing.clip === c.id) { UI.toast('That replay is on air'); return true; }
      UI.send('rp.delete', s.a); ui.sel = null; UI.toast(`Deleted ${c.name}`); return true;
    }
    return false;
  };
  document.addEventListener('dblclick', e => {
    const l = e.target.closest('[data-expand]'); if (!l) return;
    ui.expand = ui.expand === l.dataset.expand ? null : l.dataset.expand;
    UI.dirty = true;
  });

  /* ---------- Favs: the graphics used most, in the operator's order. Right-click any graphic to star it. ---------- */
  const FAV_DEFAULT = [{ t: 'tog', k: 'scorebug' }, { t: 'wm' }, { t: 'burn' }, { t: 'tog', k: 'ticker' }, { t: 'tog', k: 'big' }];
  const favKey = it => it.t === 'wm' || it.t === 'burn' ? it.t : PV.itemKey(it);
  PV.favs = () => { const f = PV.store.get('favs', null); return Array.isArray(f) ? f : FAV_DEFAULT.slice(); };
  PV.saveFavs = list => { PV.store.set('favs', list); ui.last.rows = null; UI.dirty = true; };
  PV.isFav = it => PV.favs().some(f => favKey(f) === favKey(it));
  PV.toggleFav = it => { const f = PV.favs(); const i = f.findIndex(x => favKey(x) === favKey(it)); if (i >= 0) f.splice(i, 1); else f.push(it); PV.saveFavs(f); UI.toast(i >= 0 ? 'Removed from Favs' : 'Added to Favs'); };
  PV.moveFav = (from, to) => { const f = PV.favs(); if (!f[from] || !f[to] || from === to) return; const [x] = f.splice(from, 1); f.splice(to, 0, x); PV.saveFavs(f); };
  UI.favItem = (i) => PV.favs()[i];
  function favName(st, it) {
    if (it.t === 'wm') return 'Watermark';
    if (it.t === 'burn') return 'Replay Burn';
    if (it.t === 'tog') return { scorebug: 'Scorebug', ticker: 'Ticker', big: 'Big Score' }[it.k] || it.k;
    if (it.t === 'cat') return PV.gfxName(it.ref);
    if (it.t === 'l3') { const p = PV.player(st.show, it.spec.side, it.spec.num); return `${st.show[it.spec.side].code} #${it.spec.num}${p ? ' ' + p[2] : ''} · ${it.spec.kind}`; }
    return '?';
  }
  const FAV_KEYS = { 'tog:scorebug': 'sb', 'tog:ticker': 'tick', 'tog:big': 'big', wm: 'wm', burn: 'burnTog' };
  function favBtn(st, map, it, i) {
    const k = FAV_KEYS[favKey(it)], drag = ` draggable="true" data-fav="${i}"`;
    // the watermark and replay burn stay on until clicked off, whatever else is cleared
    if (it.t === 'wm' || it.t === 'burn') {
      const on = it.t === 'wm' ? !!st.gfx.water : !!st.gfx.burn.on;
      const act = it.t === 'wm' ? 'gfx.wm' : 'gfx.burn|on|' + !on;
      const withBug = ((G.pkgOf(st.gfx.pkg) || {}).build || {}).wmWithBug !== false;
      const tip = it.t === 'wm' ? `Stays on until you click it off. Hidden during breaks, videos and replays${withBug ? '' : ', and while the scorebug is up'} · Right-click to change it` : 'Shows only on replays that air · Right-click to change it';
      return `<button class="scb${on ? ' pgm' : ''}" data-do="${act}"${drag} title="${tip}">${favName(st, it)}${K(map, k)}${on ? '<em>ON</em>' : ''}</button>`;
    }
    const pvk = it.t === 'tog' ? `tog|${it.k}` : it.t === 'cat' ? `cat|${it.ref}` : `l3|${it.spec.kind}|${it.spec.side}|${esc(it.spec.num)}`;
    const on = PV.itemLive(st, it), pv = PV.itemInPv(st, it);
    const sel = it.t === 'tog' ? isSel('tog', it.k) : it.t === 'cat' ? isSel('cat', it.ref) : isSel('l3', it.spec.kind, it.spec.side, String(it.spec.num));
    return `<button class="scb${tally(on, pv)}${sel}" data-pv="${pvk}"${drag} title="${on && !pv ? 'On air: click to take it off · Shift-click: add to the shot in Preview' : 'Click: add to the shot in Preview (click again to take it out)'} · Right-click for more">${esc(favName(st, it))}${K(map, k)}${on ? '<em>ON</em>' : ''}</button>`;
  }
  function shortcutBar(st, map) {
    const dr = (w, name, key) => `<button class="scb dr${ui.drawer === w ? ' open' : ''}" data-do="ui.drawer|${w}">${name}${K(map, key)}<span class="car">${ui.drawer === w ? '▴' : '▾'}</span></button>`;
    const body = `<div class="scbar">${PV.favs().map((it, i) => (it.t === 'tog' || it.t === 'cat') && PV.lookLacks(it.k || it.ref, st) ? '' : favBtn(st, map, it, i)).join('')}
      <span class="scsep"></span>${dr('away', `${UI.logo(st.show.away, st.show.colors.away, 16)}${esc(st.show.away.code)} GFX`, 'drawV')}${dr('home', `${UI.logo(st.show.home, st.show.colors.home, 16)}${esc(st.show.home.code)} GFX`, 'drawH')}${dr('canned', 'Canned GFX', 'drawC')}${PV.lookSets(st).map(s => dr('set:' + s.id, esc(s.name))).join('')}
      <span class="sp"></span><button class="scb clr" data-do="gfx.clear|all" title="Take every graphic off air except the scorebug, watermark and replay burn">Clear graphics ${K(map, 'clrAll')}</button></div>`;
    return row('Favs', body, 'favs');
  }


  /* which part of the show we're in, from the scoreboard */
  function curSeg(st) {
    const sb = st.sb, R = st.show.rules;
    const segs = PV.segs(st.show.sport).map(s => s[0]);
    if (sb.status === 'pre') return 'open';
    const play = segs.filter(s => !['open', 'final', 'post'].includes(s));
    const brk = s => /^(half|i\d)$/.test(s);
    const periods = play.filter(s => !brk(s)), breaks = play.filter(brk);
    if (sb.status === 'final' || sb.period > R.periods) return sb.status === 'final' ? 'post' : 'final';
    if (sb.status === 'half') return breaks.includes('half') ? 'half' : breaks[0] || periods[0];
    if (sb.status === 'break') { const b = breaks[sb.period - 1]; if (b && b !== 'half') return b; return periods[Math.min(sb.period, periods.length - 1)]; }
    return periods[Math.min(sb.period - 1, periods.length - 1)] || periods[0];
  }
  UI.curSeg = curSeg;
  function segRow(st, rowKey, label, tilesFor, count) {
    const segs = PV.segs(st.show.sport), cur = curSeg(st);
    const open = ui.segOpen[rowKey] || cur;
    const body = segs.map(([id, name]) => {
      const isOpen = open === id, n = count(id);
      return `<div class="segc${isOpen ? ' open' : ''}${id === cur ? ' now' : ''}"><button class="segt" data-do="ui.seg|${rowKey}|${id}" title="${esc(name)}${isOpen ? ': click to close' : ': click to open'}"><span>${esc(name)}</span><i>${n}</i></button>${isOpen ? `<div class="segtiles">${tilesFor(id)}</div>` : ''}</div>`;
    }).join('');
    return row(label, rowKey === 'vid' ? UI.plWrap(UI.plTabs('vid', st), body) : body, rowKey);
  }
  const GK = { full: 'FULL', lower: 'L3', take: 'TAKE', ticker: 'TICK' };
  const dragAttr = d => d ? ` draggable="true" data-drag="${esc(d)}"` : '';
  function gtile(st, ref, drag) {
    if (PV.lookLacks(ref, st)) return '';
    const it = { t: 'cat', ref }, on = PV.itemLive(st, it), pv = PV.itemInPv(st, it);
    const type = PV.isLowerRef(ref, st) ? 'lower' : (PV.GFX.find(g => g[0] === ref) || [0, 0, 'full'])[2];
 return `<div class="gt3${tally(on, pv)}${isSel('cat', ref)}"${dragAttr(drag)} data-pv="cat|${ref}" title="${on ? 'On air: click to take it off' : 'Click: Preview · Shift-click: add · ⌘R: rename · Right-click or ⌘E: edit'}"><span class="gk ${type}">${GK[type] || 'GFX'}</span>${ui.renTile === 'cat|' + ref ? renField('cat', ref, PV.gfxName(ref)) : `<b>${esc(PV.gfxName(ref))}</b>`}<small>${esc(gfxSub(st, ref))}</small>${on ? '<em>ON</em>' : ''}</div>`;
  }
  function gfxSub(st, ref) {
    const sh = st.show;
    if (ref === 'featAway' || ref === 'featHome') { const s = ref === 'featAway' ? 'away' : 'home'; const p = PV.player(sh, s, sh[s].featured); return p ? `#${p[0]} ${p[2]}` : 'Pick a player'; }
    if (ref === 'coachAway' || ref === 'coachHome') return sh[ref === 'coachAway' ? 'away' : 'home'].coach || 'Add a name';
    if (ref === 'officials') { const n = (sh.officials || []).filter(Boolean).length; return n ? n + ' names' : 'Add names'; }
    if (ref === 'weather') { const w = PV.weatherFor(sh.home.key, (sh.game.at || '').slice(0, 10)); return w ? `${w.hi}° · ${w.text}` : 'No forecast yet'; }
    if (st.text[ref] && st.text[ref].title) return '“' + st.text[ref].title + '”';
    return '';
  }
  function gfxRow(st) { return segRow(st, 'gfx', 'Graphics', seg => PV.segGfx(st, seg).map((r, i) => gtile(st, r, `g|${seg}|${i}`)).join(''), seg => PV.segGfx(st, seg).length); }
  function vidRow(st) {
    const pl = UI.plBody('vid', st);
    if (pl) return row('Videos', UI.plWrap(UI.plTabs('vid', st), pl), 'vid');
    return segRow(st, 'vid', 'Videos', seg => (st.vids[seg] || []).map((v, vi) => {
      const on = st.program === 'video' && st.pl.last && st.pl.last.id === v.id, pv = st.preview === 'video' && st.pv.vid === v.id;
      const len = UI.ms(v.tOut - v.tIn);
 return `<div class="vt3${tally(on, pv)}${isSel('vid', v.id)}${UI.plPicked('vid', v.id)}"${dragAttr(`v|${seg}|${vi}`)} data-pv="vid|${v.id}" title="Click: Preview · ⌘-click: pick for a playlist · Right-click or ⌘E: in and out, level"><canvas data-still="vid|${v.id}|${v.tIn}"></canvas><span class="tln">${esc(v.name)}</span><span class="vlen tc" data-vidleft="${v.id}" data-len="${len}">${len}</span></div>`;
    }).join('') + `<button class="vt3 plus" data-do="ui.vidAdd|${seg}" title="Add a video here">+</button>`, seg => (st.vids[seg] || []).length);
  }
  function rpRow(st, map) {
    const rp = st.rp;
    // the speed buttons work on the play that's picked (or in Preview); with none, they set the speed for new replays
    const tid = ui.sel && (ui.sel.kind === 'rp' || ui.sel.kind === 'rpclip') ? ui.sel.a : st.preview === 'replay' && st.pv.rp ? st.pv.rp.clip : null;
    const tc = tid && rp.clips.find(c => c.id === tid);
    // while a replay is on air, the speed buttons change it as it plays
    const live = st.program === 'replay' && rp.playing && rp.playing.seq;
    const spOn = live ? rp.playing.speed : tc ? tc.speed : rp.speed, spTo = live ? 'live' : tc ? tc.id : '';
    const head = `<div class="rph"><button class="btn sm pri" data-do="rp.mark" title="Mark the last few seconds as a replay">Mark ${K(map, 'mark')}</button><div class="seg sm vert${live ? ' live' : ''}" title="${live ? 'Speed of the replay on air' : tc ? 'Speed of ' + esc(tc.name) : 'Speed for the next replays'}">${[1, 0.75, 0.5, 0.25].map(s => `<button class="${spOn === s ? 'on' : ''}" data-do="rp.speed|${s}|${spTo}">${s * 100}%</button>`).join('')}</div></div>`;
    const tabs = UI.plTabs('rp', st);
    const pl = UI.plBody('rp', st, map);
    if (pl) return row('Replays', UI.plWrap(tabs, pl), 'rps');
    const groups = rp.clips.length ? rp.clips.slice(0, 12).map((c, ci) => `<div class="rpg${ui.sel && ui.sel.kind === 'rpclip' && ui.sel.a === c.id ? ' picked' : ''}${UI.plPicked('rp', c.id + '|')}"><div class="rpgh" data-clip="${c.id}"${dragAttr(`p||${ci}`)} title="Click to pick the play (Delete removes it, ⌘R renames it) · ⌘-click to pick it for a playlist · Double-click to trim · Drag to move it">${ui.renaming === c.id ? `<input type="text" class="inp rpren" value="${esc(c.name)}" maxlength="40" data-ren="${c.id}" aria-label="Replay name">` : `<b>${esc(c.name)}</b>`}<small data-ago="${c.at}">${UI.ago(c.at)}</small><button class="btn sm ghost" data-do="rp.roll|${c.id}" title="Roll every angle in order" ${rp.playing ? 'disabled' : ''}>Roll all</button></div><div class="rpgt">${c.angles.map(a => {
      const sg = st.program === 'replay' && PV.rpSeg(rp.playing), on = !!sg && sg.clip === c.id && sg.cam === a, pv = st.preview === 'replay' && st.pv.rp && st.pv.rp.clip === c.id && st.pv.rp.ang === a;
      const cut = PV.cut(c, a);
 return `<div class="rt3${tally(on, pv)}${isSel('rp', c.id, a)}${UI.plPicked('rp', c.id + '|' + a)}"${dragAttr(`a|${c.id}|${c.angles.indexOf(a)}`)} data-pv="rp|${c.id}|${a}" title="Click: Preview · ${live ? 'Double-click: fade to this angle from its start · ' : ''}⌘-click: pick for a playlist · Right-click or ⌘E: set in and out"><canvas data-still="rp|${c.id}|${a}|${cut.tIn.toFixed(1)}|${cut.tOut.toFixed(1)}"></canvas><span class="tln"><b>${PV.srcShort(a)}</b> ${esc(st.inputs[a].name)}</span><span class="vlen tc">${(cut.tOut - cut.tIn).toFixed(1)}s</span><i class="rptl" aria-hidden="true"><i></i></i><button class="rpx" data-do="rp.angDel|${c.id}|${a}" title="Delete this angle" aria-label="Delete ${PV.srcShort(a)} from ${esc(c.name)}">×</button></div>`;
    }).join('')}</div></div>`).join('') : `<div class="rpempty">Press <b>${esc(PV.keyLabel(map.mark || ''))}</b> after a play. ${rp.angles.length === 1 ? 'The replay camera lands' : rp.angles.length === 2 ? 'Both replay cameras land' : `All ${rp.angles.length} replay cameras land`} here as separate shots: ${rp.angles.map(PV.srcShort).join(', ')}.</div>`;
    return row('Replays', UI.plWrap(tabs, head + `<div class="rpgs">${groups}</div>`), 'rps');
  }
  function sndRow(st) {
    // first tile: no sound with the shot
    const blank = `<button class="st3 blank${st.pv.snd ? '' : ' pvw'}" data-do="pv.sndNone" title="No sound with the shot in Preview"><span class="si">∅</span><b>BLANK</b><small>No sound</small></button>`;
    const tiles = blank + st.snds.map(s => {
      const on = st.sndPlay && st.sndPlay.id === s.id, pv = st.pv.snd === s.id;
      return `<div class="st3${tally(on, pv)}${isSel('snd', s.id)}" data-pv="snd|${s.id}" title="${esc(s.name)} · Click: Preview · Shift-click: add to the shot · ⌘R: rename · Right-click or ⌘E: edit"><span class="si">♪</span>${ui.renTile === 'snd|' + s.id ? renField('snd', s.id, s.name) : `<b>${esc(s.name)}</b>`}<small>${s.tone ? '1 kHz · −20 dB' : s.file ? UI.ms((s.tOut || s.dur) - s.tIn) : 'No file'}</small></div>`;
    }).join('') + `<button class="st3 plus" data-do="ui.sndAdd" title="Add a sound">+</button>`;
    return row('Sounds', tiles, 'snds');
  }

  /* ---------- drawers: lower thirds and canned graphics ---------- */
  const CANNED = UI.CANNED = ['halftime', 'capAway', 'capHome', 'standings', 'schedAway', 'schedHome', 'coming', 'nextUp', 'gameLeaders', 'weather', 'tapeSeason', 'tape'];
  function drawerHtml(st, map) {
    const sh = st.show;
    if (ui.drawer === 'canned') {
      return `<div class="drawer"><div class="drh"><b>Canned graphics</b><span class="hint">For storylines and time to fill · Click: Preview · Shift-click: add · Right-click: edit</span><span class="sp"></span><button class="btn sm ghost" data-do="ui.drawer|canned">Close ${K(map, 'drawC')}</button></div><div class="drg">${CANNED.filter(r => PV.GFX.some(g => g[0] === r)).map(r => gtile(st, r)).join('')}</div></div>`;
    }
    if (/^set:/.test(ui.drawer || '')) {
      const set = PV.lookSets(st).find(s => 'set:' + s.id === ui.drawer);
      if (!set) { ui.drawer = null; return ''; }
      const tiles = set.items.map(p => {
        const it = { t: 'pic', pic: set.id + ':' + p.id }, on = PV.itemLive(st, it), pv = PV.itemInPv(st, it);
        return `<div class="gt3${tally(on, pv)}${isSel('pic', it.pic)}" data-pv="pic|${esc(it.pic)}" title="${on ? 'On air: click to take it off' : 'Click: Preview · Shift-click: add · Double-click: on air'}"><span class="gk lower">L3</span><b>${esc(p.name)}</b>${on ? '<em>ON</em>' : ''}</div>`;
      }).join('');
      return `<div class="drawer"><div class="drh"><b>${esc(set.name)}</b><span class="hint">Click: Preview · Double-click: on air · Comes off like a lower third</span><span class="sp"></span><button class="btn sm ghost" data-do="ui.drawer|${esc(ui.drawer)}">Close</button></div><div class="drg">${tiles}</div></div>`;
    }
    return teamDrawer(st, map, ui.drawer);
  }

  /* a team's lower thirds: bios, game stats, notes and season stats, by number */
  function teamNum(st, side, mode, p) {
    const sh = st.show, t = sh[side], live = st.sb.status !== 'pre';
    {
      const it = { t: 'l3', spec: { kind: mode, side, num: p[0] } }, on = PV.itemLive(st, it), pv = PV.itemInPv(st, it);
      let sub = '';
      const w = (mode === 'bio' || mode === 'text') && PV.l3words(st, side, p[0], mode);
      if (mode === 'bio') sub = (w && w.name ? w.name.split(' ').slice(-1)[0] : p[2]) + (w ? ' ✎' : '');
      else if (mode === 'text') sub = w && w.sub ? w.sub : '+ note';
      else if (PV.isField(sh)) {
        // the first of the stats picked for this player
        const S = PV.statLists(st, side, p[0], mode), k = (st.l3pick[PV.l3key(side, p[0], mode)] || S.pick)[0];
        const v = mode === 'game' ? (live && st.live ? PV.fieldGameVal(st, side, p[0], k) ?? '0' : null) : PV.fieldSeasonVal(t, p[0], k);
        sub = v != null ? `${v} ${S.list[k][0]}` : '—';
      }
      else if (mode === 'game') { const b = PV.E.statFor(side, p[0]); sub = live && b ? `${b.pts || 0} PTS` : '—'; }
      else { const ss = t.pstats && t.pstats[p[0]]; sub = ss ? `${(+ss[0]).toFixed(1)} PPG` : '—'; }
      const tip = mode === 'bio' ? ' · Right-click or ⌘E: change the bio' : mode === 'text' ? (w && w.sub ? ' · Right-click or ⌘E: change the note' : ' · Click to type a note') : ' · Right-click or ⌘E: pick the stats';
      return `<div class="pn${tally(on, pv)}${isSel('l3', mode, side, p[0])}${mode === 'text' && !(w && w.sub) ? ' empty' : ''}" data-pv="l3|${mode}|${side}|${esc(p[0])}" title="#${esc(p[0])} ${esc(p[1])} ${esc(p[2])}${tip}"><span class="pnn tc">${esc(p[0])}</span><small>${esc(sub)}</small></div>`;
    }
  }
  function teamDrawer(st, map, side) {
    const sh = st.show, t = sh[side], col = sh.colors[side], live = st.sb.status !== 'pre';
    const num = (mode, p) => teamNum(st, side, mode, p);
    const sec = (mode, name, hint) => `<div class="drs"><div class="drsh"><b>${name}</b><span class="hint">${hint}</span></div><div class="pns" data-scroll="dr${mode}">${t.roster.map(p => num(mode, p)).join('')}</div></div>`;
    return `<div class="drawer" style="--c:${col}"><div class="drh">${UI.logo(t, col, 26)}<b>${esc(t.code)} GFX</b><span class="hint">Click a number: Preview · Shift-click: add to the shot</span><span class="sp"></span>
      ${gtile(st, side === 'away' ? 'coachAway' : 'coachHome')}<button class="btn sm ghost" data-do="ui.drawer|${side}">Close ${K(map, side === 'away' ? 'drawV' : 'drawH')}</button></div>
      ${t.placeholder || !t.roster.length ? `<div class="note">No roster for ${esc(t.name)} yet. Add one in Settings › Game.</div>` : ''}
      ${sec('bio', 'Bios', 'Number, name, class, position, height, hometown · right-click to change')}${sec('game', 'Game stats', live ? PV.todayWord(sh) : `Fills in after ${PV.isField(sh) ? (sh.sport === 'FH' ? 'the start' : 'kickoff') : 'tip-off'}`)}${sec('text', 'Text', 'Type a note for any player')}${sec('season', 'Season stats', PV.isField(sh) ? 'Entering ' + PV.todayWord(sh).toLowerCase() : PV.gameSeason(sh) === PV.STATS_SEASON ? 'Entering ' + PV.todayWord(sh).toLowerCase() : PV.STATS_SEASON + ', returning players')}</div>`;
  }

  /* Pivot GFX: a team's notes tray. Closed, it holds the team's notes, one per player; V or H (or its name) opens it. */
  function teamTray(st, map, side) {
    if (ui.drawer === side) return `<div class="teamtray-open">${teamDrawer(st, map, side)}</div>`;
    const sh = st.show, t = sh[side], col = sh.colors[side], key = side === 'away' ? 'drawV' : 'drawH';
    const none = !t.roster.length || t.placeholder;
    const tiles = !t.roster.length ? `<span class="hint" style="padding:0 10px">No roster for ${esc(t.name)} yet. Add one in Settings › Game.</span>` : t.roster.map(p => teamNum(st, side, 'text', p)).join('');
    return `<div class="row3 teamtray" style="--c:${col}"><div class="rlab" data-do="ui.drawer|${side}" title="Open everything for ${esc(t.code)}: bios, stats and notes"><span>${esc(t.code)}</span></div>
      <div class="rbody"><button class="trayh" data-do="ui.drawer|${side}" title="Open everything for ${esc(t.code)}">${UI.logo(t, col, 22)}<span class="trayt"><b>${esc(t.code)} notes</b>${none && t.roster.length ? '<small>No roster yet: numbers only</small>' : ''}</span>${K(map, key)}<span class="car">▾</span></button><div class="pns" data-scroll="tray${side}">${tiles}</div></div></div>`;
  }

  /* ---------- rundown dock (lower right) ---------- */
  function rdDock(st, map) {
    const rd = st.rd, items = rd.items;
    if (!ui.rdOpen) return `<button class="rdtab" data-do="ui.rdOpen" title="Show the rundown"><span>RUNDOWN</span></button>`;
    const cur = rd.on ? rd.idx : -1, pvI = st.pv.rd;
    let lastSeg = '';
    const rows = items.map((it, i) => {
      const cls = i === cur ? 'now' : i === pvI ? 'pvw' : it.done ? 'past' : i === rd.cue ? 'cue' : 'next';
      const seg = it.seg !== lastSeg ? `<div class="rdseg">${esc(it.seg)}</div>` : ''; lastSeg = it.seg;
      return `${seg}<div class="rdi ${cls}" role="button" draggable="true" data-i="${i}" data-rdi="${i}" data-do="rd.run|${i}" title="${i === cur ? 'On air: click to take it off' : 'Click: Preview, then Enter to take · Drag to move it'}"><span class="rdk ${it.kind}">${PV.RD_TAG[it.kind] || ''}</span><span class="rdt"><b>${esc(it.label)}</b><small>${esc(it.sub)}</small></span>${cls === 'now' ? '<span class="rdon">ON</span>' : cls === 'pvw' ? '<span class="rdpv">PVW</span>' : cls === 'cue' ? '<span class="rdnx">NEXT</span>' : ''}<button class="rded" data-do="ui.rdEdit|${i}" title="Edit" aria-label="Edit ${esc(it.label)}">✎</button></div>`;
    }).join('');
    return `<div class="cardh"><button class="btn sm ghost cardtog" data-do="ui.rdOpen" title="Hide the rundown" aria-label="Hide the rundown">▸</button>Rundown<span class="sp"></span><span class="cnt">${items.filter(i => i.done).length}/${items.length}</span><button class="btn sm" data-do="rd.next" title="Next item to Preview">Next ${K(map, 'rdNext')}</button></div>
      <div class="rdlist" id="rdList">${rows}</div><div class="rdfoot"><button class="btn sm ghost" data-do="ui.rdEdit|new">+ Add item</button></div>`;
  }

  /* ---------- pop-out: Suggested and Scoreboard ---------- */
  const chev = id => `<button class="btn sm ghost cardtog" data-do="ui.card|${id}" aria-expanded="${!!ui.open[id]}">${ui.open[id] ? '▾' : '▸'}</button>`;
  function sugCard(st, map) {
    const head = `<div class="cardh">${chev('sug')}Suggested now<span class="sp"></span>${st.sugg.length ? `<span class="cnt">${st.sugg.length}</span>` : ''}</div>`;
    if (!ui.open.sug) return head;
    return head + (st.sugg.length ? st.sugg.slice(0, 5).map(s => `<div class="sug"><span style="min-width:0"><b>${esc(s.title)}</b><small>${esc(s.why)}</small></span><button class="btn sm pri" data-do="sugg.take|${s.id}">Take</button><button class="btn sm ghost" data-do="sugg.dismiss|${s.id}" title="Dismiss">×</button></div>`).join('') + `<div class="hint">${K(map, 'sug')} takes the top one</div>` : '<div class="hint">Nothing right now. Suggestions appear as the game happens.</div>');
  }
  function sbCard(st, map, pinned) {
    const sb = st.sb, sh = st.show;
    const pinBtn = `<button class="btn sm ghost pinb${pinned ? ' on' : ''}" data-do="ui.sbPin" title="${pinned ? 'Unpin: back to the pop-out on the right edge' : 'Pin it beside Program, always on screen'}" aria-pressed="${!!pinned}">${pinned ? 'Unpin' : 'Pin'}</button>`;
    const down = !sb.boxOk, phone = sb.op === 'phone', manual = sb.feed === 'manual';
    const live = sb.feed === 'stats', st0 = PV.E && PV.E.st, fresh = st0 && st0.live && Date.now() - st0.live.at < 45000;
    const status = live ? (fresh ? '<span class="status">Live stats</span>' : `<span class="status warn" title="${esc((st0 && st0.liveErr) || 'Waiting for the school\'s stats feed')}">Waiting for live stats</span>`) : down ? '<span class="status bad">Box not connected</span>' : phone ? '<span class="status warn">From phone</span>' : manual ? '<span class="status off">Manual</span>' : '<span class="status">Box connected</span>';
    const head = `<div class="cardh${down ? ' alert' : ''}">${pinned ? '' : chev('sb')}Scoreboard<span class="sp"></span>${status}${pinBtn}</div>`;
    const mini = `<div class="sbmini"><span>${UI.logo(sh.away, sh.colors.away, 20)}${esc(sh.away.code)} <b class="tc">${sb.score.away}</b></span><span class="tc"><small>${G.periodText(sb, sh.rules)}</small> <b class="ck tc" data-clk></b></span><span><b class="tc">${sb.score.home}</b> ${esc(sh.home.code)}${UI.logo(sh.home, sh.colors.home, 20)}</span></div>`;
    if (!pinned && !ui.open.sb && !down) return head + mini;
    const R = sh.rules, foot = /^FB/.test(sh.sport);   // possession only matters in football
    // what this sport's package adds to the scoreboard: its score buttons, a line under each score, its own rows and tools
    const B = PV.board(sh), H = { tally };
    const ed = manual ? ' editable' : '';
    const team = side => `<div class="sbt" style="--c:${sh.colors[side]}">${foot ? `<span class="poss${sb.poss === side ? ' on' : ''}">● BALL</span>` : ''}<span class="cd">${UI.logo(sh[side], sh.colors[side], 18)}${esc(sh[side].code)}</span>
      <span class="pt tc${ed}" data-sbedit="score|${side}" title="${manual ? 'Click to type the score' : 'Turn on Enter score by hand to type it'}">${sb.score[side]}</span>
      ${B.teamLine(st, side)}</div>`;
    // each team's buttons in its own panel, so it's clear whose they are
    const panel = side => `<div class="sbpan" style="--c:${sh.colors[side]}"><div class="sbpanh">${UI.logo(sh[side], sh.colors[side], 14)}${esc(sh[side].code)}</div>
      <div class="adj">${B.steps.map(n => `<button class="btn" data-do="sb.adjust|${side}|${n}">+${n}</button>`).join('')}<button class="btn" data-do="sb.adjust|${side}|-1">−1</button></div>
      ${B.panel(st, side, H)}</div>`;
    const pname = p => p > R.periods ? (p - R.periods === 1 ? 'OT' : (p - R.periods) + 'OT') : (R.periods === 2 ? ['1st half', '2nd half'] : ['1st quarter', '2nd quarter', '3rd quarter', '4th quarter'])[p - 1];
    const kitsOpen = PV.store.get('sbKits', false);
    const cur = sb.status === 'half' ? 'half' : sb.status === 'final' ? 'final' : String(sb.period);
    const periodSel = `<select class="inp sbper" data-ch="sb.setPeriod" aria-label="Half or quarter">${Array.from({ length: R.periods + 4 }, (_, i) => i + 1).map(p => `<option value="${p}" ${cur === String(p) ? 'selected' : ''}>${pname(p)}</option>`).join('')}<option value="half" ${cur === 'half' ? 'selected' : ''}>Halftime</option><option value="final" ${cur === 'final' ? 'selected' : ''}>Final</option></select>`;
    return head + (down ? `<div class="note" style="border-color:var(--pgm)"><b>The scoreboard box stopped sending.</b> Enter the score here, or hand it to someone on a phone (Screens › Scorebug). <button class="btn sm" data-do="sb.boxOk|true">Box is back</button></div>` : '')
      + (phone ? '<div class="note">Someone is running the scorebug from a phone. <button class="btn sm" data-do="sb.release">Take it back</button></div>' : '')
      + `<div class="sbx">${team('away')}<div class="sbc">${manual ? periodSel : `<span class="pr">${G.periodText(sb, sh.rules)}</span>`}<span class="ck tc${ed}" data-clk data-sbedit="clock" title="${manual ? 'Click to type the time' : ''}"></span><button class="btn sm" data-do="sb.clock" ${['half', 'final', 'break'].includes(sb.status) ? 'disabled' : ''}>${sb.status === 'pre' ? B.start : sb.running ? 'Stop' : 'Start'} ${K(map, 'clock')}</button></div>${team('home')}</div>
      <div class="sbpans">${panel('away')}<i class="sbdiv"></i>${panel('home')}</div>
      <div class="sbtools">${foot ? '<button class="btn sm" data-do="sb.poss">Possession</button>' : ''}
        ${B.tools(st, H)}
        ${['half', 'break'].includes(sb.status) ? `<button class="btn sm pri" data-do="sb.next">Start ${sh.rules.periods === 2 ? '2nd half' : PV.ordinal(sb.period + 1) + ' quarter'}</button>` : ''}
        ${B.banner ? `<select class="inp" style="height:26px" data-ch="ui.flag|x" aria-label="Scorebug banner"><option value="">No banner</option>${['TIMEOUT', 'OFFICIAL REVIEW'].map(f => `<option ${sb.flag === f ? 'selected' : ''}>${f}</option>`).join('')}</select>` : ''}
        ${PV.kitRow ? `<span class="btng"><button class="btn sm sbkbtn${kitsOpen ? ' on' : ''}" data-do="ui.kits" aria-expanded="${kitsOpen}" title="Uniform colors: click to change them">${['away', 'home'].map(sd => `<i style="--k:${PV.kitOf(sh, sd)}"></i>`).join('')}Uniforms</button><button class="btn sm bgear${kitsOpen ? ' on' : ''}" data-do="ui.kits" title="Change the uniform colors" aria-label="Uniform settings">⚙</button></span>` : ''}</div>
      ${PV.kitRow && kitsOpen ? `<div class="sbkits">${['away', 'home'].map(sd => `<div class="sbkr"><b>${esc(sh[sd].code)}</b>${PV.kitRow(sd)}</div>`).join('')}</div>` : ''}
      <label class="chk"><input type="checkbox" ${manual ? 'checked' : ''} data-do="ui.manual">Enter score by hand (ignore the ${B.feedWord})</label>
      ${manual ? '<div class="hint">Click the clock or a score to type over it. Enter or clicking away puts it on air.</div>' : ''}`;
  }

  /* ---------- floating panels: Audio and Macros ---------- */
  UI.panel = function (which) {
    const p0 = $('.fpanel');
    if (!which || ui.panel === which) { ui.panel = null; if (p0) p0.remove(); $$('#bAudio,#bMacros').forEach(b => b.classList.remove('on')); return; }
    ui.panel = which; ui.last.panel = null;
    if (!p0) { const p = document.createElement('div'); p.className = 'fpanel'; document.body.appendChild(p); }
    $('#bAudio').classList.toggle('on', which === 'audio'); $('#bMacros').classList.toggle('on', which === 'macros');
    UI.dirty = true;
  };
  function renderPanel(st, map) {
    const p = $('.fpanel'); if (!p) return;
    p.dataset.kind = ui.panel;
    const title = ui.panel === 'audio' ? 'Audio mixer' : 'Macros';
    put(p, `<div class="cardh"><b>${title}</b><span class="sp"></span><button class="btn sm ghost" data-do="ui.panelClose">Close</button></div>${ui.panel === 'audio' ? audioPanel(st) : macroPanel(st, map)}`, 'panel');
  }
  function audioPanel(st) {
    if (PV.native && PV.native.audioPanel) return PV.native.audioPanel(st);
    const a = st.audio;
    const strip = (i, name, sub, meterKey) => { const c = a.ch[i]; return `<div class="strip"><span class="cn" title="${esc(name)}">${esc(name)}</span><span class="sub">${esc(sub)}</span>
      <div class="fadewrap"><span class="meter" data-meter="${meterKey}"><i></i></span><input type="range" class="vfader" min="0" max="1" step="0.01" value="${c.fader}" data-in="audio.fader|${i}" aria-label="${esc(name)} level"></div>
      <span class="db tc">${c.fader <= 0.01 ? '-∞' : (20 * Math.log10(c.fader / 0.8)).toFixed(1)} dB</span>
      <button class="mute${c.mute ? ' on' : ''}" data-do="audio.mute|${i}">${c.mute ? 'MUTED' : 'MUTE'}</button></div>`; };
    let strips;
    if (a.mode === '4ch') strips = [0, 1, 2, 3].map(i => strip(i, a.ch[i].name, 'Channel ' + (i + 1), String(i))).join('');
    else if (a.mode === 'pairs') strips = strip(0, 'Voices', '1 + 2 as mono', 'v') + strip(2, 'Nats', '3 + 4 as mono', 'n');
    else strips = strip(0, 'Voices', 'Left side of input', 'v') + strip(2, 'Nats', 'Right side of input', 'n');
    const master = `<div class="strip master"><span class="cn">Stream mix</span><span class="sub">Stereo</span><div class="fadewrap"><span class="meter" data-meter="L"><i></i></span><span class="meter" data-meter="R"><i></i></span><input type="range" class="vfader" min="0" max="1" step="0.01" value="${a.master}" data-in="audio.master" aria-label="Stream mix level"></div><span class="db tc">${(20 * Math.log10(Math.max(0.01, a.master) / 0.85)).toFixed(1)} dB</span><button class="mute${st.brk ? ' on' : ''}" data-do="brk.toggle">${st.brk ? 'IN BREAK' : 'BREAK'}</button></div>`;
    const modes = [['4ch', '4 channels'], ['pairs', 'Two mono pairs'], ['split', 'Stereo split']];
    return `<div class="sec"><div class="row"><div class="seg">${modes.map(([m, n]) => `<button class="${a.mode === m ? 'on' : ''}" data-do="audio.mode|${m}">${n}</button>`).join('')}</div><span class="hint">${esc(a.device)} · <button class="btn sm ghost" data-do="ui.settings|audio">Change</button></span></div>
      <div class="mixer">${strips}${master}</div></div>`;
  }
  function macroPanel(st, map) {
    const list = PV.macros(), run = st.macro.running;
    const lbl = s => s.wait ? `wait ${(s.wait / 1000).toFixed(1)} s` : ((PV.ACTIONS.find(a => a.id === s.a) || { label: s.a }).label);
    return `<div class="sec"><div class="row"><button class="btn${st.macro.recording ? ' red' : ''}" data-do="macro.record">${st.macro.recording ? '■ Stop recording and save' : '● Record a macro'}</button><button class="btn" data-do="macro.stop" ${run ? '' : 'disabled'}>Stop ${K(map, 'mstop')}</button><span class="sp" style="flex:1"></span><button class="btn sm" data-do="ui.settings|macros">Edit macros</button></div>
      ${st.macro.recording ? '<div class="note"><b>Recording.</b> Use your shortcut keys now; pauses between them are kept. Press the button again to save.</div>' : ''}
      <div class="grid2">${list.map(m => `<div class="mac${run && run.id === m.id ? ' run' : ''}"><div style="min-width:0"><b>${esc(m.name)}</b> ${m.key ? `<kbd>${esc(PV.keyLabel(m.key))}</kbd>` : ''}<div class="steps">${m.steps.map((s, i) => `<span class="${s.wait ? 'w' : ''}${run && run.id === m.id && run.step === i ? ' cur' : ''}">${esc(lbl(s))}</span>`).join('')}</div></div><div><button class="btn sm pri" data-do="macro.run|${m.id}">Run</button></div></div>`).join('')}</div></div>`;
  }

  /* ---------- left tray: playlists ---------- */
  function trayLeft(st, map) {
    const pl = st.pl;
    const lists = pl.lists.filter(l => !l.hidden);
    const L = lists.find(l => l.id === pl.left) || lists[0];
    const pa = pl.active && pl.active.list === L.id ? pl.active : null;
    const cue = st.pl.cue[L.id] || 0;
    const total = L.items.reduce((s, i) => s + (i.dur || 0), 0);
    const rows = L.items.map((it, i) => {
      const cur = pa && pa.idx === i, isCue = !pa && i === cue;
      return `<div class="pli${cur ? ' cur' : ''}${isCue ? ' cue' : ''}${it.played && !cur ? ' played' : ''}" draggable="true" data-pli="${i}">
        <span class="h" title="Drag to reorder">⋮⋮</span><span class="ty">${{ video: 'VID', gfx: 'GFX', reel: 'REEL', replay: 'RPL' }[it.type]}</span><span class="nm" title="${esc(it.name)}">${isCue ? '<i class="cuemark">NEXT</i>' : ''}${esc(it.name)}</span>
        <span class="du tc">${cur ? '<span data-itemleft></span>' : it.dur ? UI.ms(it.dur) : (it.type === 'gfx' ? 'hold' : 'auto')}</span>
        <button class="btn sm${cur ? ' red' : ''}" data-do="${cur ? 'pl.stop' : `pl.play|${L.id}|${i}`}">${cur ? 'Stop' : it.played ? '✓ Again' : 'Play'}</button>
        <button class="btn sm ghost" data-do="pl.remove|${L.id}|${it.id}" ${cur ? 'disabled' : ''} title="Remove">×</button></div>`;
    }).join('');
    const elsewhere = pl.active && pl.active.list !== L.id ? (pl.lists.find(l => l.id === pl.active.list) || {}).name : null;
    return `<div class="trayh"><b>Playlists</b><span class="sp"></span><button class="btn sm ghost" data-do="ui.tray" title="Close">Close ${K(map, 'trayL')}</button></div>
      <div class="pltabs">${lists.map(l => `<button class="btn sm${l.id === L.id ? ' on' : ''}" data-do="pl.left|${l.id}">${esc(l.name)}${pl.active && pl.active.list === l.id ? ' ▶' : ''}</button>`).join('')}</div>
      <div class="seg full">${PV.PL_MODES.map(([m, n]) => `<button class="${L.mode === m ? 'on' : ''}" data-do="pl.mode|${L.id}|${m}">${n}</button>`).join('')}</div>
      ${elsewhere ? `<div class="hint">Now playing: <b>${esc(elsewhere)}</b></div>` : ''}
      <div class="sec trayitems" data-plist="${L.id}">${rows || '<div class="empty">Empty.</div>'}</div>
      <div class="plfoot"><button class="btn pri" data-do="pl.play|${L.id}">Play next ${K(map, 'plnext')}</button><button class="btn" data-do="pl.stop" ${pl.active ? '' : 'disabled'}>Stop ${K(map, 'plstop')}</button><span class="sp" style="flex:1"></span><span class="tm tc">${UI.ms(total)}</span><button class="btn sm ghost" data-do="pl.reset|${L.id}">Clear ✓</button></div>
      <div class="hint">${L.mode === 'one' ? 'One at a time: each item plays, then Pivot goes back to the camera in Preview and cues the next one.' : L.mode === 'order' ? 'In order: plays the whole list, then goes back to Preview.' : 'Loop: plays the list over and over until you stop it.'}</div>`;
  }

  UI.protocols = function () {
    const st = PV.E.st, pr = ((G.pkgOf(st.gfx.pkg) || {}).build || {}).protocols; if (!pr) return;
    const m = UI.modal(`<div class="dlgh"><b>${esc(pr.title)}</b><span class="sp"></span><span class="hint">${esc(pr.sub || '')}</span></div><div class="dlgb proto">${pr.html(st)}</div><div class="dlgf"><span class="sp"></span><button class="btn pri" data-close>Close</button></div>`, 'dlg-proto');
    m.querySelector('[data-close]').onclick = () => m.close();
  };
  /* ---------- Outputs menu ---------- */
  function outputsHtml(st) {
    const f = PV.FORMATS[st.rec.fmt];
    const feeds = Object.entries(st.rec.feeds).filter(([, v]) => v).length;
    const dests = st.stream.dests.filter(d => d.on).map(d => d.name).join(', ') || 'None';
    const ndi = Object.entries(st.out.ndi).filter(([, v]) => v).map(([k]) => ({ program: 'Program', clean: 'Clean feed', gfx: 'Graphics' }[k])).join(', ') || 'Off';
    const scr = ui.screens ? Object.values(ui.screens).filter(s => Date.now() - s.at < 15000).length : 0;
    return `<div class="cardh">Outputs<span class="sp"></span><button class="btn sm" data-do="ui.settings|rec">Settings</button></div>
      <dl class="kv"><dt>Recording</dt><dd>${feeds} feeds · ${esc(f.name)}</dd><dt>So far</dt><dd id="recGb">—</dd><dt>Per hour</dt><dd>${recRate(st).toFixed(0)} GB</dd>
      <dt>Stream</dt><dd>${esc(dests)}</dd><dt>Bitrate</dt><dd id="kbps">—</dd>
      <dt>Program out</dt><dd>${esc(st.out.device.replace('Blackmagic ', ''))}</dd><dt>NDI out</dt><dd>${esc(ndi)}</dd>
      <dt>Control screens</dt><dd>${scr ? scr + ' connected' : 'None'} · PIN ${esc(st.pin)}</dd></dl>`;
  }
  UI.outputsMenu = function (anchor) {
    if ($('.menu.outputs')) { closeMenus(); return; }
    closeMenus();
    const m = document.createElement('div'); m.className = 'menu outputs';
    const r = anchor.getBoundingClientRect();
    m.style.top = (r.bottom + 6) + 'px'; m.style.left = Math.max(8, Math.min(r.left, window.innerWidth - 330)) + 'px'; m.style.width = '320px'; m.style.padding = '12px';
    document.body.appendChild(m);
    m.innerHTML = (UI.outputsHtml || outputsHtml)(PV.E.st); ui.last.outmenu = m.innerHTML;
    setTimeout(() => document.addEventListener('click', function offc(e) { if (!m.contains(e.target) || e.target.closest('[data-do]')) { closeMenus(); document.removeEventListener('click', offc); } }), 0);
  };
  /* small pick-one menus */
  function popMenu(anchor, items, onPick, cls) {
    closeMenus();
    const m = document.createElement('div'); m.className = 'menu' + (cls ? ' ' + cls : '');
    const r = anchor.getBoundingClientRect();
    m.innerHTML = items.map((it, i) => it.sep ? '<hr>' : `<button data-i="${i}"${it.disabled ? ' disabled' : ''}${it.on ? ' class="on"' : ''}${it.head ? ' data-head' : ''}>${it.num != null && cls ? `<i>${esc(it.num)}</i>` : ''}${it.pick ? `<span class="mrad${it.on ? ' on' : ''}" aria-hidden="true"></span><span class="mtx">` : ''}<b>${esc(it.label)}</b>${it.sub ? `<small>${esc(it.sub)}</small>` : ''}${it.pick ? '</span>' : ''}</button>`).join('');
    document.body.appendChild(m);
    const mh = m.getBoundingClientRect().height;
    m.style.left = Math.max(8, Math.min(r.left, window.innerWidth - m.getBoundingClientRect().width - 8)) + 'px';
    m.style.top = (r.bottom + 6 + mh > window.innerHeight ? Math.max(8, r.top - mh - 6) : r.bottom + 6) + 'px';
    // a click elsewhere closes this menu (only this one: a later menu opened by that click stays open)
    const off = () => { document.removeEventListener('click', off); if (m.isConnected) closeMenus(); };
    m.addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (!b) return; e.stopPropagation(); document.removeEventListener('click', off); closeMenus(); onPick(items[+b.dataset.i]); });
    setTimeout(() => document.addEventListener('click', off), 0);
  }
  UI.popMenu = popMenu;
  UI.fadeMenu = el => popMenu(el, [300, 500, 1000, 1500, 2000].map(ms => ({ label: (ms / 1000).toFixed(1) + ' seconds', ms, on: PV.E.st.trans.dur === ms })), it => { UI.send('trans.dur', it.ms); UI.send('trans.sel', 'fade'); });
  UI.wipeMenu = el => {
    const st = PV.E.st, wipes = PV.wipesOf(st), del = wipes.filter(w => w.id !== 'replay');
    popMenu(el, wipes.map(w => ({ label: w.name, id: w.id, sub: WIPE_KIND[w.kind] || '', on: st.trans.sel === w.id }))
      .concat(del.length ? [{ sep: true }].concat(del.map(w => ({ label: 'Remove ' + w.name, del: w.id }))) : []),
      it => { if (it.del) UI.send('trans.del', it.del); else UI.send('trans.sel', it.id); });
  };
  UI.tickMenu = el => {
    const st = PV.E.st, off = st.show.tickOff || [], games = PV.tickGames(st), D = window.PIVOT_DATA;
    const name = k => { const t = D.byKey(k); return t ? (t.short || t.name) : k; };
    if (!games.length) { popMenu(el, [{ label: 'No other NEC games today', disabled: true }], () => {}); return; }
    popMenu(el, [{ label: 'Games in the ticker', disabled: true }].concat(games.map(g => ({ label: `${name(g.away)} at ${name(g.home)}`, sub: `${D.SPORTS[g.sport] || g.sport} · ${PV.fmtTime(g.at)}`, id: String(g.id), on: !off.includes(String(g.id)), pick: true }))),
      it => { UI.send('show.tickOff', it.id); setTimeout(() => UI.tickMenu(el), 0); }, 'tkpick');   // stays open to pick more
  };
  UI.addWipeMenu = el => {
    const sh = PV.E.st.show, teams = !PV.lookLacks('teamWipes');
    popMenu(el, [{ label: 'Tournament or league logo', a: ['logo'] }].concat(teams ? [{ label: `${sh.away.name} player interstitial`, a: ['player', 'away'] }, { label: `${sh.home.name} player interstitial`, a: ['player', 'home'] }, { label: `${sh.away.name} team wipe`, a: ['team', 'away'] }, { label: `${sh.home.name} team wipe`, a: ['team', 'home'] }] : []).concat([{ label: 'Sponsor wipe', a: ['sponsor'] }]), it => UI.send('trans.add', ...it.a));
  };
  UI.addVideo = (seg, el) => popMenu(el, Object.entries(S.CLIPS).map(([k, c]) => ({ label: c.name, k, sub: UI.ms(c.dur) })), it => UI.send('vid.add', seg, it.k));

  /* right-click on a graphic: edit it, or star it into Favs */
  UI.gfxMenu = function (el, it) {
    if (!it) return;
    const items = [];
    if (it.t === 'wm') items.push({ label: 'Change the watermark…', go: () => UI.markEditor('wm') });
    else if (it.t === 'burn') items.push({ label: 'Change the replay burn…', go: () => UI.markEditor('burn') });
    else if (it.t === 'cat') items.push({ label: 'Edit…', go: () => UI.gfxEditor(it.ref) }, { label: 'Rename', sub: '⌘R', go: () => { ui.sel = { kind: 'cat', a: it.ref }; UI.renameTile('cat', it.ref); } });
    else if (it.t === 'l3' && it.spec.kind === 'bio') items.push({ label: 'Change the bio…', go: () => UI.l3Editor(it.spec.side, it.spec.num, 'bio') });
    else if (it.t === 'l3' && it.spec.kind === 'text') items.push({ label: 'Change the note…', go: () => UI.l3Editor(it.spec.side, it.spec.num, 'text') });
    else if (it.t === 'l3') items.push({ label: 'Pick the stats…', go: () => UI.statPicker(it.spec.side, it.spec.num, it.spec.kind) });
    else if (it.t === 'tog' && it.k === 'big') items.push({ label: 'Edit…', go: () => UI.gfxEditor('big') }, { label: 'Graphics settings…', go: () => UI.openSettings('gfx') });
    else if (it.t === 'tog') items.push({ label: 'Graphics settings…', go: () => UI.openSettings('gfx') });
    const fav = PV.isFav(it);
    items.push({ label: fav ? '☆ Remove from Favs' : '★ Add to Favs', go: () => PV.toggleFav(it) });
    popMenu(el, items, x => x.go());
  };

  /* ---------- drag to reorder playlist items ---------- */
  document.addEventListener('dragstart', e => {
    const p = e.target.closest && e.target.closest('.pli'), r = e.target.closest && e.target.closest('.rdi');
    if (p) ui.drag = { kind: 'pl', list: p.parentElement.dataset.plist, from: +p.dataset.pli };
    else if (r) ui.drag = { kind: 'rd', from: +r.dataset.rdi };
    else if (e.target.closest && e.target.closest('[data-fav]')) ui.drag = { kind: 'fav', from: +e.target.closest('[data-fav]').dataset.fav };
    else if (e.target.closest && e.target.closest('[data-drag]')) { const [t, g, i] = e.target.closest('[data-drag]').dataset.drag.split('|'); ui.drag = { kind: 'item', t, g, from: +i }; }
    else return;
    try { e.dataTransfer.setData('text/plain', 'x'); e.dataTransfer.effectAllowed = 'move'; } catch (er) { /* ok */ }
  });
  document.addEventListener('dragover', e => { if (!ui.drag) return; const d0 = ui.drag;
    // a replay or video dragged onto a playlist tab goes on the end of that playlist
    const pt = e.target.closest('[data-pltab]'), pr = pt && UI.plDragRefs(d0);
    if (pr && pt.dataset.pltab.split(':')[0] === pr.kind) { e.preventDefault(); $$('.drop').forEach(x => x !== pt && x.classList.remove('drop')); pt.classList.add('drop'); return; }
    let t = e.target.closest(d0.kind === 'rd' ? '.rdi' : d0.kind === 'fav' ? '[data-fav]' : d0.kind === 'item' ? '[data-drag]' : '.pli');
    if (t && d0.kind === 'item') { const [tt, tg] = t.dataset.drag.split('|'); if (tt !== d0.t || tg !== d0.g) t = null; }   // only within the same group
    if (t) { e.preventDefault(); $$('.drop').forEach(x => x !== t && x.classList.remove('drop')); t.classList.add('drop'); } });
  document.addEventListener('drop', e => { const d = ui.drag; ui.drag = null; $$('.drop').forEach(x => x.classList.remove('drop')); if (!d) return; e.preventDefault();
    if (d.kind === 'rd') { const t = e.target.closest('.rdi'); if (t) UI.send('rd.move', d.from, +t.dataset.rdi); return; }
    if (d.kind === 'fav') { const t = e.target.closest('[data-fav]'); if (t) PV.moveFav(d.from, +t.dataset.fav); return; }
    const pt = e.target.closest('[data-pltab]'), pr = pt && UI.plDragRefs(d);
    if (pr && pt.dataset.pltab.split(':')[0] === pr.kind) { UI.plDropIn(pt.dataset.pltab, pr); return; }
    if (d.kind === 'item') {
      const t = e.target.closest('[data-drag]'); if (!t) return;
      const [tt, tg, ti] = t.dataset.drag.split('|'); if (tt !== d.t || tg !== d.g) return;
      UI.send({ g: 'gfx.move', v: 'vid.move', a: 'rp.angMove', p: 'rp.move', l: 'pls.move', T: 'pls.order' }[d.t], d.g, d.from, +ti);
      return;
    }
    const t = e.target.closest('.pli'); if (t) UI.send('pl.move', d.list, d.from, +t.dataset.pli); });
  document.addEventListener('dragend', () => { ui.drag = null; $$('.drop').forEach(x => x.classList.remove('drop')); });

  /* ---------- Screens menu ---------- */
  UI.screensMenu = function (anchor) {
    closeMenus();
    const m = document.createElement('div'); m.className = 'menu';
    const r = anchor.getBoundingClientRect();
    m.style.top = (r.bottom + 6) + 'px'; m.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
    m.innerHTML = [['multiview', 'Multiview monitor', 'Custom layout for an external screen'], ['director', 'Director control', 'Cameras, transitions, break'], ['graphics', 'Graphics control', 'Layers, lower thirds, suggestions'], ['replay', 'Replay control', 'Mark, angles, speed, roll'], ['audio', 'Audio control', 'Faders and mutes'], ['producer', 'Producer view', 'Clock, rundown, playlists'], ['scorebug', 'Scorebug', 'Run the score from a phone']]
      .map(([id, n, s]) => `<button data-screen="${id}"><b>${n}</b><small>${s}</small></button>`).join('') + '<button data-screen="help"><b>How to open these</b><small>Links, PIN and connected screens</small></button>';
    document.body.appendChild(m);
    m.addEventListener('click', e => { const b = e.target.closest('[data-screen]'); if (!b) return; closeMenus(); UI.openSettings('screens', b.dataset.screen); });
    setTimeout(() => document.addEventListener('click', closeMenus, { once: true }), 0);
  };
  function closeMenus() { $$('.menu').forEach(m => m.remove()); }
  UI.closeMenus = closeMenus;

  UI.confirmChangeGame = function () {
    if ($('.scrim')) return;
    const s = document.createElement('div'); s.className = 'scrim';
    s.innerHTML = `<div class="confirm" role="dialog" aria-modal="true"><h3>Pick a different game?</h3><p>This show's replays, score and game stats are cleared. Your setup, shortcuts and playlists stay.</p><div class="row" style="justify-content:flex-end"><button class="btn" data-x="no">Keep this game</button><button class="btn pri" data-x="yes">Pick a game</button></div></div>`;
    document.body.appendChild(s);
    s.addEventListener('click', e => { const b = e.target.closest('[data-x]'); if (e.target === s || (b && b.dataset.x === 'no')) s.remove(); else if (b) { PV.store.set('game', null); PV.go('main'); } });
  };
})();
