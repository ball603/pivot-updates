/* Pivot shots: Preview is a shot you build (a source plus graphics and sound), Enter takes it.
   Also the transitions row, M/Es, videos, replays by angle, sounds and the lower-third drawers. */
(function () {
  const PV = window.PV, S = window.PIVOT_SIM, G = window.PIVOT_GFX, D = window.PIVOT_DATA;
  const Eng = PV.Engine.prototype, A = Eng.actions;
  const uid = () => 'i' + Math.random().toString(36).slice(2, 9);
  const now = () => Date.now();
  const store = PV.store;

  /* ---------- parts of the show, by sport ---------- */
  PV.SEGMENTS = {
    MBB: [['open', 'Open'], ['h1', '1st Half'], ['half', 'Halftime'], ['h2', '2nd Half'], ['final', 'Final/OT'], ['post', 'Postgame']],
    WBB: [['open', 'Open'], ['q1', '1st Q'], ['q2', '2nd Q'], ['half', 'Halftime'], ['q3', '3rd Q'], ['q4', '4th Q'], ['final', 'Final/OT'], ['post', 'Postgame']],
    mih: [['open', 'Open'], ['p1', '1st P'], ['i1', '1st Intermission'], ['p2', '2nd P'], ['i2', '2nd Intermission'], ['p3', '3rd P'], ['i3', '3rd Intermission'], ['final', 'Final/OT'], ['post', 'Postgame']]
  };
  PV.SEGMENTS.wih = PV.SEGMENTS.mih;
  PV.segs = sport => PV.SEGMENTS[sport] || PV.SEGMENTS.MBB;
  const segKind = id => id === 'open' ? 'open' : id === 'final' ? 'final' : id === 'post' ? 'post' : /^(half|i\d)$/.test(id) ? 'brk' : 'play';
  PV.OUTDOOR = ['FB', 'FH', 'MSOC', 'WSOC'];

  /* new graphics in the catalogue */
  PV.GFX.push(['officials', 'Officials', 'full'], ['weather', 'Weather', 'full'], ['gameLeaders', 'Game leaders', 'full'],
    ['copyright', 'Copyright', 'full'], ['schedAway', '{A} schedule', 'full'], ['schedHome', '{H} schedule', 'full'], ['comingHalf', 'Coming up · 2nd half', 'full'], ['nextUp', 'Next games up', 'full'], ['capAway', '{A} Capsule', 'full'], ['capHome', '{H} Capsule', 'full'], ['halftime', 'Halftime report', 'full']);
  PV.GFX.find(g => g[0] === 'tapeSeason')[1] = 'Matchup';

  /* graphics for each part of the show (plus any graphic the rundown places there) */
  PV.segGfx = function (st, seg) {
    const sh = st.show, k = segKind(seg), first = PV.segs(sh.sport)[1][0] === seg;
    let list;
    if (k === 'open') list = ['title', 'tapeSeason', 'standings', 'featAway', 'featHome', 'capAway', 'capHome', 'coming'];
    else if (first) list = ['title', 'lineups', 'fiveAway', 'fiveHome', 'capAway', 'capHome', 'tape', 'officials'].concat(PV.OUTDOOR.includes(sh.sport) ? ['weather'] : []);
    else if (k === 'play') list = ['tape', 'gameLeaders', 'nextUp', 'coming'];
    else if (k === 'brk') list = ['board', 'tape', 'gameLeaders', 'standings', 'comingHalf'];
    else if (k === 'final') list = ['board', 'tape', 'gameLeaders'];
    else list = ['board', 'gameLeaders', 'nextUp', 'copyright'];
    const name = (PV.segs(sh.sport).find(s => s[0] === seg) || [0, ''])[1].toLowerCase();
    for (const it of st.rd.items) if (it.act && it.act[0] === 'gfx.play' && String(it.seg).toLowerCase() === name && !list.includes(it.act[1])) list.push(it.act[1]);
    // the operator's own order, if they've dragged these around
    const ord = st.gfxOrder && st.gfxOrder[seg];
    if (Array.isArray(ord)) { const at = r => { const i = ord.indexOf(r); return i < 0 ? 1e6 + list.indexOf(r) : i; }; list.sort((a, b) => at(a) - at(b)); }
    return list;
  };

  /* ---------- videos for each part of the show ---------- */
  const vi = (ref, name) => { const C = S.CLIPS[ref]; return { id: uid(), ref, name: name || C.name, tIn: 0, tOut: C.dur, gain: 0.8 }; };
  PV.defaultVids = function (sport) {
    const out = {};
    for (const [id] of PV.segs(sport)) {
      const k = segKind(id);
      out[id] = k === 'open' ? [vi('countdown'), vi('pivotopen'), vi('nfrpromo')]
        : k === 'play' ? [vi('sponsor1', 'Break pod · Spot A'), vi('nfrpromo', 'Break pod · Front Row promo'), vi('sponsor2', 'Break pod · Spot B')]
        : k === 'brk' ? [vi('halfopen', id === 'half' ? 'Halftime open' : 'Intermission open'), vi('sponsor1'), vi('nfrpromo'), vi('sponsor2')]
        : k === 'final' ? [vi('bumper')] : [vi('bumper'), vi('nfrpromo')];
    }
    return out;
  };
  PV.vidItem = (st, id) => { for (const k in st.vids) { const v = st.vids[k].find(x => x.id === id); if (v) return v; } return null; };

  /* ---------- sounds ---------- */
  /* the test tone, always first among the sounds (after Blank) */
  PV.TONE = { id: 'tone', name: 'Tone', tone: true, dur: 0, tIn: 0, tOut: 0, gain: 1, file: '' };
  PV.withTone = list => [Object.assign({}, PV.TONE)].concat((list || []).filter(s => s.id !== 'tone'));
  PV.defaultSnds = () => ['Open', 'Match-Up', 'Home featured player', 'Away featured player', 'To Break', 'Highlights 1', 'Highlights 2', 'Roll Out']
    .map(n => ({ id: uid(), name: n, dur: 0, tIn: 0, tOut: 0, gain: 0.8, file: '' }));

  /* ---------- M/Es ---------- */
  const L = (src, x, y, w, h, border) => ({ k: 'src', src, x, y, w, h, border: !!border });
  const third = 1 / 3;
  PV.defaultMEs2 = (cams) => Array.from({ length: Math.max(4, cams || 4) }, (_, i) => i + 1).map(n => ({ id: 'me' + n, name: `Cam ${n} + bug`, pre: 'cam', layers: [L('cam' + n, 0, 0, 1, 1), { k: 'gfx', g: 'scorebug', x: 0, y: 0, w: 1, h: 1 }], bars: [] }))
    .concat([
      { id: 'split', name: 'Split', pre: 'split', layers: [L('cam1', 0, 0, 0.5, 1), L('cam2', 0.5, 0, 0.5, 1)], bars: [{ o: 'v', at: 0.5 }] },
      { id: 'pip', name: 'PiP', pre: 'pip', layers: [L('me:me1', 0, 0, 1, 1), L('cam2', 0.62, 0.07, 0.33, 0.33, true)], bars: [] },
      { id: 'three', name: '3-up', pre: 'three', layers: [L('cam1', 0, 0, third, 1), L('cam2', third, 0, third, 1), L('cam3', 2 * third, 0, third, 1)], bars: [{ o: 'v', at: third }, { o: 'v', at: 2 * third }] },
      { id: 'quad', name: 'Quad box', pre: 'quad', layers: [L('cam1', 0, 0, 0.5, 0.5), L('cam2', 0.5, 0, 0.5, 0.5), L('cam3', 0, 0.5, 0.5, 0.5), L('cam4', 0.5, 0.5, 0.5, 0.5)], bars: [{ o: 'v', at: 0.5 }, { o: 'h', at: 0.5 }] }
    ]);
  /* the look of a video layer: rotation, opacity, crop, border, color, shadow, reflection and sound.
     Only values that differ from normal are kept, so saved M/Es stay small. */
  const LOOK = {
    fill: v => ['fill', 'fit', 'stretch'].includes(v) ? v : 'fill',
    opacity: [0, 1, 1], rotX: [-85, 85, 0], rotY: [-85, 85, 0], rotZ: [-180, 180, 0], reflection: [0, 1, 0],
    borderWidth: [0, 0.03, 0.004], borderColor: v => /^#[0-9a-f]{6}$/i.test(v || '') ? v : '#ffffff',
    shadow: v => !!v, shadowBlur: [0, 0.05, 0.01], shadowOpacity: [0, 1, 0.6],
    brightness: [-1, 1, 0], contrast: [0, 2, 1], saturation: [0, 2, 1], volume: [0, 2, 1], pan: [-1, 1, 0]
  };
  PV.LAYER_LOOK = LOOK;
  PV.layerLook = function (l) {
    const out = {};
    for (const k in LOOK) {
      if (l[k] == null) continue;
      const r = LOOK[k];
      const v = typeof r === 'function' ? r(l[k]) : Math.max(r[0], Math.min(r[1], +l[k] || 0));
      const normal = typeof r === 'function' ? (k === 'fill' ? 'fill' : k === 'borderColor' ? '#ffffff' : false) : r[2];
      if (v !== normal) out[k] = v;
    }
    if (l.crop && typeof l.crop === 'object') {
      const c = {};
      for (const k of ['l', 't', 'r', 'b']) { const v = Math.max(0, Math.min(0.45, +l.crop[k] || 0)); if (v) c[k] = v; }
      if (Object.keys(c).length) out.crop = c;
    }
    return out;
  };
  PV.meById = (st, id) => st.me && st.me.list.find(m => m.id === id);
  PV.isME = src => typeof src === 'string' && src.startsWith('me:');
  const oldName = PV.srcName, oldShort = PV.srcShort;
  PV.srcName = (st, id) => PV.isME(id) ? ((PV.meById(st, id.slice(3)) || {}).name || 'M/E') : id === 'video' && st.pl && st.pl.last && st.pl.last.name ? st.pl.last.name : oldName(st, id);
  PV.srcShort = id => PV.isME(id) ? 'M/E' : oldShort(id);
  PV.SOURCES = PV.SOURCES.filter(s => s.id !== 'me');

  /* the built-in M/Es that make sense for this many cameras: Cam N + bug for each camera,
     split and picture-in-picture from 2, 3-up from 3, quad box from 4. M/Es the operator built stay. */
  PV.syncMEs = function (st) {
    const n = PV.camIds(st).length;
    const builtIn = PV.defaultMEs2(n), ids = new Set(builtIn.map(m => m.id));
    const want = id => { const m = /^me(\d+)$/.exec(id); if (m) return +m[1] <= n; return id === 'three' ? n >= 3 : id === 'quad' ? n >= 4 : (id === 'split' || id === 'pip') ? n >= 2 : true; };
    const have = {}; for (const m of st.me.list) have[m.id] = m;
    st.me.list = builtIn.filter(m => want(m.id)).map(m => have[m.id] || m).concat(st.me.list.filter(m => !ids.has(m.id)));
  };
  /* cameras kept for replay: the first two not set to live only */
  PV.replayCams = st => PV.camIds(st).filter(id => (st.inputs[id] || {}).replay !== false).slice(0, PV.MAX_REPLAY);
  PV.replayFull = st => PV.replayCams(st).length >= PV.MAX_REPLAY;
  /* past two, the rest are live only; replays roll only angles that are kept */
  PV.fitReplay = function (st) {
    const kept = PV.replayCams(st);
    for (const id of PV.camIds(st)) if (!kept.includes(id)) st.inputs[id].replay = false;
    st.rp.angles = (st.rp.angles || []).filter(a => kept.includes(a));
  };
  function fitShow(st, E) {
    PV.syncMEs(st);
    const ok = s => !PV.isME(s) || !!PV.meById(st, s.slice(3));
    if (!ok(st.program)) E.setProgram('cam1');
    if (!ok(st.preview)) st.preview = 'cam1';
    PV.fitReplay(st);
    const rc = PV.replayCams(st);
    // replay angles roll in camera order with camera 1 last: 2, 3, 4, 1
    st.rp.angles = rc.filter(a => a !== 'cam1').sort((a, b) => +a.slice(3) - +b.slice(3)).concat(rc.includes('cam1') ? ['cam1'] : []);
  }

  /* the graphics an M/E carries full-frame get merged into the main graphics */
  PV.effGfx = function (st, src, gfx, depth) {
    const g = gfx || st.gfx;
    if (!PV.isME(src) || (depth || 0) > 2) return g;
    const me = PV.meById(st, src.slice(3)); if (!me) return g;
    let out = g;
    for (const l of me.layers) {
      const full = l.x <= 0.001 && l.y <= 0.001 && l.w >= 0.999 && l.h >= 0.999;
      if (!full) continue;
      if (l.k === 'gfx') {
        if (out === g) out = Object.assign({}, g);
        if (l.g === 'scorebug') out.scorebug = true; else if (l.g === 'watermark') out.water = true; else if (l.g === 'big') out.big = true;
        else if (l.g === 'ticker') { out.ticker = true; out.tickerData = out.tickerData || st.gfx.tickerData; }
      } else if (l.k === 'src' && PV.isME(l.src) && l.src !== src) out = PV.effGfx(st, l.src, out, (depth || 0) + 1);
    }
    return out;
  };

  /* ---------- preview shot ---------- */
  PV.itemKey = it => it.t === 'tog' ? 'tog:' + it.k : it.t === 'cat' ? 'cat:' + it.ref : it.t === 'l3' ? 'l3:' + it.spec.kind + ':' + it.spec.side + ':' + it.spec.num : it.t === 'raw' ? 'raw:' + it.slot : it.t === 'pic' ? 'pic:' + it.pic : '';
  PV.lowerKeyOf = spec => ['bio', 'game', 'season', 'text'].includes(spec.kind) ? spec.kind + spec.side + spec.num : null;
  PV.itemLive = function (st, it) {
    const g = st.gfx;
    if (it.t === 'tog') return it.k === 'scorebug' ? !!g.scorebug : it.k === 'watermark' ? !!g.water : it.k === 'big' ? !!g.big : it.k === 'ticker' ? !!g.ticker : false;
    if (it.t === 'cat') return PV.E ? PV.E.gfxLive(it.ref) : false;
    // team stats side by side: on air whichever stats are picked
    if (it.t === 'l3' && it.spec.kind === 'comps') return !!(g.lower && /^comps/.test(g.lower.key || ''));
    if (it.t === 'l3') return !!(g.lower && g.lower.key === PV.lowerKeyOf(it.spec));
    if (it.t === 'pic') return !!(g.lower && g.lower.kind === 'pic' && g.lower.pic === it.pic);
    return false;
  };
  PV.itemInPv = (st, it) => st.pv && st.pv.gfx.some(x => PV.itemKey(x) === PV.itemKey(it));
  const slotOf = it => it.t === 'raw' ? it.slot : it.t === 'tog' ? it.k : it.t === 'l3' || it.t === 'pic' ? 'lower' : (PV.isLowerRef(it.ref) ? 'lower' : /^five/.test(it.ref) ? 'take' : it.ref === 'ticker' ? 'ticker' : 'full');
  PV.slotOf = it => slotOf(it);

  Eng.buildPv = function () {
    const st = this.st, pv = st.pv, out = {};
    for (const it of pv.gfx) {
      if (it.t === 'tog') { if (it.k === 'ticker') { out.ticker = true; out.tickerData = this.buildTicker(); } else out[it.k === 'watermark' ? 'water' : it.k] = true; }
      else if (it.t === 'l3') out.lower = this.buildLower(it.spec);
      else if (it.t === 'raw') out[it.slot] = it.obj;
      else if (it.t === 'pic') { const o = this.buildPic(it.pic); if (o) out.lower = o; }
      else if (it.t === 'cat') {
        const r = it.ref;
        if (PV.isLowerRef(r, st)) out.lower = this.buildLower(PV.lowerSpec(r));
        else if (/^five/.test(r)) out.take = this.buildTake(r === 'fiveAway' ? 'away' : 'home');
        else if (r === 'ticker') { out.ticker = true; out.tickerData = this.buildTicker(); }
        else out.full = this.buildFull(r);
      }
    }
    for (const k of ['lower', 'full', 'take']) if (out[k]) { const it = pv.gfx.find(x => slotOf(x) === k); if (it && it.t !== 'raw') out[k].item = it; }
    pv.out = out;
  };
  /* a picture from the look (a rules graphic): it sits where a lower third does and comes off like one */
  Eng.buildPic = function (key) {
    const p = PV.lookPic(this.st, key); if (!p) return null;
    return { id: 'pc' + uid(), kind: 'pic', pic: key, key: 'pic' + key, label: p.name };
  };
  /* graphics that belong to a shot (they swap with it); the scorebug, big score, ticker and watermark stay on air */
  PV.SHOT_SLOTS = ['lower', 'full', 'take'];
  /* what Program will look like after the take */
  PV.pvGfx = function (st) {
    const g = st.gfx, o = (st.pv && st.pv.out) || {};
    const m = Object.assign({}, g, { trans: null });
    for (const k of PV.SHOT_SLOTS) m[k] = o[k] || null;   // a shot only carries its own graphics
    if (o.ticker) { m.ticker = true; m.tickerData = o.tickerData; }
    if (o.scorebug) m.scorebug = true; if (o.water) m.water = true; if (o.big) m.big = true;
    return PV.effGfx(st, st.preview, m);
  };
  const resetPv = st => { st.pv = { gfx: [], out: {}, snd: null, vid: null, rp: null, rd: null }; };
  PV.resetPv = resetPv;

  const CAMS = A['cams.count'];
  Object.assign(A, {
    'pv.src'(src, add) {
      const st = this.st; if (!src) return;
      if (!add) { st.pv.gfx = []; st.pv.out = {}; st.pv.snd = null; st.pv.rd = null; }
      st.preview = src; st.pv.vid = null; st.pv.rp = null;
    },
    'preview'(src) { A['pv.src'].call(this, src, false); },
    'pv.vid'(id, add) { const st = this.st; if (!PV.vidItem(st, id)) return; if (!add) { st.pv.gfx = []; st.pv.out = {}; st.pv.snd = null; st.pv.rd = null; } st.preview = 'video'; st.pv.vid = id; st.pv.rp = null; },
    'pv.rp'(clip, ang, add) { const st = this.st; if (!st.rp.clips.some(c => c.id === clip)) return; if (!add) { st.pv.gfx = []; st.pv.out = {}; st.pv.snd = null; st.pv.rd = null; } st.preview = 'replay'; st.pv.rp = { clip, ang }; st.pv.vid = null; },
    'pv.gfx'(item, add) {
      const st = this.st; if (!item || !item.t) return;
      if ((item.t === 'tog' || item.t === 'cat') && PV.lookLacks(item.k || item.ref, st)) return;
      if (item.t === 'tog' && item.k === 'watermark') { A['gfx.wm'].call(this); return; }   // the watermark is never part of a shot
      // any graphic that's on air (and not in Preview) comes off Program with one click; Shift-click still adds it to the shot
      if (PV.itemLive(st, item) && !PV.itemInPv(st, item) && !add) { A['gfx.off'].call(this, item); return; }
      const key = PV.itemKey(item), slot = slotOf(item);
      if (st.pv.gfx.some(x => PV.itemKey(x) === key)) st.pv.gfx = st.pv.gfx.filter(x => PV.itemKey(x) !== key);
      else {
        // the scorebug and the big score never share the screen: one in the shot takes the other out
        const rival = item.t === 'tog' && item.k === 'big' ? 'scorebug' : item.t === 'tog' && item.k === 'scorebug' ? 'big' : null;
        // one graphic at a time: a full screen, a lower third or a takeover replaces whichever of those is in the shot
        const one = PV.SHOT_SLOTS.includes(slot);
        st.pv.gfx = st.pv.gfx.filter(x => slotOf(x) !== slot && !(one && PV.SHOT_SLOTS.includes(slotOf(x))) && !(rival && x.t === 'tog' && x.k === rival));
        st.pv.gfx.push(item);
      }
      this.buildPv();
    },
    /* double-click: just this graphic goes to air, over whatever Program is showing (the picture doesn't change).
       Like a Take, a full page, lower third or takeover replaces whichever of those is up */
    'gfx.air'(item, _b, _c, t) {
      const st = this.st, g = st.gfx; if (!item || !item.t) return;
      if ((item.t === 'tog' || item.t === 'cat') && PV.lookLacks(item.k || item.ref, st)) return;
      if (item.t === 'tog') {
        if (item.k === 'scorebug') { g.scorebug = true; g.big = false; }
        else if (item.k === 'big') this.bigOn();
        else if (item.k === 'ticker') { g.ticker = true; g.tickerData = this.buildTicker(); }
        return;
      }
      const slot = slotOf(item);
      if (PV.SHOT_SLOTS.includes(slot)) for (const k of PV.SHOT_SLOTS) if (k !== slot) g[k] = null;
      if (item.t === 'cat') this.playGfx(item.ref, t);
      else if (item.t === 'l3') { const L = this.buildLower(item.spec); L.at = t; g.lower = L; }
      else if (item.t === 'pic') { const L = this.buildPic(item.pic); if (L) { L.at = t; g.lower = L; } }
      else if (item.t === 'raw' && item.obj) {
        const o = Object.assign({}, item.obj, { at: t });
        // a substitution joins the one already up for that team
        if (o.kind === 'subs' && g.take && g.take.kind === 'subs' && g.take.side === o.side && t - g.take.at < (g.take.hold || 9) * 1000) { o.rows = g.take.rows.concat(o.rows).slice(-4); o.players = o.rows.map(r => [r.num, r.name, r.io]); }
        if (o.kind === 'subs') o.withBug = !!g.scorebug;
        g[item.slot] = o;
        // what went to air leaves Preview
        st.pv.gfx = st.pv.gfx.filter(x => x !== item && !(x.t === 'raw' && x.slot === item.slot)); this.buildPv();
      }
    },
    /* a sound joins the shot in Preview, like a graphic; clicking it again takes it out */
    'pv.snd'(id) { const st = this.st; if (!st.snds.some(s => s.id === id)) return; st.pv.snd = st.pv.snd === id ? null : id; },
    /* X: take every graphic off the shot in Preview; the picture stays */
    'pv.gfxClear'() { const pv = this.st.pv; pv.gfx = []; pv.out = {}; },
    'gfx.wm'() { const g = this.st.gfx; g.water = !g.water; },
    /* which picture the watermark and replay burn show, and where */
    'gfx.wmSet'(p) {
      const g = this.st.gfx, w = g.wm = Object.assign({ src: 'nfr', pos: 'tr', size: 'm' }, g.wm);
      if (!p) return;
      if (typeof p.src === 'string' && /^(nfr|league|home|away|img:[\w-]+)$/.test(p.src)) w.src = p.src;
      if (['tl', 'tr', 'bl', 'br'].includes(p.pos)) w.pos = p.pos;
      if (['s', 'm', 'l'].includes(p.size)) w.size = p.size;
    },
    'gfx.burnSet'(p) {
      const b = this.st.gfx.burn; if (!p) return;
      if (typeof p.src === 'string' && /^(text|league|home|away|img:[\w-]+)$/.test(p.src)) b.src = p.src;
      if (['tl', 'tr'].includes(p.pos)) b.pos = p.pos;
    },
    'pv.sndNone'() { this.st.pv.snd = null; },
    'cams.count'(n) { CAMS.call(this, n); fitShow(this.st, this); },
    /* drag to reorder: graphics in a part of the show, videos in a part, a play's angles (their roll order), the plays */
    'gfx.move'(seg, from, to) {
      const list = PV.segGfx(this.st, seg); from = +from; to = +to;
      if (!list[from] || !list[to] || from === to) return;
      const [x] = list.splice(from, 1); list.splice(to, 0, x);
      this.st.gfxOrder = Object.assign({}, this.st.gfxOrder, { [seg]: list });
    },
    'vid.move'(seg, from, to) { const l = this.st.vids[seg]; from = +from; to = +to; if (!l || !l[from] || !l[to] || from === to) return; const [x] = l.splice(from, 1); l.splice(to, 0, x); },
    'rp.angMove'(id, from, to) { const c = this.st.rp.clips.find(x => x.id === id); from = +from; to = +to; if (!c || !c.angles[from] || !c.angles[to] || from === to) return; const [x] = c.angles.splice(from, 1); c.angles.splice(to, 0, x); },
    /* a bad angle comes out of a play; the play goes when its last angle does */
    'rp.angDel'(id, ang) {
      const st = this.st, c = st.rp.clips.find(x => x.id === id); if (!c) return;
      if (st.rp.playing && st.rp.playing.clip === id) return;
      c.angles = c.angles.filter(a => a !== ang);
      if (c.cuts) delete c.cuts[ang];
      if (st.pv.rp && st.pv.rp.clip === id && st.pv.rp.ang === ang) { st.pv.rp = null; if (st.preview === 'replay') st.preview = st.lastCam || 'cam1'; }
      if (!c.angles.length) A['rp.delete'].call(this, id);
    },
    /* speed of one play, or (no play) of the replays marked from now on */
    'rp.speed'(s, id) {
      s = Math.max(0.25, Math.min(1, +s || 0.75));
      const c = id && this.st.rp.clips.find(x => x.id === id);
      if (c) c.speed = s; else this.st.rp.speed = s;
    },
    'rp.move'(_g, from, to) { const l = this.st.rp.clips; from = +from; to = +to; if (!l[from] || !l[to] || from === to) return; const [x] = l.splice(from, 1); l.splice(to, 0, x); },
    /* + on the camera row: one more camera, kept for replay or live only */
    'cams.add'(replay) {
      const st = this.st, n = PV.camIds(st).length; if (n >= PV.MAX_CAMS) return;
      CAMS.call(this, n + 1);
      st.inputs['cam' + (n + 1)].replay = replay !== false && !PV.replayFull(st);
      fitShow(st, this);
    },
    /* the last camera can be taken away again */
    'cams.remove'() { const n = PV.camIds(this.st).length; if (n <= 1) return; CAMS.call(this, n - 1); fitShow(this.st, this); },
    'cam.replay'(id, on) {
      const i = this.st.inputs[id]; if (!i) return;
      if (on && !PV.replayCams(this.st).includes(id) && PV.replayFull(this.st)) return;   // two angles already
      i.replay = !!on; fitShow(this.st, this);
    },
    'pv.clear'() { resetPv(this.st); this.st.preview = this.st.lastCam && this.st.lastCam !== this.st.program ? this.st.lastCam : 'cam1'; },
    'gfx.off'(item) {
      const g = this.st.gfx;
      if (item.t === 'tog') { if (item.k === 'scorebug') g.scorebug = false; else if (item.k === 'watermark') g.water = false; else if (item.k === 'big') g.big = false; else if (item.k === 'ticker') g.ticker = false; }
      else if (item.t === 'cat') this.clearGfx(item.ref);
      else if (item.t === 'l3' || item.t === 'pic') g.lower = null;
    },
    'trans.sel'(id) { const st = this.st; if (id === 'cut' || id === 'fade' || PV.wipeOk(st, id)) { st.trans.sel = id; if (id !== 'cut' && id !== 'fade') st.trans.wipe = id; } },
    'trans.cycle'() {
      const st = this.st, w = st.trans.wipes; if (!w.length) return;
      const i = w.findIndex(x => x.id === st.trans.sel);
      const nx = i < 0 ? (w.find(x => x.id === st.trans.wipe) || w[0]) : w[(i + 1) % w.length];
      st.trans.sel = nx.id; st.trans.wipe = nx.id;
    },
    'trans.add'(kind, side) {
      const st = this.st, sh = st.show;
      const base = kind === 'logo' ? { name: 'NEC logo', kind: 'logo' } : kind === 'player' ? { name: `${sh[side].code} player`, kind: 'player', side } : kind === 'team' ? { name: sh[side].name, kind: 'team', side } : { name: 'Sponsor', kind: 'sponsor' };
      const w = Object.assign({ id: 'w' + uid() }, base); st.trans.wipes.push(w); st.trans.sel = w.id; st.trans.wipe = w.id;
    },
    'trans.del'(id) { const st = this.st; if (id === 'replay') return; st.trans.wipes = st.trans.wipes.filter(w => w.id !== id); if (st.trans.sel === id) st.trans.sel = 'cut'; if (st.trans.wipe === id) st.trans.wipe = 'replay'; },
    'auto'(src, _b, _c, t) { if (src) A['pv.src'].call(this, src); A.take.call(this, 'fade', 0, 0, t); },
    'cut'(src, _b, _c, t) { if (src) A['pv.src'].call(this, src); A.take.call(this, 'cut', 0, 0, t); },
    'sting'(src, _b, _c, t) { if (src) A['pv.src'].call(this, src); A.take.call(this, this.st.trans.wipe || 'replay', 0, 0, t); },

    /* Enter: take whatever is built in Preview */
    'take'(how, _b, _c, t) {
      const st = this.st, pv = st.pv;
      t = t || now();
      how = how || PV.spaceHow(st);
      let wid = null;
      if (how !== 'cut' && how !== 'fade') { wid = st.trans.wipes.some(w => w.id === how) ? how : (st.trans.wipe || 'replay'); how = 'wipe'; }
      const base = st.preview, oldPgm = st.program;
      const reroll = (base === 'video' && pv.vid) || (base === 'replay' && pv.rp);
      const switching = base !== st.program || reroll;
      const rdi = pv.rd;
      // the graphics on air come back to Preview with their picture (not from a video or replay, which never come back)
      const g0 = st.gfx, back = [], backOut = {};
      for (const k of PV.SHOT_SLOTS) if (g0[k]) { back.push(g0[k].item ? g0[k].item : { t: 'raw', slot: k, obj: g0[k] }); backOut[k] = g0[k]; }
      if (switching) {
        if (base === 'video' && pv.vid) this.startVid(pv.vid, t, how, wid);
        else if (base === 'replay' && pv.rp) this.startRp(pv.rp, t, how, wid);
        else this.switchTo(base, t, how, wid);
        if (PV.isME(base)) { const me = PV.meById(st, base.slice(3)); if (me) for (const l of me.layers) if (l.k === 'snd') this.playSnd(l.id, t); }
      }
      const g = st.gfx, o = pv.out || {};
      for (const k of PV.SHOT_SLOTS) { g[k] = o[k] || null; if (g[k] && k !== 'full') g[k].at = t; }
      if (o.ticker) { g.ticker = true; g.tickerData = o.tickerData; }
      if (o.scorebug) g.scorebug = true; if (o.big) this.bigOn();
      if (st.sndPlay && st.sndPlay.tone && pv.snd !== 'tone') st.sndPlay = null;   // the tone stops with the next shot
      if (pv.snd) this.playSnd(pv.snd, t);
      const prevBase = switching ? st.preview : base;
      resetPv(st);
      st.preview = prevBase;
      if (!['video', 'replay'].includes(oldPgm)) { st.pv.gfx = back; st.pv.out = backOut; }
      if (rdi != null) this.rdTaken(rdi, t);
      if (how === 'wipe') PV.afterWipe(st, wid);
    },
    'snd.stop'() { this.st.sndPlay = null; },
    'vid.edit'(id, patch) {
      const v = PV.vidItem(this.st, id); if (!v || !patch) return;
      const dur = v.dur || (S.CLIPS[v.ref] || {}).dur || 60;
      if (typeof patch.name === 'string') v.name = patch.name.slice(0, 40) || v.name;
      if (patch.tIn != null) v.tIn = Math.max(0, Math.min(dur - 0.5, +patch.tIn));
      if (patch.tOut != null) v.tOut = Math.max(v.tIn + 0.5, Math.min(dur, +patch.tOut));
      if (patch.gain != null) v.gain = Math.max(0, Math.min(1, +patch.gain));
    },
    /* a real video file (the Mac app): ref is file:<id> */
    'vid.addFile'(seg, it) {
      const st = this.st; if (!st.vids[seg] || !it || !/^file:/.test(it.ref)) return;
      const dur = Math.max(0.5, +it.dur || 0);
      st.vids[seg].push({ id: uid(), ref: it.ref, name: String(it.name || 'Video').slice(0, 40), tIn: 0, tOut: dur, dur, gain: 0.8 });
    },
    'vid.add'(seg, ref) { const st = this.st; if (!st.vids[seg] || !S.CLIPS[ref]) return; st.vids[seg].push(vi(ref)); },
    'vid.del'(id) { const st = this.st; for (const k in st.vids) st.vids[k] = st.vids[k].filter(v => v.id !== id); },
    /* the speaker: program sound to the stream and recording; the headphones: program sound out of this Mac */
    'audio.pgm'() { this.st.audio.pgmMute = !this.st.audio.pgmMute; },
    'audio.hp'() { this.st.audio.hp = !this.st.audio.hp; },
    /* ⌘R on a graphic: its own name (empty goes back to the usual one) */
    'gfx.name'(ref, name) {
      const st = this.st; st.gfxNames = Object.assign({}, st.gfxNames);
      const n = String(name || '').trim().slice(0, 40);
      if (n) st.gfxNames[ref] = n; else delete st.gfxNames[ref];
    },
    'snd.edit'(id, patch) {
      const s = this.st.snds.find(x => x.id === id); if (!s || !patch) return;
      if (typeof patch.name === 'string') s.name = patch.name.slice(0, 30) || s.name;
      if (patch.dur != null) { s.dur = Math.max(0, +patch.dur || 0); if (!s.tOut || s.tOut > s.dur) s.tOut = s.dur; }
      if (patch.file != null) s.file = String(patch.file).slice(0, 80);
      if (patch.tIn != null) s.tIn = Math.max(0, Math.min(Math.max(0, s.dur - 0.2), +patch.tIn));
      if (patch.tOut != null) s.tOut = Math.max(s.tIn + 0.2, Math.min(s.dur || 600, +patch.tOut));
      if (patch.gain != null) s.gain = Math.max(0, Math.min(1, +patch.gain));
    },
    'snd.add'(name) { this.st.snds.push({ id: uid(), name: String(name || 'New sound').slice(0, 30), dur: 0, tIn: 0, tOut: 0, gain: 0.8, file: '' }); },
    'snd.del'(id) { if (id === 'tone') return; this.st.snds = this.st.snds.filter(s => s.id !== id); },
    /* a corrected bio ({name, sub}) or a note ({sub}) for a player; empty puts the bio back */
    /* actions take three values at most, so who it's for comes as one: { side, num, kind } */
    'l3.text'(who, o) {
      const st = this.st; if (!who || !['bio', 'text'].includes(who.kind) || !o) return;
      const { side, num, kind } = who;
      const k = `${side}|${num}|${kind}`, v = { name: String(o.name || '').slice(0, 40), sub: String(o.sub || '').slice(0, 90) };
      // a note can have a second line for the box under the lower third ("Today", "Entering today")
      if (kind === 'text' && o.drop) v.drop = String(o.drop).slice(0, 60);
      st.l3text = Object.assign({}, st.l3text);
      if (v.name || v.sub || v.drop) st.l3text[k] = v; else delete st.l3text[k];
      // a corrected bio is kept for that team's player in every later show
      if (kind === 'bio' && st.show[side]) { const b = store.get('bios', {}); const bk = `${st.show[side].key}|${num}`; if (v.name || v.sub) b[bk] = v; else delete b[bk]; store.set('bios', b); }
      if (st.pv.gfx.length) this.buildPv();
      const g = st.gfx, spec = { kind, side, num };
      if (g.lower && g.lower.key === PV.lowerKeyOf(spec)) { const at = g.lower.at; g.lower = this.buildLower(spec); g.lower.at = at; }
    },
    'l3.pick'(key, list) { if (Array.isArray(list) && list.length) { this.st.l3pick[key] = list.slice(0, 3).map(String); if (this.st.pv.gfx.length) this.buildPv(); } },
    'gfx.text'(ref, patch) {
      if ((ref !== 'big' && !PV.GFX.some(g => g[0] === ref)) || !patch) return;
      const o = { title: String(patch.title || '').slice(0, 60), sub: String(patch.sub || '').slice(0, 80) };
      if (patch.foot) o.foot = String(patch.foot).slice(0, 80);   // a bottom line (the standings' note)
      // a graphic with lines of its own (a team capsule) keeps each one typed
      if (Array.isArray(patch.lines)) { const l = patch.lines.slice(0, 4).map(x => String(x || '').slice(0, 80)); if (l.some(Boolean)) o.lines = l; }
      if (o.title || o.sub || o.foot || o.lines) this.st.text[ref] = o; else delete this.st.text[ref];
      if (ref !== 'big' && this.gfxLive(ref)) this.playGfx(ref, now());
    },
    'rp.name'(id, name) { if (typeof name === 'string' && name.trim()) PV.rpRename(this.st, id, name.trim().slice(0, 40)); },
    'show.officials'(list) { if (Array.isArray(list)) this.st.show.officials = list.map(x => String(x || '').slice(0, 40)).slice(0, 4); },
    'me.save2'(m) {
      const st = this.st; if (!m || !Array.isArray(m.layers)) return;
      const c01 = v => { v = +v; return isFinite(v) ? Math.max(-0.5, Math.min(1.5, v)) : 0; };
      const okSrc = s => PV.isCam(st, s) || /^(replay|video|black)$/.test(s) || (PV.isME(s) && s.slice(3) !== m.id && !!PV.meById(st, s.slice(3)));
      const layers = m.layers.slice(0, 5).map(l => {
        const b = { x: c01(l.x), y: c01(l.y), w: Math.max(0.03, c01(l.w)), h: Math.max(0.03, c01(l.h)) };
        if (l.k === 'gfx' && ['scorebug', 'watermark', 'ticker', 'big'].includes(l.g)) return Object.assign({ k: 'gfx', g: l.g }, b);
        if (l.k === 'snd' && st.snds.some(s => s.id === l.id)) return { k: 'snd', id: l.id, x: 0, y: 0, w: 0, h: 0 };
        if (l.k === 'src' && okSrc(l.src)) return Object.assign({ k: 'src', src: l.src, border: !!l.border }, b, PV.layerLook(l));
        return null;
      }).filter(Boolean);
      const clean = { id: String(m.id || 'me' + uid()).slice(0, 30), name: String(m.name || 'M/E').slice(0, 30), pre: m.pre || null, layers, bars: Array.isArray(m.bars) ? m.bars.filter(b => b && (b.o === 'v' || b.o === 'h')).slice(0, 4) : [] };
      const i = st.me.list.findIndex(x => x.id === clean.id);
      if (i >= 0) st.me.list[i] = clean; else st.me.list.push(clean);
    },
    'me.del'(id) { const st = this.st; if (/^me[1-4]$|^(split|pip|three|quad)$/.test(id)) return; st.me.list = st.me.list.filter(m => m.id !== id); if (st.preview === 'me:' + id) st.preview = 'cam1'; },
    'rd.pv'(i) { this.rdPreview(i); },
    /* drag a rundown item to a new spot; it joins the part of the show it's dropped into */
    'rd.move'(from, to) {
      const rd = this.st.rd, items = rd.items; from = +from; to = +to;
      if (!(from >= 0 && from < items.length && to >= 0 && to < items.length) || from === to) return;
      const at = i => items[i] || null, onAir = rd.on ? at(rd.idx) : null, cue = at(rd.cue), inPv = this.st.pv.rd != null ? at(this.st.pv.rd) : null;
      const seg = items[to].seg;
      const [it] = items.splice(from, 1); items.splice(to, 0, it); it.seg = seg;
      if (onAir) rd.idx = items.indexOf(onAir);
      rd.cue = cue ? items.indexOf(cue) : items.length;
      if (inPv) this.st.pv.rd = items.indexOf(inPv);
    },
    'rd.next'() { const rd = this.st.rd; const i = rd.cue != null ? rd.cue : rd.idx + 1; if (i >= 0 && i < rd.items.length) this.rdPreview(i); },
    'rd.run'(i, _b, _c, t) { const rd = this.st.rd; if (i < 0 || i >= rd.items.length) return; if (i === rd.idx && rd.on) this.rundownOff(); else this.rdPreview(i); }
  });

  /* clicking a rundown item builds it in Preview; Enter takes it */
  Eng.rdPreview = function (i) {
    const st = this.st, rd = st.rd, it = rd.items[i]; if (!it) return;
    const [n, a] = it.act || [];
    // the rundown never picks a camera: a graphic joins the shot already in Preview, a camera item is just a note
    if (n === 'gfx.play') { if (!PV.itemInPv(st, { t: 'cat', ref: a })) A['pv.gfx'].call(this, { t: 'cat', ref: a }, true); }
    else if (n === 'pl.cue') { let v = null; for (const k in st.vids) v = v || st.vids[k].find(x => x.ref === a); if (v) { resetPv(st); st.preview = 'video'; st.pv.vid = v.id; } }
    st.pv.rd = i; rd.cue = i;
  };
  /* the rundown item that was in Preview just went to air */
  Eng.rdTaken = function (i, t) {
    const st = this.st, rd = st.rd, it = rd.items[i]; if (!it) return;
    if (rd.on && rd.idx !== i) { const cur = rd.items[rd.idx]; if (cur) cur.done = true; }
    rd.idx = i; rd.on = true; rd.cue = i + 1; it.done = true; it.at = t;
    st.sugg = st.sugg.filter(x => x.id !== 'rd');
    const [n, a, b] = it.act || [];
    if (n && !['gfx.play', 'auto', 'cut', 'pl.cue'].includes(n) && A[n]) A[n].call(this, a, b, undefined, t);
  };

  /* Space and TAKE use the transition picked in the column. A replay never just cuts in or out:
     with Cut picked it uses the Wipe (pick Fade for an unbranded one). Enter always cuts. */
  PV.spaceHow = st => {
    let sel = st.trans.sel || 'cut';
    if (!['cut', 'fade'].includes(sel) && !PV.wipeOk(st, sel)) sel = 'replay';   // a team wipe the look doesn't have
    const replay = st.preview === 'replay' || st.program === 'replay';
    return sel === 'cut' && replay ? (PV.wipeOk(st, st.trans.wipe) ? st.trans.wipe : 'replay') : sel;
  };
  /* Fade and Wipe stay picked; a branded wipe (a team, or one added with +) is used once, then the pick goes back to Wipe.
     A replay keeps the branded wipe for its way out, so the play still leaves the way it came in. */
  PV.afterWipe = (st, wid) => { if (wid && wid !== 'replay' && st.trans.sel === wid) { st.trans.sel = 'replay'; st.trans.wipe = 'replay'; } };
  /* ---------- switching ---------- */
  Eng.switchTo = function (to, t, how, wid, stamp) {
    const st = this.st;
    if (to === st.program && how !== 'wipe') return;
    if (st.rp.playing && st.program === 'replay' && to !== 'replay') st.rp.playing = null;
    if (how === 'cut') { st.trans.active = null; this.setProgram(to); }
    else if (how === 'fade') { st.trans.active = { type: 'mix', from: st.program, to, start: t, dur: st.trans.dur }; this.setProgram(to); }
    else st.trans.active = PV.sting(st, { type: 'stinger', from: st.program, to, start: t, dur: 1000, cut: false, wipe: wid || 'replay', stamp: stamp || null });
  };
  Eng.startVid = function (id, t, how, wid) {
    const st = this.st, v = PV.vidItem(st, id); if (!v) return;
    if (st.pl.active) { st.pl.active = null; }
    const delay = how === 'wipe' ? PV.wipeHalf(st, 'video', wid) : 0;
    st.pl.last = { ref: v.ref, name: v.name, id: v.id, start: t + delay, tIn: v.tIn, tOut: v.tOut, gain: v.gain, bounce: true, how, wid };
    st.gfx.full = null;
    if (st.program === 'video') { if (how === 'wipe') this.switchTo('video', t, how, wid); }
    else this.switchTo('video', t, how, wid);
  };
  /* a replay ends the way it came in */
  Eng.endReplay = function () {
    const st = this.st, rp = st.rp.playing; if (!rp) return;
    st.rp.playing = null;
    if (rp.fromPl) { this.itemDone(); return; }
    const to = rp.ret || 'cam1', t = now();
    // a playlist that ends on an end stamp goes back to the live shot under it
    if (rp.outStamp && !rp.stopped) { st.trans.active = PV.sting(st, { type: 'stinger', from: 'replay', to: rp.outTo || PV.stampBack(st, to), start: t, dur: 1000, cut: false, wipe: 'replay', stamp: rp.outStamp }); return; }
    if (rp.how === 'cut') { st.trans.active = null; this.setProgram(to); }
    else if (rp.how === 'fade') { st.trans.active = { type: 'mix', from: 'replay', to, start: t, dur: st.trans.dur }; this.setProgram(to); }
    else st.trans.active = PV.sting(st, { type: 'stinger', from: 'replay', to, start: t, dur: 1000, cut: false, wipe: rp.wid || 'replay' });
  };
  Eng.playSnd = function (id, t) {
    const s = this.st.snds.find(x => x.id === id); if (!s) return;
    if (s.tone) { this.st.sndPlay = { id, start: t, end: t + 864e5, gain: 1, tone: true }; return; }   // runs until the next Take
    const len = s.dur ? Math.max(0.2, (s.tOut || s.dur) - s.tIn) : 8;
    this.st.sndPlay = { id, start: t, end: t + len * 1000, gain: s.gain, file: !!s.file };
  };

  /* ---------- the rundown keeps up with the game: a new half or quarter, halftime, the end of a quarter
     and the final move the rundown's next item there (never backwards, so nothing the operator cued is undone) ---------- */
  function followClock(st) {
    const sb = st.sb, R = st.show.rules, rd = st.rd;
    const key = sb.status === 'live' ? 'p' + sb.period : sb.status === 'break' ? 'e' + sb.period : sb.status;
    if (rd.segKey === key) return false;
    const first = rd.segKey == null; rd.segKey = key;
    if (first) return false;   // just opened: the rundown is already where it was left
    const per = p => R.periods === 2 ? (p === 1 ? '1st Half' : '2nd Half') : `${PV.ordinal(p)} Quarter`;
    let i = -1;
    if (sb.status === 'half') i = rd.items.findIndex(x => x.seg === 'Halftime');
    else if (sb.status === 'final') i = rd.items.findIndex(x => x.seg === 'Postgame');
    else if (sb.status === 'break') i = rd.items.findIndex(x => x.seg === per(sb.period) && /^End of /.test(x.label));
    else if (sb.status === 'live' && sb.period <= R.periods) i = rd.items.findIndex(x => x.seg === per(sb.period));
    if (i < 0 || i <= (rd.cue || 0)) return false;
    rd.cue = i; rd.follow = true;
    return true;
  }

  /* The scorebug and the big score are never on air together, and only one graphic is: a full screen, a lower
     third or a takeover. Whichever just came on stays; the other goes. The scorebug, ticker and watermark sit beside them. */
  const oldAct = Eng.act;
  Eng.act = function (name, a, b, c) {
    const g = this.st.gfx, bug0 = !!g.scorebug, big0 = !!g.big;
    const before = PV.SHOT_SLOTS.map(k => g[k]);
    const r = oldAct.call(this, name, a, b, c);
    if (g.scorebug && g.big) { if (!big0) g.scorebug = false; else if (!bug0) g.big = false; else g.scorebug = false; this.changed(); }
    const on = PV.SHOT_SLOTS.filter(k => g[k]);
    if (on.length > 1) {
      const fresh = on.filter((k, i) => g[k] !== before[PV.SHOT_SLOTS.indexOf(k)]);
      const keep = fresh.length ? fresh[fresh.length === 1 ? 0 : fresh.indexOf('full') >= 0 ? fresh.indexOf('full') : 0] : 'full';
      for (const k of on) if (k !== keep) g[k] = null;
      this.changed();
    }
    return r;
  };
  /* ---------- tick additions: videos bounce back, sounds end ---------- */
  const oldTick = Eng.tick;
  Eng.tick = function () {
    oldTick.call(this);
    const st = this.st, t = now();
    let dirty = false;
    const lv = st.pl.last;
    if (lv && lv.bounce && !st.pl.active && st.program === 'video' && !st.trans.active && t >= lv.start + (lv.tOut - lv.tIn) * 1000) {
      lv.bounce = false;
      const back = /^cam|^me:/.test(st.preview) ? st.preview : (st.lastCam || 'cam1');
      this.switchTo(back, t, lv.how === 'cut' ? 'cut' : lv.how === 'wipe' ? 'wipe' : 'fade', lv.wid);
      dirty = true;
    }
    if (st.sndPlay && t >= st.sndPlay.end) { st.sndPlay = null; dirty = true; }
    if (followClock(st)) dirty = true;
    // the second half of going into or out of a break, once the screen is black
    const bs = st.brkStep;
    if (bs && t >= bs.at) {
      st.brkStep = null;
      if (bs.then === 'roll' && st.brk) { this.playItem('brk', 0, true); if (st.trans.active && st.trans.active.from === 'black') st.trans.active = null; }
      else if (bs.then === 'back' && !st.brk) {
        st.trans.active = { type: 'mix', from: 'black', to: bs.to, start: t, dur: 1000 }; this.setProgram(bs.to);
        if (st.preview === 'black' || st.preview === bs.to) st.preview = bs.prev || PV.camIds(st).find(c => c !== bs.to) || 'cam1';   // Preview gets a camera back, not black
      }
      dirty = true;
    }
    if (dirty) this.changed();
  };

  /* ---------- new graphics ---------- */
  /* every box-score stat a lower third can show; the values come from the stats feed (blank until it has them) */
  const pct = (m, a) => a ? (m / a * 100).toFixed(0) + '%' : '—';
  const GAME_STATS = {
    pts: ['PTS', b => b.pts, 'Points'], fg: ['FG', b => `${b.fgm}-${b.fga}`, 'Field goals'], fgp: ['FG%', b => pct(b.fgm, b.fga), 'Field goal %'],
    tp: ['3FG', b => `${b.tpm}-${b.tpa}`, '3-pointers'], tpp: ['3FG%', b => pct(b.tpm, b.tpa), '3-point %'],
    ft: ['FT', b => `${b.ftm}-${b.fta}`, 'Free throws'], ftp: ['FT%', b => pct(b.ftm, b.fta), 'Free throw %'],
    reb: ['REB', b => b.reb, 'Rebounds'], oreb: ['OREB', b => b.oreb, 'Offensive rebounds'], dreb: ['DREB', b => Math.max(0, b.reb - b.oreb), 'Defensive rebounds'],
    ast: ['AST', b => b.ast, 'Assists'], stl: ['STL', b => b.stl, 'Steals'], blk: ['BLK', b => b.blk, 'Blocks'], to: ['TO', b => b.to, 'Turnovers'],
    pf: ['PF', b => b.pf, 'Fouls'], min: ['MIN', b => b.min, 'Minutes']
  };
  /* season averages and totals, by position in the season stats from NEC Front Row */
  const SEASON_STATS = {
    ppg: ['PPG', 0, 'Points per game'], rpg: ['RPG', 1, 'Rebounds per game'], apg: ['APG', 2, 'Assists per game'], gp: ['GAMES', 3, 'Games played'],
    spg: ['SPG', 4, 'Steals per game'], bpg: ['BPG', 5, 'Blocks per game'], mpg: ['MPG', 6, 'Minutes per game'],
    fgp: ['FG%', 7, 'Field goal %'], tpp: ['3FG%', 8, '3-point %'], ftp: ['FT%', 9, 'Free throw %'], gs: ['STARTS', 10, 'Games started']
  };
  PV.GAME_STATS = GAME_STATS; PV.SEASON_STATS = SEASON_STATS;
  PV.l3key = (side, num, mode) => side + '|' + num + '|' + mode;
  const BOX0 = { pts: 0, fgm: 0, fga: 0, tpm: 0, tpa: 0, ftm: 0, fta: 0, reb: 0, oreb: 0, ast: 0, stl: 0, blk: 0, to: 0, pf: 0, min: 0 };
  PV.BOX0 = BOX0;
  /* the season the stats on file are from, and the season of this game (July starts a new one) */
  PV.STATS_SEASON = (window.PIVOT_DATA && window.PIVOT_DATA.STATS_SEASON) || '2025-26';
  PV.gameSeason = sh => { const d = new Date((sh.game && sh.game.at) || Date.now()); const y = d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1; return `${y}-${String((y + 1) % 100).padStart(2, '0')}`; };
  /* "Entering today" while the stats are this season's; otherwise which season they're from */
  PV.seasonLine = sh => PV.gameSeason(sh) === PV.STATS_SEASON ? 'Entering ' + PV.todayWord(sh).toLowerCase() : `${PV.STATS_SEASON} season`;
  PV.seasonVal = (ss, k) => { const d = SEASON_STATS[k]; if (!d || !ss) return null; const v = ss[d[1]]; if (v == null || v === '') return null; return /%$/.test(d[0]) ? (+v).toFixed(1) + '%' : (k === 'gp' || k === 'gs') ? String(v) : (+v).toFixed(1); };
  /* words the operator typed for a player: a corrected bio, or a note (the Text lower thirds) */
  PV.l3words = (st, side, num, kind) => ((st.l3text || {})[`${side}|${num}|${kind}`]) || null;

  const oldLower = Eng.buildLower0;
  Eng.buildLower0 = function (spec) {
    if (!['bio', 'game', 'season', 'text'].includes(spec.kind)) return oldLower.call(this, spec);
    const st = this.st, sh = st.show, t = sh[spec.side];
    const p = PV.player(sh, spec.side, spec.num) || [spec.num, 'Player', '#' + spec.num, '', '', '', ''];
    const base = { id: spec.kind + uid(), kind: 'player', key: spec.kind + spec.side + spec.num, side: spec.side, num: p[0], name: `${p[1]} ${p[2]}`.trim() };
    if (spec.kind === 'bio') {
      const w = PV.l3words(st, spec.side, p[0], 'bio') || {};
      return Object.assign(base, { label: `#${p[0]} ${p[2]} · bio`, name: w.name || base.name, sub: w.sub != null && w.sub !== '' ? w.sub : [p[3], p[4], p[5], p[6]].filter(Boolean).join(' · '), bioEdited: !!w.sub, stats: [] });
    }
    if (spec.kind === 'text') {
      const w = PV.l3words(st, spec.side, p[0], 'text') || {};
      return Object.assign(base, { label: `#${p[0]} ${p[2]} · text`, sub: w.sub || '', drop: w.drop || '', note: true, stats: [] });
    }
    if (spec.kind === 'game') {
      const b = Object.assign({}, BOX0, this.statFor(spec.side, p[0]));
      const pick = st.l3pick[PV.l3key(spec.side, p[0], 'game')] || ['pts', 'tp', 'ast'];
      return Object.assign(base, { label: `#${p[0]} ${p[2]} · game`, sub: PV.todayWord(sh), stats: pick.filter(k => GAME_STATS[k]).map(k => [GAME_STATS[k][1](b), GAME_STATS[k][0]]) });
    }
    const ss = t.pstats[p[0]];
    const pick = st.l3pick[PV.l3key(spec.side, p[0], 'season')] || ['ppg', 'rpg', 'apg'];
    return Object.assign(base, { label: `#${p[0]} ${p[2]} · season`, sub: ss ? PV.seasonLine(sh) : 'No season stats yet', stats: ss ? pick.map(k => [PV.seasonVal(ss, k), (SEASON_STATS[k] || [])[0]]).filter(x => x[0] != null && x[1]) : [] });
  };


  const WX = window.PIVOT_WX || {};
  const WXT = { 0: 'Clear', 1: 'Mostly clear', 2: 'Partly cloudy', 3: 'Cloudy', 45: 'Fog', 48: 'Fog', 51: 'Light drizzle', 53: 'Drizzle', 55: 'Heavy drizzle', 61: 'Light rain', 63: 'Rain', 65: 'Heavy rain', 71: 'Light snow', 73: 'Snow', 75: 'Heavy snow', 56: 'Freezing drizzle', 57: 'Freezing drizzle', 66: 'Freezing rain', 67: 'Freezing rain', 77: 'Snow', 80: 'Showers', 81: 'Showers', 82: 'Heavy showers', 85: 'Snow showers', 86: 'Snow showers', 95: 'Thunderstorms', 96: 'Thunderstorms', 99: 'Thunderstorms' };
  /* Live weather from Open-Meteo for the venue's town: the forecast for the game's day and, on game day, what it is now.
     Asked again every 15 minutes while a show uses it. Until it answers (or with no internet) the copy built in is used. */
  const STATES = { AL: 'Alabama', AK: 'Alaska', AZ: 'Arizona', AR: 'Arkansas', CA: 'California', CO: 'Colorado', CT: 'Connecticut', DE: 'Delaware', DC: 'District of Columbia', FL: 'Florida', GA: 'Georgia', HI: 'Hawaii', ID: 'Idaho', IL: 'Illinois', IN: 'Indiana', IA: 'Iowa', KS: 'Kansas', KY: 'Kentucky', LA: 'Louisiana', ME: 'Maine', MD: 'Maryland', MA: 'Massachusetts', MI: 'Michigan', MN: 'Minnesota', MS: 'Mississippi', MO: 'Missouri', MT: 'Montana', NE: 'Nebraska', NV: 'Nevada', NH: 'New Hampshire', NJ: 'New Jersey', NM: 'New Mexico', NY: 'New York', NC: 'North Carolina', ND: 'North Dakota', OH: 'Ohio', OK: 'Oklahoma', OR: 'Oregon', PA: 'Pennsylvania', RI: 'Rhode Island', SC: 'South Carolina', SD: 'South Dakota', TN: 'Tennessee', TX: 'Texas', UT: 'Utah', VT: 'Vermont', VA: 'Virginia', WA: 'Washington', WV: 'West Virginia', WI: 'Wisconsin', WY: 'Wyoming' };
  const getJSON = url => PV.native && PV.native.http
    ? PV.native.http(url).then(r => { if (!r || r.status !== 200) throw new Error('weather ' + (r ? r.status : 0)); return JSON.parse(r.text); })
    : fetch(url).then(r => { if (!r.ok) throw new Error('weather ' + r.status); return r.json(); });
  const wxLive = {};   // town -> { at, daily, now } or { at, err }
  PV.wxTown = sh => [sh.game.city, sh.game.state].filter(Boolean).join(', ');
  PV.wxFetch = function (sh) {
    const town = PV.wxTown(sh); if (!sh.game.city) return Promise.resolve(null);
    const have = wxLive[town];
    if (have && Date.now() - have.at < (have.err ? 120000 : 900000)) return Promise.resolve(have);
    if (have && have.p) return have.p;
    const st = String(sh.game.state || '').toUpperCase(), stateName = STATES[st] || sh.game.state || '';
    const p = getJSON(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(sh.game.city)}&count=10&language=en&format=json`).then(g => {
      const list = (g && g.results) || [];
      const hit = list.find(r => r.country_code === 'US' && (!stateName || r.admin1 === stateName)) || list.find(r => r.country_code === 'US') || list[0];
      if (!hit) throw new Error('town not found');
      return getJSON(`https://api.open-meteo.com/v1/forecast?latitude=${hit.latitude}&longitude=${hit.longitude}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max&current=temperature_2m,weather_code,wind_speed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=auto&forecast_days=16`);
    }).then(f => {
      const d = f.daily || {};
      const out = { at: Date.now(), days: (d.time || []).map((day, i) => ({ day, code: d.weather_code[i], hi: Math.round(d.temperature_2m_max[i]), lo: Math.round(d.temperature_2m_min[i]), pop: d.precipitation_probability_max[i] == null ? 0 : d.precipitation_probability_max[i], wind: Math.round(d.wind_speed_10m_max[i]) })),
        now: f.current ? { day: String(f.current.time || '').slice(0, 10), temp: Math.round(f.current.temperature_2m), code: f.current.weather_code } : null };
      wxLive[town] = out; if (PV.E) PV.E.changed(); return out;
    }).catch(e => { wxLive[town] = { at: Date.now(), err: String(e && e.message || e) }; return null; });
    wxLive[town] = Object.assign({}, have || { at: 0 }, { p });
    return p;
  };
  // keep the venue's weather fresh while a show is up, so it's there the moment a graphic needs it
  setInterval(() => { const sh = PV.E && PV.E.st && PV.E.st.show; if (sh && sh.game && sh.game.city) PV.wxFetch(sh); }, 20000);
  setTimeout(() => { const sh = PV.E && PV.E.st && PV.E.st.show; if (sh && sh.game && sh.game.city) PV.wxFetch(sh); }, 1500);
  PV.weatherFor = function (key, day, sh) {
    // the live forecast first (asking for it if it's due), then the copy built in
    sh = sh || (PV.E && PV.E.st.show);
    if (sh && sh.game && sh.game.city) {
      PV.wxFetch(sh);
      const L = wxLive[PV.wxTown(sh)], d = L && L.days && L.days.find(x => x.day === day);
      if (d) {
        const now = L.now && L.now.day === day ? { temp: L.now.temp, text: WXT[L.now.code] || 'Mixed' } : null;
        return { hi: d.hi, lo: d.lo, text: WXT[d.code] || 'Mixed', pop: d.pop, wind: d.wind, code: d.code, now, live: true };
      }
    }
    const w = WX[key]; if (!w) return null;
    const i = Math.round((new Date(day + 'T12:00') - new Date(w.from + 'T12:00')) / 864e5);
    if (i < 0 || i >= w.hi.length) return null;
    return { hi: w.hi[i], lo: w.lo[i], text: WXT[w.code[i]] || 'Mixed', pop: w.pop[i], wind: w.wind[i], code: w.code[i] };
  };

  const oldFull = Eng.buildFull0;
  Eng.buildFull0 = function (kind, opts) {
    const st = this.st, sh = st.show;
    if (kind === 'copyright') {
      const owner = PV.copyrightOwner(sh);
      return { id: 'cr' + uid(), kind: 'copyright', label: 'Copyright', year: PV.showYear(sh), owner,
        notice: `All rights reserved. This telecast may not be rebroadcast or retransmitted without the express written consent of ${owner}.` };
    }
    if (kind === 'officials') {
      const l = (sh.officials || []).filter(Boolean), soccer = !!(sh.rules && sh.rules.soccer);
      // soccer has a referee and assistant referees; basketball a referee and umpires
      return { id: 'of' + uid(), kind: 'list', label: 'Officials', title: 'Tonight\'s Officials', kicker: sh.event, names: l,
        rows: l.length ? l.map((n, i) => [i === 0 ? 'Referee' : soccer ? 'Assistant referee' : 'Umpire', n]) : [['Officials', 'Add names: right-click or ⌘E']] };
    }
    if (kind === 'weather') {
      const w = PV.weatherFor(sh.home.key, (sh.game.at || '').slice(0, 10));
      return { id: 'wx' + uid(), kind: 'list', label: 'Weather', wx: w || null, where: [sh.game.city, sh.game.state].filter(Boolean).join(', ') || sh.home.name, title: `Weather · ${[sh.game.city, sh.game.state].filter(Boolean).join(', ') || sh.home.name}`, kicker: 'Forecast · Open-Meteo',
        rows: w ? [['Conditions', w.text], ['High / Low', `${w.hi}° / ${w.lo}°`], ['Chance of rain', w.pop + '%'], ['Wind', `Up to ${w.wind} mph`]] : [['Forecast', 'Not available for this date yet']] };
    }
    if (kind === 'gameLeaders') {
      const L = s => this.leaders(s);
      const a = L('away'), h = L('home');
      return { id: 'gl' + uid(), kind: 'duel', label: 'Game leaders', title: 'Game Leaders', kicker: sh.event, rows: [['Points', a[0], h[0]], ['Rebounds', a[1], h[1]], ['Assists', a[2], h[2]]].map(([n, x, y]) => [n, `${x.name} · ${x.v}`, `${y.name} · ${y.v}`]) };
    }
    if (kind === 'schedAway' || kind === 'schedHome') {
      // the team's whole regular season from NEC Front Row: each game with its result once played, the date and time before;
      // until that's in, the games still to come on the schedule Pivot has
      const side = kind === 'schedAway' ? 'away' : 'home', t = sh[side];
      const day = at => PV.fmtDate(at, { weekday: 'short', month: 'short', day: 'numeric' });
      // each line: the date, the opponent, then the result (or the start time); today's game is marked so it stands out
      const other = sh[side === 'away' ? 'home' : 'away'], today = String(sh.game.at || '').slice(0, 10);
      const line = (at, game, res, opp) => ({ date: day(at), when: day(at), game, res, sport: res, al: '', hl: '', now: String(at).slice(0, 10) === today && opp === other.key });
      let list, season;
      if (t.sched && t.sched.length) {
        list = t.sched.map(g => line(g.at, (g.home || g.neutral ? 'vs ' : 'at ') + g.opp, g.result || g.time || '', g.oppKey));
        const yrs = [...new Set(t.sched.map(g => String(g.day || g.at).slice(0, 4)))];
        season = yrs.length > 1 ? `${yrs[0]}-${yrs[yrs.length - 1].slice(2)}` : yrs[0];
      } else {
        list = D.GAMES.filter(g => (g.home === t.key || g.away === t.key) && g.sport === sh.sport && g.at.slice(0, 10) >= today).sort((x, y) => x.at < y.at ? -1 : 1).map(g => {
          const home = g.home === t.key, ok = home ? g.away : g.home, opp = D.byKey(ok) || { name: ok };
          return line(g.at, (home ? 'vs ' : 'at ') + opp.name, PV.fmtTime(g.at), ok);
        });
        season = String(sh.game.at || '').slice(0, 4);
      }
      return { id: 'sd' + uid(), kind: 'coming', label: `${t.code} schedule`, list, otitle: `${t.name} Schedule`, okicker: `${season} Regular Season` };
    }
    if (kind === 'capAway' || kind === 'capHome') {
      // a team capsule: name and nickname, head coach, record, then three lines to fill (goals for and against a game, the streak)
      const side = kind === 'capAway' ? 'away' : 'home', t = sh[side];
      const tape = l => ((t.tape || []).find(x => new RegExp('^' + l + '$', 'i').test(String(x[0]))) || [])[1];
      const gpg = tape('Goals per game'), gaa = tape('Goals allowed per game');
      const sr = ((sh.frStand && sh.frStand.rows) || []).find(r => r.school === t.key), streak = PV.streakWords(sr && sr.streak);
      return { id: 'cp' + uid(), kind: 'capsule', side, label: `${t.code} capsule`, title: [t.name, t.mascot].filter(Boolean).join(' '), sub: t.coach ? `Head Coach: ${t.coach}` : 'Head Coach',
        lines: [t.rec ? `Record: ${t.rec}${t.conf ? ` (${t.conf} NEC)` : ''}` : 'Record: —', gpg != null ? `Goals per game: ${gpg}` : 'Goals per game: —', gaa != null ? `Goals against per game: ${gaa}` : 'Goals against per game: —', streak || 'Streak: —'] };
    }
    if (kind === 'comingHalf') {
      // the halftime Coming up: the same graphic, its top line about the second half (the other Coming ups keep theirs)
      return Object.assign(this.buildFull0('coming'), { id: 'ch' + uid(), label: 'Coming up · 2nd half', otitle: '2nd Half Action' });
    }
    if (kind === 'halftime') {
      // what's coming up at the break: a title, a line under it and three stories, every one of them typed over to suit
      return { id: 'ht' + uid(), kind: 'report', label: 'Halftime report', title: 'Halftime Report', sub: 'Coming Up', lines: ['First half highlights', 'Stats at the break', 'Second half preview'] };
    }
    if (kind === 'nextUp') {
      // the next three games after this one, for a corner box (ESPN's 9619); other looks show them as Coming Up
      const after = sh.game.at || '', day = after.slice(0, 10);
      const list = D.GAMES.filter(g => g.at > after && g.id !== sh.game.id).slice(0, 3).map(g => {
        const A2 = D.byKey(g.away) || { name: g.away, code: g.away }, H2 = D.byKey(g.home) || { name: g.home, code: g.home };
        const when = (g.at.slice(0, 10) === day ? '' : PV.fmtDate(g.at, { weekday: 'short' }) + ' ') + PV.fmtTime(g.at);
        return { when, sport: D.SPORTS[g.sport] || g.sport, game: `${A2.name} at ${H2.name}`, a: A2.short || A2.name, h: H2.short || H2.name, al: A2.logo || '', hl: H2.logo || '', ac: A2.color || '', hc: H2.color || '' };
      });
      return { id: 'nu' + uid(), kind: 'coming', upper: true, label: 'Next games up', list, otitle: 'Next Games Up' };
    }
    return oldFull.call(this, kind, opts);
  };

  /* ---------- state additions ---------- */
  const oldDefault = PV.defaultState;
  PV.defaultState = function (show) {
    const st = oldDefault(show);
    st.me = { list: PV.defaultMEs2() };
    st.program = 'me:me1'; st.preview = 'cam2'; st.lastCam = 'cam1';
    resetPv(st);
    st.trans.sel = 'cut'; st.trans.wipe = 'replay';
    st.trans.wipes = [{ id: 'replay', name: 'Replay wipe', kind: 'pkg' }, { id: 'away', name: show.away.name, kind: 'team', side: 'away' }, { id: 'home', name: show.home.name, kind: 'team', side: 'home' }];
    st.vids = PV.defaultVids(show.sport);
    st.snds = PV.withTone(PV.defaultSnds());
    st.sndPlay = null;
    st.l3pick = {};
    st.gfx.water = false; st.gfx.big = false; st.gfx.scorebug = false;
    st.gfx.wm = { src: 'nfr', pos: 'tr', size: 'm' };
    st.gfx.burn.src = st.gfx.burn.src || 'text';
    show.officials = show.officials || [];
    st.rd.cue = 0;
    return st;
  };

  /* ---------- shortcuts ---------- */
  const P = (n, a, b) => () => [n, a, b];
  const drop = new Set(['pvwM', 'autoCam1', 'l3TopHome', 'l3TopAway', 'l3Ann', 'trayR']);
  for (let i = PV.ACTIONS.length - 1; i >= 0; i--) if (drop.has(PV.ACTIONS[i].id)) PV.ACTIONS.splice(i, 1);
  const fix = (id, patch) => { const a = PV.ACTIONS.find(x => x.id === id); if (a) Object.assign(a, patch); };
  fix('cut', { label: 'Take Preview with a Cut (always)', run: P('take', 'cut') });
  fix('auto', { label: 'Take Preview with the selected transition (replays never cut)', run: E => ['take', PV.spaceHow(E.st)] });
  fix('sting', { label: 'Take Preview with the selected wipe', run: E => ['take', E.st.trans.wipe || 'replay'] });
  fix('sb', { label: 'Scorebug on/off (on air)', run: P('gfx.toggle', 'scorebug') });
  fix('brk', { key: 'Meta+B' });
  fix('clrLower', { key: '' });
  fix('clrAll', { label: 'Clear graphics on air (not the watermark)' });
  fix('clrAllB', { label: 'Clear graphics on air (second key)', key: '' });   // Delete removes a picked replay angle or play now
  fix('tick', { label: 'Ticker to Preview', run: P('pv.gfx', { t: 'tog', k: 'ticker' }) });
  fix('rdNext', { label: 'Rundown: next item to Preview' });
  fix('rdEdit', { label: 'Edit the selected item (or the cued rundown item)' });
  fix('clock', { key: 'Alt+Space' });
  fix('trayL', { label: 'Open or close the Playlists tray' });
  ['fsTitle', 'fsLineups', 'fsTape', 'fsStandings', 'fsBoard'].forEach(id => { const a = PV.ACTIONS.find(x => x.id === id); if (a) { const ref = a.run()[1]; a.run = P('pv.gfx', { t: 'cat', ref }); a.label = a.label + ' to Preview'; } });
  PV.ACTIONS.push(
    { id: 'wipeSel', group: 'Switcher', label: 'Select a wipe (press again for the next one)', key: 'W', run: P('trans.cycle') },
    { id: 'drawV', group: 'Graphics', label: 'Visitor lower thirds (open or close)', key: 'V', run: () => null },
    { id: 'drawH', group: 'Graphics', label: 'Home lower thirds (open or close)', key: 'H', run: () => null },
    { id: 'drawC', group: 'Graphics', label: 'Canned graphics (open or close)', key: 'C', run: () => null },
    { id: 'clrPv', group: 'Graphics', label: 'Clear graphics in Preview', key: 'X', run: P('pv.gfxClear') },
    { id: 'wm', group: 'Graphics', label: 'Watermark on/off', key: '', run: P('gfx.wm') },
    { id: 'burnTog', group: 'Graphics', label: 'Replay burn on/off', key: '', run: E => ['gfx.burn', 'on', !E.st.gfx.burn.on] },
    { id: 'big', group: 'Graphics', label: 'Big score on/off (on air)', key: 'B', run: P('gfx.toggle', 'big') },
    { id: 'pvClear', group: 'Switcher', label: 'Clear Preview', key: 'Shift+Escape', run: P('pv.clear') },
    { id: 'rpRename', group: 'Replay', label: 'Rename the picked replay', key: 'Meta+R', run: () => null }
  );
  (function moveKeys() {
    let saved = store.get('keys4', null); if (saved) return;
    saved = store.get('keys3', {});
    const was = { sb: 'S', brk: 'B', big: '', wm: '', clrLower: 'X', clrAllB: 'Backspace' };
    for (const id in was) if (id in saved && saved[id] === was[id]) delete saved[id];
    store.set('keys4', saved);
  })();
  PV.shortcuts = function () { const saved = store.get('keys4', {}); const m = {}; for (const a of PV.ACTIONS) m[a.id] = a.id in saved ? saved[a.id] : a.key; return m; };
  PV.saveShortcuts = m => store.set('keys4', m);
  PV.DEFAULT_MACROS[1].steps = [{ a: 'cutCam2' }, { wait: 6000 }, { a: 'clrLower' }];
  PV.DEFAULT_MACROS[2].steps = [{ a: 'brk' }];   // break mode clears the graphics itself and brings the scorebug back after
})();
