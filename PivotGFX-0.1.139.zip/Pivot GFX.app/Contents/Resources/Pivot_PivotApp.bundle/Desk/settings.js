/* Pivot settings: show, templates, packages, inputs, audio, recording, streaming,
   outputs, shortcuts, macros, multiview, control screens, profile. */
(function () {
  const PV = window.PV, UI = PV.UI, S = window.PIVOT_SIM, G = window.PIVOT_GFX, D = window.PIVOT_DATA;
  const esc = UI.esc, $ = UI.$, $$ = UI.$$;
  const ui = UI.state;
  const SECTIONS = [
    ['game', 'Game'], ['tpl', 'Templates'], ['pkg', 'Graphics package'], ['inputs', 'Cameras'], ['audio', 'Audio'], ['rec', 'Recording'], ['stream', 'Streaming'], ['replay', 'Replays'],
    ['out', 'Outputs and NDI'], ['keys', 'Shortcuts'], ['macros', 'Macros'], ['mv', 'Multiview'], ['screens', 'Control screens'], ['profile', 'Profile'], ['about', 'About this sample']
  ];
  let sec = 'game', focusScreen = null, pkgStages = [], lastHtml = '', tplName = '';

  UI.openSettings = function (which, extra) {
    if (which) sec = which;
    focusScreen = extra || null;
    UI.closeMenus && UI.closeMenus();
    let scrim = $('.scrim');
    if (!scrim) {
      scrim = document.createElement('div'); scrim.className = 'scrim';
      scrim.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-label="Settings"><nav class="mnav"><h3>Settings</h3>${SECTIONS.map(([id, n]) => `<button data-sec="${id}">${n}</button>`).join('')}</nav><div class="mbody"><div class="mhead"><h2 id="sTitle"></h2><button class="btn" data-s="close">Done</button></div><div class="mcontent" id="sBody"></div></div></div>`;
      document.body.appendChild(scrim);
      scrim.addEventListener('click', onClick);
      scrim.addEventListener('change', onChange);
      scrim.addEventListener('input', onInput);
      scrim.addEventListener('pointerdown', e => { if (e.target === scrim) UI.closeSettings(); });
    }
    ui.settings = true; lastHtml = '';
    UI.renderSettings();
  };
  UI.closeSettings = function () { const s = $('.scrim'); if (s) s.remove(); ui.settings = false; ui.listening = null; destroyPkg(); };
  function destroyPkg() { pkgStages.forEach(p => p.stage.destroy()); pkgStages = []; }

  UI.renderSettings = function () {
    const body = $('#sBody'); if (!body) return;
    $$('.mnav button').forEach(b => b.classList.toggle('on', b.dataset.sec === sec));
    $('#sTitle').textContent = SECTIONS.find(s => s[0] === sec)[1];
    const st = PV.E.st;
    const html = (SEC[sec] || SEC.game)(st);
    if (html === lastHtml) return;
    const ae = document.activeElement;
    if (ae && body.contains(ae) && ae.matches('input[type=text],input[type=password],input:not([type]),textarea,input[type=range],select')) return;
    lastHtml = html;
    destroyPkg();
    body.innerHTML = html;
    if (sec === 'pkg') mountPkg();
  };

  UI.settingsFrame = function (t) {
    if (sec !== 'pkg') return;
    const st = PV.E.st;
    pkgStages.forEach(p => {
      const c = p.canvas; const [w, h] = UI.fit(c, 640);
      S.drawCamera(c.getContext('2d'), w, h, 'cam1', PV.worldT(st, t) - 3, PV.gameFor(st.show), PV.lookFor(st.show));
      p.stage.update(p.state, t);
    });
  };
  function mountPkg() {
    const st = PV.E.st;
    $$('.pkg .pv').forEach(pv => {
      const id = pv.dataset.pkg;
      const sample = PV.E.buildLower({ kind: 'player', side: 'home' });
      const state = { show: st.show, sb: st.sb, program: 'cam1', brk: false, rp: { playing: null }, trans: { active: null }, gfx: { pkg: id, scorebug: true, ticker: false, lower: sample, full: null, take: null, burn: st.gfx.burn } };
      const canvas = pv.querySelector('canvas');
      const stage = G.createStage(pv);
      pkgStages.push({ stage, state, canvas });
    });
  }

  /* ---------- events ---------- */
  function args(str) { return str.split('|').map(x => x === '' ? undefined : (/^-?\d+(\.\d+)?$/.test(x) && !/^0\d/.test(x) ? +x : x)); }
  function onClick(e) {
    const nav = e.target.closest('[data-sec]');
    if (nav) { sec = nav.dataset.sec; lastHtml = ''; UI.renderSettings(); return; }
    const b = e.target.closest('[data-s]'); if (!b || b.disabled) return;
    const [name, ...a] = args(b.dataset.s);
    const E = PV.E, st = E.st;
    switch (name) {
      case 'close': UI.closeSettings(); return;
      case 'act': UI.send(...a); break;
      case 'pickgame': UI.closeSettings(); UI.confirmChangeGame(); return;
      case 'pkgAdd': if (PV.native) PV.native.post({ type: 'addGfxPackage' }); return;
      case 'pkgRemove': if (PV.native && confirm('Remove this package from this Mac?')) PV.native.post({ type: 'removeGfxPackage', id: a[0] }); lastHtml = ''; setTimeout(() => UI.renderSettings(), 200); return;
      case 'tplSave': { const n = ($('#tplName') || {}).value || 'My template'; const tp = PV.saveTemplate(st, n.trim().slice(0, 60)); UI.toast(tp ? `Saved “${tp.name}”` : 'This browser blocked saving'); tplName = ''; break; }
      case 'tplDel': PV.deleteTemplate(a[0]); UI.toast('Template deleted'); break;
      case 'tplApply': UI.send('tpl.apply', a[0]); UI.toast('Template applied'); break;
      case 'unlock': UI.send('tpl.unlock'); UI.toast('Unlocked for this show'); break;
      case 'pin': st.pin = String(1000 + Math.floor(Math.random() * 9000)); E.changed(); UI.toast('New PIN. Control screens will ask again.'); break;
      case 'listen': ui.listening = { kind: a[0], id: a[1] }; lastHtml = ''; break;
      case 'keyClear': setKey(a[0], a[1], ''); break;
      case 'keysReset': PV.saveShortcuts({}); UI.toast('Shortcuts reset to the template defaults'); break;
      case 'macNew': { const l = PV.macros(); l.push({ id: PV.uid(), name: `Macro ${l.length + 1}`, key: '', steps: [] }); PV.saveMacros(l); break; }
      case 'macDel': PV.saveMacros(PV.macros().filter(m => m.id !== a[0])); break;
      case 'macStepDel': { const l = PV.macros(); const m = l.find(x => x.id === a[0]); if (m) m.steps.splice(a[1], 1); PV.saveMacros(l); break; }
      case 'macStepUp': { const l = PV.macros(); const m = l.find(x => x.id === a[0]); const i = a[1]; if (m && i > 0) { const [s] = m.steps.splice(i, 1); m.steps.splice(i - 1, 0, s); } PV.saveMacros(l); break; }
      case 'macAddStep': { const l = PV.macros(); const m = l.find(x => x.id === a[0]); const sel = $(`#ms_${a[0]}`); if (m && sel) { const v = sel.value; m.steps.push(/^wait/.test(v) ? { wait: +v.split(':')[1] } : { a: v }); } PV.saveMacros(l); break; }
      case 'macReset': PV.saveMacros(JSON.parse(JSON.stringify(PV.DEFAULT_MACROS))); break;
      case 'copy': { const txt = b.dataset.copy; try { navigator.clipboard.writeText(txt).then(() => UI.toast('Link copied'), () => selectText(b)); } catch (er) { selectText(b); } break; }
      case 'role': PV.go(a[0]); return;
      case 'tryRemote': UI.closeSettings(); PV.go(a[0]); return;
      case 'mvPreset': PV.store.set('mvLayout', PV.MV_PRESETS[a[0]].tiles); UI.toast(`“${PV.MV_PRESETS[a[0]].name}” is now your multiview layout`); break;
    }
    lastHtml = ''; UI.renderSettings();
  }
  function selectText(b) { const code = b.parentElement.querySelector('code'); if (!code) return; const r = document.createRange(); r.selectNodeContents(code); const s = getSelection(); s.removeAllRanges(); s.addRange(r); UI.toast('Press ⌘C to copy'); }
  function onChange(e) {
    const el = e.target.closest('[data-sc]'); if (!el) return;
    const [name, ...a] = args(el.dataset.sc);
    const v = el.type === 'checkbox' ? el.checked : el.value;
    const st = PV.E.st;
    switch (name) {
      case 'coach': UI.send('show.coach', a[0], { [a[1]]: v }); break;
      case 'rank': UI.send('show.rank', a[0], v); break;
      case 'boxok': UI.send('sb.boxOk', !v); break;
      case 'burnpos': UI.send('gfx.burn', 'pos', v); break;
      case 'burnon': UI.send('gfx.burn', 'on', v); break;
      case 'event': UI.send('show.event', v); break;
      case 'replay': PV.setReplay({ [a[0]]: a[0] === 'minutes' ? +v : v }); break;
      case 'replaycam': UI.send('cam.replay', a[0], v); break;
      case 'ann': UI.send('show.ann', a[0], { [a[1]]: v }); break;
      case 'input': UI.send('input.set', a[0], { [a[1]]: v }); break;
      case 'chname': st.audio.ch[a[0]].name = String(v).slice(0, 20); PV.E.changed(); break;
      case 'adev': st.audio.device = v; PV.E.changed(); break;
      case 'rec': UI.send('rec.set', a[0], v); break;
      case 'stream': UI.send('stream.set', a[0], v); break;
      case 'rehearsal': PV.store.set('rehearsal', !!v); break;
      case 'out': UI.send('out.set', a[0], v); break;
      case 'tplName': tplName = v; return;
      case 'macName': { const l = PV.macros(); const m = l.find(x => x.id === a[0]); if (m) m.name = String(v).slice(0, 40); PV.saveMacros(l); break; }
      case 'profile': UI.send('profile.name', v); break;
    }
    lastHtml = ''; UI.renderSettings();
  }
  function onInput() { /* text fields commit on change */ }

  /* capturing a new shortcut */
  document.addEventListener('keydown', e => {
    if (!ui.listening) return;
    e.preventDefault(); e.stopPropagation();
    const L = ui.listening;
    if (e.key === 'Escape') { ui.listening = null; lastHtml = ''; UI.renderSettings(); return; }
    if (e.key === 'Backspace' || e.key === 'Delete') { setKey(L.kind, L.id, ''); ui.listening = null; lastHtml = ''; UI.renderSettings(); return; }
    const k = PV.keyName(e); if (!k) return;
    setKey(L.kind, L.id, k);
    ui.listening = null; lastHtml = ''; UI.renderSettings();
  }, true);
  function setKey(kind, id, k) {
    const map = PV.shortcuts(); const macros = PV.macros();
    if (k) {
      // one key does one thing: take it off anything else that used it
      for (const a in map) if (map[a] === k && !(kind === 'action' && a === id)) { map[a] = ''; UI.toast(`${PV.keyLabel(k)} moved from “${PV.ACTIONS.find(x => x.id === a).label}”`); }
      for (const m of macros) if (m.key === k && !(kind === 'macro' && m.id === id)) { m.key = ''; UI.toast(`${PV.keyLabel(k)} moved from macro “${m.name}”`); }
    }
    if (kind === 'action') map[id] = k; else { const m = macros.find(x => x.id === id); if (m) m.key = k; }
    PV.saveShortcuts(map); PV.saveMacros(macros);
    UI.render();
  }

  /* ---------- sections ---------- */
  const opt = (v, n, sel, dis) => `<option value="${esc(v)}" ${sel ? 'selected' : ''} ${dis ? 'disabled' : ''}>${esc(n)}</option>`;
  const sw = (on, s, dis) => `<button class="sw ${on ? 'on' : ''}" data-s="${s}" ${dis ? 'disabled' : ''} aria-pressed="${on}"></button>`;
  const SEC = {};
  UI.SEC = SEC;
  UI.SECTIONS = SECTIONS;

  /* ---------- the uniform color: the team's own colors, common ones, any color, or one picked off the screen ---------- */
  const KITS = [['White', '#ffffff'], ['Black', '#111111'], ['Gray', '#8a8d8f'], ['Navy', '#0b1f41'], ['Royal', '#1d4fbf'], ['Light blue', '#7bafd4'], ['Red', '#c8102e'], ['Maroon', '#7a1f2b'], ['Orange', '#f56600'], ['Gold', '#f2b705'], ['Green', '#00704a'], ['Purple', '#4e2a84']];
  PV.kitOf = (sh, side) => sh[side].kit || (side === 'home' ? '#ffffff' : sh[side].color);
  PV.kitRow = side => {
    const sh = PV.E.st.show, t = sh[side], cur = PV.kitOf(sh, side).toLowerCase();
    const own = [['Primary', t.color], ['Secondary', t.accent]].filter(x => /^#[0-9a-f]{6}$/i.test(x[1] || ''));
    const chip = ([n, c], mine) => `<button class="kit${cur === c.toLowerCase() ? ' on' : ''}${mine ? ' own' : ''}" style="--k:${esc(c)}" data-kit="${side}|${esc(c)}" title="${esc(n)}" aria-label="${esc(t.code)} uniform: ${esc(n)}"></button>`;
    return `<div class="kits">${own.map(x => chip(x, true)).join('')}<i class="kitgap"></i>${KITS.map(x => chip(x)).join('')}
      <label class="kit any" title="Any color" aria-label="${esc(t.code)} uniform: any color" style="--k:${esc(cur)}"><input type="color" value="${esc(cur)}" data-kitc="${side}"></label>
      ${PV.native ? `<button class="btn sm kitdrop" data-kitdrop="${side}" title="Click anywhere on the screen, like a jersey on Program, to use its color">Pick from screen</button>` : ''}</div>`;
  };
  document.addEventListener('click', e => {
    const k = e.target.closest('[data-kit]');
    if (k) { const [side, hex] = k.dataset.kit.split('|'); UI.send('show.kit', side, hex); refreshKits(); return; }
    const d = e.target.closest('[data-kitdrop]');
    if (d && PV.native && PV.native.sampleColor) { const side = d.dataset.kitdrop; PV.native.sampleColor(hex => { if (hex) { UI.send('show.kit', side, hex); refreshKits(); } }); }
  });
  document.addEventListener('input', e => { const c = e.target.closest('[data-kitc]'); if (c) { UI.send('show.kit', c.dataset.kitc, c.value); c.parentNode.style.setProperty('--k', c.value); } });
  document.addEventListener('change', e => { if (e.target.closest('[data-kitc]')) refreshKits(); });
  function refreshKits() { setTimeout(() => { if (UI.state && UI.state.settings) { lastHtml = ''; UI.renderSettings(); } UI.dirty = true; }, 30); }

  SEC.game = st => {
    const sh = st.show, g = sh.game;
    const team = side => { const t = sh[side]; return `<div class="card" style="background:var(--raise)"><div class="cardh"><i class="swc" style="background:${sh.colors[side]};width:12px;height:12px;border-radius:3px;display:inline-block"></i>${side === 'home' ? 'Home' : 'Visitors'} · ${esc(t.name)}<span class="sp"></span>${t.placeholder ? '<span class="status warn">No roster on file</span>' : `<span class="status">${t.roster.length} players</span>`}</div>
      <div class="grid2" style="grid-template-columns:2fr 1fr 1fr;gap:10px"><div class="fld"><label>Head coach</label><input type="text" value="${esc(t.coach)}" data-sc="coach|${side}|coach"></div><div class="fld"><label>Season with the team</label><input type="text" value="${esc(t.coachSeason)}" placeholder="e.g. 9" data-sc="coach|${side}|coachSeason"></div><div class="fld"><label>National ranking</label><input type="text" inputmode="numeric" maxlength="2" value="${esc(t.rank || '')}" placeholder="Unranked" data-sc="rank|${side}" aria-label="${esc(t.name)} national ranking"></div></div>
      <div class="fld"><label>Uniform color tonight</label>${PV.kitRow(side)}</div>
      <div class="hint">${esc(t.rec ? `2025-26: ${t.rec}${t.conf ? ', ' + t.conf + ' NEC' : ''}` : 'No 2025-26 record on file')} · ${t.featured ? `Featured player: #${esc(t.featured)} (change it in the Graphics tab)` : 'No featured player until a roster is added'}</div></div>`; };
    return `<div class="note"><b>${esc(sh.away.name)} at ${esc(sh.home.name)}</b> · ${esc(sh.event)}<br>${esc(PV.fmtDate(g.at))} · ${esc(PV.fmtTime(g.at))} · ${esc([g.venue, [g.city, g.state].filter(Boolean).join(', ')].filter(Boolean).join(' · ') || 'Venue not on file')}<div class="row" style="margin-top:8px"><button class="btn sm" data-s="pickgame">Pick a different game</button></div></div>
      ${team('away')}${team('home')}
      <div class="fld"><label>Event title on graphics</label><input type="text" value="${esc(sh.event)}" data-sc="event"></div>
      <div class="fld"><label>Talent</label>${sh.announcers.map((a, i) => `<div class="grid2" style="grid-template-columns:180px 1fr;gap:8px;margin-bottom:6px"><input type="text" class="inp" value="${esc(a.role)}" data-sc="ann|${i}|role" aria-label="Role"><input type="text" class="inp" value="${esc(a.name)}" data-sc="ann|${i}|name" aria-label="Name"></div>`).join('')}</div>
      <div class="sec"><div class="sech">Try a problem</div><label class="chk" style="color:var(--ink)"><input type="checkbox" ${st.sb.boxOk ? '' : 'checked'} data-sc="boxok">Pretend the scoreboard box stopped sending</label><span class="hint">Shows what happens on the main screen and lets someone take over from the Scorebug phone screen.</span></div>`;
  };

  SEC.tpl = st => {
    const all = PV.allTemplates();
    const cur = all.find(t => t.id === st.tpl.id && t.network === st.gfx.pkg) || all.find(t => t.network === st.gfx.pkg && !(t.locks || {}).pkg);
    const locks = st.tpl.locks || {};
    const layer = (n, v, note) => `<div class="layer"><span class="nm"><span class="lbl">${n}</span><br><b>${esc(v)}</b></span>${note || ''}</div>`;
    return `<div class="note">A template sets up everything for a kind of show. Templates stack in layers: <b>Network</b> (the look), <b>League</b> (data, sponsors, logos), <b>Sport</b> (scorebug and stats) and <b>Show</b> (tonight's teams). Pick one from the list and everything fills in.</div>
      <div class="sec"><div class="sech">In use</div>
      <div class="grid2">${layer('Network', G.pkgOf(st.gfx.pkg).name, locks.pkg ? '<span class="lock">Locked</span>' : '')}${layer('League', 'NEC')}
      ${layer('Sport', st.show.event)}
      ${layer('Show', `${st.show.away.name} at ${st.show.home.name}`)}</div>
      ${Object.keys(locks).some(k => locks[k]) ? `<div class="row"><span class="hint">Locked settings keep every crew on brand. An admin can unlock them.</span><button class="btn sm" data-s="unlock">Unlock (admin)</button></div>` : ''}</div>
      <div class="sec"><div class="sech">Templates</div>
      <table class="tbl"><tbody>${all.map(t => `<tr><td><b>${esc(t.name)}</b><br><span class="hint">${t.custom ? 'Saved on this Mac' : 'Pivot · pushed by your admin'}</span></td><td style="text-align:right;white-space:nowrap">${cur && cur.id === t.id ? '<span class="status">In use</span>' : `<button class="btn sm pri" data-s="tplApply|${t.id}">Apply</button>`} ${t.custom ? `<button class="btn sm ghost" data-s="tplDel|${t.id}">Delete</button>` : ''}</td></tr>`).join('')}</tbody></table></div>
      <div class="sec"><div class="sech">Save the current setup as a template</div><div class="row"><input type="text" class="inp" id="tplName" placeholder="NEC Men's Basketball · My crew" value="${esc(tplName)}" data-sc="tplName" style="flex:1;min-width:220px"><button class="btn pri" data-s="tplSave">Save template</button></div>
      <div class="hint">Saves the package, camera names, audio setup, recording format, stream destinations and replay settings. Stream keys are never saved in templates.</div></div>`;
  };

  SEC.pkg = st => {
    const locked = st.tpl.locks && st.tpl.locks.pkg;
    return `${locked ? '<div class="note"><b>Locked by the template.</b> Unlock it under Templates to switch packages.</div>' : ''}
      <div class="pkgs">${Object.values(G.PACKAGES).filter(p => !p.hidden).map(p => `<button class="pkg ${st.gfx.pkg === p.id ? 'on' : ''}" data-s="act|gfx.pkg|${p.id}" ${locked ? 'disabled' : ''}><div class="pv" data-pkg="${p.id}"><canvas></canvas></div><div class="pi"><b>${esc(p.name)}</b><small>${esc(p.desc)}</small></div></button>`).join('')}</div>
      <div class="sec"><div class="sech">Packages added on this Mac</div>
        ${Object.values(G.PACKAGES).filter(p => p.added).map(p => `<div class="row"><b style="min-width:160px">${esc(p.name)}</b><small style="flex:1;color:var(--mute)">Kept on this Mac only</small><button class="btn" data-s="pkgRemove|${p.id}">Remove</button></div>`).join('') || '<div class="hint">None yet. A package file ends in .pivotgfx.</div>'}
        ${PV.native ? '<div class="row"><button class="btn pri" data-s="pkgAdd">Add a package…</button></div>' : ''}</div>
      <div class="sec"><div class="sech">Replay burn</div><div class="row"><label class="chk" style="color:var(--ink)"><input type="checkbox" ${st.gfx.burn.on ? 'checked' : ''} data-sc="burnon">Show the REPLAY tag during replays</label><select class="inp" data-sc="burnpos" style="height:30px"><option value="tl" ${st.gfx.burn.pos === 'tl' ? 'selected' : ''}>Top left</option><option value="tr" ${st.gfx.burn.pos === 'tr' ? 'selected' : ''}>Top right</option></select></div><div class="hint">Everything else steps aside while a replay is on air.</div></div>
      <div class="note">Every package draws the same graphics from the same data: scorebug, lower thirds, lineups, tale of the tape, standings, score board, ticker, replay tag and stinger. Switch any time and your shortcuts, macros and data keep working. School, conference and licensed network packages will download here.</div>`;
  };

  SEC.inputs = st => {
    const fmts = ['1080p59.94', '1080i59.94', '1080p60', '1080p29.97', '720p59.94'];
    return `<div class="note">Cameras are named by their job, not by the plug. The first time a template opens on a new Mac, Pivot asks once which input is which and remembers it.</div>
      <table class="tbl"><thead><tr><th>Camera</th><th>Job</th><th>Input</th><th>Format</th><th>Signal</th></tr></thead><tbody>
      ${PV.camIds(st).map(id => { const i = st.inputs[id]; return `<tr><td><b>${PV.srcShort(id)}</b></td><td><input type="text" class="inp" value="${esc(i.name)}" data-sc="input|${id}|name" style="width:140px"></td><td><select class="inp" data-sc="input|${id}|device">${PV.DEVICES.map(d => opt(d, d, d === i.device)).join('')}</select></td><td><select class="inp" data-sc="input|${id}|fmt">${fmts.map(f => opt(f, f, f === i.fmt)).join('')}</select></td><td><span class="status">${esc(i.fmt)}</span></td></tr>`; }).join('')}</tbody></table>
      <div class="hint">Mixed formats are fine: interlaced inputs are cleaned up to 1080p59.94 automatically. In this sample every input shows a simulated camera.</div>`;
  };

  SEC.audio = st => {
    const a = st.audio;
    const devs = ['USB mixer (4 channels)', 'USB interface (2 channels)', 'USB mixer (8 channels)', "This Mac's microphone"];
    return `<div class="fld"><label>Audio input</label><select data-sc="adev">${devs.map(d => opt(d, d, d === a.device)).join('')}</select><span class="hint">Any affordable USB mixer that shows up on the Mac works. Pivot takes up to 8 inputs and uses the first 4.</span></div>
      <div class="fld"><label>How the channels arrive</label><div class="seg">${[['4ch', '4 channels'], ['pairs', 'Two mono pairs'], ['split', 'Stereo split']].map(([m, n]) => `<button class="${a.mode === m ? 'on' : ''}" data-s="act|audio.mode|${m}">${n}</button>`).join('')}</div></div>
      <table class="tbl"><thead><tr><th>Channel</th><th>Name</th><th>Used for</th></tr></thead><tbody>${a.ch.map((c, i) => `<tr><td>${i + 1}</td><td><input type="text" class="inp" value="${esc(c.name)}" data-sc="chname|${i}"></td><td class="hint">${i < 2 ? 'Commentator voice' : 'Crowd and court sound (nats)'}</td></tr>`).join('')}</tbody></table>
      <div class="sec"><div class="sech">What goes where</div><dl class="kv" style="max-width:560px"><dt>Each stream</dt><dd>One stereo mix</dd><dt>Recordings</dt><dd>Every channel on its own track</dd><dt>Camera recordings</dt><dd>Nats only, for replays</dd><dt>Replays on air</dt><dd>Recorded nats + live voices</dd><dt>Break mode</dt><dd>Mutes all four channels</dd></dl></div>`;
  };

  SEC.rec = st => {
    const r = st.rec;
    // one row per camera in this show
    const feeds = PV.camIds(st).map(id => [id, PV.srcLabel(st, id).replace(/^CAM /, 'Camera ')]).concat([['program', 'Program (with graphics)'], ['clean', 'Clean feed (no graphics)']]);
    const n = Object.values(r.feeds).filter(Boolean).length;
    const perHr = UI.recRate(st);
    return `<div class="fld"><label>Format</label><table class="tbl"><thead><tr><th></th><th>Format</th><th>Per camera, per hour (1080p60)</th><th></th></tr></thead><tbody>${Object.entries(PV.FORMATS).map(([id, f]) => `<tr><td><input type="radio" name="fmt" ${r.fmt === id ? 'checked' : ''} data-sc="rec|fmt" value="${id}" ${r.on ? 'disabled' : ''}></td><td><b>${esc(f.name)}</b><br><span class="hint">${esc(f.note)}</span></td><td class="tc">about ${Math.round(PV.gbPerHour(f.mbps[r.q]))} GB</td><td></td></tr>`).join('')}</tbody></table></div>
      ${r.fmt === 'hevc' || r.fmt === 'h264' ? `<div class="fld"><label>Quality</label><div class="seg">${['good', 'better', 'best'].map(q => `<button class="${r.q === q ? 'on' : ''}" data-s="act|rec.set|q|${q}" ${r.on ? 'disabled' : ''}>${q[0].toUpperCase() + q.slice(1)}</button>`).join('')}</div></div>` : ''}
      <div class="fld"><label>What to record</label><div class="grid2" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:6px">${feeds.map(([k, nm]) => `<label class="chk" style="color:var(--ink)"><input type="checkbox" ${r.feeds[k] ? 'checked' : ''} data-s="act|rec.set|feed|${k}" ${r.on ? 'disabled' : ''}>${esc(nm)}</label>`).join('')}</div></div>
      <div class="note"><b>${n} recordings at once · about ${perHr.toFixed(0)} GB per hour</b> in ${esc(PV.FORMATS[r.fmt].name)}. A two-hour game needs about ${(perHr * 2).toFixed(0)} GB free.${r.on ? ' Stop recording to change these.' : ''}</div>
      <div class="fld"><label>Save to</label><input type="text" value="${esc(r.folder)}" data-sc="rec|folder"><span class="hint">Files are named by show and camera, for example ${esc(st.show.away.code)}_at_${esc(st.show.home.code)}_Cam1${(st.inputs.cam1 || {}).name ? '_' + esc(st.inputs.cam1.name) : ''}.mov</span></div>
      <div class="hint">Program can also go out to a separate recorder through the Blackmagic output box (Outputs and NDI). That gives you a backup if the Mac ever has a problem.</div>`;
  };

  SEC.replay = st => {
    const r = PV.replayCfg(), N = PV.native, live = N && N.status && N.status.replay, nr = (N && N.replaySettings) || {};
    const kept = PV.replayCams(st), cams = PV.camIds(st);
    const per = (nr.kbps || 10000) * 1000 / 8 * 60 * r.minutes / 1e9;
    const mins = [2, 4, 6, 10, 15, 20, 30, 60, 120].concat([r.minutes]).filter((v, i, a) => a.indexOf(v) === i).sort((a, b) => a - b);
    const nm = v => v < 60 ? v + ' minutes' : (v / 60) + (v === 60 ? ' hour' : ' hours');
    return `<label class="chk" style="color:var(--ink)"><input type="checkbox" ${r.enabled ? 'checked' : ''} data-sc="replay|enabled">Save replays: keep up to ${PV.MAX_REPLAY} cameras so any moment can be replayed, from either angle, at any speed</label>
      <div class="fld"><label>Go back as far as</label><select data-sc="replay|minutes" ${r.enabled ? '' : 'disabled'}>${mins.map(v => `<option value="${v}" ${v === r.minutes ? 'selected' : ''}>${nm(v)}</option>`).join('')}</select>
      <span class="hint">Replays you mark are kept for the whole show, however old.${N ? ` Uses about ${per.toFixed(1)} GB a camera on this Mac's disk, cleared each time Pivot opens.${nr.freeBytes ? ` ${(nr.freeBytes / 1e9).toFixed(0)} GB free.` : ''}` : ''}</span></div>
      <div class="fld"><label>Angles to save</label><div class="grid2" style="grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px">${cams.map(id => `<label class="chk" style="color:var(--ink)"><input type="checkbox" ${kept.includes(id) ? 'checked' : ''} ${r.enabled && (kept.includes(id) || kept.length < PV.MAX_REPLAY) ? '' : 'disabled'} data-sc="replaycam|${id}">${esc(PV.srcLabel(st, id).replace(/^CAM /, 'Camera '))}</label>`).join('')}</div>
      <span class="hint">Up to ${PV.MAX_REPLAY} angles. An angle left out isn't saved, and won't roll in replays. ${kept.length} of ${cams.length} saved.</span></div>
      ${live && live.cameras ? `<div class="note">Holding ${Math.floor(live.seconds / 60) ? Math.floor(live.seconds / 60) + ' min ' : ''}${Math.round(live.seconds % 60)} s from ${live.cameras} camera${live.cameras === 1 ? '' : 's'} · ${live.bytes < 1e9 ? Math.max(1, Math.round(live.bytes / 1e6)) + ' MB' : (live.bytes / 1e9).toFixed(2) + ' GB'}</div>` : ''}
      ${live && live.lowDisk ? '<div class="note warn"><b>The disk is nearly full.</b> Replay has stopped keeping new footage until there is room.</div>' : ''}`;
  };

  SEC.stream = st => {
    const s = st.stream;
    const reh = PV.rehearsal ? PV.rehearsal() : false;
    return `<div class="sec"><label class="chk" style="margin-bottom:10px"><input type="checkbox" data-sc="rehearsal" ${reh ? 'checked' : ''}${s.on ? ' disabled' : ''}><span><b>Rehearsal mode</b>: STREAM stays locked off, so a test can't go live by accident. Recording still works.</span></label></div><div class="sec">${s.dests.map(d => `<div class="dest">${sw(d.on, `act|stream.dest|${d.id}`, s.on)}<b>${esc(d.name)}</b><input type="password" class="inp" placeholder="${d.id === 'rtmp' ? 'rtmp://server/app and stream key' : 'Stream key'}" autocomplete="off" aria-label="${esc(d.name)} stream key"><span class="status ${d.on ? (s.on ? '' : 'warn') : 'off'}">${d.on ? (s.on ? 'Live' : 'Ready') : 'Off'}</span></div>`).join('')}</div>
      <div class="grid2"><div class="fld"><label>Video bitrate</label><select data-sc="stream|kbps" ${s.on ? 'disabled' : ''}>${[[4500, '4,500 kbps'], [6000, '6,000 kbps (recommended)'], [8000, '8,000 kbps'], [12000, '12,000 kbps']].map(([v, n]) => opt(v, n, s.kbps === v)).join('')}</select></div>
      <div class="fld"><label>Resolution</label><select data-sc="stream|res" ${s.on ? 'disabled' : ''}>${[['1080p60', '1080p 59.94'], ['1080p30', '1080p 29.97'], ['720p60', '720p 59.94']].map(([v, n]) => opt(v, n, s.res === v)).join('')}</select></div></div>
      <div class="note">Every destination gets the same stereo mix and the same picture. Stream keys stay on this Mac and are never put in templates. In this sample nothing is actually sent.</div>`;
  };

  SEC.out = st => {
    const o = st.out;
    return `<div class="grid2"><div class="fld"><label>Program out device</label><select data-sc="out|device">${['Blackmagic UltraStudio Monitor 3G', "Mac's HDMI port", 'None'].map(d => opt(d, d, o.device === d)).join('')}</select>
      <span class="hint">${o.device.startsWith('Blackmagic') ? 'Frame-accurate HDMI and SDI with audio. Feed a HyperDeck or Atomos recorder, or a TV in the booth.' : o.device === 'None' ? 'Nothing is sent out.' : 'Fine for a confidence monitor. The frame rate is not locked to video, so use the Blackmagic box for the master recording.'}</span></div>
      <div class="fld"><label>It carries</label><select data-sc="out|feed">${[['program', 'Program'], ['clean', 'Clean feed (no graphics)'], ['multiview', 'Multiview']].map(([v, n]) => opt(v, n, o.feed === v)).join('')}</select></div>
      <div class="fld"><label>Mac's HDMI port</label><select data-sc="out|hdmi">${[['multiview', 'Multiview monitor'], ['program', 'Full-screen program'], ['off', 'Not used']].map(([v, n]) => opt(v, n, o.hdmi === v)).join('')}</select></div></div>
      <div class="sec"><div class="sech">NDI out</div>
      ${[['program', 'Program', 'With graphics and stream mix'], ['clean', 'Clean feed', 'No graphics'], ['gfx', 'Graphics only', 'See-through background, for another system to lay over its video']].map(([k, n, h]) => `<div class="dest" style="grid-template-columns:auto 160px 1fr">${sw(o.ndi[k], `act|out.set|ndi|${k}`)}<b>${n}</b><span class="hint">${h}</span></div>`).join('')}</div>
      <div class="sec"><div class="sech">NDI sources found on the network</div><table class="tbl"><tbody>
        <tr><td><b>iPhone (camera app)</b></td><td class="hint">1080p30</td><td><span class="status">Available</span></td></tr>
        <tr><td><b>Second Mac · Screen</b></td><td class="hint">1080p60</td><td><span class="status">Available</span></td></tr></tbody></table>
      <div class="hint">NDI needs a wired gigabit network, separate from the venue's internet. Assign NDI sources to cameras under Cameras.</div></div>`;
  };

  SEC.keys = st => {
    const map = PV.shortcuts();
    const groups = [...new Set(PV.ACTIONS.map(a => a.group))];
    const L = ui.listening;
    const cap = (kind, id, k) => `<button class="keycap ${L && L.kind === kind && L.id === id ? 'listen' : ''}" data-s="listen|${kind}|${id}">${L && L.kind === kind && L.id === id ? 'Press a key…' : (k ? esc(PV.keyLabel(k)) : '—')}</button>`;
    return `<div class="note">Click a key, then press the new one. <b>Esc</b> cancels, <b>Delete</b> clears it. External keypads, Stream Deck and MIDI controllers send keys too, so anything here can go on a button. Shortcuts are saved with your profile.</div>
      <table class="tbl"><tbody>${groups.map(g => `<tr class="grp"><td colspan="2">${g}</td></tr>` + PV.ACTIONS.filter(a => a.group === g).map(a => `<tr><td>${esc(a.label)}</td><td style="text-align:right">${cap('action', a.id, map[a.id])}</td></tr>`).join('')).join('')}
      <tr class="grp"><td colspan="2">Macros</td></tr>${PV.macros().map(m => `<tr><td>${esc(m.name)}</td><td style="text-align:right">${cap('macro', m.id, m.key)}</td></tr>`).join('')}</tbody></table>
      <div class="row"><button class="btn" data-s="keysReset">Reset to defaults</button></div>`;
  };

  SEC.macros = st => {
    const list = PV.macros();
    const choices = PV.ACTIONS.map(a => opt(a.id, `${a.group}: ${a.label}`, false)).join('') + [500, 1000, 2000, 4000, 6000, 8000].map(w => opt('wait:' + w, `Wait ${w / 1000} s`, false)).join('');
    return `<div class="note">A macro runs several steps from one key. Build one here, or record one from the Macros tab by doing the steps. <b>${esc(PV.keyLabel(PV.shortcuts().mstop))}</b> stops a macro that's running.</div>
      ${list.map(m => `<div class="card" style="background:var(--raise)"><div class="row"><input type="text" class="inp" value="${esc(m.name)}" data-sc="macName|${m.id}" style="flex:1;min-width:200px" aria-label="Macro name"><span class="hint">Key</span><button class="keycap" data-s="listen|macro|${m.id}">${ui.listening && ui.listening.id === m.id ? 'Press a key…' : (m.key ? esc(PV.keyLabel(m.key)) : '—')}</button><button class="btn sm pri" data-s="act|macro.run|${m.id}">Run</button><button class="btn sm ghost" data-s="macDel|${m.id}">Delete</button></div>
        <ol style="margin:0;padding-left:22px;display:flex;flex-direction:column;gap:4px">${m.steps.map((s, i) => `<li><div class="row" style="justify-content:space-between"><span>${s.wait ? `Wait ${(s.wait / 1000).toFixed(1)} s` : esc((PV.ACTIONS.find(a => a.id === s.a) || { label: s.a }).label)}</span><span><button class="btn sm ghost" data-s="macStepUp|${m.id}|${i}" ${i ? '' : 'disabled'}>↑</button><button class="btn sm ghost" data-s="macStepDel|${m.id}|${i}">Remove</button></span></div></li>`).join('') || '<li class="hint" style="list-style:none;margin-left:-22px">No steps yet.</li>'}</ol>
        <div class="row"><select class="inp" id="ms_${m.id}" style="flex:1;min-width:220px">${choices}</select><button class="btn sm" data-s="macAddStep|${m.id}">Add step</button></div></div>`).join('')}
      <div class="row"><button class="btn pri" data-s="macNew">New macro</button><button class="btn ghost" data-s="macReset">Restore sample macros</button></div>`;
  };

  SEC.mv = st => {
    const link = PV.APP_URL ? PV.APP_URL + '#multiview' : '';
    return `<div class="note">Plug in an external monitor, open the multiview link in a new browser window, drag that window onto the monitor and press <b>Full screen</b>. Click <b>Edit layout</b> there to move and resize boxes on a grid. In the Mac app, Pivot puts it on the monitor for you.</div>
      ${linkRow('Multiview', link, 'multiview')}
      <div class="sec"><div class="sech">Ready-made layouts</div><div class="grid2">${Object.entries(PV.MV_PRESETS).map(([k, p]) => `<div class="layer"><span class="nm"><b>${esc(p.name)}</b><br><span class="hint">${esc(p.desc)}</span></span><button class="btn sm" data-s="mvPreset|${k}">Use</button></div>`).join('')}</div>
      <div class="hint">Layouts you build are saved with your profile, so they follow you to any Mac you sign in on. Templates can carry a standard layout for every crew.</div></div>`;
  };

  function linkRow(name, link, role) {
    return `<div class="linkrow"><b>${esc(name)}</b>${link ? `<code>${esc(link)}</code><button class="btn sm" data-s="copy" data-copy="${esc(link)}">Copy link</button>` : `<span class="hint">Open this page's link with <b>#${role}</b> added to the end.</span><span></span>`}</div>`;
  }

  SEC.screens = st => {
    const roles = [['director', 'Director'], ['graphics', 'Graphics'], ['replay', 'Replay'], ['audio', 'Audio'], ['producer', 'Producer'], ['scorebug', 'Scorebug'], ['multiview', 'Multiview']];
    const scr = ui.screens ? Object.entries(ui.screens).filter(([, s]) => Date.now() - s.at < 15000) : [];
    return `<div class="note">Crew members open these on an iPad or phone signed in to your account. They type the PIN once. Screens on this Mac connect on their own. In the Mac app this runs over the dedicated local network.</div>
      <div class="row" style="gap:16px"><div><div class="lbl">PIN for this show</div><div class="pin tc">${esc(st.pin)}</div></div><button class="btn" data-s="pin">New PIN</button></div>
      <div class="sec">${roles.map(([id, n]) => `<div style="${focusScreen === id ? 'box-shadow:0 0 0 2px var(--brand);border-radius:8px' : ''}">${linkRow(n, PV.APP_URL ? PV.APP_URL + '#' + id : '', id)}</div>`).join('')}</div>
      <div class="sec"><div class="sech">Connected now</div>${scr.length ? `<table class="tbl"><tbody>${scr.map(([, s]) => `<tr><td><b>${esc(s.role[0].toUpperCase() + s.role.slice(1))}</b></td><td class="hint">${s.via === 'local' ? 'This Mac' : 'Over the network'}</td><td><span class="status">Connected</span></td></tr>`).join('')}</tbody></table>` : '<div class="hint">No control screens connected.</div>'}</div>
      <div class="sec"><div class="sech">Try one here</div><div class="row">${roles.map(([id, n]) => `<button class="btn sm" data-s="tryRemote|${id}">${n}</button>`).join('')}</div><div class="hint">Turns this window into that screen. Use <b>Back to main</b> at the top to return.</div></div>`;
  };

  SEC.profile = st => {
    const days = Math.max(0, Math.ceil((st.profile.trialEnds - Date.now()) / 864e5));
    return `<div class="fld"><label>Name</label><input type="text" value="${esc(st.profile.name)}" data-sc="profile"></div>
      <div class="note"><b>Your profile follows you.</b> Shortcuts, macros, multiview layouts and preferences are saved to your account, so you can sign in on any Mac and everything is where you left it. In this sample they're saved in this browser.</div>
      <div class="card" style="background:var(--raise)"><div class="cardh">Subscription</div><dl class="kv"><dt>Plan</dt><dd>Free trial</dd><dt>Trial ends</dt><dd>${days} day${days === 1 ? '' : 's'} left</dd><dt>After the trial</dt><dd>Annual subscription</dd><dt>Includes</dt><dd>Updates, synced profiles and templates, support</dd></dl></div>`;
  };

  SEC.about = () => `<div class="note"><b>This is a working sample of Pivot.</b> Everything you click works, but the outside world is simulated:</div>
    <table class="tbl"><tbody>
    <tr><td><b>Cameras</b></td><td>Four simulated angles of a live game. In the Mac app: Blackmagic USB-C capture devices, a breakout chassis or NDI.</td></tr>
    <tr><td><b>Scoreboard box</b></td><td>Simulated over “USB”. Score, clock, fouls and possession come from the game.</td></tr>
    <tr><td><b>Schedule and teams</b></td><td>Real NEC Front Row data: schedule, rosters, coaches, 2025-26 stats and standings, from a snapshot taken October 23.</td></tr>
    <tr><td><b>Live stats</b></td><td>Built from the simulated plays.</td></tr>
    <tr><td><b>Logos</b></td><td>Team-color badges for now. The Mac app loads the real logos from NEC Front Row.</td></tr>
    <tr><td><b>Audio</b></td><td>Meters move with simulated voices and crowd sound. No sound plays.</td></tr>
    <tr><td><b>Recording and streaming</b></td><td>Timers, sizes and status work. Nothing is written or sent.</td></tr>
    <tr><td><b>Control screens</b></td><td>Real. Open them in other windows or on an iPad signed in to your account.</td></tr>
    <tr><td><b>Saved settings</b></td><td>Kept in this browser on this computer.</td></tr></tbody></table>`;
})();
