/* Draws the program graphics for the stream and recordings.
   The app keeps this page out of sight and takes a picture of it every frame. */
(function () {
  const G = window.PIVOT_GFX;
  // drawn by Chrome's engine (Pivot Graphics): messages go out through the console, the engine runs the animations
  const engineDrawn = window.PivotGfxEngine === 'chrome' || /[?&]engine=chrome/.test(location.search);
  const H = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.gfx;
  const post = engineDrawn
    ? m => { try { console.log('\u0001' + JSON.stringify(m)); } catch (e) { /* closing */ } }
    : m => { try { H && H.postMessage(m); } catch (e) { /* closing */ } };
  const stage = G.createStage(document.getElementById('stage'));
  let show = null, st = null, active = null, fresh = true;

  window.PivotGfx = {
    show(s) { show = s; fresh = true; },
    state(s) { st = s; fresh = true; },
    marks(m) { window.PIVOT_MARKS = m || {}; }
  };

  /* every CSS animation is stepped from here, so each picture shows exactly where it is */
  const t0 = performance.now();
  function stepAnimations(now) {
    for (const a of document.getAnimations()) {
      if (a.__pv == null) { a.__pv = now - (a.currentTime || 0); a.pause(); }
      a.currentTime = now - a.__pv;
    }
  }

  /* the app takes a picture only when something on the page changed or is moving: a scorebug sitting still
     (or a clock ticking once a second) costs next to nothing, which matters most on older Macs */
  let dirty = true;
  const watch = new MutationObserver(() => { dirty = true; });
  watch.observe(document.body, { subtree: true, attributes: true, childList: true, characterData: true });
  const moving = () => document.getAnimations().some(a => {
    const end = a.effect && a.effect.getComputedTiming().endTime;
    return end === Infinity || (a.currentTime || 0) < (end || 0) + 50;
  });

  const isOn = () => !!document.querySelector('.gfx-stage .lay:not(.hide)') || (document.querySelector('.g-sting') || {}).style && document.querySelector('.g-sting').style.display !== 'none';

  /* Drawn ahead (Pivot GFX): the app asks for each picture by the moment it's meant for, a little ahead of time,
     and keeps a few ready, so a slow moment on the Mac never shows. Everything on the page moves by that moment,
     not by the clock on the wall. Answers "on,changed": whether anything is on screen, and whether it looks
     different from the picture before. */
  const ahead = window.PivotGfxAhead === true;
  let lastOn = null, lastStep = null;
  window.PivotGfx.at = function (ms) {
    // a look made at a set number of pictures a second (NEC's are 30) only changes that often: between its
    // pictures, nothing is drawn, the one before goes out again, unless the operator just changed something
    const P = window.PIVOT_GFX, fps = st && st.gfx && P ? (P.pkgOf(st.gfx.pkg).fps || 0) : 0;
    if (fps > 0) {
      const step = 1000 / fps, at = Math.floor(ms / step + 1e-6) * step;
      if (at === lastStep && !fresh && lastOn !== null) return (lastOn ? '1' : '0') + ',0';
      lastStep = at; ms = at;
    }
    fresh = false;
    if (show && st) {
      try { stage.update(Object.assign({}, st, { show }), ms); } catch (e) { post({ type: 'log', msg: 'graphics: ' + e.message }); }
    }
    stepAnimations(ms);
    const on = isOn();
    if (watch.takeRecords().length) dirty = true;
    const changed = on !== lastOn || (on && (dirty || moving()));
    dirty = false; lastOn = on;
    return (on ? '1' : '0') + ',' + (changed ? '1' : '0');
  };

  function frame() {
    requestAnimationFrame(frame);
    if (ahead) return;
    const now = performance.now();
    if (show && st) {
      const full = Object.assign({}, st, { show });
      try { stage.update(full, Date.now()); } catch (e) { post({ type: 'log', msg: 'graphics: ' + e.message }); }
    }
    // in Chrome's engine, animations run on the graphics chip in step with each frame Pivot asks for; holding them
    // and moving them by hand is only needed when the app takes pictures of the page
    if (!engineDrawn) stepAnimations(now);
    // only worth photographing while something is on screen
    const on = isOn();
    if (on !== active) { active = on; post({ type: 'active', on }); dirty = true; }
    if (active && (dirty || moving())) { dirty = false; post({ type: 'changed' }); }
  }
  requestAnimationFrame(frame);
  void t0;
  post({ type: 'ready' });
})();
