/* Pivot: multiview monitor, control screens (iPad, phone), launcher and start-up. */
(function () {
  const PV = window.PV, UI = PV.UI, S = window.PIVOT_SIM, G = window.PIVOT_GFX, D = window.PIVOT_DATA;
  const esc = UI.esc, $ = UI.$, $$ = UI.$$;
  const ROLES = { director: 'Director', graphics: 'Graphics', replay: 'Replay', audio: 'Audio', producer: 'Producer', scorebug: 'Scorebug' };

  /* ---------- multiview presets (12 x 12 grid) ---------- */
  PV.MV_PRESETS = {
    standard: { name: 'Standard', desc: 'Program and preview on top, every input below', tiles: [
      { src: 'preview', x: 0, y: 0, w: 6, h: 6 }, { src: 'program', x: 6, y: 0, w: 6, h: 6 },
      { src: 'cam1', x: 0, y: 6, w: 3, h: 3 }, { src: 'cam2', x: 3, y: 6, w: 3, h: 3 }, { src: 'cam3', x: 6, y: 6, w: 3, h: 3 }, { src: 'cam4', x: 9, y: 6, w: 3, h: 3 },
      { src: 'replay', x: 0, y: 9, w: 3, h: 3 }, { src: 'video', x: 3, y: 9, w: 3, h: 3 }, { src: 'gfx', x: 6, y: 9, w: 3, h: 3 }, { src: 'clock', x: 9, y: 9, w: 3, h: 3 }] },
    replay: { name: 'Replay operator', desc: 'Replay out next to program, all angles, meters', tiles: [
      { src: 'program', x: 0, y: 0, w: 6, h: 6 }, { src: 'replay', x: 6, y: 0, w: 6, h: 6 },
      { src: 'cam1', x: 0, y: 6, w: 3, h: 3 }, { src: 'cam2', x: 3, y: 6, w: 3, h: 3 }, { src: 'cam3', x: 6, y: 6, w: 3, h: 3 }, { src: 'cam4', x: 9, y: 6, w: 3, h: 3 },
      { src: 'audio', x: 0, y: 9, w: 6, h: 3 }, { src: 'clock', x: 6, y: 9, w: 6, h: 3 }] },
    producer: { name: 'Producer', desc: 'Big program, clock, status and graphics check', tiles: [
      { src: 'program', x: 0, y: 0, w: 8, h: 8 }, { src: 'clock', x: 8, y: 0, w: 4, h: 4 }, { src: 'status', x: 8, y: 4, w: 4, h: 4 },
      { src: 'clean', x: 0, y: 8, w: 4, h: 4 }, { src: 'gfx', x: 4, y: 8, w: 4, h: 4 }, { src: 'audio', x: 8, y: 8, w: 4, h: 4 }] }
  };
  const MV_SOURCES = [['program', 'Program'], ['preview', 'Preview'], ['clean', 'Clean feed'], ['cam1', 'Camera 1'], ['cam2', 'Camera 2'], ['cam3', 'Camera 3'], ['cam4', 'Camera 4'], ['cam5', 'Camera 5'], ['cam6', 'Camera 6'], ['cam7', 'Camera 7'], ['cam8', 'Camera 8'], ['replay', 'Replay'], ['video', 'Video'], ['gfx', 'Graphics only'], ['audio', 'Audio meters'], ['clock', 'Clock and score'], ['status', 'Show status']];

  /* ======================================================================
     Followers: windows and screens that show the show and send it actions
     ====================================================================== */
  const F = { st: null, c: null, at: 0, eng: null, ok: false, via: null, pin: '', sent: new Set() };
  function follow() {
    try { F.pin = sessionStorage.getItem('pivot.pin') || ''; } catch (e) { F.pin = ''; }
    PV.link.on((msg, via) => {
      if (msg.k === 'state') {
        // stay with the main window we found first, unless it has gone quiet
        const eng = msg.s ? msg.s.eng : msg.eng;
        const stale = Date.now() - F.at > 4000;
        if (F.eng && eng !== F.eng && !stale) return;
        if (F.eng && eng !== F.eng) { F.ok = false; F.okLocal = false; }
        if (msg.s) { F.st = msg.s; F.c = PV.compact(msg.s); F.at = Date.now(); F.eng = eng; F.via = via === 'room' ? 'room' : 'local'; }
        else if (eng && (F.via !== 'local' || stale)) {
          F.c = msg; F.at = Date.now(); F.eng = eng; F.via = 'room';
          // the full picture comes once a second over the network; keep what's on air current in between
          if (F.st && F.st.eng === eng) { F.st.program = msg.program; F.st.preview = msg.preview; }
        }
        F.dirty = true;
      } else if (msg.k === 'show' && (!F.eng || msg.eng === F.eng)) {
        F.ros = msg; F.dirty = true;
      } else if (msg.k === 'welcome' && msg.to === PV.link.me) {
        if (via === 'local' && msg.ok) F.okLocal = true;
        if (via === 'room' && F.okLocal) return;
        F.ok = !!msg.ok; F.welcomed = true; F.dirty = true;
        F.needPin = !msg.ok && via === 'room';
      }
    });
  }
  function hello(role) {
    const m = { k: 'hello', role, pin: F.pin };
    PV.link.local(m); PV.link.remote('pivot.hello', m);
  }
  function send(...a) {
    if (!F.eng) { UI.toast('Not connected to Pivot yet'); return; }
    const m = { k: 'act', eng: F.eng, a, pin: F.pin, mid: PV.uid() };
    if (F.via === 'local') PV.link.local(m); else PV.link.remote('pivot.act', m);
  }
  PV.followSend = send;

  /* ======================================================================
     MULTIVIEW
     ====================================================================== */
  function startMultiview() {
    follow();
    const app = $('#app');
    let tiles = PV.store.get('mvLayout', null) || PV.MV_PRESETS.standard.tiles;
    tiles = tiles.map(t => Object.assign({}, t));
    let edit = false;
    app.innerHTML = `<div class="mvbar" id="mvbar"><div class="brand" style="font-size:16px"><span class="mark" style="width:16px;height:16px"></span>PIVOT</div><b style="font:700 14px var(--cond);letter-spacing:.14em;color:var(--mute)">MULTIVIEW</b><span class="sp"></span>
      <span class="conn" id="mvConn">Waiting for the main window</span>
      <select class="inp" id="mvPreset" style="height:30px"><option value="">Layouts…</option>${Object.entries(PV.MV_PRESETS).map(([k, p]) => `<option value="${k}">${esc(p.name)}</option>`).join('')}</select>
      <span id="mvEditTools" class="row hide"><select class="inp" id="mvAddSrc" style="height:30px">${MV_SOURCES.map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select><button class="btn sm" id="mvAdd">Add box</button></span>
      <button class="btn sm" id="mvEdit">Edit layout</button><button class="btn sm" id="mvFull">Full screen</button><button class="btn sm ghost" id="mvBack">${PV.netScreen ? 'Screens' : 'Back to main'}</button></div>
      <div class="mv" id="mv"><div class="mvgrid" id="mvgrid"></div></div>`;
    const mv = $('#mv');
    const stages = new Map();
    function build() {
      $$('.mvt', mv).forEach(t => { const s = stages.get(t); if (s) s.destroy(); t.remove(); });
      stages.clear();
      tiles.forEach((t, i) => {
        const el = document.createElement('div'); el.className = 'mvt'; el.dataset.i = i;
        const info = ['audio', 'clock', 'status'].includes(t.src);
        el.innerHTML = (info ? '<div class="info"></div>' : '<canvas></canvas>') + `<div class="tl"><span>${esc((MV_SOURCES.find(s => s[0] === t.src) || [0, t.src])[1].toUpperCase())}</span><span class="nm"></span></div><button class="x" title="Remove">×</button><span class="rz"></span>`;
        if (t.src === 'program' || t.src === 'gfx') stages.set(el, G.createStage(el));
        mv.appendChild(el);
      });
      place();
    }
    function place() {
      $$('.mvt', mv).forEach(el => { const t = tiles[+el.dataset.i]; el.style.left = (t.x / 12 * 100) + '%'; el.style.top = (t.y / 12 * 100) + '%'; el.style.width = (t.w / 12 * 100) + '%'; el.style.height = (t.h / 12 * 100) + '%'; });
      $('#mvgrid').style.backgroundSize = `${100 / 12}% ${100 / 12}%`;
    }
    function save() { PV.store.set('mvLayout', tiles); }
    build();
    $('#mvEdit').onclick = () => { edit = !edit; mv.classList.toggle('edit', edit); $('#mvEdit').textContent = edit ? 'Done' : 'Edit layout'; $('#mvEditTools').classList.toggle('hide', !edit); if (!edit) { save(); UI.toast('Layout saved to your profile'); } };
    $('#mvAdd').onclick = () => { tiles.push({ src: $('#mvAddSrc').value, x: 0, y: 0, w: 3, h: 3 }); build(); save(); };
    $('#mvPreset').onchange = e => { const p = PV.MV_PRESETS[e.target.value]; if (!p) return; tiles = p.tiles.map(t => Object.assign({}, t)); build(); save(); e.target.value = ''; };
    $('#mvFull').onclick = () => { const r = document.documentElement.requestFullscreen; if (r) document.documentElement.requestFullscreen().catch(() => UI.toast('Full screen isn’t available here. Use the browser’s own full-screen.')); else UI.toast('Use the browser’s own full-screen.'); };
    $('#mvBack').onclick = () => PV.go(PV.netScreen ? 'screens' : 'main');
    let drag = null;
    mv.addEventListener('click', e => { const x = e.target.closest('.x'); if (!x || !edit) return; const i = +x.parentElement.dataset.i; tiles.splice(i, 1); build(); save(); });
    mv.addEventListener('pointerdown', e => {
      if (!edit) return; const el = e.target.closest('.mvt'); if (!el || e.target.closest('.x')) return;
      const i = +el.dataset.i; const r = mv.getBoundingClientRect();
      drag = { i, mode: e.target.closest('.rz') ? 'size' : 'move', sx: e.clientX, sy: e.clientY, t: Object.assign({}, tiles[i]), cw: r.width / 12, ch: r.height / 12 };
      el.setPointerCapture(e.pointerId); e.preventDefault();
    });
    mv.addEventListener('pointermove', e => {
      if (!drag) return;
      const dx = Math.round((e.clientX - drag.sx) / drag.cw), dy = Math.round((e.clientY - drag.sy) / drag.ch);
      const t = tiles[drag.i], o = drag.t;
      if (drag.mode === 'move') { t.x = Math.max(0, Math.min(12 - o.w, o.x + dx)); t.y = Math.max(0, Math.min(12 - o.h, o.y + dy)); }
      else { t.w = Math.max(1, Math.min(12 - o.x, o.w + dx)); t.h = Math.max(1, Math.min(12 - o.y, o.h + dy)); }
      place();
    });
    mv.addEventListener('pointerup', () => { if (drag) { drag = null; save(); } });
    // keep the layout if another window changes it
    window.addEventListener('storage', e => { if (e.key === 'pivot.mvLayout' && !edit) { tiles = PV.store.get('mvLayout', tiles); build(); } });
    let frameN = 0;
    function frame() {
      requestAnimationFrame(frame);
      frameN++;
      const st = F.st, t = Date.now();
      const conn = $('#mvConn');
      const fresh = st && t - F.at < 3500;
      if (frameN % 15 === 0) { conn.textContent = fresh ? 'Live' : 'Waiting for the main Pivot window on this Mac'; conn.className = 'conn ' + (fresh ? 'ok' : 'bad'); }
      if (!st) return;
      $$('.mvt', mv).forEach((el, k) => {
        const tdef = tiles[+el.dataset.i]; if (!tdef) return;
        const src = tdef.src;
        const isPgm = src === 'program' || src === st.program;
        el.classList.toggle('pgm', isPgm && src !== 'preview');
        el.classList.toggle('pvw', !isPgm && (src === 'preview' || src === st.preview));
        const nm = el.querySelector('.nm');
        if (frameN % 20 === 0) nm.textContent = src === 'program' ? PV.srcName(st, st.program) : src === 'preview' ? PV.srcName(st, st.preview) : /^cam/.test(src) ? st.inputs[src].name : '';
        if (src === 'audio' || src === 'clock' || src === 'status') { if (frameN % 6 === 0) infoTile(el.querySelector('.info'), src, st, t); return; }
        const big = tdef.w * tdef.h >= 25;
        if (!big && (frameN + k) % 2) return;
        const c = el.querySelector('canvas'); const [w, h] = UI.fit(c, big ? 1280 : 640); const ctx = c.getContext('2d');
        if (src === 'program' || src === 'clean') UI.drawProgram(ctx, w, h, st, t);
        else if (src === 'preview') UI.drawSource(ctx, w, h, st.preview, st, t);
        else if (src === 'gfx') checker(ctx, w, h);
        else UI.drawSource(ctx, w, h, src, st, t);
        const stg = stages.get(el); if (stg) stg.update(st, t);
      });
    }
    requestAnimationFrame(frame);
  }
  function checker(ctx, w, h) {
    const s = Math.max(8, Math.round(w / 40));
    ctx.fillStyle = '#2a2f37'; ctx.fillRect(0, 0, w, h); ctx.fillStyle = '#3a414c';
    for (let y = 0; y < h; y += s) for (let x = (y / s) % 2 ? s : 0; x < w; x += s * 2) ctx.fillRect(x, y, s, s);
  }
  function infoTile(el, src, st, t) {
    let html = '';
    if (src === 'clock') {
      const sb = st.sb; const ck = ['half', 'final', 'break'].includes(sb.status) ? G.periodText(sb, st.show.rules) : G.clockText(G.sbClockMs(sb, t));
      html = `<div class="hint" style="font:700 14px var(--cond);letter-spacing:.16em">${G.periodText(sb, st.show.rules)}</div><div class="big tc" style="color:${sb.running ? '#fff' : 'var(--warn)'}">${ck}</div><div style="font:700 clamp(14px,2.4vw,30px) var(--cond);letter-spacing:.06em">${esc(st.show.away.code)} ${sb.score.away} · ${sb.score.home} ${esc(st.show.home.code)}</div><div class="hint tc">${new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</div>`;
    } else if (src === 'status') {
      const pa = st.pl.active; const list = pa && st.pl.lists.find(l => l.id === pa.list);
      html = `<dl class="kv" style="width:min(100%,360px);font-size:clamp(11px,1.2vw,15px)"><dt>Recording</dt><dd style="color:${st.rec.on ? 'var(--pgm)' : 'inherit'}">${st.rec.on ? UI.hms(t - st.rec.start) : 'Off'}</dd><dt>Stream</dt><dd style="color:${st.stream.on ? 'var(--pvw)' : 'inherit'}">${st.stream.on ? UI.hms(t - st.stream.start) : 'Off'}</dd><dt>Break</dt><dd>${st.brk ? 'ON' : 'Off'}</dd><dt>Playlist</dt><dd>${list ? esc(list.name) + ' · ' + esc(list.items[pa.idx] ? list.items[pa.idx].name : '') : '—'}</dd><dt>Replay</dt><dd>${st.rp.playing ? 'Rolling' : st.rp.clips.length + ' saved'}</dd><dt>Graphics</dt><dd>${[st.gfx.scorebug && 'Scorebug', st.gfx.lower && st.gfx.lower.label, st.gfx.full && st.gfx.full.label].filter(Boolean).map(esc).join(', ') || 'None'}</dd></dl>`;
    } else {
      const L = UI.levels(st, t);
      const bars = [['V1', L.ch[0]], ['V2', L.ch[1]], ['N1', L.ch[2]], ['N2', L.ch[3]], ['L', L.L], ['R', L.R]];
      html = `<div style="display:flex;gap:10px;align-items:flex-end;height:70%;width:90%">${bars.map(([n, v]) => `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%"><div class="meter" style="width:100%;flex:1"><i style="height:${Math.round(v * 100)}%;background-size:100% 100%"></i></div><span class="hint">${n}</span></div>`).join('')}</div>`;
    }
    el.innerHTML = html;
  }

  /* ======================================================================
     CONTROL SCREENS (iPad, phone, or another window)
     ====================================================================== */
  function startRemote(role) {
    follow();
    const app = $('#app');
    app.innerHTML = `<header class="top"><div class="brand"><span class="mark"></span>PIVOT${PV.GFX_ONLY ? '<em>GFX</em>' : ''}</div><b style="font:700 15px var(--cond);letter-spacing:.14em;color:var(--mute)">${ROLES[role].toUpperCase()}</b><span class="sp"></span><span class="conn" id="rConn">Connecting…</span><button class="btn sm" id="rSwitch">Screens</button></header><div class="rem" id="rem"></div>`;
    $('#rSwitch').onclick = () => { PV.go('screens'); };
    const rem = $('#rem');
    let last = '', side = 'home', pinEntry = '';
    const R = { tab: 'favs', kind: 'bio' };
    hello(role);
    PV.netHello = () => hello(role);
    setInterval(() => { hello(role); }, 5000);
    function render() {
      const c = F.c, t = Date.now();
      const fresh = c && t - F.at < 6000;
      const conn = $('#rConn');
      conn.textContent = fresh ? (F.via === 'local' ? 'Connected · this Mac' : 'Connected') : 'Looking for Pivot…';
      conn.className = 'conn ' + (fresh ? 'ok' : 'bad');
      let html;
      if (F.needPin && !F.ok) html = pinPad(pinEntry);
      else if (!c) html = `<div class="launch"><div class="empty" style="max-width:520px">${PV.netScreen ? 'Looking for Pivot on the production Mac. Keep it open, and keep this device on the same network.' : 'Looking for the main Pivot window. Keep it open on the production Mac. This screen needs to be signed in to the same account.<br><br><a class="btn" href="#" data-r="home">Back to main screen</a>'}</div></div>`;
      else html = ({ director: rDirector, graphics: rGraphics, replay: rReplay, audio: rAudio, producer: rProducer, scorebug: rScorebug })[role](c, t, side, R);
      if (html !== last) {
        const ae = document.activeElement;
        if (!(ae && rem.contains(ae) && ae.matches('input[type=range]') && F.pdown)) { rem.innerHTML = html; last = html; }
      }
      rem.querySelectorAll('[data-live]').forEach(el => liveVal(el, c, t));
    }
    rem.addEventListener('click', e => {
      const b = e.target.closest('[data-r]'); if (!b) return;
      e.preventDefault();
      const [n, ...a] = b.dataset.r.split('|').map(x => x === '' ? undefined : (/^-?\d+(\.\d+)?$/.test(x) && !/^0\d/.test(x) ? +x : x));
      if (n === 'home') { PV.go('main'); return; }
      if (n === 'side') { side = a[0]; render(); return; }
      if (n === 'pin') { if (a[0] === 'del') pinEntry = pinEntry.slice(0, -1); else if (pinEntry.length < 4) pinEntry += a[0]; if (pinEntry.length === 4) { F.pin = pinEntry; try { sessionStorage.setItem('pivot.pin', F.pin); } catch (er) { /* ok */ } F.needPin = false; pinEntry = ''; hello(role); } render(); return; }
      if (n === 'tab') { R.tab = a[0]; render(); return; }
      if (n === 'kind') { R.kind = a[0]; render(); return; }
      if (n === 'pg') { send('pv.gfx', { t: 'cat', ref: a[0] }); return; }
      if (n === 'pt') { send('pv.gfx', { t: 'tog', k: a[0] }); return; }
      if (n === 'pl3') { send('pv.gfx', { t: 'l3', spec: { kind: a[0], side: a[1], num: String(a[2]) } }); return; }
      if (n === 'score' || n === 'clock') {
        const sb = (F.st || F.c).sb;
        const v = prompt(n === 'score' ? 'Score' : 'Clock (minutes:seconds)', n === 'score' ? String(sb.score[a[0]]) : G.clockText(G.sbClockMs(sb, Date.now())));
        if (v == null || !v.trim()) return;
        if (n === 'score') send('sb.setScore', a[0], v.trim());
        else { const m = /^(\d+)(?::(\d{1,2}))?$/.exec(v.trim()); if (m) send('sb.setClock', (+m[1] * 60 + +(m[2] || 0)) * 1000); else UI.toast('Type the time like 12:00'); }
        return;
      }
      if (n === 'sb.flag') { send('sb.flag', a[0] || ''); return; }
      if (n === 'angle') {
        const c = F.c; let list = c.rp.angles.slice(); list = list.includes(a[0]) ? list.filter(x => x !== a[0]) : list.concat(a[0]); send('rp.angles', list); return;
      }
      send(n, ...a);
      if (navigator.vibrate) try { navigator.vibrate(8); } catch (er) { /* ok */ }
    });
    let ft = 0;
    rem.addEventListener('input', e => {
      const r = e.target.closest('[data-fader]'); if (!r) return;
      const now = Date.now(); if (now - ft < 80) return; ft = now;
      const k = r.dataset.fader; if (k === 'm') send('audio.master', +r.value); else send('audio.fader', +k, +r.value);
    });
    rem.addEventListener('change', e => { const sel = e.target.closest('[data-rch]'); if (sel) send(sel.dataset.rch, sel.value); });
    rem.addEventListener('change', e => { const r = e.target.closest('[data-fader]'); if (!r) return; const k = r.dataset.fader; if (k === 'm') send('audio.master', +r.value); else send('audio.fader', +k, +r.value); });
    document.addEventListener('pointerdown', () => { F.pdown = true; }, true);
    document.addEventListener('pointerup', () => { F.pdown = false; }, true);
    setInterval(render, 120);
    render();
  }

  function pinPad(entry) {
    return `<div class="launch"><h2 style="font:700 26px var(--cond);letter-spacing:.06em;margin:0">Enter the show PIN</h2><p class="hint" style="margin:0;text-align:center;max-width:420px">It's on the production Mac in Settings › Control screens.</p>
      <div class="pindots">${[0, 1, 2, 3].map(i => `<i class="${i < entry.length ? 'on' : ''}"></i>`).join('')}</div>
      <div class="pinpad">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button data-r="pin|${n}">${n}</button>`).join('')}<span></span><button data-r="pin|0">0</button><button data-r="pin|del" aria-label="Delete">⌫</button></div></div>`;
  }
  function tally(c, id) { return c.program === id ? 'pgm' : c.preview === id ? 'pvw' : ''; }
  function nm(c, id) { if (PV.isME && PV.isME(id)) { const m = (c.me || []).find(x => 'me:' + x[0] === id); return m ? m[1] : 'M/E'; } return /^cam/.test(id) ? c.inputs[id] : { replay: 'Replay', video: 'Video', bars: 'Color bars', black: 'Black' }[id]; }
  const SRC = ['cam1', 'cam2', 'cam3', 'cam4', 'replay', 'video', 'black', 'bars'];
  function liveVal(el, c, t) {
    const k = el.dataset.live;
    if (k === 'clock') { const sb = c.sb; el.textContent = ['half', 'final', 'break'].includes(sb.status) ? G.periodText(sb, { periods: c.show.periods }) : G.clockText(G.sbClockMs(sb, t)); }
    else if (k === 'rec') el.textContent = c.rec.on ? UI.hms(t - c.rec.start) : 'Off';
    else if (k === 'stream') el.textContent = c.stream.on ? UI.hms(t - c.stream.start) : 'Off';
    else if (k === 'tod') el.textContent = new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    else if (/^m/.test(k)) {
      const L = UI.levels(pseudo(c), t); const i = k.slice(1);
      const v = i === 'L' ? L.L : i === 'R' ? L.R : L.ch[+i];
      el.firstElementChild.style.height = Math.round(v * 100) + '%';
    }
  }
  function pseudo(c) { return { epoch: c.epoch, show: { sport: c.show.sport, home: { key: c.show.home }, away: { key: c.show.away }, colors: c.show.col }, program: c.program, rp: { playing: null, clips: [] }, audio: { mode: c.audio.mode, master: c.audio.master, ch: c.audio.ch.map(x => ({ name: x[0], fader: x[1], mute: !!x[2] })) } }; }

  function rDirector(c) {
    const SRC = Object.keys(c.inputs).concat((c.me || []).map(m => 'me:' + m[0]), ['replay', 'video', 'black', 'bars']);
    return `<div class="rh">Program</div><div class="rgrid">${SRC.map(id => `<button class="rbtn ${c.program === id ? 'pgm' : ''}" data-r="cut|${id}">${PV.srcShort(id)}<small>${esc(nm(c, id))}</small></button>`).join('')}</div>
      <div class="rh">Preview</div><div class="rgrid">${SRC.map(id => `<button class="rbtn ${c.preview === id && c.program !== id ? 'pvw' : ''}" data-r="preview|${id}">${PV.srcShort(id)}<small>${esc(nm(c, id))}</small></button>`).join('')}</div>
      <div class="rgrid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr))"><button class="rbtn big brand" data-r="cut">TAKE<small>${c.trans.sel === 'fade' ? 'Fade' : c.trans.sel && c.trans.sel !== 'cut' ? 'Wipe' : 'Cut'}</small></button><button class="rbtn big" data-r="auto">FADE</button><button class="rbtn big" data-r="sting">WIPE</button><button class="rbtn big ${c.brk ? 'brand' : ''}" data-r="brk.toggle">BREAK<small>${c.brk ? 'On' : 'Off'}</small></button></div>
      <div class="rgrid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr))"><button class="rbtn" data-r="rp.mark">MARK REPLAY</button><button class="rbtn" data-r="rp.roll">ROLL REPLAY</button><button class="rbtn ${c.gfx.scorebug ? 'live' : ''}" data-r="gfx.toggle|scorebug">SCOREBUG</button><button class="rbtn" data-r="gfx.clear|all">CLEAR GFX</button></div>`;
  }
  function rosterOf(side) {
    if (F.st) { const t = F.st.show[side]; return { list: t.roster.map(r => [r[0], r[2]]), starters: t.starters }; }
    if (F.ros) return { list: F.ros[side] || [], starters: (side === 'home' ? F.ros.hs : F.ros.as) || [] };
    return { list: [], starters: [] };
  }
  /* ---------- Graphics: everything the desk has, in the same order, and it all goes to Preview ---------- */
  const liveOf = (st, it) => it.t === 'cat' ? PV.Engine.prototype.gfxLive.call({ st }, it.ref) : PV.itemLive(st, it);
  const tl = (st, it) => liveOf(st, it) ? ' live' : PV.itemInPv(st, it) ? ' pvw' : '';
  const ITEM = it => it.t === 'cat' ? `pg|${it.ref}` : it.t === 'tog' ? `pt|${it.k}` : `pl3|${it.spec.kind}|${it.spec.side}|${it.spec.num}`;
  function rGraphics(c, t, side, R) {
    const st = F.st;
    if (!st) return '<div class="empty">Getting the show from Pivot…</div>';
    const sh = st.show, tab = R.tab || 'favs', kind = R.kind || 'bio';
    const pvNames = (st.pv.gfx || []).map(it => it.t === 'cat' ? PV.gfxName(it.ref, st) : it.t === 'tog' ? { scorebug: 'Scorebug', ticker: 'Ticker', big: 'Big score' }[it.k] : `#${it.spec.num} ${it.spec.kind}`);
    const btn = (it, label, sub) => `<button class="rbtn${tl(st, it)}" data-r="${esc(ITEM(it))}">${esc(label)}${sub ? `<small>${esc(sub)}</small>` : ''}</button>`;
    const tabs = [['favs', 'Favs'], ['gfx', 'Graphics'], ['away', `${sh.away.code} GFX`], ['home', `${sh.home.code} GFX`], ['canned', 'Canned']];
    let body = '';
    if (tab === 'favs') body = `<div class="rgrid">${btn({ t: 'tog', k: 'scorebug' }, 'SCOREBUG')}${PV.lookLacks('ticker', st) ? '' : btn({ t: 'tog', k: 'ticker' }, 'TICKER')}${btn({ t: 'tog', k: 'big' }, 'BIG SCORE')}</div>`;
    else if (tab === 'gfx') {
      body = PV.segs(sh.sport).map(([id, name]) => { const list = PV.segGfx(st, id); return list.length ? `<div class="rh">${esc(name)}</div><div class="rgrid">${list.map(r => btn({ t: 'cat', ref: r }, PV.gfxName(r, st))).join('')}</div>` : ''; }).join('');
    } else if (tab === 'canned') body = `<div class="rgrid">${(UI.CANNED || []).filter(r => PV.GFX.some(g => g[0] === r) && !PV.lookLacks(r, st)).map(r => btn({ t: 'cat', ref: r }, PV.gfxName(r, st))).join('')}</div>`;
    else {
      const sd = tab, tm = sh[sd];
      const kinds = [['bio', 'Bios'], ['game', 'Game stats'], ['text', 'Text'], ['season', 'Season stats']];
      const subOf = p => kind === 'bio' ? p[2] : kind === 'text' ? (PV.l3words(st, sd, p[0], 'text') || {}).sub || p[2] : p[2];
      body = `<div class="rgrid">${btn({ t: 'cat', ref: sd === 'away' ? 'coachAway' : 'coachHome' }, PV.gfxName(sd === 'away' ? 'coachAway' : 'coachHome', st), tm.coach || '')}</div>
        <div class="seg rseg">${kinds.map(([k, n]) => `<button class="${kind === k ? 'on' : ''}" data-r="kind|${k}">${n}</button>`).join('')}</div>
        ${tm.roster.length ? `<div class="rgrid nums">${tm.roster.map(p => `<button class="rbtn num${tl(st, { t: 'l3', spec: { kind, side: sd, num: p[0] } })}" data-r="pl3|${kind}|${sd}|${esc(p[0])}"><b>${esc(p[0])}</b><small>${esc(subOf(p))}</small></button>`).join('')}</div>` : `<div class="empty">No roster for ${esc(tm.name)} yet.</div>`}`;
    }
    return `<div class="rbar"><div class="rbarl"><span><b>Preview:</b> ${pvNames.length ? esc(pvNames.join(' · ')) : 'no graphics'}</span><span class="sp"></span>${pvNames.length ? '<button class="btn" data-r="pv.gfxClear">Clear Preview</button>' : ''}</div>
      <div class="seg rtabs">${tabs.map(([k, n]) => `<button class="${tab === k ? 'on' : ''}" data-r="tab|${k}">${esc(n)}</button>`).join('')}</div></div>
      <div class="note">Tap a graphic to put it in <b>Preview</b>; tap again to take it out. The producer at Pivot takes it to air.</div>${body}`;
  }
  function rReplay(c) {
    const rp = c.rp;
    return `<button class="rbtn big brand" style="min-height:140px;font-size:34px" data-r="rp.mark">MARK REPLAY<small>Grabs the last ${rp.back} seconds</small></button>
      <div class="rgrid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr))"><button class="rbtn" data-r="rp.back|${Math.max(3, rp.back - 1)}">− 1 s</button><button class="rbtn" data-r="rp.back|${Math.min(30, rp.back + 1)}">+ 1 s</button></div>
      <div class="note">Put a replay in <b>Preview</b>; the producer at Pivot rolls it.</div>
      <div class="rh">Angle order · tap to include or leave out</div><div class="rgrid">${Object.keys(c.inputs).map(a => { const i = rp.angles.indexOf(a); return `<button class="rbtn ${i >= 0 ? 'pvw' : ''}" data-r="angle|${a}">${i >= 0 ? (i + 1) + ' · ' : ''}${PV.srcShort(a)}<small>${esc(c.inputs[a])}</small></button>`; }).join('')}</div>
      <div class="rh">Speed</div><div class="rgrid">${[1, 0.75, 0.5, 0.25].map(s => `<button class="rbtn ${rp.speed === s ? 'pvw' : ''}" data-r="rp.speed|${s}">${s * 100}%</button>`).join('')}</div>
      <div class="rh">Saved replays</div>${rp.clips.length ? rp.clips.map(cl => `<div class="clip" style="grid-template-columns:minmax(0,1fr) auto"><div><b>${esc(cl[1])}</b><div class="meta">${cl[3].map(a => PV.srcShort(a)).join(' → ')} · ${cl[2] * 100}%${cl[4] ? ' · aired' : ''}</div></div><button class="btn pri" data-r="pv.rp|${cl[0]}|${cl[3][0] || ''}" style="height:44px;padding:0 20px">To Preview</button></div>`).join('') : '<div class="empty">No replays yet.</div>'}`;
  }
  function rAudio(c) {
    const strip = (i, n) => `<div class="strip"><span class="cn">${esc(n)}</span><div class="fadewrap" style="height:260px"><span class="meter" data-live="m${i}"><i></i></span><input type="range" class="vfader" style="height:260px;width:40px" min="0" max="1" step="0.01" value="${c.audio.ch[i][1]}" data-fader="${i}"></div><button class="mute ${c.audio.ch[i][2] ? 'on' : ''}" style="height:44px" data-r="audio.mute|${i}">${c.audio.ch[i][2] ? 'MUTED' : 'MUTE'}</button></div>`;
    const strips = c.audio.mode === '4ch' ? [0, 1, 2, 3].map(i => strip(i, c.audio.ch[i][0])).join('') : strip(0, 'Voices') + strip(2, 'Nats');
    return `<div class="mixer" style="justify-content:center">${strips}<div class="strip master"><span class="cn">Stream mix</span><div class="fadewrap" style="height:260px"><span class="meter" data-live="mL"><i></i></span><span class="meter" data-live="mR"><i></i></span><input type="range" class="vfader" style="height:260px;width:40px" min="0" max="1" step="0.01" value="${c.audio.master}" data-fader="m"></div><button class="mute ${c.brk ? 'on' : ''}" style="height:44px" data-r="brk.toggle">${c.brk ? 'IN BREAK' : 'BREAK'}</button></div></div>
      <div class="hint" style="text-align:center">${c.audio.mode === '4ch' ? 'Four channels' : c.audio.mode === 'pairs' ? 'Two mono pairs' : 'Stereo split'} · change the setup on the production Mac.</div>`;
  }
  /* ---------- Producer: the clock and score, and the order of the rundown (taking things to air stays at Pivot) ---------- */
  function rProducer(c) {
    const sb = c.sb, st = F.st;
    const items = st ? st.rd.items : [];
    const cur = st && st.rd.on ? st.rd.idx : -1, cue = st ? st.rd.cue : -1;
    let seg = '';
    const rows = items.map((it, i) => {
      const head = it.seg !== seg ? `<div class="rh rdseg">${esc(seg = it.seg)}</div>` : '';
      const cls = i === cur ? 'now' : i === cue ? 'cue' : it.done ? 'past' : 'next';
      return `${head}<div class="rdrow ${cls}"><div class="rdtx"><b>${esc(it.label)}</b><small>${esc(it.sub || '')}</small></div>${i === cur ? '<span class="rdon">ON</span>' : i === cue ? '<span class="rdnx">NEXT</span>' : `<button class="btn" data-r="rd.cue|${i}">Next</button>`}
        <button class="btn mv" data-r="rd.move|${i}|${i - 1}" ${i ? '' : 'disabled'} aria-label="Move up">▲</button><button class="btn mv" data-r="rd.move|${i}|${i + 1}" ${i < items.length - 1 ? '' : 'disabled'} aria-label="Move down">▼</button></div>`;
    }).join('');
    return `<div class="card" style="align-items:center"><div class="rh">${G.periodText(sb, { periods: c.show.periods })}</div><div class="tc" style="font:700 clamp(44px,12vw,100px)/1 var(--mono);color:${sb.running ? '#fff' : 'var(--warn)'}" data-live="clock"></div>
      <div style="font:700 clamp(24px,6vw,44px) var(--cond);letter-spacing:.06em">${esc(c.show.ac)} ${sb.score.away} · ${sb.score.home} ${esc(c.show.hc)}</div>
      <span class="hint">Time of day <b data-live="tod"></b> · REC <b data-live="rec"></b> · STREAM <b data-live="stream"></b></span></div>
      <div class="rh">Rundown · ▲ ▼ to change the order, Next to cue an item</div>
      ${st ? `<div class="rdlist2">${rows}</div>` : '<div class="empty">Getting the rundown from Pivot…</div>'}`;
  }
  /* ---------- Scorebug: everything the scoreboard box on the desk has ---------- */
  function rScorebug(c, t, side, R) {
    const st = F.st, sb = st ? st.sb : c.sb, sh = st ? st.show : null;
    const mine = sb.op === 'phone' || sb.feed === 'manual';
    const foot = sh && /^FB/.test(sh.sport), rules = sh ? sh.rules : { periods: c.show.periods, timeouts: 4 };
    const dis = mine ? '' : 'disabled';
    // the sport's own score buttons and start word, from its package (the desk's copy, when this screen has it)
    const B = sh && PV.board ? PV.board(sh) : null, steps = B ? B.steps : rules.field ? [1] : [1, 2, 3];
    const team = sd => {
      const code = sd === 'home' ? c.show.hc : c.show.ac;
      return `<div class="sbside" style="--c:${c.show.col[sd]}"><div class="sbname">${esc(code)}${foot && sb.poss === sd ? ' <small>● BALL</small>' : ''}</div>
        <button class="sbpts tc" data-r="score|${sd}" ${dis} aria-label="Type ${esc(code)}'s score">${sb.score[sd]}</button>
        <div class="rgrid ${steps.length < 2 ? 'g2' : 'g4'}">${steps.map(n => `<button class="rbtn" data-r="sb.adjust|${sd}|${n}" ${dis}>+${n}</button>`).join('')}<button class="rbtn" data-r="sb.adjust|${sd}|-1" ${dis}>−1</button></div>
        ${rules.field ? '' : `<div class="pmrow"><span>FOUL <b>${(sb.fouls || {})[sd] || 0}</b>${(sb.bonus || {})[sd] ? ' · BONUS' : ''}</span><button class="btn" data-r="sb.foul|${sd}|-1" ${dis}>−</button><button class="btn" data-r="sb.foul|${sd}|1" ${dis}>+</button></div>`}
        ${rules.timeouts ? `<div class="pmrow"><span>TIMEOUT <b>${(sb.timeouts || {})[sd] ?? '—'}</b></span><button class="btn" data-r="sb.to|${sd}|-1" ${dis}>−</button><button class="btn" data-r="sb.to|${sd}|1" ${dis}>+</button></div>` : ''}
        ${foot ? `<button class="btn" data-r="sb.poss|${sd}" ${dis}>Ball</button>` : ''}</div>`;
    };
    const pname = p => p > rules.periods ? (p - rules.periods === 1 ? 'OT' : (p - rules.periods) + 'OT') : (rules.periods === 2 ? ['1st half', '2nd half'] : ['1st quarter', '2nd quarter', '3rd quarter', '4th quarter'])[p - 1];
    const cur = sb.status === 'half' ? 'half' : sb.status === 'final' ? 'final' : String(sb.period);
    return `${mine ? '<div class="note"><b>You are running the scorebug.</b> Your changes go straight to the scorebug.</div>' : `<div class="note">The scorebug is reading the ${sb.feed === 'stats' ? 'live stats' : 'scoreboard box'}. Take over to run it by hand.</div>`}
      <button class="rbtn big ${mine ? 'live' : 'brand'}" data-r="${mine ? 'sb.release' : 'sb.takeover'}">${mine ? 'HAND IT BACK' : 'TAKE OVER THE SCOREBUG'}</button>
      <div class="sbpair">${team('away')}${team('home')}</div>
      <div class="card" style="align-items:center">
        <select class="inp rsel" data-rch="sb.setPeriod" ${dis} aria-label="Half or quarter">${Array.from({ length: rules.periods + 4 }, (_, i) => i + 1).map(p => `<option value="${p}" ${cur === String(p) ? 'selected' : ''}>${pname(p)}</option>`).join('')}<option value="half" ${cur === 'half' ? 'selected' : ''}>Halftime</option><option value="final" ${cur === 'final' ? 'selected' : ''}>Final</option></select>
        <button class="tc rclock" data-r="clock" ${dis} style="color:${sb.running ? '#fff' : 'var(--warn)'}" data-live="clock" aria-label="Type the time"></button>
        <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="rbtn" style="min-height:56px;min-width:150px" data-r="sb.clock" ${dis}>${sb.status === 'pre' ? (B ? B.start.toUpperCase() : rules.field ? 'KICKOFF' : 'TIP-OFF') : sb.running ? 'STOP CLOCK' : 'START CLOCK'}</button>${['half', 'break'].includes(sb.status) ? `<button class="rbtn" style="min-height:56px" data-r="sb.next" ${dis}>NEXT PERIOD</button>` : ''}</div>
        ${rules.soccer ? '' : `<div class="seg rseg">${[['', 'No banner'], ['TIMEOUT', 'Timeout'], ['OFFICIAL REVIEW', 'Official review']].map(([v, n]) => `<button class="${(sb.flag || '') === v ? 'on' : ''}" data-r="sb.flag|${v}" ${dis}>${n}</button>`).join('')}</div>`}</div>`;
  }

  /* ======================================================================
     LAUNCHER (phones, or the Screens button on a control screen)
     ====================================================================== */
  function startLauncher(narrow) {
    const app = $('#app');
    app.innerHTML = `<header class="top"><div class="brand"><span class="mark"></span>PIVOT${PV.GFX_ONLY ? '<em>GFX</em>' : ''}</div><span class="sp"></span></header>
      <div class="launch"><h1 style="font:700 30px var(--cond);letter-spacing:.06em;margin:0;text-align:center">Pick a screen</h1>
      <p class="hint" style="margin:0;text-align:center;max-width:520px">${narrow === 'net' ? 'Connected to Pivot on the production Mac. Pick what you\'re running.' : narrow ? 'The main Pivot screen is built for a Mac. On this device, run part of the show from one of these.' : 'Run part of the show from this window or device.'}</p>
      <div class="lgrid">${Object.entries(ROLES).map(([id, n]) => `<button class="lc" data-go="${id}"><b>${n}</b><small>${{ director: 'Cameras, transitions, break', graphics: 'Every graphic, into Preview', replay: 'Mark, angles, speed, to Preview', audio: 'Faders, mutes, meters', producer: 'Clock, score, order of the rundown', scorebug: 'Score, clock, fouls, timeouts, period' }[id]}</small></button>`).join('')}
      <button class="lc" data-go="multiview"><b>Multiview</b><small>${narrow === 'net' ? 'Every picture, live' : 'For a monitor on the production Mac'}</small></button>
      ${narrow === 'net' ? '' : `<button class="lc" data-go=""><b>Main screen</b><small>${narrow ? 'Opens anyway. Best on a Mac.' : 'The full Pivot desk'}</small></button>`}</div></div>`;
    app.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (!b) return; PV.go(b.dataset.go || 'main'); });
  }

  /* ======================================================================
     START
     ====================================================================== */
  function boot() {
    let role = (location.hash || '').replace('#', '');
    try {
      if (ROLES[role]) startRemote(role);
      else if (role === 'multiview') startMultiview();
      else if (role === 'screens' || PV.netScreen) startLauncher(PV.netScreen ? 'net' : false);
      else if (role !== 'main' && (window.innerWidth < 600 || (window.matchMedia && matchMedia('(pointer: coarse)').matches && !matchMedia('(pointer: fine)').matches))) startLauncher(true);
      else UI.startPicker();
    } catch (e) {
      $('#app').innerHTML = `<div class="launch"><div class="empty">Pivot couldn't start: ${esc(e && e.message || e)}</div></div>`;
      throw e;
    }
  }
  PV.go = function (h) { h = h || ''; if ((location.hash || '').replace('#', '') === h) location.reload(); else location.hash = h; };
  window.addEventListener('hashchange', () => location.reload());
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
